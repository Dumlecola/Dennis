# Dennis WMS 2.0.76 – säkerhetsuppdatering

## Före installation

Ta en fullständig säkerhetskopia av databas, uppladdade filer och wp-config.php. Krypteringen använder WordPress auth-salt från serverns konfiguration. Bevara samma säkerhetsnycklar vid återställning/flytt. Byte av dessa nycklar utan omkryptering gör privata filer och API-nycklar oläsbara. Gamla pluginversioner kan inte öppna det nya krypterade formatet.

## Skydd som tillkommit

- Nya order- och inleveransbilder sparas direkt som krypterade filer. Ingen offentlig bildkopia skapas i mediabiblioteket. Orderbilder laddas upp direkt från WMS.
- Bilder visas via en kontrollerad adress som kräver WMS-behörighet och en giltig WordPress nonce. Privata bilder döljs för obehöriga i mediefrågor och via WordPress REST API.
- Fraktdokument krypteras och levereras via den behörighetskontrollerade dokumentfunktionen. Filåtkomst begränsas till uppladdningsmappen. Svar skickas med no-store och nosniff.
- API-nycklar använder autentiserad kryptering: AES-256-GCM, eller Sodium secretbox om GCM saknas. Ingen okrypterad reservlagring finns. Om båda saknas stoppas nya privata uppladdningar och nya nycklar; ett adminmeddelande visas.
- API-anrop med autentiseringsuppgifter följer inte omdirigeringar. Tracking använder WordPress säkra HTTP-funktioner.
- Spara leveransflöde och simulera tracking kräver hanteringsrätt och rätt att redigera order. En användare med enbart visningsrätt kan inte göra dessa ändringar.
- Nya bilder valideras som JPG, PNG, WebP eller GIF, högst 12 MB och högst 20 000 pixlar per sida. PDF-dokument får vara högst 10 MB.

## Äldre data

Äldre API-nycklar och WMS-filer migreras när en administratör öppnar adminsidor. Filer hanteras i mindre omgångar. Originalbilder, registrerade storlekar, original före skalning och registrerade redigeringskopior krypteras.

Bilder som också används på en produktsida eller i annat WordPress-innehåll lämnas oförändrade så att offentliga produktbilder inte förstörs. Ett adminmeddelande med bildens ID visas. Dessa undantag är fortfarande offentliga och behöver hanteras separat. Det gäller även redan spridda kopior, externa cachekopior och säkerhetskopior, som pluginet inte kan återkalla. Misslyckade migreringar köas och provas igen; varningarna försvinner när problemet åtgärdats.

## Kontroll och begränsningar

Koden har granskats och lokala tester har verifierat kryptering/dekryptering, ändrad krypterad data, bakåtkompatibel nyckelmigrering, nekad obehörig åtkomst, ogiltiga nonces, REST-skydd, sökvägsbegränsning, delade bilder, migreringsåterförsök samt verkliga multipart-uppladdningar och HTTP-bildsvar i en testmiljö med WordPress-stubbar.

Det är inte ett oberoende penetrationstest av en komplett WordPress-installation. Server, WordPress, WooCommerce, andra plugins, användarkonton och backuphantering ingår också i installationens säkerhet. Ingen garanti om skydd mot alla intrång lämnas.
