<?php
if (!defined('ABSPATH')) exit;
/** Central audit trail. Never stores raw request payloads, SQL or credentials. */
final class Dennis_WMS_Audit {
 const CAP='manage_options';
 static $ready=false,$busy=false,$pending=[],$transaction=false,$before=[],$request='',$stock=[];
 static function boot(){
  add_action('plugins_loaded',function(){self::$ready=get_option('dennis_wms_audit_schema')==='2';},1);
  add_action('admin_init',[__CLASS__,'install'],0);
  add_action('admin_menu',[__CLASS__,'menu'],115);
  add_action('admin_post_dennis_wms_audit_export',[__CLASS__,'export']);
  add_action('admin_notices',[__CLASS__,'notice']);
  foreach(['added_post_meta','updated_post_meta','deleted_post_meta'] as $hook)add_action($hook,[__CLASS__,'meta'],10,4);
  add_action('update_post_meta',[__CLASS__,'before_meta'],10,4);
  add_action('delete_post_meta',[__CLASS__,'before_meta'],10,4);
  add_action('wp_after_insert_post',[__CLASS__,'post'],10,4);
  add_action('before_delete_post',function($id){if(self::relevant_post($id))self::$before['deleted_sku:'.$id]=get_post_meta($id,'_sku',true);});
  add_action('deleted_post',[__CLASS__,'deleted_post'],10,2);
  foreach(['woocommerce_product_before_set_stock','woocommerce_variation_before_set_stock'] as $hook)add_action($hook,[__CLASS__,'before_stock']);
  foreach(['woocommerce_product_set_stock','woocommerce_variation_set_stock'] as $hook)add_action($hook,[__CLASS__,'stock']);
  add_action('woocommerce_order_status_changed',function($id,$old,$new){self::record('Orderstatus','order',$id,['status'=>$old],['status'=>$new],'WooCommerce');},10,3);
  add_action('woocommerce_before_order_object_save',[__CLASS__,'before_order'],10,1);
  foreach(['woocommerce_new_order','woocommerce_update_order'] as $hook)add_action($hook,[__CLASS__,'order'],20,2);
  foreach(['woocommerce_delete_order','woocommerce_trash_order','woocommerce_untrash_order'] as $hook)add_action($hook,function($id)use($hook){self::record($hook,'order',$id,[],[],'WooCommerce');},20,1);

 }
 static function table(){global $wpdb;return $wpdb->prefix.'dennis_wms_activity_log';}
 static function install(){
  global $wpdb;if(get_option('dennis_wms_audit_schema')==='2'){self::$ready=true;return;}
  if(!current_user_can(self::CAP))return;
  require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::table();$c=$wpdb->get_charset_collate();
  // dbDelta compares one definition per line when upgrading existing tables.
  dbDelta("CREATE TABLE $t (
 id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
 created_at datetime NOT NULL,
 created_utc datetime NULL,
 user_id bigint(20) unsigned NOT NULL DEFAULT 0,
 actor varchar(190) NOT NULL DEFAULT '',
 source varchar(30) NOT NULL DEFAULT 'WMS',
 event varchar(190) NOT NULL,
 object_type varchar(190) NOT NULL,
 object_id bigint(20) unsigned NOT NULL DEFAULT 0,
 sku varchar(190) NOT NULL DEFAULT '',
 outcome varchar(20) NOT NULL DEFAULT 'success',
 request_id varchar(64) NOT NULL DEFAULT '',
 before_data longtext NULL,
 after_data longtext NULL,
 PRIMARY KEY  (id),
 KEY created_at (created_at),
 KEY created_utc (created_utc),
 KEY user_id (user_id),
 KEY sku (sku),
 KEY object_ref (object_type,object_id)
) $c;");
  $exists=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))===$t;
  // Explicit, repeatable fallback for installations where dbDelta omitted the new nullable column.
  if($exists&&!$wpdb->get_var("SHOW COLUMNS FROM `$t` LIKE 'created_utc'"))$wpdb->query("ALTER TABLE `$t` ADD COLUMN created_utc datetime NULL");
  if($exists&&$wpdb->get_var("SHOW COLUMNS FROM `$t` LIKE 'created_utc'")){self::$ready=true;update_option('dennis_wms_audit_schema','2',false);self::record('Loggpanel uppdaterad','system',0,[],['version'=>PB_WMS_VERSION]);}

 }
 static function notice(){if(current_user_can(self::CAP)&&(!self::$ready||get_option('dennis_wms_audit_write_failed')))echo '<div class="notice notice-error"><p>Händelseloggen kunde inte startas eller skrivas. Kontrollera databasens behörigheter och diskutrymme.</p></div>';}
 static function clean($value,$key='',$depth=0){
  if(preg_match('/password|passwd|pwd|secret|token|nonce|authorization|cookie|salt|api.?key|consumer.?key|access.?key|(?:dhl|dsv).*key|user_pass/i',(string)$key))return '[skyddad uppgift]';
  if(preg_match('/^(path|file_path|upload_path)$/i',(string)$key))return '[privat sökväg]';
  if($depth>8)return '[begränsat djup]';
  if(is_object($value))$value=get_object_vars($value);
  if(is_array($value)){$out=[];foreach($value as $k=>$v)$out[$k]=self::clean($v,(string)$k,$depth+1);return $out;}
  if(is_string($value)){
   if(function_exists('is_serialized')&&is_serialized($value))return self::clean(maybe_unserialize($value),$key,$depth+1);
   $json=json_decode($value,true);if(is_array($json))return self::clean($json,$key,$depth+1);
   if(preg_match('/(?:password|secret|token|nonce|consumer.?key|access.?key|api.?key|authorization)\s*[:=]/i',$value))return '[innehåll med skyddade uppgifter]';
   return function_exists('mb_strcut')?mb_strcut($value,0,12000,'UTF-8'):substr($value,0,12000);
  }return $value;
 }
 static function state(){global $wpdb;$out=[];foreach(['insert_id','rows_affected','last_error','last_query','last_result','num_rows'] as $k)$out[$k]=$wpdb->$k;return $out;}
 static function restore($state){global $wpdb;foreach($state as $k=>$v)$wpdb->$k=$v;}
 static function warehouse_type($type){
  if(in_array($type,['page','request','user','settings','system','dennis_wms_shops'],true))return false;
  return in_array($type,['product','product_variation','shop_order','shop_order_refund','order','attachment','warehouse_transaction'],true)||preg_match('/^(?:dennis_wms_|pb_wms_)/',$type);
 }
 static function record($event,$type,$id=0,$old=[],$new=[],$source='WMS',$outcome='success',$sku=''){
  if(self::$busy||!self::$ready||!self::warehouse_type($type))return;
  $u=wp_get_current_user();if(!self::$request)self::$request=wp_generate_uuid4();
  $row=['created_at'=>current_time('mysql'),'created_utc'=>gmdate('Y-m-d H:i:s'),'user_id'=>get_current_user_id(),'actor'=>$u->display_name?:'System / ej inloggad','source'=>$source,'event'=>$event,'object_type'=>$type,'object_id'=>absint($id),'sku'=>(string)$sku,'outcome'=>$outcome,'request_id'=>self::$request,'before_data'=>wp_json_encode(self::clean($old)),'after_data'=>wp_json_encode(self::clean($new))];
  $skus=[(string)$sku];
  if(in_array($type,['order','shop_order'],true)&&$id&&function_exists('wc_get_order')){$order=wc_get_order($id);if($order&&method_exists($order,'get_items')){$found=[];foreach($order->get_items() as $item){$product=$item->get_product();if($product&&$product->get_sku()!=='')$found[]=$product->get_sku();}if($found)$skus=array_values(array_unique($found));}}
  foreach($skus as $item_sku){$row['sku']=$item_sku;if(self::$transaction)self::$pending[]=$row;else self::write($row);}
 }
 static function write($row){global $wpdb;$s=self::state();self::$busy=true;try{$ok=$wpdb->insert(self::table(),$row);if($ok===false){error_log('Dennis WMS: händelseloggen kunde inte skrivas.');update_option('dennis_wms_audit_write_failed',current_time('mysql'),false);}else delete_option('dennis_wms_audit_write_failed');}finally{self::$busy=false;self::restore($s);}}
 static function tracked($t){global $wpdb;return $t!==self::table()&&preg_match('/^'.preg_quote($wpdb->prefix,'/').'(?:dennis_wms_|pb_wms_)[a-z0-9_]+$/i',$t);}
 static function rows($t,$where){global $wpdb;$parts=[];$args=[];foreach($where as $k=>$v){if(!preg_match('/^[a-zA-Z0-9_]+$/',$k))return [];if($v===null)$parts[]="`$k` IS NULL";else{$parts[]="`$k`=%s";$args[]=$v;}}if(!$parts)return [];$q="SELECT * FROM `$t` WHERE ".implode(' AND ',$parts).' LIMIT 101';return (array)$wpdb->get_results($args?$wpdb->prepare($q,$args):$q,ARRAY_A);}
 static function row_sku($row){if(!empty($row['sku']))return (string)$row['sku'];$pid=(int)($row['product_id']??0);return $pid?(string)get_post_meta($pid,'_sku',true):'';}
 static function mutation($method,$args){
  global $wpdb;$t=$args[0];if(!self::$ready||self::$busy||!self::tracked($t))return call_user_func_array([$wpdb,$method],$args);
  $old=$method==='insert'?[]:self::rows($t,$args[$method==='update'?2:1]);
  $result=call_user_func_array([$wpdb,$method],$args);$s=self::state();
  try{if($result!==0){$data=$method==='delete'?[]:$args[1];$sample=$data+($old[0]??[]);self::record(['insert'=>'Skapad','update'=>'Ändrad','delete'=>'Borttagen'][$method],substr($t,strlen($wpdb->prefix)),(int)($sample['id']??($method==='insert'?$s['insert_id']:0)),$old,$data+['_berörda_rader'=>$result,'_urval_begränsat'=>count($old)>=101],'WMS',$result===false?'failed':'success',self::row_sku($sample));}}finally{self::restore($s);}return $result;
 }
 static function insert(...$args){return self::mutation('insert',$args);}
 static function update(...$args){return self::mutation('update',$args);}
 static function delete(...$args){return self::mutation('delete',$args);}
 static function where_clause($sql){
  $quote='';$len=strlen($sql);for($i=0;$i<$len;$i++){$ch=$sql[$i];if($quote){if($ch==='\\'){$i++;continue;}if($ch===$quote){if(($sql[$i+1]??'')===$quote){$i++;continue;}$quote='';}continue;}if($ch==="'"||$ch==='"'||$ch==='`'){$quote=$ch;continue;}if(strncasecmp(substr($sql,$i,5),'WHERE',5)===0&&($i===0||strpos(" \t\r\n",$sql[$i-1])!==false)&&(($sql[$i+5]??'')!==''&&strpos(" \t\r\n",$sql[$i+5])!==false))return rtrim(substr($sql,$i+6),';');}return '';
 }
 static function query($sql){
  global $wpdb;if(!self::$ready||self::$busy)return $wpdb->query($sql);$trim=trim($sql);$transaction=preg_match('/^(START TRANSACTION|BEGIN|COMMIT|ROLLBACK)\s*;?$/i',$trim,$m);
  $match=preg_match('/^(UPDATE|DELETE\s+FROM|INSERT\s+(?:IGNORE\s+)?INTO)\s+`?([a-zA-Z0-9_]+)`?/i',$trim,$parts)&&self::tracked($parts[2]);$old=[];$select='';$clause=self::where_clause($trim);
  // WHERE is already prepared by the caller. Do not execute or store raw request text.
  if($match&&self::$ready&&in_array(strtoupper($parts[1]),['UPDATE','DELETE FROM'],true)&&$clause!==''){$select='SELECT * FROM `'.$parts[2].'` WHERE '.$clause.' LIMIT 101';$old=(array)$wpdb->get_results($select,ARRAY_A);}
  $result=$wpdb->query($sql);$s=self::state();
  try{
   if($transaction&&$result!==false){$cmd=strtoupper($m[1]);if($cmd==='BEGIN'||$cmd==='START TRANSACTION'){self::$transaction=true;}else{$staged=self::$pending;self::$pending=[];self::$transaction=false;if($cmd==='COMMIT'){foreach($staged as $row)self::write($row);}else self::record('Transaktion återställd','warehouse_transaction',0,[],['avbrutna_logghändelser'=>count($staged)],'WMS','rolled_back');}}
   elseif($match&&$result!==0&&self::$ready){$after_select=$select;if($old&&isset($old[0]['id'])){$ids=array_map('absint',array_column($old,'id'));$after_select='SELECT * FROM `'.$parts[2].'` WHERE id IN ('.implode(',',$ids).') LIMIT 101';}$new=$after_select?(array)$wpdb->get_results($after_select,ARRAY_A):['berörda_rader'=>$result];$new['_berörda_rader']=$result;if(count($old)===101)$new['_urval_begränsat']=true;self::record('Databasändring',substr($parts[2],strlen($wpdb->prefix)),(int)($old[0]['id']??0),$old,$new,'WMS',$result===false?'failed':'success',self::row_sku($old[0]??[]));}
  }finally{self::restore($s);}return $result;
 }
 static function relevant_post($id){return in_array(get_post_type($id),['product','product_variation','shop_order','shop_order_refund'],true);}
 static function before_meta($mid,$id,$key,$value){if(self::relevant_post($id)||strpos($key,'_dennis_wms_')===0)self::$before[$id.':'.$key]=get_post_meta($id,$key,true);}
 static function meta($mid,$id,$key,$value){
  if(!self::relevant_post($id)&&strpos($key,'_dennis_wms_')!==0)return;
  if(in_array($key,['_edit_lock','_edit_last','_stock'],true))return;
  $hook=current_filter();$old=self::$before[$id.':'.$key]??null;unset(self::$before[$id.':'.$key]);$new=$hook==='deleted_post_meta'?null:$value;
  self::record('Produkt / orderuppgift ändrad',get_post_type($id)?:'attachment',$id,[$key=>$old],[$key=>$new],'WooCommerce','success',(string)(get_post_meta($id,'_sku',true)?:($key==='_sku'?$old:'')));
 }
 static function post($id,$post,$update,$before){if($update&&$before&&$before->post_title===$post->post_title&&$before->post_status===$post->post_status)return;if(!in_array($post->post_type,['product','product_variation','shop_order','shop_order_refund'],true))return;self::record($update?'Titel / status ändrad':'Produkt / order skapad',$post->post_type,$id,$before?['titel'=>$before->post_title,'status'=>$before->post_status]:[],['titel'=>$post->post_title,'status'=>$post->post_status],'WooCommerce','success',(string)get_post_meta($id,'_sku',true));}
 static function deleted_post($id,$post){if(in_array($post->post_type,['product','product_variation','shop_order','shop_order_refund'],true))self::record('Produkt / order borttagen',$post->post_type,$id,['titel'=>$post->post_title],[],'WooCommerce','success',(string)(self::$before['deleted_sku:'.$id]??''));unset(self::$before['deleted_sku:'.$id]);}
 static function before_stock($p){self::$stock[$p->get_id()]=get_post_meta($p->get_id(),'_stock',true);}
 static function stock($p){$id=$p->get_id();self::record('Lagersaldo ändrat','product',$id,['saldo'=>self::$stock[$id]??null],['saldo'=>$p->get_stock_quantity()],'WooCommerce','success',$p->get_sku());unset(self::$stock[$id]);}
 static function before_order($order){$changes=$order->get_changes();$meta=[];foreach($order->get_meta_data() as $m){if($m->get_changes()){$d=array_merge($m->get_data(),$m->get_changes());if(strpos($d['key'],'_dennis_wms_')===0)$meta[$d['key']]=$d['value'];}}if($meta)$changes['wms_metadata']=$meta;self::$before['order:'.spl_object_id($order)]=$changes;}
 static function order($id,$order=null){if(!$order&&function_exists('wc_get_order'))$order=wc_get_order($id);if(!$order)return;$key='order:'.spl_object_id($order);$changes=self::$before[$key]??[];unset(self::$before[$key]);if($changes||current_filter()==='woocommerce_new_order')self::record('Order sparad','order',$id,[], $changes,'WooCommerce');}
 static function menu(){add_submenu_page('pb-wms','Händelselogg','Händelselogg',self::CAP,'dennis-wms-activity-log',[__CLASS__,'page']);}
 static function guard(){if(!current_user_can(self::CAP))wp_die('Åtkomst nekad.',403);}
 static function filters(){global $wpdb;$where=["(object_type NOT IN ('page','request','user','settings','system','dennis_wms_shops') OR (object_type='system' AND event='Transaktion återställd'))"];$values=[];foreach(['sku','source','outcome','user_id'] as $key){$value=$_GET[$key]??'';if(!is_scalar($value)||$value==='')continue;$where[]="`$key`=".($key==='user_id'?'%d':'%s');$values[]=$key==='user_id'?absint($value):sanitize_text_field(wp_unslash($value));}
  foreach(['from'=>'>=','to'=>'<='] as $key=>$op){$d=$_GET[$key]??'';if(is_string($d)&&preg_match('/^\d{4}-\d{2}-\d{2}$/',$d)&&checkdate((int)substr($d,5,2),(int)substr($d,8,2),(int)substr($d,0,4))){$local=$d.($key==='from'?' 00:00:00':' 23:59:59');$boundary=new DateTimeImmutable($local,new DateTimeZone('Europe/Stockholm'));$utc=$boundary->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');$legacy=$boundary->setTimezone(wp_timezone())->format('Y-m-d H:i:s');$where[]="(created_utc $op %s OR (created_utc IS NULL AND created_at $op %s))";array_push($values,$utc,$legacy);}}
  $q=$_GET['q']??'';if(is_scalar($q)&&$q!==''){$where[]='(event LIKE %s OR actor LIKE %s OR object_type LIKE %s OR sku LIKE %s OR object_id = %d)';$term='%'.$wpdb->esc_like(sanitize_text_field(wp_unslash($q))).'%';array_push($values,$term,$term,$term,$term,absint($q));}
  $sql=implode(' AND ',$where);return $values?$wpdb->prepare($sql,$values):$sql;
 }
 static function time_label($r){
  try{$utc=$r->created_utc??'';$dt=new DateTimeImmutable($utc?:$r->created_at,$utc?new DateTimeZone('UTC'):wp_timezone());return $dt->setTimezone(new DateTimeZone('Europe/Stockholm'))->format('Y-m-d H:i');}catch(Exception $e){return substr((string)$r->created_at,0,16);}
 }
 static function page_label($slug){$labels=['dennis-wms-activity-log'=>'Händelselogg','dennis-wms-dashboard'=>'Översikt','dennis-wms-orders'=>'Ordrar','dennis-wms-products'=>'Produkter','dennis-wms-kits'=>'Förpackning','dennis-wms-receiving'=>'Inleveranser','pb-wms'=>'Inventering','dennis-wms-locations'=>'Lagerplatser','dennis-wms-batches'=>'Batcher och datum','dennis-wms-tracking'=>'Tracking','dennis-wms-delivery'=>'Leverans och transport','dennis-wms-report-builder'=>'Statistikrapport','dennis-wms-date-warnings'=>'Datumvarningar'];return $labels[$slug]??str_replace('-',' ',preg_replace('/^(dennis-wms-|pb-wms-)/','',$slug));}
 static function object_title($r){if($r->object_type==='page'){$data=json_decode($r->after_data,true);return self::page_label($data['vy']??'');}return self::object_label($r->object_type).($r->object_id?' #'.$r->object_id:'');}
 static function event_label($r){return $r->object_type==='page'?'Sidbesök begärt':$r->event;}
 static function fields($data,$prefix='',$depth=0){
  if(!is_array($data)||!$data)return $prefix!==''?[$prefix=>$data]:[];
  if(count($data)===1&&isset($data[0])&&is_array($data[0]))$data=$data[0];
  $out=[];foreach($data as $key=>$value){$path=$prefix!==''?$prefix.'.'.$key:(string)$key;if(is_array($value)&&$value&&$depth<3)$out+=self::fields($value,$path,$depth+1);else $out[$path]=$value;if(count($out)>=200)break;}return $out;
 }
 static function field_label($key){$labels=['vy'=>'Sida','version'=>'Version','status'=>'Status','quantity'=>'Antal','received_qty'=>'Mottaget antal','approved_qty'=>'Godkänt antal','posted_qty'=>'Bokfört antal','rejected_qty'=>'Avvisat antal','expected_qty'=>'Förväntat antal','saldo'=>'Saldo','wc_saldo'=>'WooCommerce-saldo','batchsaldo'=>'Batchsaldo','differens'=>'Differens','orsak'=>'Orsak','datum'=>'Datum','senaste_batchhandelse'=>'Batchhändelse-ID','batch'=>'Batch','expiry'=>'Expire date','last_order_date'=>'Last order date','location'=>'Lagerplats','note'=>'Kommentar','notes'=>'Kommentar','product_id'=>'Produkt-ID','receipt_id'=>'Inleverans-ID','line_id'=>'Rad-ID','action'=>'Händelse','_berörda_rader'=>'Berörda rader','_urval_begränsat'=>'Detaljurval begränsat','created_at'=>'Registrerat','updated_at'=>'Uppdaterat','user_id'=>'Användar-ID','created_by'=>'Registrerat av','sku'=>'SKU','title'=>'Titel','reference'=>'Projektnr','supplier'=>'Leverantör','åtgärd'=>'Åtgärd','http_status'=>'HTTP-status','php_fel'=>'PHP-fel'];return $labels[$key]??str_replace('_',' ',$key);}
 static function field_value($key,$v){if($v===null)return '—';if($v===true)return 'Ja';if($v===false)return 'Nej';if(in_array($key,['created_at','updated_at','counted_at','arrived_at'],true)&&is_string($v)&&preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}/',$v))return self::time_label((object)['created_at'=>$v]);if($key==='vy')return self::page_label((string)$v);if($key==='action'&&class_exists('Dennis_WMS_Batches'))return Dennis_WMS_Batches::action_label((string)$v);if(is_array($v))return $v?wp_json_encode($v,JSON_UNESCAPED_UNICODE):'—';return (string)$v;}
 static function human_details($r){
  $before=self::fields(json_decode($r->before_data,true)?:[]);$after=self::fields(json_decode($r->after_data,true)?:[]);$keys=array_values(array_unique(array_merge(array_keys($before),array_keys($after))));if(!$keys)return '<p>Inga ytterligare uppgifter.</p>';
  $html='<table class="dw-audit-values"><thead><tr><th>Uppgift</th>'.($before?'<th>Före</th>':'').'<th>'.($before?'Efter':'Värde').'</th></tr></thead><tbody>';foreach($keys as $key){$a=$before[$key]??null;$b=$after[$key]??null;if($before&&$after&&!array_key_exists($key,$after))continue;if(array_key_exists($key,$before)&&array_key_exists($key,$after)&&$a===$b)continue;$html.='<tr><th>'.esc_html(self::field_label($key)).'</th>'.($before?'<td>'.esc_html(self::field_value($key,$a)).'</td>':'').'<td>'.esc_html(self::field_value($key,$b)).'</td></tr>';}$html.='</tbody></table>';return $html;
 }
 static function object_label($type){$map=['dennis_wms_receipts'=>'Inleverans','dennis_wms_receipt_lines'=>'Inleveransrad','dennis_wms_receipt_events'=>'Inleveranshändelse','dennis_wms_receipt_images'=>'Inleveransbild','dennis_wms_batch_balances'=>'Batchsaldo','dennis_wms_batch_movements'=>'Batchhändelse','pb_wms_counts'=>'Inventering','dennis_wms_deliveries'=>'Leverans','product'=>'Produkt','product_variation'=>'Variant','order'=>'Order','shop_order'=>'Order','request'=>'Åtgärd','settings'=>'Inställningar','user'=>'Användare','system'=>'System','warehouse_transaction'=>'Lagerändring','page'=>'Vy'];return $map[$type]??str_replace('_',' ',preg_replace('/^(dennis_wms_|pb_wms_)/','',$type));}
 static function label($outcome){return ['success'=>'Genomförd','failed'=>'Fel','denied'=>'Nekad','rolled_back'=>'Återställd'][$outcome]??$outcome;}
 static function cell($value){$v=is_scalar($value)?(string)$value:wp_json_encode($value);return preg_match('/^[\s]*[=+\-@]/u',$v)?"'".$v:$v;}
 static function export(){self::guard();check_admin_referer('dennis_wms_audit_export');global $wpdb;$where=self::filters();$table=self::table();$max=(int)$wpdb->get_var("SELECT MAX(id) FROM $table");$print=($_GET['format']??'')==='print';
  if($print){header('Content-Type: text/html; charset=UTF-8');echo '<!doctype html><html lang="sv"><meta charset="utf-8"><title>Händelselogg</title><style>body{font:14px sans-serif;color:#464646}table{border-collapse:collapse;width:100%}th,td{padding:7px;border-bottom:1px solid #ddd;text-align:left;vertical-align:top;overflow-wrap:anywhere}th{color:#1D949C}pre{white-space:pre-wrap}button{background:#1D949C;color:white;padding:10px;border:0}@media print{button{display:none}thead{display:table-header-group}tr{break-inside:avoid}}</style><button onclick="window.print()">Skriv ut / spara PDF</button><h1>Händelselogg</h1><p>Tider visas i svensk tid: '.esc_html('Europe/Stockholm').'.</p><table><thead><tr><th>Tid</th><th>Användare</th><th>Händelse / SKU</th><th>Resultat</th><th>Detaljer</th></tr></thead><tbody>';}
  else{header('Content-Type: text/csv; charset=UTF-8');header('Content-Disposition: attachment; filename="wms-handelser.csv"');$out=fopen('php://output','w');fwrite($out,"\xEF\xBB\xBF");fputcsv($out,['Tid','Användare','Källa','Händelse','Objekt','ID','SKU','Resultat','Före','Efter','Begäran'], ';');}
  header('Cache-Control: no-store');$cursor=0;do{$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE ($where) AND id>%d AND id<=%d ORDER BY id ASC LIMIT 500",$cursor,$max));foreach($rows as $r){$cursor=(int)$r->id;if($print)self::print_row($r);else fputcsv($out,array_map([__CLASS__,'cell'],[self::time_label($r),$r->actor,$r->source,$r->event,$r->object_type,$r->object_id,$r->sku,self::label($r->outcome),$r->before_data,$r->after_data,$r->request_id]),';');}}while(count($rows)===500);if($print)echo '</tbody></table></html>';else fclose($out);exit;
 }
 static function detail($r){return wp_json_encode(['före'=>json_decode($r->before_data,true),'efter'=>json_decode($r->after_data,true)],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);}
 static function print_row($r){echo '<tr><td>'.esc_html(self::time_label($r)).'</td><td>'.esc_html($r->actor).'</td><td>'.esc_html(self::event_label($r).' · '.$r->source.' · '.self::object_title($r).' · '.$r->sku).'</td><td>'.esc_html(self::label($r->outcome)).'</td><td>'.self::human_details($r).'</td></tr>';}
 static function page(){self::guard();global $wpdb;if(!self::$ready){echo '<div class="wrap"><h1>Händelselogg</h1><p>Loggen är inte tillgänglig. Kontrollera databasinstallationen.</p></div>';return;}$t=self::table();$where=self::filters();$page=max(1,absint($_GET['paged']??1));$total=(int)$wpdb->get_var("SELECT COUNT(*) FROM $t WHERE $where");$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE $where ORDER BY id DESC LIMIT 50 OFFSET %d",($page-1)*50));
  echo '<div class="wrap"><h1>Händelselogg</h1><p>Artiklar, lagersaldon, inleveranser, inventering, batcher, lagerplatser, ordrar och leveranser. Tider visas i svensk tid: <strong>'.esc_html('Europe/Stockholm').'</strong>. Händelser registreras från denna uppdatering. Äldre inleverans- och batchhistorik finns kvar i respektive vy.</p><p>Här visas lagerrelaterade ändringar och fel. Sidbesök, inloggningar och allmänna systemhändelser visas inte.</p>';
  echo '<style>.dw-audit-filters{display:flex;flex-wrap:wrap;gap:12px;align-items:end;margin:18px 0}.dw-audit-filters label{display:grid;gap:5px}.dw-audit-table pre{white-space:pre-wrap;overflow-wrap:anywhere;max-width:650px}.dw-audit-scroll{overflow:auto}.dw-audit-table td{vertical-align:top!important}.dw-audit-table details{margin-top:6px}.dw-audit-table summary{cursor:pointer}.dw-audit-technical{margin-top:12px!important}.dw-audit-values{border-collapse:collapse;font-size:12px;max-width:650px}.dw-audit-values th,.dw-audit-values td{padding:6px!important;border-bottom:1px solid #edf0f4;overflow-wrap:anywhere}.dw-audit-values th{font-weight:600}.dw-audit-scroll .dw-audit-table>tbody>tr>td{padding:12px 14px!important}.dw-audit-table th{color:#1D949C}@media(max-width:600px){.dw-audit-filters label{width:100%}.dw-audit-table{min-width:750px}}</style><form method="get" class="dw-audit-filters"><input type="hidden" name="page" value="dennis-wms-activity-log">';
  foreach(['q'=>'Sök händelse, namn eller ID','sku'=>'Exakt SKU','user_id'=>'Användar-ID','from'=>'Från datum','to'=>'Till datum'] as $k=>$label){$v=is_scalar($_GET[$k]??null)?sanitize_text_field(wp_unslash($_GET[$k])):'';echo '<label>'.esc_html($label).'<input type="'.(in_array($k,['from','to'])?'date':($k==='user_id'?'number':'search')).'" name="'.esc_attr($k).'" value="'.esc_attr($v).'"></label>';}
  foreach(['source'=>[''=>'Alla källor','WMS'=>'WMS','WooCommerce'=>'WooCommerce',],'outcome'=>[''=>'Alla resultat','success'=>'Genomförd','failed'=>'Fel','denied'=>'Nekad','rolled_back'=>'Återställd']] as $key=>$options){echo '<label>'.($key==='source'?'Källa':'Resultat').'<select name="'.esc_attr($key).'">';foreach($options as $v=>$label)echo '<option value="'.esc_attr($v).'" '.selected(is_scalar($_GET[$key]??null)?$_GET[$key]:'',$v,false).'>'.esc_html($label).'</option>';echo '</select></label>';}
  echo '<button class="button button-primary">Filtrera</button><a class="button" href="'.esc_url(admin_url('admin.php?page=dennis-wms-activity-log')).'">Rensa filter</a></form>';
  $args=[];foreach(['q','sku','user_id','from','to','source','outcome'] as $key)if(is_scalar($_GET[$key]??null))$args[$key]=sanitize_text_field(wp_unslash($_GET[$key]));$args['action']='dennis_wms_audit_export';$url=wp_nonce_url(add_query_arg($args,admin_url('admin-post.php')),'dennis_wms_audit_export');
  echo '<p><strong>'.esc_html($total).' händelser</strong> · <a class="button" href="'.esc_url($url).'">Exportera alla träffar (CSV)</a> <a class="button" target="_blank" href="'.esc_url(add_query_arg('format','print',$url)).'">Skriv ut alla träffar</a></p><div class="dw-audit-scroll"><table class="widefat striped dw-audit-table"><thead><tr><th>Tid</th><th>Användare</th><th>Källa</th><th>Händelse / objekt</th><th>SKU</th><th>Resultat / detaljer</th></tr></thead><tbody>';
  foreach($rows as $r)echo '<tr><td>'.esc_html(self::time_label($r)).'</td><td>'.esc_html($r->actor).' (#'.absint($r->user_id).')</td><td>'.esc_html($r->source).'</td><td>'.esc_html(self::event_label($r)).'<br><small>'.esc_html(self::object_title($r)).'</small></td><td>'.esc_html($r->sku?:'—').'</td><td>'.esc_html(self::label($r->outcome)).'<details><summary>Visa detaljer</summary>'.self::human_details($r).'<details class="dw-audit-technical"><summary>Tekniska detaljer</summary><pre>'.esc_html(self::detail($r)).'</pre><small>Begärans ID: '.esc_html($r->request_id).'</small></details></details></td></tr>';
  if(!$rows)echo '<tr><td colspan="6">Inga händelser matchar filtren.</td></tr>';echo '</tbody></table></div><p>';if($page>1)echo '<a class="button" href="'.esc_url(add_query_arg('paged',$page-1)).'">Föregående</a> ';echo 'Sida '.esc_html($page).' av '.esc_html(max(1,ceil($total/50)));if($page*50<$total)echo ' <a class="button" href="'.esc_url(add_query_arg('paged',$page+1)).'">Nästa</a>';echo '</p></div>';
 }
}
Dennis_WMS_Audit::boot();
