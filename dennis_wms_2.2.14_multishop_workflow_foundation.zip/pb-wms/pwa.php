<?php
if (!defined('ABSPATH')) exit;
/** Dennis WMS PWA settings. Authenticated content is never cached by this worker. */
final class Dennis_WMS_PWA {
 const OPT = 'dennis_wms_pwa_settings';
 static function boot() {
  add_action('admin_menu',[__CLASS__,'menu'],110);
  add_action('admin_enqueue_scripts',[__CLASS__,'assets']);
  add_action('admin_post_dennis_wms_pwa_save',[__CLASS__,'save']);
  foreach (['dennis_wms_manifest'=>'manifest','dennis_wms_sw'=>'worker','dennis_wms_icon'=>'icon'] as $action=>$method) {
   add_action('admin_post_'.$action,[__CLASS__,$method]);
   add_action('admin_post_nopriv_'.$action,[__CLASS__,$method]);
  }
 }
 static function settings(){return wp_parse_args((array)get_option(self::OPT,[]),['name'=>'Dennis WMS','color'=>'#142b38','icon'=>0]);}
 static function icon_url($size=192){return admin_url('admin-post.php?action=dennis_wms_icon&size='.$size.'&v='.absint(get_option('dennis_wms_pwa_icon_version',1)));}
 static function menu(){add_submenu_page('pb-wms','Mobilapp','Mobilapp','manage_options','dennis-wms-mobile-settings',[__CLASS__,'page']);}
 static function assets($hook='') {
  if (!PB_WMS_V03::is_wms_screen())return;
  $opts=self::settings();$manifest=admin_url('admin-post.php?action=dennis_wms_manifest');
  add_action('admin_head',static function()use($manifest,$opts){
   echo '<link rel="manifest" href="'.esc_url($manifest).'">';
   echo '<meta name="theme-color" content="'.esc_attr($opts['color']).'">';
   echo '<meta name="apple-mobile-web-app-capable" content="yes">';
   echo '<meta name="apple-mobile-web-app-title" content="'.esc_attr($opts['name']).'">';
   echo '<link rel="apple-touch-icon" sizes="180x180" href="'.esc_url(self::icon_url(180)).'">';
  });
  wp_enqueue_script('dennis-wms-pwa',plugins_url('pwa.js',__FILE__),[],PB_WMS_VERSION,true);
  wp_add_inline_script('dennis-wms-pwa','window.DennisWMSPWA='.wp_json_encode(['worker'=>admin_url('admin-post.php?action=dennis_wms_sw'),'scope'=>wp_parse_url(admin_url(),PHP_URL_PATH)]).';','before');
  if (isset($_GET['page'])&&sanitize_key(wp_unslash($_GET['page']))==='dennis-wms-mobile-settings') {
   wp_enqueue_media();wp_enqueue_script('dennis-wms-pwa-settings',plugins_url('pwa-settings.js',__FILE__),['jquery','media-views'],PB_WMS_VERSION,true);wp_add_inline_script('dennis-wms-pwa-settings','window.DennisWMSDefaultIcon='.wp_json_encode(plugins_url('icons/icon-192.png',__FILE__)).';','before');
  }
 }
 static function page(){
  if(!current_user_can('manage_options'))wp_die('Åtkomst nekad');
  $o=self::settings();$default=plugins_url('icons/icon-192.png',__FILE__);
  $preview=$o['icon']?wp_get_attachment_url($o['icon']):$default;
  echo '<div class="wrap"><h1>Dennis WMS – Mobilapp</h1><p>Ändra namn, appikon och färg för iPhone och Android.</p>';
  if(isset($_GET['updated']))echo '<div class="notice notice-success is-dismissible"><p>Inställningarna har sparats.</p></div>';
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
  echo '<input type="hidden" name="action" value="dennis_wms_pwa_save">';wp_nonce_field('dennis_wms_pwa_save');
  echo '<table class="form-table"><tr><th><label for="dw-app-name">Appens namn</label></th><td><input id="dw-app-name" name="app_name" type="text" maxlength="40" class="regular-text" value="'.esc_attr($o['name']).'" required></td></tr>';
  echo '<tr><th>Appikon</th><td><img id="dw-app-preview" src="'.esc_url($preview).'" width="120" height="120" style="object-fit:cover;border-radius:22px;display:block;margin-bottom:12px;background:#eee">';
  echo '<input type="hidden" name="icon_id" id="dw-app-icon-id" value="'.esc_attr($o['icon']).'">';
  echo '<button type="button" class="button" id="dw-app-choose">Välj eller ladda upp ikon</button> <button type="button" class="button" id="dw-app-reset">Återställ standardikon</button>';
  echo '<p class="description">Välj en kvadratisk PNG-bild på minst 512 × 512 pixlar. Den används även för iPhone.</p></td></tr>';
  echo '<tr><th><label for="dw-app-color">Appens bakgrundsfärg</label></th><td><input type="color" id="dw-app-color" name="app_color" value="'.esc_attr($o['color']).'"></td></tr></table>';
  submit_button('Spara mobilappsinställningar');echo '</form><p>Efter ikonbyte kan du behöva ta bort den gamla hemskärmsikonen och lägga till appen igen.</p></div>';
 }
 static function save(){
  if(!current_user_can('manage_options'))wp_die('Åtkomst nekad',403);
  check_admin_referer('dennis_wms_pwa_save');
  $name=sanitize_text_field(wp_unslash($_POST['app_name']??'Dennis WMS'));
  $name=trim($name);if($name==='')$name='Dennis WMS';$name=mb_substr($name,0,40);
  $color=sanitize_hex_color(wp_unslash($_POST['app_color']??''));if(!$color)$color='#142b38';
  $id=absint($_POST['icon_id']??0);
  if($id){
   $mime=get_post_mime_type($id);$path=get_attached_file($id);$dim=$path&&is_file($path)?@getimagesize($path):false;
   if($mime!=='image/png'||!$dim||$dim[0]!==$dim[1]||$dim[0]<512){wp_die('Välj en kvadratisk PNG-bild på minst 512 × 512 pixlar.',400);}
  }
  update_option(self::OPT,['name'=>$name,'color'=>$color,'icon'=>$id],false);
  update_option('dennis_wms_pwa_icon_version',time(),false);
  wp_safe_redirect(add_query_arg(['page'=>'dennis-wms-mobile-settings','updated'=>1],admin_url('admin.php')));exit;
 }
 static function manifest(){
  nocache_headers();header('Content-Type: application/manifest+json; charset=utf-8');header('X-Content-Type-Options: nosniff');
  $o=self::settings();
  echo wp_json_encode(['id'=>admin_url('admin.php?page=dennis-wms-dashboard'),'name'=>$o['name'],'short_name'=>$o['name'],'description'=>'Lagerhantering för Dennis WMS','start_url'=>admin_url('admin.php?page=dennis-wms-dashboard'),'scope'=>wp_parse_url(admin_url(),PHP_URL_PATH),'display'=>'standalone','background_color'=>$o['color'],'theme_color'=>$o['color'],'icons'=>[['src'=>self::icon_url(192),'sizes'=>'192x192','type'=>'image/png','purpose'=>'any'],['src'=>self::icon_url(512),'sizes'=>'512x512','type'=>'image/png','purpose'=>'any']]],JSON_UNESCAPED_SLASHES);exit;
 }
 static function icon(){
  $size=absint($_GET['size']??192);if(!in_array($size,[180,192,512],true))$size=192;
  $o=self::settings();$path=$o['icon']?get_attached_file($o['icon']):plugin_dir_path(__FILE__).'icons/icon-512.png';
  if(!$path||!is_file($path))$path=plugin_dir_path(__FILE__).'icons/icon-512.png';
  require_once ABSPATH.'wp-admin/includes/image.php';
  $editor=wp_get_image_editor($path);
  if(!is_wp_error($editor)){
   $res=$editor->resize($size,$size,true);
   if(!is_wp_error($res)){
    $tmp=wp_tempnam('dennis-wms-icon.png');
    $saved=$editor->save($tmp,'image/png');
    if(!is_wp_error($saved)&&is_file($saved['path'])){
     header('Content-Type: image/png');header('X-Content-Type-Options: nosniff');header('Cache-Control: public, max-age=3600');
     readfile($saved['path']);@unlink($saved['path']);exit;
    }
    @unlink($tmp);
   }
  }
  // Fallback to default icon when image processing is unavailable.
  $fallback=plugin_dir_path(__FILE__).'icons/icon-512.png';
  header('Content-Type: image/png');header('X-Content-Type-Options: nosniff');readfile($fallback);exit;
 }
 static function worker(){
  nocache_headers();header('Content-Type: text/javascript; charset=utf-8');header('X-Content-Type-Options: nosniff');
  header('Service-Worker-Allowed: '.wp_parse_url(admin_url(),PHP_URL_PATH));
  echo "self.addEventListener('install',event=>{self.skipWaiting();});\n";
  echo "self.addEventListener('activate',event=>{event.waitUntil(self.clients.claim());});\n";exit;
 }
}
Dennis_WMS_PWA::boot();
