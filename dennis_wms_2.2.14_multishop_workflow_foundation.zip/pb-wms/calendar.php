<?php
if (!defined('ABSPATH')) exit;
/** Operational calendar. Drag and drop may update shipping deadlines only. */
final class Dennis_WMS_Calendar {
 const CAP='pb_wms_view';
 static function boot(){add_action('admin_menu',[__CLASS__,'menu'],100);add_action('dennis_wms_calendar_dashboard',[__CLASS__,'dashboard']);add_action('wp_ajax_dennis_wms_calendar_move',[__CLASS__,'move_order']);}
 static function menu(){add_submenu_page('pb-wms','Kalender','Kalender',self::CAP,'dennis-wms-calendar',[__CLASS__,'page']);}
 static function url($date=''){return add_query_arg(['page'=>'dennis-wms-calendar']+($date?['dw_month'=>substr($date,0,7)]:[]),admin_url('admin.php'));}
 static function events($start,$end){
  $events=[];
  $add=function($date,$type,$label,$url,$detail='',$order_id=0)use(&$events,$start,$end){$date=substr((string)$date,0,10);if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date)||$date<$start||$date>$end)return;$events[$date][]=['type'=>$type,'label'=>$label,'url'=>$url,'detail'=>$detail,'order_id'=>(int)$order_id];};
  if(function_exists('wc_get_orders')){
   // Bounded, paginated local WooCommerce orders (HPOS-compatible).
   for($page=1;$page<=20;$page++){
    $result=wc_get_orders(['limit'=>100,'page'=>$page,'paginate'=>true,'status'=>['processing','on-hold','pending'],'orderby'=>'date','order'=>'DESC']);
    if(!is_object($result)||!isset($result->orders)||!is_array($result->orders))break;
    foreach($result->orders as $order){
     $id=$order->get_id();$date=$order->get_date_created();$customer=trim($order->get_formatted_billing_full_name());if($customer==='')$customer=trim((string)$order->get_billing_company());if($customer==='')$customer='Kund saknas';$customer=wp_strip_all_tags($customer);$qty=0;foreach($order->get_items('line_item') as $item)$qty+=(int)$item->get_quantity();$suffix=' · '.$customer;
     // Waiting pre-orders take precedence over regular orders and shipping deadlines.
     // Classify once so the same order cannot appear as a purple movable deadline.
     $waiting_preorder=class_exists('Dennis_WMS_Preorders')
      && Dennis_WMS_Preorders::order_has_preorder($order)
      && Dennis_WMS_Preorders::order_waiting($order);
     if($waiting_preorder){
      if($date)$add($date->date_i18n('Y-m-d'),'preorder','Pre-order #'.$id.$suffix,admin_url('admin.php?page=dennis-wms-preorders'),'Väntar på varor · '.$qty.' st');
     }else{
      if($date)$add($date->date_i18n('Y-m-d'),'order','Order #'.$id.$suffix,admin_url('admin.php?page=dennis-wms-orders&order_id='.$id),'Skapad · '.wc_get_order_status_name($order->get_status()).' · '.$qty.' st');
      if(class_exists('Dennis_WMS_Deadline')){
       $due=Dennis_WMS_Deadline::due('local',$id,$order);
       if($due instanceof DateTimeInterface)$add($due->format('Y-m-d'),'deadline','Skicka #'.$id.$suffix,admin_url('admin.php?page=dennis-wms-orders&order_id='.$id),'Fraktdeadline '.$due->format('H:i').' · '.$qty.' st',$id);
      }
     }
    }
    if($page >= (int)($result->max_num_pages??1))break;
   }
  }
  global $wpdb;
  if(class_exists('Dennis_WMS_Receiving')){
   $table=Dennis_WMS_Receiving::table('receipts');
   if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$table))===$table){
    $rows=$wpdb->get_results($wpdb->prepare("SELECT id,reference,title,status,expected_date FROM `$table` WHERE expected_date BETWEEN %s AND %s ORDER BY expected_date LIMIT 500",$start,$end));
    foreach((array)$rows as $r)$add($r->expected_date,'receiving','Inleverans #'.$r->id,Dennis_WMS_Receiving::url((int)$r->id),trim((string)($r->title?:$r->reference)).' · '.$r->status);
   }
  }
  // Date warnings from product metadata. Limited for responsiveness on larger stores.
  if(function_exists('wc_get_products')){
   for($page=1;$page<=10;$page++){
    $products=wc_get_products(['limit'=>100,'page'=>$page,'paginate'=>true,'status'=>['publish','private'],'type'=>['simple','variation'],'orderby'=>'ID','order'=>'ASC']);
    if(!is_object($products)||!isset($products->products))break;
    foreach($products->products as $p){
     $pid=$p->get_id();$name=$p->get_name();
     foreach(['_pb_wms_expiry'=>['expiry','Utgångsdatum'],'_dennis_wms_last_order_date'=>['lastorder','Last order date']] as $meta=>$type){
      $date=$p->get_meta($meta,true);
      if($date)$add($date,$type,$name,admin_url('admin.php?page=dennis-wms-date-warnings'),$type[1]);
     }
    }
    if($page >= (int)($products->max_num_pages??1))break;
   }
  }
  if(class_exists('Dennis_WMS_Batches')&&Dennis_WMS_Batches::schema_ready()){
   $batch_table=Dennis_WMS_Batches::table('balances');
   $rows=$wpdb->get_results($wpdb->prepare("SELECT product_id,expiry,last_order_date FROM `$batch_table` WHERE (expiry BETWEEN %s AND %s OR last_order_date BETWEEN %s AND %s) LIMIT 500",$start,$end,$start,$end));
   foreach((array)$rows as $r){
    $p=wc_get_product((int)$r->product_id);$name=$p?$p->get_name():'Produkt #'.(int)$r->product_id;
    $url=admin_url('admin.php?page=dennis-wms-date-warnings');
    if($r->expiry)$add($r->expiry,'expiry',$name,$url,'Batch: utgångsdatum');
    if($r->last_order_date)$add($r->last_order_date,'lastorder',$name,$url,'Batch: Last order date');
   }
  }
  return $events;
 }
 static function page(){
  if(!current_user_can(self::CAP))wp_die('Åtkomst nekad');
  $month=sanitize_text_field(wp_unslash($_GET['dw_month']??wp_date('Y-m')));
  if(!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/',$month))$month=wp_date('Y-m');
  $view=isset($_GET['dw_view'])&&$_GET['dw_view']==='week'?'week':'month';
  $tz=wp_timezone();$first=DateTimeImmutable::createFromFormat('!Y-m-d',$month.'-01',$tz);if(!$first)$first=new DateTimeImmutable('first day of this month',$tz);
  $today=new DateTimeImmutable('today',$tz);
  $start=$view==='week'?($first->format('Y-m')===$today->format('Y-m')?$today->modify('monday this week'):$first->modify('monday this week')):$first->modify('monday this week');
  $end=$view==='week'?$start->modify('+6 days'):$first->modify('last day of this month')->modify('sunday this week');
  $events=self::events($start->format('Y-m-d'),$end->format('Y-m-d'));
  $prev=$first->modify('-1 month')->format('Y-m');$next=$first->modify('+1 month')->format('Y-m');
  $link=function($m,$v){return esc_url(add_query_arg(['page'=>'dennis-wms-calendar','dw_month'=>$m,'dw_view'=>$v],admin_url('admin.php')));};
  echo '<div class="wrap dw-calendar"><h1>📅 Kalender</h1><p>Ordrar, fraktdeadlines, pre-orders, inleveranser och datumvarningar. Dra en lila fraktdeadline till ett nytt datum för att planera om ordern. Övriga händelser kan inte flyttas.</p>';
  echo '<div class="dw-cal-tools"><a class="button" href="'.$link($prev,$view).'">← Föregående</a><strong>'.esc_html(wp_date('F Y',$first->getTimestamp())).'</strong><a class="button" href="'.$link($next,$view).'">Nästa →</a><a class="button'.($view==='month'?' button-primary':'').'" href="'.$link($month,'month').'">Månad</a><a class="button'.($view==='week'?' button-primary':'').'" href="'.$link($month,'week').'">Vecka</a></div>';
  echo '<section class="dw-cal-guide" aria-label="Förklaring av kalenderhändelser"><h2>Vad betyder färgerna i kalendern?</h2><p>Färgerna visar vilken typ av händelse det är och om något behöver göras. Klicka på en händelse för att öppna den i WMS.</p><div class="dw-cal-guide-grid">';
  foreach([
   ['order','🔵 Vanlig order – Registrerad','Visar dagen då en vanlig kundorder skapades. Detta är information, inte sista skickdatum.'],
   ['deadline','🟣 Fraktdeadline – Ska skickas','Ordern ska plockas, packas och skickas senast angivet datum. Behöver du planera om? Dra den lila händelsen till ett annat datum.'],
   ['preorder','🟠 Pre-order – Väntar på varor','Ordern innehåller varor som ännu inte är tillgängliga. Den väntar på tilldelning från godkända inleveranser och visas inte som vanlig fraktdeadline under väntetiden.'],
   ['receiving','🟢 Inleverans – Varor till lagret','En planerad eller registrerad inleverans. Kontrollera mottagna varor och godkänn dem innan lagersaldot uppdateras.'],
   ['expiry','🔴 Datumvarning – Kontrollera produkt','Utgångsdatum eller Last order date för en produkt eller batch. Kontrollera om varan får beställas eller användas.']
  ] as $guide){echo '<div class="dw-cal-guide-item dw-cal-guide-'.esc_attr($guide[0]).'"><strong>'.esc_html($guide[1]).'</strong><p>'.esc_html($guide[2]).'</p></div>';}
  echo '</div><details class="dw-cal-guide-help"><summary>ℹ️ Hur fungerar kalendern?</summary><p><strong>Flytta skickdatum:</strong> Dra endast lila fraktdeadlines. Det nya skickdatumet sätts till kl. 12:00 och ändringen loggas. Lager och orderstatus påverkas inte.</p><p><strong>Pre-orders:</strong> Orange betyder att ordern väntar på varor. När den inte längre väntar hanteras den enligt de vanliga orderreglerna.</p><p><strong>Datumvarningar:</strong> Rött betyder att du behöver kontrollera produktens datum, inte automatiskt att den redan har kasserats.</p></details></section>';
  echo '<div class="dw-cal-feedback" role="status" aria-live="polite"></div><div class="dw-cal-grid">';foreach(['Mån','Tis','Ons','Tor','Fre','Lör','Sön'] as $d)echo '<div class="dw-cal-weekday">'.esc_html($d).'</div>';
  for($day=$start;$day<=$end;$day=$day->modify('+1 day')){
   $date=$day->format('Y-m-d');$classes='dw-cal-day'.($date===$today->format('Y-m-d')?' today':'').($day->format('Y-m')!==$month?' outside':'');
   echo '<div class="'.esc_attr($classes).'" data-cal-date="'.esc_attr($date).'"><div class="dw-cal-daynum">'.esc_html($day->format('j')).'</div>';
   foreach(($events[$date]??[]) as $e){echo '<a class="dw-cal-event dw-cal-'.esc_attr($e['type']).'" href="'.esc_url($e['url']).'" title="'.esc_attr($e['detail']).'"'.($e['type']==='deadline'&&$e['order_id']&&current_user_can('pb_wms_manage')?' draggable="true" data-order-id="'.esc_attr($e['order_id']).'"':'').'><span>'.esc_html($e['label']).'</span></a>';}
   echo '</div>';
  }
  echo '</div><p class="description">Orderdatum visar när ordern skapades. Dra endast lila fraktdeadlines för att ändra skickdatum (kl. 12:00). Ändringen loggas i befintlig deadlinehistorik och påverkar inte lagersaldo eller orderstatus. Visningen är begränsad till de senaste 2 000 öppna ordrarna och 1 000 produkter för att skydda prestandan.</p></div>';
  if(current_user_can('pb_wms_manage')){
   $cfg=['url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('dennis_wms_calendar_move')];
   echo '<script>document.addEventListener("DOMContentLoaded",function(){const cfg='.wp_json_encode($cfg).';const feedback=document.querySelector(".dw-cal-feedback");let dragged=null;document.querySelectorAll(".dw-cal-event[draggable=true]").forEach(function(el){el.addEventListener("dragstart",function(e){dragged=el;e.dataTransfer.setData("text/plain",el.dataset.orderId);e.dataTransfer.effectAllowed="move";});el.addEventListener("dragend",function(){dragged=null;document.querySelectorAll(".dw-cal-over").forEach(x=>x.classList.remove("dw-cal-over"));});});document.querySelectorAll("[data-cal-date]").forEach(function(day){day.addEventListener("dragover",function(e){if(!dragged)return;e.preventDefault();day.classList.add("dw-cal-over");});day.addEventListener("dragleave",function(){day.classList.remove("dw-cal-over");});day.addEventListener("drop",async function(e){e.preventDefault();day.classList.remove("dw-cal-over");if(!dragged)return;const el=dragged;dragged=null;const orderId=el.dataset.orderId;const date=day.dataset.calDate;if(!orderId||!date)return;feedback.classList.remove("error");feedback.textContent="Sparar nytt skickdatum…";try{const body=new URLSearchParams({action:"dennis_wms_calendar_move",nonce:cfg.nonce,order_id:orderId,date:date});const res=await fetch(cfg.url,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded;charset=UTF-8"},body:body.toString()});const data=await res.json();if(!res.ok||!data.success)throw new Error(data.data?.message||"Kunde inte spara datumet.");day.appendChild(el);feedback.textContent=data.data.message;}catch(err){feedback.classList.add("error");feedback.textContent=err.message||"Ett fel uppstod.";}});});});</script>';
  }
  echo '<style>.dw-cal-guide{background:#fff;border:1px solid #dce2e8;border-radius:12px;padding:16px;margin:16px 0}.dw-cal-guide h2{margin:0 0 8px;font-size:17px}.dw-cal-guide>p{margin:0 0 14px;color:#475569}.dw-cal-guide-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px}.dw-cal-guide-item{padding:12px;border-radius:9px;border-left:5px solid #2563eb;background:#eff6ff}.dw-cal-guide-item strong{display:block;margin-bottom:7px}.dw-cal-guide-item p{margin:0;line-height:1.5}.dw-cal-guide-deadline{background:#f5efff;border-color:#7c3aed}.dw-cal-guide-preorder{background:#fff5e6;border-color:#d97706}.dw-cal-guide-receiving{background:#eaf8ef;border-color:#16a34a}.dw-cal-guide-expiry{background:#fff0f0;border-color:#dc2626}.dw-cal-guide-help{margin-top:12px;padding:10px 12px;background:#f8fafc;border-radius:8px}.dw-cal-guide-help summary{cursor:pointer;font-weight:600}.dw-cal-guide-help p{margin:10px 0 0}.dw-cal-tools,.dw-cal-legend{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:14px 0}.dw-cal-tools strong{font-size:19px;margin:0 12px}.dw-cal-legend span{background:#fff;border:1px solid #dce2e8;border-radius:20px;padding:5px 10px}.dw-cal-grid{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));border:1px solid #dce2e8;border-radius:12px;overflow:hidden;background:#fff}.dw-cal-weekday{text-align:center;padding:12px 3px;background:#f0f3f8;font-weight:700}.dw-cal-day{min-height:110px;border-top:1px solid #e3e7eb;border-right:1px solid #e3e7eb;padding:7px;min-width:0}.dw-cal-day.outside{background:#f7f8fa;opacity:.65}.dw-cal-day.today{background:#edf6ff}.dw-cal-daynum{font-weight:700;margin-bottom:7px}.dw-cal-event{display:block;padding:5px 7px;margin-bottom:4px;border-radius:5px;text-decoration:none!important;font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;background:#e8f0ff;color:#1e40af}.dw-cal-deadline{background:#f1e8ff;color:#6b21a8}.dw-cal-event[draggable=true]{cursor:grab}.dw-cal-day.dw-cal-over{outline:3px dashed #7c3aed;outline-offset:-3px;background:#f5efff}.dw-cal-feedback{font-weight:600;margin:8px 0}.dw-cal-feedback.error{color:#b91c1c}.dw-cal-preorder{background:#fff0d9;color:#9a5000}.dw-cal-receiving{background:#e0f5e7;color:#146c37}.dw-cal-expiry,.dw-cal-lastorder{background:#ffe4e4;color:#a51e27}@media(max-width:850px){.dw-cal-grid{overflow-x:auto;grid-template-columns:repeat(7,minmax(110px,1fr))}.dw-cal-day{min-height:90px}}</style>';
 }
 static function move_order(){
  if(!current_user_can('pb_wms_manage'))wp_send_json_error(['message'=>'Behörighet saknas.'],403);
  check_ajax_referer('dennis_wms_calendar_move','nonce');
  if(!class_exists('Dennis_WMS_Deadline')||!function_exists('wc_get_order'))wp_send_json_error(['message'=>'Orderhantering saknas.'],500);
  $id=absint($_POST['order_id']??0);$date=sanitize_text_field(wp_unslash($_POST['date']??''));
  if(!$id||!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date))wp_send_json_error(['message'=>'Ogiltig order eller datum.'],400);
  $dt=DateTimeImmutable::createFromFormat('!Y-m-d',$date,wp_timezone());
  if(!$dt||$dt->format('Y-m-d')!==$date)wp_send_json_error(['message'=>'Ogiltigt datum.'],400);
  $order=wc_get_order($id);
  if(!$order||!in_array($order->get_status(),['processing','on-hold','pending'],true))wp_send_json_error(['message'=>'Ordern kan inte planeras om.'],409);
  if(class_exists('Dennis_WMS_Preorders')&&Dennis_WMS_Preorders::order_has_preorder($order)&&Dennis_WMS_Preorders::order_waiting($order))wp_send_json_error(['message'=>'Väntande pre-orders kan inte planeras om här.'],409);
  $state=Dennis_WMS_Deadline::state('local',$id,$order);
  if(in_array($state['key'],['inactive','none','sent_ok','sent_late'],true))wp_send_json_error(['message'=>'Ordern har ingen aktiv fraktdeadline.'],409);
  $old=Dennis_WMS_Deadline::record('local',$id);$old_due=Dennis_WMS_Deadline::due('local',$id,$order);
  $custom=$date.' 12:00:00';$hist=Dennis_WMS_Deadline::history($old);
  array_unshift($hist,['time'=>current_time('mysql'),'user'=>get_current_user_id(),'action'=>'calendar_move','reason'=>'Flyttad i WMS-kalendern','old_deadline'=>$old_due?$old_due->format('Y-m-d H:i:s'):'','new_deadline'=>$custom]);
  $data=['shop_key'=>'local','order_ref'=>$id,'mode'=>'custom','custom_deadline'=>$custom,'reason'=>'Flyttad i WMS-kalendern','history'=>wp_json_encode(array_slice($hist,0,100),JSON_UNESCAPED_UNICODE),'updated_at'=>current_time('mysql'),'updated_by'=>get_current_user_id()];
  if($old)$result=Dennis_WMS_Audit::update(Dennis_WMS_Deadline::table(),$data,['id'=>(int)$old->id]);
  else $result=Dennis_WMS_Audit::insert(Dennis_WMS_Deadline::table(),$data);
  if($result===false)wp_send_json_error(['message'=>'Kunde inte spara datumet.'],500);
  wp_send_json_success(['message'=>'Order #'.$id.' planerad till '.$date.' kl. 12:00.']);
 }
 static function dashboard(){
  if(!current_user_can(self::CAP))return;
  $start=wp_date('Y-m-d');$end=wp_date('Y-m-d',time()+6*DAY_IN_SECONDS);$events=self::events($start,$end);$count=0;foreach($events as $rows)$count+=count($rows);
  echo '<div style="background:#fff;border:1px solid #dce2e8;border-radius:10px;padding:14px;margin:14px 0"><strong>📅 Kommande 7 dagar</strong><p>'.esc_html($count).' kalenderhändelser. <a href="'.esc_url(self::url()).'">Öppna kalendern →</a></p></div>';
 }
}
Dennis_WMS_Calendar::boot();
