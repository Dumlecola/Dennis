<?php
if (!defined('ABSPATH')) exit;
/** Opt-in location ledger. WooCommerce remains authoritative for total stock. */
final class Dennis_WMS_Locations_V14 {
 const CAP='pb_wms_manage';
 static function table($part){global $wpdb;return $wpdb->prefix.'dennis_wms_loc_'.$part;}
 static function boot(){add_action('admin_post_dennis_wms_location_distribution',[__CLASS__,'distribution_submit']);add_action('woocommerce_reduce_order_stock',[__CLASS__,'deduct_order_stock'],20,1);add_action('woocommerce_reduce_order_item_stock',[__CLASS__,'deduct_order_item_stock'],20,3);add_action('woocommerce_restore_order_stock',[__CLASS__,'restore_order_location_stock'],20,1);add_action('woocommerce_order_refunded',[__CLASS__,'restore_refund_stock'],20,2);add_action('woocommerce_restock_refunded_item',[__CLASS__,'restore_refunded_item_stock'],20,5);add_action('admin_menu',[__CLASS__,'menu'],105);add_action('admin_post_dennis_wms_loc14',[__CLASS__,'submit']);add_action('admin_post_dennis_wms_loc_adjust',[__CLASS__,'adjust']);add_action('admin_post_dennis_wms_loc_add',[__CLASS__,'add_location']);add_action('admin_post_dennis_wms_batch_loc_set',[__CLASS__,'batch_loc_set']);add_action('admin_post_dennis_wms_batch_loc_transfer',[__CLASS__,'batch_loc_transfer']);add_action('admin_post_dennis_wms_loc_add_batch',[__CLASS__,'add_batch_info']);add_action('admin_post_dennis_wms_location_rename',[__CLASS__,'rename_location']);add_action('admin_init',[__CLASS__,'upgrade']);}
 static function upgrade(){if(get_option('dennis_wms_loc_schema')==='1.6.2'||!current_user_can('manage_options'))return;global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$c=$wpdb->get_charset_collate();$b=self::table('balances');$e=self::table('events');
 dbDelta("CREATE TABLE $b (id bigint(20) unsigned NOT NULL AUTO_INCREMENT, product_id bigint(20) unsigned NOT NULL, location varchar(80) NOT NULL, quantity bigint(20) NOT NULL DEFAULT 0, minimum_qty bigint(20) NOT NULL DEFAULT 0, target_qty bigint(20) NOT NULL DEFAULT 0, kind varchar(20) NOT NULL DEFAULT 'reserve', PRIMARY KEY (id), UNIQUE KEY product_location (product_id,location), KEY product_id (product_id)) $c;");
 dbDelta("CREATE TABLE $e (id bigint(20) unsigned NOT NULL AUTO_INCREMENT, product_id bigint(20) unsigned NOT NULL, source_location varchar(80) NOT NULL DEFAULT '', target_location varchar(80) NOT NULL DEFAULT '', quantity bigint(20) unsigned NOT NULL, action varchar(30) NOT NULL, note text NULL, user_id bigint(20) unsigned NOT NULL, created_at datetime NOT NULL, PRIMARY KEY (id), KEY product_date (product_id,created_at)) $c;");$r=self::table('order_allocations');dbDelta("CREATE TABLE $r (id bigint(20) unsigned NOT NULL AUTO_INCREMENT, order_id bigint(20) unsigned NOT NULL, order_item_id bigint(20) unsigned NOT NULL, product_id bigint(20) unsigned NOT NULL, location varchar(120) NOT NULL DEFAULT '', batch varchar(120) NOT NULL DEFAULT '', expiry date NULL, quantity decimal(18,4) NOT NULL DEFAULT 0, source varchar(20) NOT NULL DEFAULT 'location', created_at datetime NOT NULL, PRIMARY KEY (id), KEY order_id (order_id), KEY product_id (product_id), KEY order_item_id (order_item_id)) $c;");update_option('dennis_wms_loc_schema','1.6.2');}
 static function order_alloc_table(){return self::table('order_allocations');}
 static function deduct_order_item_stock($item,$change,$order){
  if(!$item||!$order)return;global $wpdb;$at=self::order_alloc_table();$lb=self::table('balances');$iid=(int)$item->get_id();
  if($iid<1||(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $at WHERE order_item_id=%d",$iid))>0)return;
  $pr=$item->get_product();if(!$pr||(class_exists('Dennis_WMS_Kits')&&Dennis_WMS_Kits::item_on_demand($item)))return;$pid=$pr->get_stock_managed_by_id();
  $left=(is_array($change)&&isset($change['from'],$change['to']))?max(0,(float)$change['from']-(float)$change['to']):0;
  if($left<=0)$left=max(0,(float)$item->get_quantity());if($left<=0)return;
  $br=class_exists('Dennis_WMS_Batches')?Dennis_WMS_Batches::rows_for_product($pid):[];
  if($br){foreach($br as $r){if($left<=0)break;$take=min($left,max(0,(float)$r->quantity));if($take<=0)continue;
   $key='order-direct-'.$order->get_id().'-'.$iid.'-'.$r->id;
   if(Dennis_WMS_Batches::movement($pid,(string)$r->batch,$r->expiry?:null,(string)$r->location,-$take,'order_created','woocommerce_order',$order->get_id(),$key,'Direkt lageruttag när order skapades')){
    Dennis_WMS_Audit::insert($at,['order_id'=>$order->get_id(),'order_item_id'=>$iid,'product_id'=>$pid,'location'=>(string)$r->location,'batch'=>(string)$r->batch,'expiry'=>$r->expiry?:null,'quantity'=>$take,'source'=>'batch','created_at'=>current_time('mysql',true)]);$left-=$take;
   }}}
  else{$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $lb WHERE product_id=%d AND quantity>0 ORDER BY CASE WHEN kind='pick' THEN 0 ELSE 1 END,id",$pid));
   foreach($rows as $r){if($left<=0)break;$take=min($left,(float)$r->quantity);if($take<=0)continue;
    if(Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $lb SET quantity=quantity-%f WHERE id=%d AND quantity >= %f",$take,$r->id,$take))===1){
     Dennis_WMS_Audit::insert($at,['order_id'=>$order->get_id(),'order_item_id'=>$iid,'product_id'=>$pid,'location'=>(string)$r->location,'batch'=>'','expiry'=>null,'quantity'=>$take,'source'=>'location','created_at'=>current_time('mysql',true)]);$left-=$take;
    }}}
 }
 static function deduct_order_stock($order){
  if(is_numeric($order))$order=wc_get_order($order);if(!$order)return;global $wpdb;$at=self::order_alloc_table();$lb=self::table('balances');
  foreach($order->get_items('line_item') as $iid=>$item){
   $pr=$item->get_product();if(!$pr||(class_exists('Dennis_WMS_Kits')&&Dennis_WMS_Kits::item_on_demand($item)))continue;$pid=$pr->get_stock_managed_by_id();$left=(float)$item->get_quantity();if($left<=0)continue;
   if((int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $at WHERE order_item_id=%d",$iid))>0)continue;
   $br=class_exists('Dennis_WMS_Batches')?Dennis_WMS_Batches::rows_for_product($pid):[];
   if($br){
    foreach($br as $r){if($left<=0)break;$free=max(0,(float)$r->quantity);$take=min($left,$free);if($take<=0)continue;
     $key='order-direct-'.$order->get_id().'-'.$iid.'-'.$r->id;
     if(Dennis_WMS_Batches::movement($pid,(string)$r->batch,$r->expiry?:null,(string)$r->location,-$take,'order_created','woocommerce_order',$order->get_id(),$key,'Direkt lageruttag när order skapades')){
      Dennis_WMS_Audit::insert($at,['order_id'=>$order->get_id(),'order_item_id'=>$iid,'product_id'=>$pid,'location'=>(string)$r->location,'batch'=>(string)$r->batch,'expiry'=>$r->expiry?:null,'quantity'=>$take,'source'=>'batch','created_at'=>current_time('mysql',true)]);$left-=$take;
     }
    }
   }else{
    $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $lb WHERE product_id=%d AND quantity>0 ORDER BY CASE WHEN kind='pick' THEN 0 ELSE 1 END,id",$pid));
    foreach($rows as $r){if($left<=0)break;$take=min($left,(float)$r->quantity);if($take<=0)continue;
     if(Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $lb SET quantity=quantity-%f WHERE id=%d AND quantity >= %f",$take,$r->id,$take))===1){
      Dennis_WMS_Audit::insert($at,['order_id'=>$order->get_id(),'order_item_id'=>$iid,'product_id'=>$pid,'location'=>(string)$r->location,'batch'=>'','expiry'=>null,'quantity'=>$take,'source'=>'location','created_at'=>current_time('mysql',true)]);$left-=$take;
     }
    }
   }
  }
 }
 static function restore_refund_stock($order_id,$refund_id){
  $order=wc_get_order($order_id);$refund=wc_get_order($refund_id);if(!$order||!$refund)return;global $wpdb;$at=self::order_alloc_table();$lb=self::table('balances');
  foreach($refund->get_items('line_item') as $ri){$qty=abs((float)$ri->get_quantity());if($qty<=0)continue;$refunded_item_id=absint($ri->get_meta('_refunded_item_id',true));$orig=$refunded_item_id?$order->get_item($refunded_item_id):false;$pr=$orig?$orig->get_product():$ri->get_product();if(!$pr)continue;$pid=(int)$pr->get_stock_managed_by_id();
   $key='_dennis_wms_refund_restored_'.$refund_id.'_'.$pid.'_'.$refunded_item_id;if($order->get_meta($key,true))continue;
   $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $at WHERE order_id=%d AND product_id=%d AND quantity>0 ORDER BY id DESC",$order_id,$pid));$left=$qty;
   foreach($rows as $r){if($left<=0)break;$take=min($left,(float)$r->quantity);if($take<=0)continue;$ok=false;
    if($r->source==='batch'&&class_exists('Dennis_WMS_Batches'))$ok=(bool)Dennis_WMS_Batches::movement($pid,(string)$r->batch,$r->expiry?:null,(string)$r->location,$take,'order_refund','woocommerce_refund',$refund_id,'refund-'.$refund_id.'-allocation-'.$r->id,'Återlagt på ursprunglig batch/lagerplats efter WooCommerce-retur');
    else{$ok=Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $lb SET quantity=quantity+%f WHERE product_id=%d AND location=%s",$take,$pid,(string)$r->location))!==false;}
    if($ok){$remain=(float)$r->quantity-$take;if($remain>0)Dennis_WMS_Audit::update($at,['quantity'=>$remain],['id'=>(int)$r->id],['%f'],['%d']);else Dennis_WMS_Audit::delete($at,['id'=>(int)$r->id],['%d']);$left-=$take;}
   }
   if($left<=0){$order->update_meta_data($key,'yes');$order->save_meta_data();}
  }
 }
 static function restore_refunded_item_stock($product_id,$old_stock,$new_stock,$order,$product){
  if(!$order||!$product)return;global $wpdb;$at=self::order_alloc_table();$lb=self::table('balances');$qty=max(0,(float)$new_stock-(float)$old_stock);if($qty<=0)return;
  $refunds=$order->get_refunds();foreach($refunds as $rf){$mark='_dennis_wms_refund_restored_'.$rf->get_id().'_'.(int)$product->get_stock_managed_by_id().'_';foreach($order->get_meta_data() as $md){if(strpos((string)$md->key,$mark)===0&&$md->value==='yes')return;}}
  $pid=(int)$product->get_stock_managed_by_id();$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $at WHERE order_id=%d AND product_id=%d AND quantity>0 ORDER BY id DESC",$order->get_id(),$pid));$left=$qty;
  foreach($rows as $r){if($left<=0)break;$take=min($left,(float)$r->quantity);if($take<=0)continue;$ok=false;
   if($r->source==='batch'&&class_exists('Dennis_WMS_Batches')){$ok=(bool)Dennis_WMS_Batches::movement($pid,(string)$r->batch,$r->expiry?:null,(string)$r->location,$take,'order_refund','woocommerce_order',$order->get_id(),'refund-restock-'.$order->get_id().'-'.$r->id.'-'.wc_format_decimal($take,4),'Återlagt på lagerplats efter WooCommerce-retur');}
   else{$ok=Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $lb SET quantity=quantity+%f WHERE product_id=%d AND location=%s",$take,$pid,(string)$r->location))!==false;}
   if($ok){$remain=(float)$r->quantity-$take;if($remain>0)Dennis_WMS_Audit::update($at,['quantity'=>$remain],['id'=>(int)$r->id],['%f'],['%d']);else Dennis_WMS_Audit::delete($at,['id'=>(int)$r->id],['%d']);$left-=$take;}
  }
  // If an old order has no allocation history, do not guess a location/batch.
  // The reconciliation warning remains visible so stock cannot silently be put in the wrong place.
 }
 static function restore_order_location_stock($order){
  if(is_numeric($order))$order=wc_get_order($order);if(!$order)return;global $wpdb;$at=self::order_alloc_table();$lb=self::table('balances');
  $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $at WHERE order_id=%d ORDER BY id",$order->get_id()));
  foreach($rows as $r){$q=(float)$r->quantity;if($r->source==='batch'&&class_exists('Dennis_WMS_Batches')){
    Dennis_WMS_Batches::movement((int)$r->product_id,(string)$r->batch,$r->expiry?:null,(string)$r->location,$q,'order_restored','woocommerce_order',$order->get_id(),'order-restore-'.$order->get_id().'-'.$r->id,'Återfört efter att WooCommerce återställde orderlagret');
   }else{Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $lb SET quantity=quantity+%f WHERE product_id=%d AND location=%s",$q,(int)$r->product_id,(string)$r->location));}
  }
  Dennis_WMS_Audit::delete($at,['order_id'=>$order->get_id()],['%d']);
 }
 static function menu(){
  // Keep the legacy page registered for existing internal links and stock workflows.
  // Hide only its separate navigation entry: location management is under Batcher.
  add_submenu_page('pb-wms','Lagerplatssaldon','Lagerplatssaldon','pb_wms_view','dennis-wms-locations',[__CLASS__,'page']);
  add_action('admin_menu',static function(){remove_submenu_page('pb-wms','dennis-wms-locations');},999);
 }
 static function url($msg=''){return add_query_arg(['page'=>'dennis-wms-locations']+($msg?['dw_loc_notice'=>$msg]:[]),admin_url('admin.php'));}
 static function product(){ $sku=sanitize_text_field(wp_unslash($_POST['sku']??''));$id=$sku?wc_get_product_id_by_sku($sku):0;$p=$id?wc_get_product($id):false;if(!$p||!$p->managing_stock()||$p->get_stock_quantity()===null)wp_die('SKU saknas eller saknar eget WooCommerce-lagersaldo.',400);return $p;}
 static function positive($key,$allow_zero=false){$n=filter_var(wp_unslash($_POST[$key]??''),FILTER_VALIDATE_INT,['options'=>['min_range'=>$allow_zero?0:1,'max_range'=>999999999]]);if($n===false)wp_die('Ogiltigt antal: '.esc_html($key),400);return $n;}
 static function location($key){$s=sanitize_text_field(wp_unslash($_POST[$key]??''));if(!$s||strlen($s)>80)wp_die('Ange en lagerplats med högst 80 tecken.',400);return $s;}
 static function submit(){if(!current_user_can(self::CAP)||!current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad',403);check_admin_referer('dennis_wms_loc14');global $wpdb;$b=self::table('balances');$e=self::table('events');$p=self::product();$pid=$p->get_id();$mode=sanitize_key($_POST['mode']??'');$qty=self::positive('quantity');$src=self::location('source');$dst=self::location('target');if($src===$dst)wp_die('Välj två olika lagerplatser.',400);
 // Serialize mutations for the same SKU; ensure both balance updates commit or roll back.
 Dennis_WMS_Audit::query('START TRANSACTION');try{
 $lock=$wpdb->get_var($wpdb->prepare("SELECT id FROM $b WHERE product_id=%d ORDER BY id LIMIT 1 FOR UPDATE",$pid));
 if(!$lock)throw new Exception('Först registrera startfördelning för SKU på sidan Lagerplatssaldon.');
 $allocated=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(quantity),0) FROM $b WHERE product_id=%d",$pid));
 $fresh=wc_get_product($pid);if(!$fresh||$fresh->get_stock_quantity()===null||$allocated!==(int)$fresh->get_stock_quantity())throw new Exception('Platsbalanserna skiljer sig från WooCommerce-saldot. Stäm av innan lagerflytt.');
 $source=$wpdb->get_row($wpdb->prepare("SELECT * FROM $b WHERE product_id=%d AND location=%s FOR UPDATE",$pid,$src));
 if(!$source||(int)$source->quantity<$qty)throw new Exception('Otillräckligt saldo på ursprungsplatsen.');
 $target=$wpdb->get_row($wpdb->prepare("SELECT * FROM $b WHERE product_id=%d AND location=%s FOR UPDATE",$pid,$dst));
 if(!$target)throw new Exception('Registrera destinationsplatsen i startfördelningen innan flytt.');
 if(Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $b SET quantity=quantity-%d WHERE id=%d AND quantity >= %d",$qty,$source->id,$qty))!==1)throw new Exception('Kunde inte minska ursprungsplatsen.');
 if(Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $b SET quantity=quantity+%d WHERE id=%d",$qty,$target->id))!==1)throw new Exception('Kunde inte öka destinationsplatsen.');
 if(!Dennis_WMS_Audit::insert($e,['product_id'=>$pid,'source_location'=>$src,'target_location'=>$dst,'quantity'=>$qty,'action'=>'transfer','note'=>sanitize_textarea_field(wp_unslash($_POST['note']??'')),'user_id'=>get_current_user_id(),'created_at'=>current_time('mysql',true)]))throw new Exception('Kunde inte spara flytthistoriken.');
 Dennis_WMS_Audit::query('COMMIT');wp_safe_redirect(self::url('transferred'));exit;
 }catch(Exception $ex){Dennis_WMS_Audit::query('ROLLBACK');wp_die(esc_html($ex->getMessage()),409);}}
 static function setup(){if(!current_user_can(self::CAP)||!current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad',403);check_admin_referer('dennis_wms_loc_setup');global $wpdb;$b=self::table('balances');$p=self::product();$pid=$p->get_id();$raw=trim((string)wp_unslash($_POST['rows']??''));$rows=preg_split('/\r\n|\n|\r/',$raw);if(!$raw||count($rows)>100)wp_die('Ange 1–100 rader.',400);$parsed=[];$total=0;foreach($rows as $row){if(!trim($row))continue;$parts=str_getcsv($row,';');if(count($parts)!==5)wp_die('Format: plats;antal;typ;min;mål',400);[$loc,$qty,$kind,$min,$target]=array_map('trim',$parts);if(!$loc||strlen($loc)>80||isset($parsed[$loc])||!in_array($kind,['pick','reserve'],true)||!ctype_digit($qty)||!ctype_digit($min)||!ctype_digit($target)||(int)$target<(int)$min)wp_die('Kontrollera platser, typer och antal.',400);$parsed[$loc]=['quantity'=>(int)$qty,'kind'=>$kind,'minimum_qty'=>(int)$min,'target_qty'=>(int)$target];$total+=(int)$qty;}
 if($total!==(int)$p->get_stock_quantity())wp_die('Startfördelningen måste exakt motsvara WooCommerce-saldot ('.esc_html((string)$p->get_stock_quantity()).' st).',400);
 Dennis_WMS_Audit::query('START TRANSACTION');try{if((int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $b WHERE product_id=%d",$pid))>0)throw new Exception('SKU är redan startfördelad.');foreach($parsed as $loc=>$data){if(!Dennis_WMS_Audit::insert($b,['product_id'=>$pid,'location'=>$loc]+$data))throw new Exception('Databasfel vid startfördelning.');}Dennis_WMS_Audit::query('COMMIT');wp_safe_redirect(self::url('initialized'));exit;}catch(Exception $ex){Dennis_WMS_Audit::query('ROLLBACK');wp_die(esc_html($ex->getMessage()),409);}}
 static function selected_product(){
  $sku=sanitize_text_field(wp_unslash($_GET['sku']??'')); if(!$sku)return false;
  $id=wc_get_product_id_by_sku($sku); return $id?wc_get_product($id):false;
 }
 static function adjust(){
  if(!current_user_can(self::CAP)||!current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad',403);check_admin_referer('dennis_wms_loc_adjust');global $wpdb;$b=self::table('balances');$e=self::table('events');
  $p=self::product();$pid=$p->get_id();$loc=self::location('location');$new=self::positive('quantity',true);$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $b WHERE product_id=%d AND location=%s",$pid,$loc));if(!$row)wp_die('Lagerplatsen finns inte för denna SKU.',404);
  $old=(int)$row->quantity;$delta=$new-$old;$wc_old=(int)$p->get_stock_quantity();$wc_new=$wc_old+$delta;if($wc_new<0)wp_die('Justeringen skulle ge negativt WooCommerce-saldo.',409);
  Dennis_WMS_Audit::query('START TRANSACTION');try{
   if(Dennis_WMS_Audit::update($b,['quantity'=>$new],['id'=>(int)$row->id],['%d'],['%d'])===false)throw new Exception('Kunde inte uppdatera lagerplatsen.');
   $action=$delta===0?'adjust_nochange':'adjust';$note='Faktiskt saldo '.$old.' → '.$new.'. '.sanitize_textarea_field(wp_unslash($_POST['note']??''));
   if(!Dennis_WMS_Audit::insert($e,['product_id'=>$pid,'source_location'=>$loc,'target_location'=>$loc,'quantity'=>abs($delta),'action'=>$action,'note'=>$note,'user_id'=>get_current_user_id(),'created_at'=>current_time('mysql',true)]))throw new Exception('Kunde inte spara historiken.');
   Dennis_WMS_Audit::query('COMMIT');
   if($delta!==0){wc_update_product_stock($p,$wc_new,'set');$p=wc_get_product($pid);if(!$p||(int)$p->get_stock_quantity()!==$wc_new){Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $b SET quantity=%d WHERE id=%d",$old,$row->id));throw new Exception('WooCommerce-saldot kunde inte uppdateras. Platsjusteringen återställdes.');}}
   wp_safe_redirect(self::url('adjusted').'&sku='.rawurlencode($p->get_sku()));exit;
  }catch(Exception $ex){Dennis_WMS_Audit::query('ROLLBACK');wp_die(esc_html($ex->getMessage()),409);}
 }


 static function add_batch_info(){
  if(!current_user_can(self::CAP)||!current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad',403);check_admin_referer('dennis_wms_loc_add_batch');
  if(!class_exists('Dennis_WMS_Batches'))wp_die('Batchmodulen är inte tillgänglig.',500);
  global $wpdb;$p=self::product();$pid=$p->get_id();$loc=self::location('location');$batch=sanitize_text_field(wp_unslash($_POST['batch']??''));$expiry=Dennis_WMS_Batches::normalize_expiry(wp_unslash($_POST['expiry']??''));$qty=self::positive('quantity');
  if($batch===''&&!$expiry)wp_die('Ange batchnummer, expire date eller båda.',400);
  $lb=self::table('balances');$locrows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $lb WHERE product_id=%d ORDER BY id",$pid));if(!$locrows)wp_die('Artikeln saknar lagerplatssaldo.',409);
  $source=null;foreach($locrows as $r)if((string)$r->location===$loc){$source=$r;break;}if(!$source||(int)$source->quantity<$qty)wp_die('Antalet är större än saldot på lagerplatsen.',409);
  $existing=Dennis_WMS_Batches::rows_for_product($pid);$token=wp_generate_uuid4();
  // First conversion: mirror every location balance as an unclassified batch slot so total stock stays reconciled.
  if(!$existing){foreach($locrows as $r){if((float)$r->quantity<=0)continue;if(!Dennis_WMS_Batches::movement($pid,'',null,(string)$r->location,(float)$r->quantity,'location_to_batch_base','locations',0,'loc-batch-base-'.$pid.'-'.$r->id.'-'.$token,'Lagerplatssaldo infört i batchregistret utan saldoändring'))wp_die('Kunde inte förbereda batchregistret.',500);}}
  // Move quantity from the unclassified slot to the new batch/expiry slot. WooCommerce total is untouched.
  if(!Dennis_WMS_Batches::movement($pid,'',null,$loc,-$qty,'classify_batch_out','locations',0,'loc-batch-classify-out-'.$token,'Klassificeras med batch/expire'))wp_die('Det finns inte tillräckligt oklassificerat saldo på platsen.',409);
  if(!Dennis_WMS_Batches::movement($pid,$batch,$expiry,$loc,$qty,'classify_batch_in','locations',0,'loc-batch-classify-in-'.$token,'Batch/expire tillagd i efterhand')){Dennis_WMS_Batches::movement($pid,'',null,$loc,$qty,'classify_batch_rollback','locations',0,'loc-batch-classify-rollback-'.$token,'Återställning efter fel');wp_die('Batchinformationen kunde inte sparas.',500);}
  wp_safe_redirect(self::url('batch_added').'&sku='.rawurlencode($p->get_sku()));exit;
 }

 static function batch_loc_set(){
  if(!current_user_can(self::CAP)||!current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad',403);check_admin_referer('dennis_wms_batch_loc_set');
  if(!class_exists('Dennis_WMS_Batches'))wp_die('Batchmodulen är inte tillgänglig.',500);
  global $wpdb;$p=self::product();$pid=$p->get_id();$batch=sanitize_text_field(wp_unslash($_POST['batch']??''));$expiry=Dennis_WMS_Batches::normalize_expiry(wp_unslash($_POST['expiry']??''));$loc=self::location('location');$new=self::positive('quantity',true);$bt=Dennis_WMS_Batches::table('balances');
  $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $bt WHERE product_id=%d AND batch=%s AND ((expiry=%s) OR (expiry IS NULL AND %s='')) AND location=%s",$pid,$batch,$expiry?:'',$expiry?:'',$loc));$old=$row?(float)$row->quantity:0;$delta=$new-$old;
  if(abs($delta)<0.00001){wp_safe_redirect(self::url('batch_adjusted').'&sku='.rawurlencode($p->get_sku()));exit;}
  $wc_old=(float)$p->get_stock_quantity();$wc_new=$wc_old+$delta;if($wc_new<0)wp_die('Justeringen skulle ge negativt WooCommerce-saldo.',409);
  $key='loc-batch-adjust-'.get_current_user_id().'-'.wp_generate_uuid4();$note='Faktiskt batchsaldo '.$old.' → '.$new.'. '.sanitize_textarea_field(wp_unslash($_POST['note']??''));
  if(!Dennis_WMS_Batches::movement($pid,$batch,$expiry,$loc,$delta,'location_adjustment','locations',0,$key,$note))wp_die('Batchsaldot kunde inte uppdateras.',409);
  wc_update_product_stock($p,$wc_new,'set');$fresh=wc_get_product($pid);if(!$fresh||abs((float)$fresh->get_stock_quantity()-$wc_new)>0.00001){Dennis_WMS_Batches::movement($pid,$batch,$expiry,$loc,-$delta,'location_adjustment_rollback','locations',0,$key.'-rollback','Återställning efter WooCommerce-fel');wp_die('WooCommerce-saldot kunde inte uppdateras. Batchjusteringen återställdes.',500);}
  wp_safe_redirect(self::url('batch_adjusted').'&sku='.rawurlencode($p->get_sku()));exit;
 }
 static function batch_loc_transfer(){
  if(!current_user_can(self::CAP)||!current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad',403);check_admin_referer('dennis_wms_batch_loc_transfer');if(!class_exists('Dennis_WMS_Batches'))wp_die('Batchmodulen är inte tillgänglig.',500);
  $p=self::product();$pid=$p->get_id();$batch=sanitize_text_field(wp_unslash($_POST['batch']??''));$expiry=Dennis_WMS_Batches::normalize_expiry(wp_unslash($_POST['expiry']??''));$src=self::location('source');$dst=self::location('target');$qty=self::positive('quantity');if($src===$dst)wp_die('Välj två olika lagerplatser.',400);$note=sanitize_textarea_field(wp_unslash($_POST['note']??''));$token=wp_generate_uuid4();
  if(!Dennis_WMS_Batches::movement($pid,$batch,$expiry,$src,-$qty,'location_transfer_out','locations',0,'loc-transfer-out-'.$token,'Flytt till '.$dst.'. '.$note))wp_die('Otillräckligt batchsaldo på ursprungsplatsen.',409);
  if(!Dennis_WMS_Batches::movement($pid,$batch,$expiry,$dst,$qty,'location_transfer_in','locations',0,'loc-transfer-in-'.$token,'Flytt från '.$src.'. '.$note)){Dennis_WMS_Batches::movement($pid,$batch,$expiry,$src,$qty,'location_transfer_rollback','locations',0,'loc-transfer-rollback-'.$token,'Återställning efter misslyckad flytt');wp_die('Kunde inte lägga saldot på destinationsplatsen. Flytten återställdes.',500);}
  wp_safe_redirect(self::url('batch_transferred').'&sku='.rawurlencode($p->get_sku()));exit;
 }
 /** Only show a date explanation when the discard recorded a new, still-current discrepancy. */
 static function difference_info($p,$diff,$batch=true){
  if(!$batch||abs((float)$diff)<0.00001||!class_exists('Dennis_WMS_Audit')||!Dennis_WMS_Audit::$ready)return;
  global $wpdb;$pid=(int)$p->get_id();$t=Dennis_WMS_Audit::table();
  $entry=$wpdb->get_row($wpdb->prepare("SELECT id,before_data,after_data FROM $t WHERE object_type='product' AND object_id=%d AND event='Differens vid datumkassering' ORDER BY id DESC LIMIT 1",$pid));if(!$entry)return;
  $before=json_decode($entry->before_data,true);$after=json_decode($entry->after_data,true);
  if(!is_array($before)||!is_array($after)||!isset($before['differens'],$after['differens'],$after['wc_saldo'],$after['batchsaldo'],$after['senaste_batchhandelse']))return;
  $wc=(float)$p->get_stock_quantity();if(abs((float)$before['differens'])>=0.00001||abs((float)$after['differens']-(float)$diff)>=0.00001||abs((float)$after['wc_saldo']-$wc)>=0.00001||abs((float)$after['batchsaldo']-($wc+(float)$diff))>=0.00001)return;
  if(!in_array($after['orsak']??'',['expired_discard','last_order_discard'],true)||!preg_match('/^\d{4}-\d{2}-\d{2}$/',(string)($after['datum']??'')))return;
  $m=Dennis_WMS_Batches::table('movements');$latest=(int)$wpdb->get_var($wpdb->prepare("SELECT MAX(id) FROM $m WHERE product_id=%d",$pid));if($latest!==(int)$after['senaste_batchhandelse'])return;
  // A later stock change invalidates the causal snapshot, even if the quantity subsequently returned.
  if($wpdb->get_var($wpdb->prepare("SELECT id FROM $t WHERE object_type='product' AND object_id=%d AND event='Lagersaldo ändrat' AND id>%d LIMIT 1",$pid,(int)$entry->id)))return;
  $label=$after['orsak']==='last_order_discard'?'Last order date':'Expire date';
  echo '<p class="dw-diff-date" style="margin:0 0 14px;padding:0 14px"><strong>Differens uppstod vid kassering:</strong> '.esc_html($label.' '.$after['datum']).(!empty($after['batch'])?' · Batch '.esc_html($after['batch']):'').'.</p>';
 }
 static function batch_panel($p,$rows){
  $wc=(float)$p->get_stock_quantity();$sum=0;foreach($rows as $r)$sum+=(float)$r->quantity;$diff=$sum-$wc;$by=[];foreach($rows as $r){$key=$r->location?:'Ingen lagerplats';$by[$key][]=$r;}
  echo '<section class="dw-loc-product"><div><h2>'.esc_html($p->get_name()).'</h2><p><strong>SKU:</strong> '.esc_html($p->get_sku()).' · <strong>Batchhanterad artikel</strong></p></div><div class="dw-loc-total"><span>WooCommerce totalt</span><strong>'.esc_html(wc_format_localized_decimal($wc)).' st</strong></div></section>';
  echo '<div class="dw-loc-check '.(abs($diff)<0.00001?'ok':'bad').'"><strong>'.(abs($diff)<0.00001?'✓ Avstämt':'⚠ Differens').'</strong><span>Batcher/lagerplatser: '.esc_html(wc_format_localized_decimal($sum)).' st · WooCommerce: '.esc_html(wc_format_localized_decimal($wc)).' st'.(abs($diff)>=0.00001?' · Skillnad: '.esc_html(wc_format_localized_decimal($diff)).' st':'').'</span></div>';
  self::difference_info($p,$diff,true);
  echo '<p class="description"><strong>Enkel lagervy:</strong> lagerplatsen visas först. Batch och expire visas bara när de faktiskt finns. Plockordningen styrs först av Last order date och därefter av Expire date.</p><div class="dw-batch-locations">';$ranks=[];$rank=0;$today=current_time('Y-m-d');foreach($rows as $row){$valid=(empty($row->expiry)||$row->expiry>=$today)&&(empty($row->last_order_date)||$row->last_order_date>=$today);$ranks[$row->id]=$valid?'#'.(++$rank):'–';}foreach($by as $loc=>$items){echo '<article class="dw-batch-location"><h3><span>📍 '.esc_html($loc).'</span><strong>'.esc_html(wc_format_localized_decimal(array_sum(array_map(fn($x)=>(float)$x->quantity,$items)))).' st</strong></h3>';foreach($items as $r){$valid_expiry=!empty($r->expiry)&&$r->expiry!=='0000-00-00';$batch_label=!empty($r->batch)?$r->batch:'Ej angiven';$expiry_label=$valid_expiry?$r->expiry:'Ej angivet';echo '<div class="dw-batch-row"><div class="dw-batch-meta"><span class="dw-batch-kicker">Batchinformation</span><strong>Batch: '.esc_html($batch_label).'</strong><span>Expire: '.esc_html($expiry_label).' · Plockordning '.esc_html((string)$ranks[$r->id]).'</span><span>Last order date: '.esc_html($r->last_order_date?:'Ej angivet').'</span></div><div class="dw-batch-q"><strong>'.esc_html(wc_format_localized_decimal($r->quantity)).' st</strong></div>';
   if(current_user_can(self::CAP)&&current_user_can('manage_woocommerce')){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="dw-batch-adjust">';wp_nonce_field('dennis_wms_batch_loc_set');echo '<input type="hidden" name="action" value="dennis_wms_batch_loc_set"><input type="hidden" name="sku" value="'.esc_attr($p->get_sku()).'"><input type="hidden" name="batch" value="'.esc_attr($r->batch).'"><input type="hidden" name="expiry" value="'.esc_attr($r->expiry).'"><input type="hidden" name="location" value="'.esc_attr($r->location).'"><label>Faktiskt antal<input type="number" min="0" step="1" name="quantity" value="'.esc_attr((string)(float)$r->quantity).'" required></label><input name="note" placeholder="Orsak / kommentar"><button class="button button-primary">Spara</button></form>';}
   self::place_form($p,$r,true);echo '</div>'; }
   if(current_user_can(self::CAP)&&current_user_can('manage_woocommerce')){
    $loc_total=array_sum(array_map(fn($x)=>(float)$x->quantity,$items));
    echo '<details class="dw-loc-batch-add"><summary>＋ Lägg till / ändra batch & expire</summary><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_loc_add_batch');echo '<input type="hidden" name="action" value="dennis_wms_loc_add_batch"><input type="hidden" name="sku" value="'.esc_attr($p->get_sku()).'"><input type="hidden" name="location" value="'.esc_attr($loc==='Ingen lagerplats'?'':$loc).'"><div class="dw-loc-batch-fields"><label>Antal<input type="number" name="quantity" min="1" max="'.esc_attr((string)$loc_total).'" value="'.esc_attr((string)$loc_total).'" required></label><label>Batch<input name="batch" placeholder="Valfritt"></label><label>Expire date<input type="date" name="expiry"></label><button class="button">Spara batchinfo</button></div><p class="description">Du kan klassificera hela eller delar av saldot. WooCommerce totalsaldo ändras inte.</p></form></details>';
    if($loc!=='Ingen lagerplats') echo '<a class="button dw-move-location" href="#dw-batch-transfer">↔ Flytta från '.esc_html($loc).'</a>';
   }
   echo '</article>'; }echo '</div>';
  if(current_user_can(self::CAP)&&current_user_can('manage_woocommerce')){echo '<details class="dw-loc-tools"><summary>＋ Lägg till lagerplats</summary>';self::add_form($p,false);echo '</details><details class="dw-loc-tools" id="dw-batch-transfer" open><summary>↔ Flytta batch / saldo mellan lagerplatser</summary><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_batch_loc_transfer');echo '<input type="hidden" name="action" value="dennis_wms_batch_loc_transfer"><input type="hidden" name="sku" value="'.esc_attr($p->get_sku()).'"><div class="dw-loc-transfer"><label>Batch<select name="batch" id="dw-batch-select" required>';foreach($rows as $r)echo '<option value="'.esc_attr($r->batch).'" data-expiry="'.esc_attr($r->expiry).'">'.esc_html(($r->batch?:'utan batchnr').' · '.($r->expiry?:'utan datum')).'</option>';echo '</select><input type="hidden" name="expiry" id="dw-batch-expiry" value="'.esc_attr($rows[0]->expiry??'').'"></label><label>Från<select name="source" required>';foreach(array_keys($by) as $loc)if($loc!=='Ingen lagerplats')echo '<option>'.esc_html($loc).'</option>';echo '</select></label><label>Till<input name="target" placeholder="t.ex. PLOCK-01" required></label><label>Antal<input type="number" name="quantity" min="1" step="1" required></label><label>Kommentar<input name="note" placeholder="Valfritt"></label><button class="button button-primary" onclick="return confirm(\'Bekräfta fysisk batchflytt?\')">Flytta batch</button></div></form></details><script>document.addEventListener("change",function(e){if(e.target&&e.target.id==="dw-batch-select"){var o=e.target.options[e.target.selectedIndex];document.getElementById("dw-batch-expiry").value=o.dataset.expiry||"";}});</script>';}
  $moves=Dennis_WMS_Batches::recent_movements(30,50);echo '<details class="dw-loc-history"><summary>Senaste batchändringar</summary><div class="dw-loc-history-list">';$shown=0;foreach($moves as $m){if((int)$m->product_id!==(int)$p->get_id())continue;$shown++;echo '<div><strong>'.esc_html($m->batch?:'utan batchnr').'</strong> · '.esc_html($m->location?:'–').' · '.esc_html(wc_format_localized_decimal($m->quantity)).' st<br><small>'.esc_html($m->created_at).' · '.esc_html($m->action).' · '.esc_html($m->note).'</small></div>';}if(!$shown)echo '<p>Ingen batchhistorik ännu.</p>';echo '</div></details>';
 }

 static function add_location(){
  if(!current_user_can(self::CAP)||!current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad',403);check_admin_referer('dennis_wms_loc_add');global $wpdb;$b=self::table('balances');$e=self::table('events');$p=self::product();$pid=$p->get_id();$loc=self::location('location');$qty=self::positive('quantity',true);
  if($wpdb->get_var($wpdb->prepare("SELECT id FROM $b WHERE product_id=%d AND location=%s",$pid,$loc)))wp_die('Lagerplatsen finns redan för denna SKU.',409);
  $allocated=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(quantity),0) FROM $b WHERE product_id=%d",$pid));$wc=(int)$p->get_stock_quantity();
  if($allocated>0 && $allocated!==$wc)wp_die('Befintliga lagerplatser måste först stämmas av mot WooCommerce-saldot.',409);
  if($allocated===0 && $qty!==$wc)wp_die('Första lagerplatsen måste innehålla hela WooCommerce-saldot ('.$wc.' st). Lägg sedan till fler tomma platser och flytta saldo mellan dem.',400);
  if($allocated>0 && $qty!==0)wp_die('Nya extra lagerplatser skapas med 0 st. Flytta sedan saldo dit.',400);
  if(!Dennis_WMS_Audit::insert($b,['product_id'=>$pid,'location'=>$loc,'quantity'=>$qty,'minimum_qty'=>0,'target_qty'=>0,'kind'=>'reserve']))wp_die('Kunde inte lägga till lagerplats.',500);
  Dennis_WMS_Audit::insert($e,['product_id'=>$pid,'source_location'=>'','target_location'=>$loc,'quantity'=>$qty,'action'=>'location_added','note'=>'Lagerplats tillagd','user_id'=>get_current_user_id(),'created_at'=>current_time('mysql',true)]);
  wp_safe_redirect(self::url('location_added').'&sku='.rawurlencode($p->get_sku()));exit;
 }
 static function rename_location(){
  if(!current_user_can(self::CAP)||!current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad',403);
  check_admin_referer('dennis_wms_location_rename');global $wpdb;
  $p=self::product();$pid=$p->get_id();$id=absint($_POST['location_id']??0);$location=self::location('location');$b=self::table('balances');$e=self::table('events');
  Dennis_WMS_Audit::query('START TRANSACTION');try{
   $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $b WHERE product_id=%d ORDER BY id FOR UPDATE",$pid));$row=null;
   foreach($rows as $r){if((int)$r->id===$id)$row=$r;elseif($r->location===$location)throw new Exception('Platsen finns redan för artikeln. Använd Flytta saldo mellan lagerplatser.');}
   if(!$row)throw new Exception('Lagerplatsen hittades inte.');
   if(class_exists('Dennis_WMS_Batches')&&Dennis_WMS_Batches::all_balances($pid))throw new Exception('Artikeln har batchposter. Ändra plats på batchraden.');
   if($row->location===$location)throw new Exception('Välj en annan lagerplats.');
   if(Dennis_WMS_Audit::update($b,['location'=>$location],['id'=>$id])===false)throw new Exception('Kunde inte spara lagerplatsen.');
   if(!Dennis_WMS_Audit::insert($e,['product_id'=>$pid,'source_location'=>$row->location,'target_location'=>$location,'quantity'=>$row->quantity,'action'=>'location_renamed','note'=>'Lagerplats ändrad utan saldoändring','user_id'=>get_current_user_id(),'created_at'=>current_time('mysql',true)]))throw new Exception('Kunde inte spara historiken.');
   Dennis_WMS_Audit::query('COMMIT');
  }catch(Exception $ex){Dennis_WMS_Audit::query('ROLLBACK');wp_die(esc_html($ex->getMessage()),409);}
  wp_safe_redirect(self::url('location_saved').'&sku='.rawurlencode($p->get_sku()));exit;
 }
 static function place_form($p,$r,$batch=false){
  if(!current_user_can(self::CAP)||!current_user_can('manage_woocommerce'))return;
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="dw-place-edit" style="display:flex;gap:8px;flex-wrap:wrap;align-items:end;margin:12px 0">';
  wp_nonce_field($batch?'dennis_wms_batch_set_location':'dennis_wms_location_rename');
  echo '<input type="hidden" name="action" value="'.($batch?'dennis_wms_batch_set_location':'dennis_wms_location_rename').'"><input type="hidden" name="'.($batch?'balance_id':'location_id').'" value="'.esc_attr($r->id).'"><input type="hidden" name="sku" value="'.esc_attr($p->get_sku()).'"><label>Lagerplats<br><input name="location" maxlength="80" required value="'.esc_attr($r->location).'" placeholder="T.ex. A3"></label><button class="button">Spara plats</button><small>Hela radens saldo följer med.</small></form>';
 }
 static function page($embedded=false){if(!$embedded&&($_GET['storage_tab']??'')==='temporary'){wp_safe_redirect(Dennis_WMS_Temporary_Storage::url());exit;}if(!current_user_can('pb_wms_view'))wp_die('Åtkomst nekad',403);global $wpdb;$b=self::table('balances');$e=self::table('events');$selected=self::selected_product();$sku=sanitize_text_field(wp_unslash($_GET['sku']??''));
  echo '<div class="'.($embedded?'':'wrap ').'dw-loc-simple">'.($embedded?'<h2>Lagerplatser och saldo</h2>':'<h1>Lagerplatssaldon</h1>').'<p class="description">Sök eller scanna en SKU och justera lagerplatser utan tekniska tabeller. WooCommerce visar totalsaldot; Dennis WMS visar hur samma saldo är fördelat på lagerplatser.</p>';
  if(!$embedded&&class_exists('Dennis_WMS_Multi_Shop')&&class_exists('Dennis_WMS_Remote_Stock_Details')){
   $dw_shop=absint($_GET['dw_location_shop']??0);
   echo '<section class="dw-multishop-stock"><h2>Lagerplatser – anslutna shoppar</h2><form method="get"><input type="hidden" name="page" value="dennis-wms-locations"><label>Shop <select name="dw_location_shop"><option value="0">Alla anslutna shoppar</option>';
   foreach(Dennis_WMS_Multi_Shop::shops() as $dw_s)echo '<option value="'.absint($dw_s->id).'" '.selected($dw_shop,(int)$dw_s->id,false).'>'.esc_html($dw_s->name).'</option>';
   echo '</select></label> <button class="button">Filtrera</button></form>';
   Dennis_WMS_Remote_Stock_Details::render($dw_shop,'locations');echo '</section><hr style="margin:30px 0"><h2>Huvudshop – lagerplatser</h2>';
  }
  if(isset($_GET['dw_loc_notice'])){$m=sanitize_key($_GET['dw_loc_notice']);$labels=['location_saved'=>'Lagerplatsen är uppdaterad. Totalsaldot är oförändrat.','adjusted'=>'Saldot är uppdaterat.','transferred'=>'Lagerflytten är klar.','location_added'=>'Lagerplatsen är tillagd.','initialized'=>'Startfördelningen är sparad.','distributed'=>'Fördelningen är sparad och loggad. WooCommerce-saldot är oförändrat.','batch_adjusted'=>'Batchsaldot är uppdaterat.','batch_transferred'=>'Batchflytten är klar.','batch_added'=>'Batch / expire date är tillagd utan att totalsaldot ändrades.'];echo '<div class="notice notice-success"><p>'.esc_html($labels[$m]??'Klart.').'</p></div>';}
  echo '<form method="get" class="dw-loc-search"><input type="hidden" name="page" value="dennis-wms-locations"><input type="search" name="sku" value="'.esc_attr($sku).'" placeholder="Sök eller scanna SKU…" autofocus><button class="button button-primary">Visa artikel</button></form>';
  if($sku!==''&&!$selected)echo '<div class="notice notice-warning inline"><p>Ingen lagerstyrd produkt hittades för SKU <strong>'.esc_html($sku).'</strong>.</p></div>';
  if($selected){$pid=$selected->get_id();$batch_rows=class_exists('Dennis_WMS_Batches')?Dennis_WMS_Batches::all_balances($pid):[];if($batch_rows){Dennis_WMS_Batches::distribution_panel($selected,true);echo '<details class="dw-location-extra"><summary>Visa lagerplatser, justeringar och historik</summary>';self::batch_panel($selected,$batch_rows);echo '</details>';echo '<style>.dw-loc-simple{max-width:1180px}.dw-loc-search{display:flex;gap:8px;margin:18px 0}.dw-loc-search input{min-width:320px;max-width:520px;width:50%;font-size:16px;padding:8px 12px}.dw-loc-product{display:flex;justify-content:space-between;align-items:center;background:#fff;border:1px solid #dce5eb;border-radius:14px;padding:18px 20px;margin:14px 0 10px}.dw-loc-product h2{margin:0 0 5px}.dw-loc-product p{margin:0}.dw-loc-total{text-align:right}.dw-loc-total span{display:block;color:#64748b}.dw-loc-total strong{font-size:26px}.dw-loc-check{display:flex;gap:18px;align-items:center;border-radius:10px;padding:12px 15px;margin-bottom:14px}.dw-loc-check.ok{background:#ecfdf5;border:1px solid #a7f3d0}.dw-loc-check.bad{background:#fff7ed;border:1px solid #fdba74}.dw-batch-locations{display:grid;gap:12px;margin-top:14px}.dw-batch-location{background:#fff;border:1px solid #dce5eb;border-radius:14px;padding:15px}.dw-batch-location h3{display:flex;justify-content:space-between;margin:0 0 10px}.dw-batch-location h3 span{font-size:14px;color:#64748b}.dw-batch-row{display:grid;grid-template-columns:minmax(180px,1fr) 100px minmax(360px,2fr);gap:12px;align-items:end;border-top:1px solid #eef2f6;padding:12px 0}.dw-batch-meta span{display:block;color:#64748b;margin-top:3px}.dw-batch-q{font-size:18px}.dw-batch-adjust{display:grid;grid-template-columns:120px 1fr auto;gap:8px;align-items:end}.dw-batch-adjust label{font-weight:600}.dw-batch-adjust input{width:100%;margin-top:4px}.dw-loc-tools,.dw-loc-history{background:#fff;border:1px solid #dce5eb;border-radius:12px;padding:14px;margin-top:14px}.dw-loc-tools summary,.dw-loc-history summary{font-weight:700;cursor:pointer}.dw-loc-transfer{display:grid;grid-template-columns:1.2fr 1fr 1fr 100px 1fr auto;gap:10px;align-items:end;margin-top:14px}.dw-loc-transfer label{font-weight:600}.dw-loc-transfer select,.dw-loc-transfer input{display:block;width:100%;margin-top:4px}.dw-loc-history-list>div{padding:10px 0;border-bottom:1px solid #eef2f6}.dw-loc-add{display:flex;gap:10px;align-items:end;margin-top:12px}.dw-loc-add label{font-weight:600}.dw-loc-add input{display:block;margin-top:4px}.dw-move-location{margin-top:10px}@media(max-width:760px){.dw-loc-search{flex-direction:column}.dw-loc-search input{width:100%;min-width:0}.dw-loc-product{align-items:flex-start}.dw-batch-row{grid-template-columns:1fr}.dw-batch-adjust,.dw-loc-transfer,.dw-loc-add{display:flex;flex-direction:column;align-items:stretch}.dw-loc-check{flex-direction:column;align-items:flex-start;gap:3px}}</style></div>';return;}$locs=$wpdb->get_results($wpdb->prepare("SELECT * FROM $b WHERE product_id=%d ORDER BY kind,location",$pid));$allocated=0;foreach($locs as $r)$allocated+=(int)$r->quantity;$wc=(int)$selected->get_stock_quantity();$diff=$allocated-$wc;
   echo '<section class="dw-loc-product"><div><h2>'.esc_html($selected->get_name()).'</h2><p><strong>SKU:</strong> '.esc_html($selected->get_sku()).'</p></div><div class="dw-loc-total"><span>Totalt lager</span><strong>'.esc_html((string)$wc).' st</strong></div></section>';
   echo '<div class="dw-loc-check '.($diff===0?'ok':'bad').'"><strong>'.($diff===0?'✓ Avstämt':'⚠ Differens').'</strong><span>Lagerplatser: '.esc_html((string)$allocated).' st · WooCommerce: '.esc_html((string)$wc).' st'.($diff!==0?' · Skillnad: '.esc_html((string)$diff).' st':'').'</span></div>';
   self::difference_info($selected,$diff,false);self::distribution_form($selected,$locs);
   if(!$locs){echo '<p>Fördela saldot i raderna ovan. Lagerplats kan lämnas tom och anges senare.</p>';}
   else {echo '<details class="dw-location-extra"><summary>Visa lagerplatser och fler åtgärder</summary><div class="dw-loc-grid">';foreach($locs as $r){echo '<article class="dw-loc-card"><div class="dw-loc-card-head"><div><span class="dw-loc-pin">📍</span><strong>'.esc_html($r->location).'</strong></div><span class="dw-loc-kind">'.esc_html($r->kind==='pick'?'Plockplats':'Reserv').'</span></div><div class="dw-loc-qty">'.esc_html((string)$r->quantity).' <small>st</small></div>';
     self::place_form($selected,$r);
     if(current_user_can(self::CAP)&&current_user_can('manage_woocommerce')){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="dw-loc-adjust">';wp_nonce_field('dennis_wms_loc_adjust');echo '<input type="hidden" name="action" value="dennis_wms_loc_adjust"><input type="hidden" name="sku" value="'.esc_attr($selected->get_sku()).'"><input type="hidden" name="location" value="'.esc_attr($r->location).'"><label>Faktiskt antal på platsen<input type="number" name="quantity" min="0" step="1" value="'.esc_attr((string)$r->quantity).'" required></label><input type="text" name="note" placeholder="Orsak / kommentar"><button class="button button-primary">Spara saldo</button></form>';}
     if(current_user_can(self::CAP)&&current_user_can('manage_woocommerce')){echo '<details class="dw-loc-batch-add"><summary>＋ Lägg till / ändra batch & expire</summary><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_loc_add_batch');echo '<input type="hidden" name="action" value="dennis_wms_loc_add_batch"><input type="hidden" name="sku" value="'.esc_attr($selected->get_sku()).'"><input type="hidden" name="location" value="'.esc_attr($r->location).'"><div class="dw-loc-batch-fields"><label>Antal<input type="number" name="quantity" min="1" max="'.esc_attr((string)$r->quantity).'" value="'.esc_attr((string)$r->quantity).'" required></label><label>Batch<input name="batch" placeholder="Valfritt"></label><label>Expire date<input type="date" name="expiry"></label><button class="button">Spara batchinfo</button></div><p class="description">Du kan klassificera hela eller delar av saldot. WooCommerce totalsaldo ändras inte.</p></form></details>';}echo '</article>'; }echo '</div>';
    if(current_user_can(self::CAP)&&current_user_can('manage_woocommerce')){echo '<details class="dw-loc-tools"><summary>＋ Lägg till lagerplats</summary>';self::add_form($selected,false);echo '</details><details class="dw-loc-tools" open><summary>↔ Flytta saldo mellan lagerplatser</summary><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_loc14');echo '<input type="hidden" name="action" value="dennis_wms_loc14"><input type="hidden" name="mode" value="transfer"><input type="hidden" name="sku" value="'.esc_attr($selected->get_sku()).'"><div class="dw-loc-transfer"><label>Från<select name="source" required>';foreach($locs as $r)echo '<option value="'.esc_attr($r->location).'">'.esc_html($r->location).' · '.$r->quantity.' st</option>';echo '</select></label><label>Till<select name="target" required>';foreach($locs as $r)echo '<option value="'.esc_attr($r->location).'">'.esc_html($r->location).' · '.$r->quantity.' st</option>';echo '</select></label><label>Antal<input type="number" name="quantity" min="1" step="1" required></label><label>Kommentar<input name="note" placeholder="Valfritt"></label><button class="button button-primary" onclick="return confirm(\'Bekräfta fysisk lagerflytt?\')">Flytta saldo</button></div></form></details>';}
   }
   if($locs)echo '</details>';
  }
  $events=$wpdb->get_results("SELECT * FROM $e ORDER BY id DESC LIMIT 20");echo '<details class="dw-loc-history"><summary>Senaste ändringar</summary><div class="dw-loc-history-list">';foreach($events as $event){$p=wc_get_product($event->product_id);$u=get_userdata((int)$event->user_id);echo '<div><strong>'.esc_html($p?$p->get_sku():'#'.$event->product_id).'</strong> · '.esc_html($event->source_location?:'–').' → '.esc_html($event->target_location?:'–').' · '.esc_html((string)$event->quantity).' st<br><small>'.esc_html($event->created_at).' · '.esc_html($u?$u->display_name:'Okänd').' · '.esc_html($event->note).'</small></div>';}if(!$events)echo '<p>Ingen historik ännu.</p>';echo '</div></details>';
  echo '<style>.dw-loc-simple{max-width:1180px}.dw-loc-search{display:flex;gap:8px;margin:18px 0}.dw-loc-search input{min-width:320px;max-width:520px;width:50%;font-size:16px;padding:8px 12px}.dw-loc-product{display:flex;justify-content:space-between;align-items:center;background:#fff;border:1px solid #dce5eb;border-radius:14px;padding:18px 20px;margin:14px 0 10px}.dw-loc-product h2{margin:0 0 5px}.dw-loc-product p{margin:0}.dw-loc-total{text-align:right}.dw-loc-total span{display:block;color:#64748b}.dw-loc-total strong{font-size:26px}.dw-loc-check{display:flex;gap:18px;align-items:center;border-radius:10px;padding:12px 15px;margin-bottom:14px}.dw-loc-check.ok{background:#ecfdf5;border:1px solid #a7f3d0}.dw-loc-check.bad{background:#fff7ed;border:1px solid #fdba74}.dw-loc-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px}.dw-loc-card{background:#fff;border:1px solid #dce5eb;border-radius:14px;padding:16px;box-shadow:0 2px 8px rgba(15,23,42,.04)}.dw-loc-card-head{display:flex;justify-content:space-between;align-items:center;font-size:16px}.dw-loc-pin{margin-right:5px}.dw-loc-kind{font-size:12px;background:#f1f5f9;border-radius:999px;padding:4px 8px}.dw-loc-qty{font-size:34px;font-weight:700;margin:15px 0}.dw-loc-qty small{font-size:15px;font-weight:500}.dw-loc-adjust label{display:block;font-weight:600;margin:8px 0}.dw-loc-adjust input{width:100%;margin-top:4px}.dw-loc-adjust .button{width:100%;margin-top:8px}.dw-loc-batch-add{margin-top:12px;border-top:1px solid #eef2f6;padding-top:10px}.dw-loc-batch-add summary{font-weight:700;cursor:pointer}.dw-loc-batch-fields{display:grid;grid-template-columns:90px 1fr 1fr auto;gap:8px;align-items:end;margin-top:10px}.dw-loc-batch-fields label{font-weight:600}.dw-loc-batch-fields input{display:block;width:100%;margin-top:4px}.dw-loc-tools,.dw-loc-history,.dw-loc-empty{background:#fff;border:1px solid #dce5eb;border-radius:12px;padding:14px;margin-top:14px}.dw-loc-tools summary,.dw-loc-history summary{font-weight:700;cursor:pointer}.dw-loc-transfer{display:grid;grid-template-columns:1fr 1fr 120px 1fr auto;gap:10px;align-items:end;margin-top:14px}.dw-loc-transfer label{font-weight:600}.dw-loc-transfer select,.dw-loc-transfer input{display:block;width:100%;margin-top:4px}.dw-loc-history-list>div{padding:10px 0;border-bottom:1px solid #eef2f6}.dw-loc-add{display:flex;gap:10px;align-items:end;margin-top:12px}.dw-loc-add label{font-weight:600}.dw-loc-add input{display:block;margin-top:4px}.dw-move-location{margin-top:10px}.dw-loc-add{display:flex;gap:10px;align-items:end;margin-top:12px}.dw-loc-add label{font-weight:600}.dw-loc-add input{display:block;margin-top:4px}@media(max-width:700px){.dw-loc-search{flex-direction:column}.dw-loc-search input{width:100%;min-width:0}.dw-loc-product{align-items:flex-start}.dw-loc-transfer,.dw-loc-add,.dw-loc-batch-fields{display:flex;flex-direction:column;align-items:stretch}.dw-loc-check{flex-direction:column;align-items:flex-start;gap:3px}.dw-loc-grid{grid-template-columns:1fr}}</style></div>';
 }

 static function save_distribution($p,$locations,$quantities){
  if(!current_user_can(self::CAP)||!current_user_can('manage_woocommerce'))throw new Exception('Åtkomst nekad.');
  if(!$p||!$p->managing_stock()||$p->get_stock_managed_by_id()!==$p->get_id())throw new Exception('Välj en SKU med eget lagersaldo.');
  if(count($locations)>100||count($locations)!==count($quantities)||!count($locations))throw new Exception('Ange 1–100 rader.');
  $new=[];$total=0;
  foreach($locations as $i=>$raw){if(!is_scalar($raw)||!is_scalar($quantities[$i]))throw new Exception('Ogiltig rad.');$loc=sanitize_text_field(wp_unslash($raw));$q=filter_var($quantities[$i],FILTER_VALIDATE_INT,['options'=>['min_range'=>0,'max_range'=>999999999]]);if(strlen($loc)>80||$q===false)throw new Exception('Kontrollera lagerplats och antal.');$new[$loc]=($new[$loc]??0)+$q;$total+=$q;}
  global $wpdb;$pid=$p->get_id();$b=self::table('balances');$e=self::table('events');
  Dennis_WMS_Audit::query('START TRANSACTION');
  try{
   $old=$wpdb->get_results($wpdb->prepare("SELECT * FROM $b WHERE product_id=%d FOR UPDATE",$pid));
   if(class_exists('Dennis_WMS_Batches')&&Dennis_WMS_Batches::all_balances($pid))throw new Exception('Artikeln har batchsaldo. Använd fördelningen för batchrader.');
   $fresh=wc_get_product($pid);if(!$fresh||$fresh->get_stock_quantity()===null||abs($total-(float)$fresh->get_stock_quantity())>0.0001)throw new Exception('Fördelningen måste motsvara hela WooCommerce-saldot.');
   $settings=[];foreach($old as $r){$settings[$r->location]=$r;if(!Dennis_WMS_Audit::insert($e,['product_id'=>$pid,'source_location'=>$r->location,'target_location'=>'','quantity'=>$r->quantity,'action'=>'distribution_out','note'=>'Omfördelning av lagerplatser','user_id'=>get_current_user_id(),'created_at'=>current_time('mysql',true)]))throw new Exception('Kunde inte logga ändringen.');}
   if(Dennis_WMS_Audit::query($wpdb->prepare("DELETE FROM $b WHERE product_id=%d",$pid))===false)throw new Exception('Kunde inte spara.');
   foreach($new as $loc=>$q){$r=$settings[$loc]??null;if(!Dennis_WMS_Audit::insert($b,['product_id'=>$pid,'location'=>(string)$loc,'quantity'=>$q,'minimum_qty'=>$r?$r->minimum_qty:0,'target_qty'=>$r?$r->target_qty:0,'kind'=>$r?$r->kind:'reserve']))throw new Exception('Kunde inte spara platsen.');if(!Dennis_WMS_Audit::insert($e,['product_id'=>$pid,'source_location'=>'','target_location'=>(string)$loc,'quantity'=>$q,'action'=>'distribution_in','note'=>'Fördelning utan ändring av WooCommerce-saldo','user_id'=>get_current_user_id(),'created_at'=>current_time('mysql',true)]))throw new Exception('Kunde inte logga ändringen.');}
   Dennis_WMS_Audit::query('COMMIT');
  }catch(Exception $ex){Dennis_WMS_Audit::query('ROLLBACK');throw $ex;}
 }
 static function distribution_submit(){
  if(!current_user_can(self::CAP)||!current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad',403);check_admin_referer('dennis_wms_location_distribution');$p=self::product();
  try{self::save_distribution($p,(array)($_POST['locations']??[]),(array)($_POST['quantities']??[]));}catch(Exception $ex){wp_die(esc_html($ex->getMessage()),409);}
  wp_safe_redirect(self::url('distributed').'&sku='.rawurlencode($p->get_sku()));exit;
 }
 static function distribution_form($p,$rows){
  if(!current_user_can(self::CAP)||!current_user_can('manage_woocommerce'))return;
  echo '<section class="dw-location-distribution" style="background:#fff;border:2px solid #1D949C;border-radius:12px;padding:16px;margin:18px 0"><h2>Fördela saldo på lagerplatser</h2><p>Lägg till en rad per lagerplats och ange antal. Lagerplats är valfri. Totalsaldot ändras inte.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_location_distribution');echo '<input type="hidden" name="action" value="dennis_wms_location_distribution"><input type="hidden" name="sku" value="'.esc_attr($p->get_sku()).'"><div class="dw-location-rows">';
  if(!$rows)$rows=[(object)['location'=>'','quantity'=>$p->get_stock_quantity()]];
  foreach($rows as $r)echo '<div class="dw-location-line"><label>Lagerplats (valfri)<input name="locations[]" maxlength="80" placeholder="Kan anges senare" value="'.esc_attr($r->location).'"></label><label>Antal<input name="quantities[]" type="number" min="0" step="1" required value="'.esc_attr($r->quantity).'"></label><button type="button" class="button dw-location-remove">Ta bort</button></div>';
  echo '</div><p><button type="button" class="button dw-location-add">+ Lägg till rad</button></p><p class="dw-location-total" aria-live="polite"></p><button class="button button-primary">Spara fördelning</button></form></section><style>.dw-location-line{display:grid;grid-template-columns:minmax(160px,1fr) 120px auto;gap:12px;align-items:end;padding:12px 0;border-bottom:1px solid #eee}.dw-location-line label{font-weight:600}.dw-location-line input{display:block;width:100%;margin-top:5px}@media(max-width:600px){.dw-location-line{grid-template-columns:1fr}.dw-location-line input{min-height:44px}}</style>';
  echo '<script>(function(){const panel=document.querySelector(".dw-location-distribution"),rows=panel.querySelector(".dw-location-rows"),template=rows.firstElementChild.cloneNode(true),total='.wp_json_encode((float)$p->get_stock_quantity()).';function calc(){let n=0;rows.querySelectorAll("[name=\"quantities[]\"]").forEach(x=>n+=Number(x.value)||0);panel.querySelector(".dw-location-total").textContent="WooCommerce: "+total+" · Fördelat: "+n+" · Kvar: "+(total-n)}panel.addEventListener("input",calc);panel.addEventListener("click",function(e){if(e.target.closest(".dw-location-remove")){e.target.closest(".dw-location-line").remove();calc()}if(e.target.closest(".dw-location-add")){const row=template.cloneNode(true);row.querySelectorAll("input").forEach(x=>x.value=x.type==="number"?"0":"");rows.appendChild(row);calc()}});calc()})();</script>';
 }

 static function add_form($p,$first=false){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="dw-loc-add">';wp_nonce_field('dennis_wms_loc_add');echo '<input type="hidden" name="action" value="dennis_wms_loc_add"><input type="hidden" name="sku" value="'.esc_attr($p->get_sku()).'"><label>Lagerplats<input name="location" placeholder="t.ex. A-01-02" required></label><input type="hidden" name="quantity" value="'.esc_attr($first?(string)(int)$p->get_stock_quantity():'0').'"> <button class="button button-primary">Lägg till lagerplats'.($first?' med '.esc_html((string)(int)$p->get_stock_quantity()).' st':'').'</button></form>';}

}
add_action('admin_post_dennis_wms_loc_setup',['Dennis_WMS_Locations_V14','setup']);
Dennis_WMS_Locations_V14::boot();
