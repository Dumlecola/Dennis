# Multi-shop status — 2.2.14

## Implemented in this version
- Persisted picking checklist for connected-shop orders, keyed by shop ID and remote WooCommerce order ID.
- Packing completion and reopening after all identifiable order lines have been picked.
- Nonce and capability validation; audit history of workflow changes.
- Existing remote inventory, per-shop batch/location notes, and remote order UI retained.

## Not implemented / NOT safe to assume
- Unified physical stock ledger shared across local and connected shops.
- Stock reservations / decrements, atomic/idempotent sync between stores.
- Shared receiving, returns, FEFO/expiry, prepacked product logic, advanced picking/packing timings.
- WooCommerce order status write-back, image uploads, transport/tracking parity.
- Same capabilities across all pages, and full integration/environment testing.

## Caution
Remote picking/packing in this version is WMS-only and never changes stock or WooCommerce order status. Do not install on live production without staging tests and backup.
