<?php
if (!defined('ABSPATH')) exit;
final class Dennis_WMS_Warnings {
 const META='_dennis_wms_last_order_date';
 const EXP_OPT='dennis_wms_expiry_warning_days';
 const LOD_OPT='dennis_wms_last_order_warning_days';
 const HANDLED_META='_dennis_wms_warning_handled_';
 static function boot(){
  add_action('admin_menu',[__CLASS__,'menu'],104);
  add_action('woocommerce_product_options_inventory_product_data',[__CLASS__,'product_field']);
  add_action('woocommerce_process_product_meta',[__CLASS__,'save_product_field']);
  add_action('woocommerce_variation_options_inventory',[__CLASS__,'variation_field'],10,3);
  add_action('woocommerce_save_product_variation',[__CLASS__,'save_variation_field'],10,2);
  add_action('admin_post_dennis_wms_warning_settings',[__CLASS__,'save_settings']);
  add_action('admin_post_dennis_wms_warning_state',[__CLASS__,'save_state']);
 }
 static function expiry_days(){return max(1,min(365,absint(get_option(self::EXP_OPT,7))));}
 static function last_order_days(){return max(1,min(365,absint(get_option(self::LOD_OPT,7))));}
 static function product_field(){
  woocommerce_wp_text_input(['id'=>self::META,'label'=>'Last order date','type'=>'date','description'=>'Sista datum produkten får beställas. Dennis WMS varnar före och efter datumet.','desc_tip'=>true]);
 }
 static function save_product_field($id){$v=sanitize_text_field(wp_unslash($_POST[self::META]??''));update_post_meta($id,self::META,preg_match('/^\d{4}-\d{2}-\d{2}$/',$v)?$v:'');}
 static function variation_field($loop,$data,$variation){$v=get_post_meta($variation->ID,self::META,true);echo '<div class="form-row form-row-full"><label>Last order date</label><input type="date" name="dennis_wms_last_order_date_var['.esc_attr($loop).']" value="'.esc_attr($v).'"><p class="description">Sista datum varianten får beställas.</p></div>';}
 static function save_variation_field($id,$loop){$all=(array)($_POST['dennis_wms_last_order_date_var']??[]);$v=sanitize_text_field(wp_unslash($all[$loop]??''));update_post_meta($id,self::META,preg_match('/^\d{4}-\d{2}-\d{2}$/',$v)?$v:'');}
 static function save_settings(){
  if(!current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad',403);check_admin_referer('dennis_wms_warning_settings');
  update_option(self::EXP_OPT,max(1,min(365,absint($_POST['expiry_days']??7))));
  update_option(self::LOD_OPT,max(1,min(365,absint($_POST['last_order_days']??7))));
  wp_safe_redirect(add_query_arg(['page'=>'dennis-wms-batches','dw_batch_notice'=>'warning_settings'],admin_url('admin.php')));exit;
 }
 static function days_until($date){if(!Dennis_WMS_Batches::normalize_expiry($date))return null;$tz=wp_timezone();$today=new DateTimeImmutable(current_time('Y-m-d'),$tz);$d=DateTimeImmutable::createFromFormat('!Y-m-d',$date,$tz);return $d?(int)$today->diff($d)->format('%r%a'):null;}
 static function product_date($p,$key){
  if(!$p)return '';$v=(string)$p->get_meta($key,true);
  if($v===''&&$p->is_type('variation')){$par=wc_get_product($p->get_parent_id());if($par)$v=(string)$par->get_meta($key,true);}
  return Dennis_WMS_Batches::normalize_expiry($v)?:'';
 }
 static function product_last_order_date($p){return self::product_date($p,self::META);}
 // Once expiry is tracked per batch, the old product field is no longer the stock's expiry.
 // Include exhausted dated rows so a discarded batch does not resurrect a stale product warning.
 static function has_batch_expiry($id){
  if(!class_exists('Dennis_WMS_Batches'))return false;global $wpdb;$table=Dennis_WMS_Batches::table('balances');
  return (bool)$wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE product_id=%d AND expiry IS NOT NULL AND expiry<>'' AND expiry<>'0000-00-00' LIMIT 1",absint($id)));
 }
 static function product_alerts($type,$limit=100,$today_only=false){
  global $wpdb;$out=[];$limit=max(1,absint($limit));$key=$type==='expiry'?'_pb_wms_expiry':self::META;$days=$type==='expiry'?self::expiry_days():self::last_order_days();
  $today=current_time('Y-m-d');$until=(new DateTimeImmutable($today,wp_timezone()))->modify('+'.$days.' days')->format('Y-m-d');
  // WooCommerce's mixed product/variation query can omit variations. Query dated IDs directly,
  // including inherited parent dates, then resolve each product's effective date.
  for($offset=0;;$offset+=100){
   $ids=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT p.ID FROM {$wpdb->posts} p JOIN {$wpdb->postmeta} m ON (m.post_id=p.ID OR (p.post_type='product_variation' AND m.post_id=p.post_parent)) WHERE p.post_type IN ('product','product_variation') AND p.post_status NOT IN ('trash','auto-draft') AND m.meta_key=%s AND m.meta_value<>'' AND m.meta_value<=%s ORDER BY p.ID LIMIT 100 OFFSET %d",$key,$today_only?$today:$until,$offset));
   foreach($ids as $id){$p=wc_get_product($id);if(!$p||($type==='expiry'&&self::has_batch_expiry($id)))continue;$date=self::product_date($p,$key);$left=self::days_until($date);if($left===null||$left>$days||($today_only===true&&$date!==$today)||($today_only==='overdue'&&$date>=$today)||self::is_handled($id,'product',$id,$type,$date))continue;$out[]=['product'=>$p,'date'=>$date,'days'=>$left];if(count($out)>=$limit)break 2;}
   if(count($ids)<100)break;
  }
  usort($out,function($a,$b){return $a['days']<=>$b['days'];});return $out;
 }
 static function product_expiry_alerts($limit=100){return self::product_alerts('expiry',$limit);}
 static function batch_query($type,$limit=100,$product_id=0,$day_filter=false){
  if(!class_exists('Dennis_WMS_Batches')||!Dennis_WMS_Batches::schema_ready())return [];global $wpdb;$b=Dennis_WMS_Batches::table('balances');$column=$type==='expiry'?'expiry':'last_order_date';$today=current_time('Y-m-d');$days=$type==='expiry'?self::expiry_days():self::last_order_days();$until=(new DateTimeImmutable($today,wp_timezone()))->modify('+'.$days.' days')->format('Y-m-d');
  $where=$wpdb->prepare("quantity>0 AND $column IS NOT NULL AND $column<>'' AND $column<>'0000-00-00' AND $column<=%s",$until);
  if($product_id)$where.=$wpdb->prepare(' AND product_id=%d',absint($product_id));
  if($day_filter===true)$where.=$wpdb->prepare(" AND $column=%s",$today);
  elseif($day_filter==='overdue')$where.=$wpdb->prepare(" AND $column<%s",$today);
  $out=[];$limit=max(1,absint($limit));
  for($offset=0;;$offset+=100){$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $b WHERE $where ORDER BY $column,id LIMIT 100 OFFSET %d",$offset));foreach($rows as $row){$date=$row->$column;if(!Dennis_WMS_Batches::normalize_expiry($date)||self::is_handled($row->product_id,'batch',$row->id,$type,$date))continue;$out[]=$row;if(count($out)>=$limit)break 2;}if(count($rows)<100)break;}
  return $out;
 }
 static function batch_alerts($limit=100){return self::batch_query('expiry',$limit);}
 static function batch_last_order_alerts($limit=100,$product_id=0){return self::batch_query('last',$limit,$product_id);}
 static function last_order_alerts($limit=100){return self::product_alerts('last',$limit);}
 static function label($days,$type){
  if($type==='expiry'){if($days<0)return '🔴 UTGÅNGEN';if($days===0)return '🔴 GÅR UT IDAG';if($days<=2)return '🟠 Går ut om '.$days.' dag'.($days===1?'':'ar');return '🟡 Går ut om '.$days.' dagar';}
  if($days<0)return '⛔ SISTA ORDERDAG PASSERAD';if($days===0)return '🔴 SISTA ORDERDAG IDAG';if($days===1)return '🟠 Sista orderdag imorgon';if($days<=2)return '🟠 Sista orderdag om '.$days.' dagar';return '🟡 Sista orderdag om '.$days.' dagar';
 }
 static function has_due_today(){
  if(!current_user_can('pb_wms_view'))return false;
  return (bool)(self::batch_query('expiry',1,0,true)||self::batch_query('last',1,0,true)||self::product_alerts('expiry',1,true)||self::product_alerts('last',1,true));
 }
 static function urgency(){
  if(!current_user_can('pb_wms_view'))return '';
  if(self::has_due_today())return 'today';
  return self::batch_query('expiry',1,0,'overdue')||self::batch_query('last',1,0,'overdue')||self::product_alerts('expiry',1,'overdue')||self::product_alerts('last',1,'overdue')?'overdue':'';
 }
 static function menu(){add_submenu_page('pb-wms','Datumvarningar','Datumvarningar','pb_wms_view','dennis-wms-date-warnings',[__CLASS__,'page']);}
 static function url($kind='all'){return add_query_arg(['page'=>'dennis-wms-date-warnings','kind'=>$kind],admin_url('admin.php'));}
 static function render_global(){
  if(!current_user_can('pb_wms_view')||($_GET['page']??'')==='dennis-wms-date-warnings')return;
  if(!self::batch_alerts(1)&&!self::batch_last_order_alerts(1)&&!self::last_order_alerts(1)&&!self::product_expiry_alerts(1))return;
  echo '<div class="dw-date-reminder"><span>⚠️ Datum behöver kontrolleras</span><a href="'.esc_url(self::url()).'">Visa datumvarningar →</a></div>';
 }
 static function rows($limit=500){
  $rows=[];
  foreach(['expiry'=>self::batch_alerts($limit),'last'=>self::batch_last_order_alerts($limit)] as $type=>$batches){foreach($batches as $batch){$product=wc_get_product($batch->product_id);$date=$type==='expiry'?$batch->expiry:$batch->last_order_date;$days=self::days_until($date);if($days===null)continue;$rows[]=['product_id'=>(int)$batch->product_id,'scope'=>'batch','source_id'=>(int)$batch->id,'type'=>$type,'sku'=>$product?$product->get_sku():'#'.$batch->product_id,'name'=>$product?$product->get_name():'Borttagen produkt','batch'=>$batch->batch?:'Ej angiven','location'=>$batch->location?:'Ej angiven','quantity'=>$batch->quantity,'date'=>$date,'days'=>$days];}}
  foreach(['expiry'=>self::product_expiry_alerts($limit),'last'=>self::last_order_alerts($limit)] as $type=>$alerts)foreach($alerts as $alert){$product=$alert['product'];$rows[]=['product_id'=>$product->get_id(),'scope'=>'product','source_id'=>$product->get_id(),'type'=>$type,'sku'=>$product->get_sku(),'name'=>$product->get_name(),'batch'=>'Hela produkten','location'=>'–','quantity'=>'–','date'=>$alert['date'],'days'=>$alert['days']];}
  usort($rows,function($a,$b){return ($a['days']<=>$b['days'])?:strcmp($a['sku'],$b['sku']);});return $rows;
 }
 static function key($scope,$source_id,$type,$date){return self::HANDLED_META.hash('sha256',$scope.'|'.(int)$source_id.'|'.$type.'|'.$date);}
 static function is_handled($pid,$scope,$source_id,$type,$date){return (bool)get_post_meta((int)$pid,self::key($scope,$source_id,$type,$date),true);}
 static function can_manage(){return current_user_can('pb_wms_manage')&&current_user_can('manage_woocommerce');}
 static function set_state($pid,$scope,$source_id,$type,$date,$handled){
  if(!self::can_manage())throw new Exception('Åtkomst nekad.');
  $pid=absint($pid);$source_id=absint($source_id);
  if(!in_array($scope,['batch','product'],true)||!in_array($type,['expiry','last'],true)||!Dennis_WMS_Batches::normalize_expiry($date))throw new Exception('Ogiltig datumvarning.');
  $key=self::key($scope,$source_id,$type,$date);$previous=get_post_meta($pid,$key,true);
  if(!$handled){if(!$previous)return false;if(!delete_post_meta($pid,$key))throw new Exception('Varningen kunde inte återaktiveras.');Dennis_WMS_Audit::record('Datumvarning återaktiverad','dennis_wms_date_warning',$pid,$previous,[],'WMS','success',$previous['sku']??'');return true;}
  $p=wc_get_product($pid);if(!$p)throw new Exception('Produkten finns inte längre.');$row=null;
  if($scope==='batch'){
   global $wpdb;$table=Dennis_WMS_Batches::table('balances');$batch=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d AND product_id=%d",$source_id,$pid));$column=$type==='expiry'?'expiry':'last_order_date';
   if(!$batch||(float)$batch->quantity<=0||$batch->$column!==$date)throw new Exception('Batchens saldo eller datum har ändrats. Ladda om vyn.');
   $row=['batch'=>$batch->batch?:'Ej angiven','location'=>$batch->location?:'Ej angiven','quantity'=>$batch->quantity];
  }else{
   if($source_id!==$pid||self::product_date($p,$type==='expiry'?'_pb_wms_expiry':self::META)!==$date||($type==='expiry'&&self::has_batch_expiry($pid)))throw new Exception('Produktens datum har ändrats. Ladda om vyn.');
   $row=['batch'=>'Hela produkten','location'=>'–','quantity'=>'–'];
  }
  $days=self::days_until($date);if($days===null||$days>($type==='expiry'?self::expiry_days():self::last_order_days()))throw new Exception('Datumet ligger utanför varningsgränsen.');
  if($previous)return false;
  $row+=['product_id'=>$pid,'scope'=>$scope,'source_id'=>$source_id,'type'=>$type,'sku'=>$p->get_sku(),'name'=>$p->get_name(),'date'=>$date,'days'=>$days,'handled_at'=>current_time('mysql'),'handled_by'=>get_current_user_id()];
  if(update_post_meta($pid,$key,$row)===false)throw new Exception('Varningen kunde inte markeras som behandlad.');
  Dennis_WMS_Audit::record('Datumvarning behandlad','dennis_wms_date_warning',$pid,[],$row,'WMS','success',$row['sku']);return true;
 }
 static function save_state(){
  if(!self::can_manage())wp_die('Åtkomst nekad',403);check_admin_referer('dennis_wms_warning_state');
  try{$state=sanitize_key(wp_unslash($_POST['warning_state']??''));if(!in_array($state,['handled','active'],true))throw new Exception('Ogiltig åtgärd.');self::set_state(absint($_POST['product_id']??0),sanitize_key(wp_unslash($_POST['scope']??'')),absint($_POST['source_id']??0),sanitize_key(wp_unslash($_POST['type']??'')),sanitize_text_field(wp_unslash($_POST['date']??'')),$state==='handled');}catch(Exception $e){wp_die(esc_html($e->getMessage()),400);}
  wp_safe_redirect(self::url());exit;
 }
 static function handled_rows($page=1,$limit=25,$kind='all',$search=''){
  global $wpdb;$out=[];$skip=(max(1,(int)$page)-1)*25;$matched=0;
  for($offset=0;;$offset+=100){$records=$wpdb->get_results($wpdb->prepare("SELECT post_id,meta_key,meta_value FROM {$wpdb->postmeta} WHERE meta_key>=%s AND meta_key<%s ORDER BY meta_id DESC LIMIT 100 OFFSET %d",self::HANDLED_META,self::HANDLED_META.'~',$offset));
   foreach($records as $record){$row=maybe_unserialize($record->meta_value);if(!is_array($row)||!isset($row['scope'],$row['source_id'],$row['type'],$row['date'],$row['handled_at']))continue;if($kind!=='all'&&$row['type']!==$kind)continue;if($search!==''&&stripos(implode(' ',[$row['sku'],$row['name'],$row['batch'],$row['location']]),$search)===false)continue;if($matched++<$skip)continue;$out[]=$row;if(count($out)>=$limit)break 2;}if(count($records)<100)break;
  }return $out;
 }
 static function handled_count(){global $wpdb;return (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key>=%s AND meta_key<%s",self::HANDLED_META,self::HANDLED_META.'~'));}
 static function action_form($row,$handled){
  if(!self::can_manage())return;
  echo '<form method="post" class="dw-warning-action" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_warning_state');
  foreach(['action'=>'dennis_wms_warning_state','warning_state'=>$handled?'active':'handled','product_id'=>$row['product_id'],'scope'=>$row['scope'],'source_id'=>$row['source_id'],'type'=>$row['type'],'date'=>$row['date']] as $key=>$value)echo '<input type="hidden" name="'.esc_attr($key).'" value="'.esc_attr($value).'">';
  echo '<button class="button '.($handled?'':'button-primary').'">'.($handled?'Återaktivera':'Markera som behandlad').'</button></form>';
 }
 static function table($rows,$kind,$search,$handled=false){
  echo '<div class="dw-warning-table-scroll"><table class="widefat striped"><thead><tr><th>Status</th><th>Datumtyp</th><th>SKU</th><th>Produkt</th><th>Batch</th><th>Lagerplats</th><th>Antal</th><th>Datum</th><th>Åtgärd</th></tr></thead><tbody>';$shown=0;
  foreach($rows as $row){if($kind!=='all'&&$row['type']!==$kind)continue;if($search!==''&&stripos(implode(' ',[$row['sku'],$row['name'],$row['batch'],$row['location']]),$search)===false)continue;$shown++;$days=self::days_until($row['date']);$severity=$handled?'handled':($days<=0?'urgent':($days<=2?'soon':'upcoming'));
   echo '<tr><td><span class="dw-date-status '.$severity.'">'.esc_html($handled?'Behandlad':self::label($days,$row['type'])).'</span>';
   if($handled){$user=get_userdata($row['handled_by']);echo '<small class="dw-warning-handled-by">'.esc_html(mysql2date('Y-m-d H:i',$row['handled_at'])).'<br>'.esc_html($user?$user->display_name:'Användare #'.$row['handled_by']).'</small>';}
   echo '</td><td>'.esc_html($row['type']==='expiry'?'Utgångsdatum':'Last order date').'</td><td><strong>'.esc_html($row['sku']?:'SKU saknas').'</strong></td><td>'.esc_html($row['name']).'</td><td>'.esc_html($row['batch']).'</td><td>'.esc_html($row['location']).'</td><td>'.esc_html($row['quantity']).'</td><td>'.esc_html($row['date']).'</td><td>';self::action_form($row,$handled);echo '<a href="'.esc_url(add_query_arg(['page'=>'dennis-wms-batches','sku'=>$row['sku']],admin_url('admin.php'))).'">Öppna batcher</a></td></tr>';
  }
  if(!$shown)echo '<tr><td colspan="9">'.($handled?'Inga behandlade varningar i urvalet.':'Inga aktiva datumvarningar matchar urvalet.').'</td></tr>';echo '</tbody></table></div>';return $shown;
 }
 static function page(){
  if(!current_user_can('pb_wms_view'))wp_die('Åtkomst nekad',403);
  $kind=sanitize_key(wp_unslash($_GET['kind']??'all'));if(!in_array($kind,['all','expiry','last'],true))$kind='all';$search=trim(sanitize_text_field(wp_unslash($_GET['warning_search']??'')));$rows=self::rows();
  echo '<div class="wrap dw-date-warnings"><h1>Datumvarningar</h1><p>Utgångsdatum och Last order date samlade på ett ställe, med de mest brådskande överst.</p><nav class="dw-date-tabs" aria-label="Datumtyp">';
  foreach(['all'=>'Alla','expiry'=>'Utgångsdatum','last'=>'Last order date'] as $key=>$label){$urgent=false;foreach($rows as $row)if($row['days']<=0&&($key==='all'||$row['type']===$key)){$urgent=true;break;}echo '<a class="'.($kind===$key?'active ':'').($urgent?'dw-date-urgent':'').'" '.($kind===$key?'aria-current="page"':'').' href="'.esc_url(add_query_arg('warning_search',$search,self::url($key))).'">'.esc_html($label).($urgent?'<span class="dw-date-urgent-dot" aria-label="Datum idag eller passerat"></span>':'').'</a>';}
  echo '</nav><form method="get" class="dw-date-filter"><input type="hidden" name="page" value="dennis-wms-date-warnings"><input type="hidden" name="kind" value="'.esc_attr($kind).'"><label>Sök SKU, produkt, batch eller plats <input type="search" name="warning_search" value="'.esc_attr($search).'"></label> <button class="button">Sök</button></form><section class="dw-warning-section"><h2>Aktiva varningar</h2>';
  $shown=self::table($rows,$kind,$search);echo '<p>'.esc_html($shown).' aktiva varningar visas. Varningsgränser: utgångsdatum '.esc_html(self::expiry_days()).' dagar, Last order date '.esc_html(self::last_order_days()).' dagar.</p></section>';
  $page=max(1,absint($_GET['handled_page']??1));$handled=self::handled_rows($page,26,$kind,$search);$has_next=count($handled)>25;echo '<section class="dw-warning-section dw-warning-handled"><h2>Behandlade</h2><p>Behandlade varningar ger inga påminnelser eller pulsering. Markeringen ändrar inte saldo eller datum.</p>';self::table(array_slice($handled,0,25),$kind,$search,true);
  $args=['kind'=>$kind,'warning_search'=>$search];echo '<nav class="dw-warning-pagination">';if($page>1)echo '<a class="button" href="'.esc_url(add_query_arg($args+['handled_page'=>$page-1],self::url())).'">← Föregående</a> ';if($has_next)echo '<a class="button" href="'.esc_url(add_query_arg($args+['handled_page'=>$page+1],self::url())).'">Nästa →</a>';echo '</nav></section>';
  echo '<p><a href="'.esc_url(admin_url('admin.php?page=dennis-wms-batches')).'">Ändra varningsgränser i Batcher &amp; utgångsdatum →</a></p><p class="description">Visar högst 500 aktiva poster per datumtyp och källa. Batchvarningar avser varor med positivt batchsaldo. Utgångsdatum visas per batch när batchdatum finns; annars används produktens datum. Ett nytt datum eller en ny batch ger en ny varning.</p></div>';
 }
 static function render_order($order){
  $items=[];$seen=[];foreach($order->get_items('line_item') as $item){$p=$item->get_product();if(!$p)continue;
   if(!isset($seen[$p->get_id()])){$seen[$p->get_id()]=true;foreach(self::batch_last_order_alerts(100,$p->get_id()) as $r){$left=self::days_until($r->last_order_date);$items[]=[self::label($left,'last'),($p->get_sku()?:$p->get_name()).' · Batch '.($r->batch?:'Ej angiven').' · Plats '.($r->location?:'Ej angiven').' (kontrollera vald batch)',$r->last_order_date];}}
   $d=self::product_last_order_date($p);if(!$d)continue;$days=self::days_until($d);if($days!==null&&$days<=self::last_order_days()&&!self::is_handled($p->get_id(),'product',$p->get_id(),'last',$d))$items[]=[self::label($days,'last'),$p->get_sku()?:$p->get_name(),$d];}
  if(!$items)return;echo '<div style="background:#fff3cd;border-left:5px solid #dba617;padding:12px 14px;margin:0 0 14px;border-radius:8px"><strong>⚠️ Last order date</strong>';foreach($items as $x)echo '<div><strong>'.esc_html($x[0]).'</strong> · '.esc_html($x[1]).' · '.esc_html($x[2]).'</div>';echo '</div>';
 }
}
