(function($){'use strict';
 function initFilters(){
  $('.dw-image-filters').on('click','.dw-filter',function(){var f=$(this).data('filter');$('.dw-filter').removeClass('active');$(this).addClass('active');$('.dw-image-card').each(function(){$(this).toggle(f==='all'||$(this).data('category')===f);});});
 }
 $(function(){initFilters();});
})(jQuery);
