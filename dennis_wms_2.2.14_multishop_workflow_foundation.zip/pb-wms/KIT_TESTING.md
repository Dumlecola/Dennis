# Dennis WMS 2.1.29 – förpackning av en SKU

Ladda upp `dennis_wms_v2129_picklist_batch_fix.zip` i `/wordpress/wp-content/plugins/`.
Öppna Dev Tools → Terminal → PHP och kör utan PHP-taggar:

```php
$zip = new ZipArchive();
$file = '/wordpress/wp-content/plugins/dennis_wms_v2129_picklist_batch_fix.zip';
if (!is_file($file)) {
    echo 'Ladda upp ZIP-filen i plugins-mappen först.';
} elseif ($zip->open($file) !== true) {
    echo 'Kunde inte öppna ZIP-filen.';
} else {
    $ok = $zip->extractTo('/wordpress/wp-content/plugins/');
    $zip->close();
    echo $ok ? 'Dennis WMS 2.1.29 är uppackad. Ladda om WMS.' : 'Kunde inte packa upp filen.';
}
```

Öppna För-packade produkter. Ange SKU och välj Visa produkt. Ange hur många som faktiskt är förpackade. Totalsaldot ändras inte och antalet får inte överstiga saldot. Plockning använder förpackade enheter först.

Om en produkt har tidigare förpackningsinställning: välj Återställ vanlig saldohantering. Produktens sparade saldo och orderhistorik behålls. Tidigare komponentuttag återförs inte automatiskt. Ange därefter korrekt antal förpackade för denna SKU.

Händelselogg ska finnas i sidopanelen, utan länk i WMS toppmeny.

## Tillfällig förvaring
Inleveranser → Tillfällig förvaring utan SKU. Registrera beskrivning, plats, kommentar och valfri bild. Välj Hantera förvaring → Markera som behandlad. Posten flyttas till fliken Behandlade. Aktiva poster varnar efter 48 timmar. Förvaringen ändrar inga saldon och kan överföras till inleveranser.

Skapa inleverans från Hantera förvaring. Beskrivning och bild följer med; lagerplats och kommentar fylls i när inleveransens rad öppnas. Ange SKU och räknat antal, spara mottagning. Förvaringen behandlas. Upprepat klick öppnar samma utkast. Godkännande krävs innan saldo uppdateras.
