<?php
if (!defined('ABSPATH')) exit;
/** Internal Code 128B product labels. No inventory mutations. */
final class Dennis_WMS_Barcodes {
 const META = '_dennis_wms_barcode';
 static function boot() {
  add_action('admin_menu', [__CLASS__, 'menu'], 107);
  add_action('wp_ajax_dw_barcode_lookup', [__CLASS__, 'lookup']);
  add_action('admin_post_dw_barcode_save', [__CLASS__, 'save']);
  add_action('admin_post_dw_barcode_generate', [__CLASS__, 'generate_batch']);
  add_action('woocommerce_new_product', [__CLASS__, 'ensure']);
  add_action('woocommerce_update_product', [__CLASS__, 'ensure']);
  add_action('woocommerce_new_product_variation', [__CLASS__, 'ensure']);
  add_action('woocommerce_update_product_variation', [__CLASS__, 'ensure']);
 }
 static function menu() { add_submenu_page('pb-wms','Streckkoder','Streckkoder','pb_wms_view','dennis-wms-barcodes',[__CLASS__,'page']); }
 static function url($args=[]) { return add_query_arg(array_merge(['page'=>'dennis-wms-barcodes'],$args),admin_url('admin.php')); }
 static function unique($code,$exclude=0) {
  $found=wc_get_products(['limit'=>2,'return'=>'ids','status'=>['publish','private','draft','pending','future'],'type'=>['simple','variable','variation','grouped','external'],'meta_key'=>self::META,'meta_value'=>$code]);
  foreach($found as $id) if((int)$id!==(int)$exclude) return false;
  return true;
 }
 static function ensure($id) {
  $id=absint($id); if(!$id || !function_exists('wc_get_product'))return '';
  $product=wc_get_product($id); if(!$product)return '';
  $existing=(string)$product->get_meta(self::META,true);
  if($existing!=='')return $existing;
  // Site-scoped prefix prevents collisions between separate WooCommerce installations.
  $site=strtoupper(substr(hash('sha256',home_url('/')),0,8));
  $code='DW'.$site.'P'.$id;
  if(!self::unique($code,$id))return '';
  $product->update_meta_data(self::META,$code);
  $product->save_meta_data();
  return $code;
 }
 static function patterns() {return explode(' ', '212222 222122 222221 121223 121322 131222 122213 122312 132212 221213 221312 231212 112232 122132 122231 113222 123122 123221 223211 221132 221231 213212 223112 312131 311222 321122 321221 312212 322112 322211 212123 212321 232121 111323 131123 131321 112313 132113 132311 211313 231113 231311 112133 112331 132131 113123 113321 133121 313121 211331 231131 213113 213311 213131 311123 311321 331121 312113 312311 332111 314111 221411 431111 111224 111422 121124 121421 141122 141221 112214 112412 122114 122411 142112 142211 241211 221114 413111 241112 134111 111242 121142 121241 114212 124112 124211 411212 421112 421211 212141 214121 412121 111143 111341 131141 114113 114311 411113 411311 113141 114131 311141 411131 211412 211214 211232 2331112'); }
 static function svg($value,$height=55) {
  // Code 128 subset B encodes printable ASCII 32–126.
  if($value==='' || strlen($value)>64 || !preg_match('/^[\x20-\x7E]+$/D',$value))return '';
  $patterns=self::patterns();$codes=[104];$checksum=104;
  for($i=0;$i<strlen($value);$i++){$n=ord($value[$i])-32;$codes[]=$n;$checksum+=$n*($i+1);}
  $codes[]=$checksum%103;$codes[]=106;
  $x=10;$bars='';foreach($codes as $c){$pat=$patterns[$c];for($j=0;$j<strlen($pat);$j++){$w=(int)$pat[$j]*2;if($j%2===0)$bars.='<rect x="'.$x.'" y="0" width="'.$w.'" height="'.$height.'"/>';$x+=$w;}}
  $width=$x+10;
  return '<svg class="dw-barcode-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 '.$width.' '.$height.'" width="'.$width.'" height="'.$height.'" role="img" aria-label="Code 128: '.esc_attr($value).'" style="max-width:100%;height:auto"><g fill="#111">'.$bars.'</g></svg>';
 }
 static function lookup(){
  if(!current_user_can('pb_wms_view'))wp_send_json_error(['message'=>'Åtkomst nekad.'],403);
  check_ajax_referer('dw_barcode_lookup','nonce');
  $code=trim(sanitize_text_field(wp_unslash($_POST['code']??'')));
  if($code==='' || strlen($code)>64)wp_send_json_error(['message'=>'Ogiltig kod.'],400);
  $ids=wc_get_products(['limit'=>2,'return'=>'ids','status'=>['publish','private','draft','pending','future'],'meta_key'=>self::META,'meta_value'=>$code]);
  if(count($ids)===1){wp_send_json_success(['url'=>self::url(['product_id'=>$ids[0]])]);}
  if(count($ids)>1)wp_send_json_error(['message'=>'Streckkoden används på flera produkter.'],409);
  $id=wc_get_product_id_by_sku($code);
  if($id)wp_send_json_success(['url'=>self::url(['product_id'=>$id])]);
  wp_send_json_error(['message'=>'Ingen produkt hittades för koden.'],404);
 }
 static function save(){
  if(!current_user_can('pb_wms_manage') || !current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad.',403);
  check_admin_referer('dw_barcode_save');$id=absint($_POST['product_id']??0);$p=wc_get_product($id);if(!$p)wp_die('Produkten saknas.',404);
  $code=trim(sanitize_text_field(wp_unslash($_POST['barcode']??'')));
  if($code==='' || strlen($code)>64 || !preg_match('/^[\x20-\x7E]+$/D',$code))wp_die('Ange 1–64 tecken i Code 128 (ASCII).',400);
  if(!self::unique($code,$id))wp_die('Streckkoden används redan av en annan produkt.',409);
  $p->update_meta_data(self::META,$code);$p->save_meta_data();
  wp_safe_redirect(self::url(['product_id'=>$id,'saved'=>1]));exit;
 }
 static function generate_batch(){
  if(!current_user_can('pb_wms_manage') || !current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad.',403);
  check_admin_referer('dw_barcode_generate');$offset=max(0,absint($_POST['offset']??0));
  $ids=wc_get_products(['limit'=>100,'offset'=>$offset,'return'=>'ids','orderby'=>'ID','order'=>'ASC','status'=>['publish','private','draft','pending','future']]);
  foreach($ids as $id)self::ensure($id);
  wp_safe_redirect(self::url(['generated'=>count($ids),'next_offset'=>$offset+count($ids)]));exit;
 }
 static function page(){
  if(!current_user_can('pb_wms_view') || !function_exists('wc_get_products'))wp_die('Åtkomst nekad.',403);
  $search=trim(sanitize_text_field(wp_unslash($_GET['q']??'')));$id=absint($_GET['product_id']??0);$p=$id?wc_get_product($id):false;
  echo '<div class="wrap dw-barcode-page"><h1>Streckkoder & etiketter</h1><p>Unika interna Code 128-streckkoder för WooCommerce-produkter. Streckkoder ändrar inte SKU eller lagersaldo.</p>';
  echo '<style>.dw-barcode-page .dw-label{display:inline-block;background:#fff;color:#111;border:1px solid #ddd;padding:16px;margin:8px 8px 8px 0;max-width:390px;text-align:center;break-inside:avoid}.dw-label strong,.dw-label small{display:block;margin:5px}.dw-barcode-page .dw-barcode-svg{display:block;margin:8px auto}.dw-barcode-page .dw-bc-table td{vertical-align:middle}@media print{#adminmenumain,#wpadminbar,#wpfooter,.notice,.dw-barcode-page .dw-no-print{display:none!important}#wpcontent{margin:0!important}.dw-barcode-page .dw-label{border:1px solid #ccc}}</style>';
  echo '<div class="dw-no-print"><form method="get"><input type="hidden" name="page" value="dennis-wms-barcodes"><input type="search" name="q" placeholder="Sök produktnamn eller SKU" value="'.esc_attr($search).'"> <button class="button button-primary">Sök</button></form>';
  if(current_user_can('pb_wms_manage') && current_user_can('manage_woocommerce')){
   $offset=absint($_GET['next_offset']??0);
   echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin:12px 0">';wp_nonce_field('dw_barcode_generate');echo '<input type="hidden" name="action" value="dw_barcode_generate"><input type="hidden" name="offset" value="'.$offset.'"><button class="button">Tilldela streckkoder till nästa 100 produkter</button> <span class="description">Befintliga koder ändras inte.</span></form>';
   if(isset($_GET['generated']))echo '<p class="notice notice-success" style="padding:8px">Bearbetade '.absint($_GET['generated']).' produkter. Klicka igen för nästa omgång.</p>';
  }
  echo '<p><label>Skanna eller skriv streckkod: <input id="dw-barcode-scan" type="text" autocomplete="off" placeholder="Skanna och tryck Enter"></label> <button type="button" class="button" id="dw-barcode-find">Sök kod</button> <span id="dw-barcode-message" aria-live="polite"></span></p></div>';
  if($p){$code=current_user_can('pb_wms_manage')?self::ensure($p->get_id()):(string)$p->get_meta(self::META,true);echo '<h2>'.esc_html($p->get_name()).' – '.esc_html($p->get_sku()).'</h2>';self::label($p,$code);
   if(current_user_can('pb_wms_manage') && current_user_can('manage_woocommerce')){echo '<form class="dw-no-print" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dw_barcode_save');echo '<input type="hidden" name="action" value="dw_barcode_save"><input type="hidden" name="product_id" value="'.(int)$p->get_id().'"><label>Egen EAN/GTIN eller streckkod <input name="barcode" value="'.esc_attr($code).'" maxlength="64" size="36"></label> <button class="button">Spara</button></form>';}echo '<p class="dw-no-print"><button type="button" class="button" onclick="window.print()">Skriv ut etikett</button></p>';
  }else{
   $args=['limit'=>30,'orderby'=>'name','order'=>'ASC','status'=>['publish','private','draft','pending','future']];if($search!==''){$by_sku=wc_get_product_id_by_sku($search);if($by_sku)$args['include']=[$by_sku];else $args['s']=$search;}
   $products=wc_get_products($args);echo '<table class="widefat striped dw-bc-table"><thead><tr><th>Produkt</th><th>SKU</th><th>Streckkod</th><th>Etikett</th></tr></thead><tbody>';
   foreach($products as $item){$code=current_user_can('pb_wms_manage')?self::ensure($item->get_id()):(string)$item->get_meta(self::META,true);echo '<tr><td>'.esc_html($item->get_name()).'</td><td>'.esc_html($item->get_sku()).'</td><td><code>'.esc_html($code).'</code></td><td><a class="button" href="'.esc_url(self::url(['product_id'=>$item->get_id()])).'">Visa / skriv ut</a></td></tr>';}
   echo '</tbody></table>';
  }
  echo '<script>document.addEventListener("DOMContentLoaded",function(){var input=document.getElementById("dw-barcode-scan"),button=document.getElementById("dw-barcode-find"),msg=document.getElementById("dw-barcode-message");if(!input)return;function lookup(){var code=input.value.trim();if(!code)return;msg.textContent="Söker…";var data=new URLSearchParams({action:"dw_barcode_lookup",nonce:'.wp_json_encode(wp_create_nonce('dw_barcode_lookup')).',code:code});fetch('.wp_json_encode(admin_url('admin-ajax.php')).',{method:"POST",credentials:"same-origin",body:data}).then(function(r){return r.json()}).then(function(result){if(result.success&&result.data.url)window.location.href=result.data.url;else msg.textContent=(result.data&&result.data.message)||"Ingen träff";}).catch(function(){msg.textContent="Sökningen misslyckades.";});}button.addEventListener("click",lookup);input.addEventListener("keydown",function(e){if(e.key==="Enter"){e.preventDefault();lookup();}});});</script></div>';
 }
 static function label($p,$code){echo '<div class="dw-label"><strong>'.esc_html($p->get_name()).'</strong>'.self::svg($code).'<small>'.esc_html($code).'</small><small>SKU: '.esc_html($p->get_sku()).'</small></div>';}
}
Dennis_WMS_Barcodes::boot();
