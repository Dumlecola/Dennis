(function(){
  'use strict';
  var cfg=window.dennisPreorderAlert;
  if(!cfg)return;
  var tabs=document.querySelectorAll('.dw-appnav a[href*="page=dennis-wms-preorders"], #adminmenu a[href*="page=dennis-wms-preorders"], [data-dw-preorder-tab]');
  if(!tabs.length)return;
  function update(){
    var data=new URLSearchParams({action:'dennis_wms_preorder_alert',nonce:cfg.nonce});
    fetch(cfg.url,{method:'POST',credentials:'same-origin',body:data})
      .then(function(r){return r.json();})
      .then(function(r){
        if(!r.success||!r.data)return;
        var unseen=Math.max(0,parseInt(r.data.count,10)||0);
        var active=Math.max(0,parseInt(r.data.active,10)||0);
        tabs.forEach(function(tab){
          tab.classList.toggle('dw-preorder-new',active>0);
          var badge=tab.querySelector('.dw-preorder-badge');
          if(unseen>0){
            if(!badge){badge=document.createElement('span');badge.className='dw-preorder-badge';tab.appendChild(badge);}
            badge.textContent=unseen>99?'99+':String(unseen);
            badge.setAttribute('aria-label',unseen+' nya Pre-orders');
          }else if(badge){badge.remove();}
          if(active>0)tab.title=active+' Pre-orders väntar på inleverans'+(unseen?', '+unseen+' nya':'');
          else if(unseen>0)tab.title=unseen+' nya Pre-orders';
          else tab.removeAttribute('title');
        });
      }).catch(function(){});
  }
  update();
  setInterval(update,60000);
})();
