<?php
if (!defined('ABSPATH')) exit;
/** Authenticated encryption and authenticated delivery of WMS evidence. */
final class Dennis_WMS_Security {
 const FILE_PREFIX="DWMS-PRIVATE-1\n";
 const PRIVATE_META='_dennis_wms_private';
 static function boot(){
  add_action('admin_post_dennis_wms_private_image',[__CLASS__,'serve_image']);
  add_action('admin_post_nopriv_dennis_wms_private_image',[__CLASS__,'deny']);
  add_filter('wp_get_attachment_url',[__CLASS__,'attachment_url'],99,2);
  add_filter('image_downsize',[__CLASS__,'image_src'],99,3);
  add_filter('wp_calculate_image_srcset',[__CLASS__,'srcset'],99,5);
  add_filter('wp_prepare_attachment_for_js',[__CLASS__,'media_response'],99,3);
  add_filter('ajax_query_attachments_args',[__CLASS__,'media_query']);
  add_filter('rest_attachment_query',[__CLASS__,'media_query']);
  add_filter('rest_pre_dispatch',[__CLASS__,'rest_guard'],10,3);
  add_action('template_redirect',[__CLASS__,'attachment_guard']);
  add_action('admin_init',[__CLASS__,'migrate'],120);
  add_action('admin_notices',[__CLASS__,'notice']);
 }
 static function openssl_ready(){return function_exists('openssl_encrypt')&&function_exists('openssl_decrypt')&&in_array('aes-256-gcm',openssl_get_cipher_methods(),true);}
 static function ready(){return self::openssl_ready()||(function_exists('sodium_crypto_secretbox')&&function_exists('sodium_crypto_secretbox_open'));}
 static function key($purpose){return hash('sha256',wp_salt('auth').'|dennis-wms|'.$purpose,true);}
 static function encrypt($value,$purpose='secrets'){
  if(!self::ready())return new WP_Error('dw_crypto','Säker kryptering saknas på servern. Aktivera OpenSSL eller Sodium innan API-nycklar eller privata filer sparas.');
  if(!self::openssl_ready()){$nonce=random_bytes(24);return 'v3:'.base64_encode($nonce.sodium_crypto_secretbox((string)$value,$nonce,self::key($purpose)));}
  $iv=random_bytes(12);$tag='';$data=openssl_encrypt((string)$value,'aes-256-gcm',self::key($purpose),OPENSSL_RAW_DATA,$iv,$tag,'Dennis-WMS-'.$purpose,16);
  if($data===false||strlen($tag)!==16)return new WP_Error('dw_crypto','Krypteringen misslyckades. Inget sparades.');
  return 'v2:'.base64_encode($iv.$tag.$data);
 }
 static function decrypt($value,$purpose='secrets'){
  if(strpos((string)$value,'v3:')===0&&function_exists('sodium_crypto_secretbox_open')){$raw=base64_decode(substr($value,3),true);if($raw===false||strlen($raw)<40)return new WP_Error('dw_crypto','Ogiltig krypterad data.');$out=sodium_crypto_secretbox_open(substr($raw,24),substr($raw,0,24),self::key($purpose));return $out===false?new WP_Error('dw_crypto','Krypterad data har ändrats eller säkerhetsnyckeln stämmer inte.'):$out;}
  if(!self::openssl_ready()||strpos((string)$value,'v2:')!==0)return new WP_Error('dw_crypto','Filen eller nyckeln kan inte dekrypteras.');
  $data=base64_decode(substr($value,3),true);if($data===false||strlen($data)<28)return new WP_Error('dw_crypto','Ogiltig krypterad data.');
  $out=openssl_decrypt(substr($data,28),'aes-256-gcm',self::key($purpose),OPENSSL_RAW_DATA,substr($data,0,12),substr($data,12,16),'Dennis-WMS-'.$purpose);
  return $out===false?new WP_Error('dw_crypto','Krypterad data har ändrats eller säkerhetsnyckeln stämmer inte.'):$out;
 }
 static function safe_path($path){
  $u=wp_upload_dir();$base=realpath($u['basedir']);$real=realpath($path);
  return $base&&$real&&is_file($real)&&strpos(wp_normalize_path($real),trailingslashit(wp_normalize_path($base)))===0?$real:false;
 }
 static function write_private($bytes){
  $enc=self::encrypt($bytes,'files');if(is_wp_error($enc))return $enc;$u=wp_upload_dir();if(!empty($u['error']))return new WP_Error('dw_file','Uppladdningsmappen är inte tillgänglig.');
  $dir=trailingslashit($u['basedir']).'dennis-wms/private';if(!wp_mkdir_p($dir))return new WP_Error('dw_file','Kunde inte skapa privat lagring.');
  $base=realpath($u['basedir']);$real=realpath($dir);if(!$base||!$real||strpos(wp_normalize_path($real),trailingslashit(wp_normalize_path($base)))!==0)return new WP_Error('dw_path','Privat lagring har en otillåten sökväg.');
  $path=trailingslashit($dir).bin2hex(random_bytes(24)).'.bin';$data=self::FILE_PREFIX.$enc;
  if(file_put_contents($path,$data,LOCK_EX)!==strlen($data)){@unlink($path);return new WP_Error('dw_file','Kunde inte spara den privata filen.');}@chmod($path,0600);return $path;
 }
 static function seal($path){
  $path=self::safe_path($path);if(!$path)return new WP_Error('dw_path','Filens sökväg är inte tillåten.');$data=file_get_contents($path);if($data===false)return new WP_Error('dw_file','Filen kunde inte läsas.');
  if(strpos($data,self::FILE_PREFIX)===0){$check=self::decrypt(substr($data,strlen(self::FILE_PREFIX)),'files');return is_wp_error($check)?$check:true;}
  $enc=self::encrypt($data,'files');if(is_wp_error($enc))return $enc;$tmp=$path.'.'.bin2hex(random_bytes(12)).'.tmp';$out=self::FILE_PREFIX.$enc;
  if(file_put_contents($tmp,$out,LOCK_EX)!==strlen($out)||!rename($tmp,$path)){@unlink($tmp);return new WP_Error('dw_file','Filen kunde inte skyddas.');}@chmod($path,0600);return true;
 }
 static function read_private($path){$path=self::safe_path($path);if(!$path)return new WP_Error('dw_path','Filens sökväg är inte tillåten.');$data=file_get_contents($path);if($data===false||strpos($data,self::FILE_PREFIX)!==0)return new WP_Error('dw_file','Filen är inte skyddad.');return self::decrypt(substr($data,strlen(self::FILE_PREFIX)),'files');}
 static function upload_image($field,$title){
  if(!self::ready())return new WP_Error('dw_crypto','OpenSSL eller Sodium krävs för privata bilder.');
  $f=$_FILES[$field]??[];if(empty($f['tmp_name'])||!is_uploaded_file($f['tmp_name'])||!empty($f['error']))return new WP_Error('dw_image','Välj en bild att ladda upp.');
  if(filesize($f['tmp_name'])>12*1024*1024)return new WP_Error('dw_image','Bilden får vara högst 12 MB.');
  $info=@getimagesize($f['tmp_name']);$mime=$info['mime']??'';if(!$info||!in_array($mime,['image/jpeg','image/png','image/webp','image/gif'],true)||$info[0]>20000||$info[1]>20000)return new WP_Error('dw_image','Välj en giltig JPG-, PNG-, WebP- eller GIF-bild.');
  $bytes=file_get_contents($f['tmp_name']);if($bytes===false)return new WP_Error('dw_image','Bilden kunde inte läsas.');$path=self::write_private($bytes);if(is_wp_error($path))return $path;
  $id=wp_insert_attachment(['post_mime_type'=>$mime,'post_title'=>sanitize_text_field($title),'post_status'=>'inherit'],$path,0,true);
  if(is_wp_error($id)||!$id){@unlink($path);return is_wp_error($id)?$id:new WP_Error('dw_image','Bilden kunde inte registreras.');}
  if(update_post_meta($id,self::PRIVATE_META,1)===false){wp_delete_attachment($id,true);@unlink($path);return new WP_Error('dw_image','Bildens privata skydd kunde inte registreras.');}wp_update_attachment_metadata($id,['width'=>$info[0],'height'=>$info[1],'file'=>_wp_relative_upload_path($path),'sizes'=>[]]);return $id;
 }
 static function private_id($id){return (bool)get_post_meta($id,self::PRIVATE_META,true);}
 static function url($id){return wp_nonce_url(add_query_arg(['action'=>'dennis_wms_private_image','attachment_id'=>(int)$id],admin_url('admin-post.php')),'dennis_wms_private_image_'.(int)$id);}
 static function attachment_url($url,$id){return self::private_id($id)?(current_user_can('pb_wms_view')?self::url($id):''):$url;}
 static function image_src($out,$id,$size){if(!self::private_id($id))return $out;$m=wp_get_attachment_metadata($id);return [current_user_can('pb_wms_view')?self::url($id):'',(int)($m['width']??0),(int)($m['height']??0),false];}
 static function srcset($sources,$size,$src,$meta,$id){return self::private_id($id)?false:$sources;}
 static function media_response($r,$attachment,$meta){if(self::private_id($attachment->ID)){if(!current_user_can('pb_wms_view'))return false;$r['url']=self::url($attachment->ID);$r['sizes']=[];if(isset($r['originalImageURL']))$r['originalImageURL']=$r['url'];}return $r;}
 static function media_query($args){if(!current_user_can('pb_wms_view')){$original=$args['meta_query']??[];$args['meta_query']=['relation'=>'AND',['key'=>self::PRIVATE_META,'compare'=>'NOT EXISTS']];if($original)$args['meta_query'][]=$original;}return $args;}
 static function rest_guard($result,$server,$request){if(!current_user_can('pb_wms_view')&&preg_match('#^/wp/v2/media/(\d+)(?:/|$)#',$request->get_route(),$m)&&self::private_id((int)$m[1]))return new WP_Error('dw_private','Åtkomst nekad.',['status'=>403]);return $result;}
 static function attachment_guard(){if(is_attachment()&&self::private_id(get_queried_object_id())&&!current_user_can('pb_wms_view'))self::deny();}
 static function deny(){wp_die('Åtkomst nekad.',403);}
 static function serve_image(){
  if(!current_user_can('pb_wms_view'))self::deny();$id=absint($_GET['attachment_id']??0);check_admin_referer('dennis_wms_private_image_'.$id);if(!self::private_id($id))wp_die('Bilden saknas.',404);
  $data=self::read_private(get_attached_file($id));if(is_wp_error($data))wp_die('Bilden kunde inte öppnas.',404);$mime=get_post_mime_type($id);if(!in_array($mime,['image/jpeg','image/png','image/webp','image/gif'],true))wp_die('Otillåten filtyp.',403);
  nocache_headers();header('Cache-Control: private, no-store, max-age=0');header('X-Content-Type-Options: nosniff');header('Referrer-Policy: no-referrer');header('Content-Type: '.$mime);header('Content-Length: '.strlen($data));echo $data;exit;
 }
 static function shared_image($id){
  global $wpdb;$path=get_attached_file($id);$u=wp_upload_dir();$relative=ltrim(str_replace(trailingslashit($u['basedir']),'',(string)$path),'/');$stem=preg_replace('/\.[^.]+$/','',$relative);
  $used=$wpdb->get_var($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE (meta_key='_thumbnail_id' AND meta_value=%s) OR (meta_key='_product_image_gallery' AND (meta_value=%s OR meta_value LIKE %s OR meta_value LIKE %s OR meta_value LIKE %s)) LIMIT 1",(string)$id,(string)$id,$id.',%', '%,'.$id.',%', '%,'.$id));
  if($used)return true;return $stem!==''&&(bool)$wpdb->get_var($wpdb->prepare("SELECT ID FROM {$wpdb->posts} WHERE post_type!='attachment' AND post_content LIKE %s LIMIT 1",'%'.$wpdb->esc_like($stem).'%'));
 }
 static function protect_attachment($id){
  if(self::private_id($id)||!get_post($id))return true;if(self::shared_image($id))return new WP_Error('dw_shared','En äldre WMS-bild används också på en produktsida eller i annat innehåll. Den behöver hanteras separat.');
  $file=get_attached_file($id);if(!$file||!is_file($file))return new WP_Error('dw_file','En äldre WMS-bild saknar sin fil.');$meta=wp_get_attachment_metadata($id);$files=[$file];$dir=dirname($file);
  foreach(($meta['sizes']??[]) as $size)if(!empty($size['file']))$files[]=$dir.'/'.basename($size['file']);if(!empty($meta['original_image']))$files[]=$dir.'/'.basename($meta['original_image']);
  $backups=get_post_meta($id,'_wp_attachment_backup_sizes',true);foreach((array)$backups as $backup)if(!empty($backup['file']))$files[]=$dir.'/'.basename($backup['file']);
  foreach(array_unique($files) as $path){if(!is_file($path))continue;$ok=self::seal($path);if(is_wp_error($ok))return $ok;}
  if(update_post_meta($id,self::PRIVATE_META,1)===false&&!self::private_id($id))return new WP_Error('dw_file','Bildens privata skydd kunde inte registreras.');return true;
 }
 static function migrate(){
  if(!current_user_can('manage_options')||!self::ready()||get_option('dennis_wms_security_migrated')==='2.0.76')return;
  global $wpdb;$errors=[];$pending=(array)get_option('dennis_wms_security_pending',[]);$images=(array)($pending['images']??[]);$documents=(array)($pending['documents']??[]);$more=false;
  $shop_table=Dennis_WMS_Multi_Shop::table('shops');if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$shop_table))===$shop_table)foreach(Dennis_WMS_Multi_Shop::shops() as $shop){$updates=[];foreach(['consumer_key','consumer_secret'] as $field){$old=(string)$shop->$field;if($old===''||strpos($old,'v2:')===0||strpos($old,'v3:')===0)continue;$plain=Dennis_WMS_Multi_Shop::decrypt($old);if($plain===''){$errors[]='En äldre API-nyckel kunde inte läsas. Ange nyckeln igen.';continue;}$encrypted=self::encrypt($plain);if(!is_wp_error($encrypted))$updates[$field]=$encrypted;}if($updates&&Dennis_WMS_Audit::update($shop_table,$updates,['id'=>$shop->id])===false)$errors[]='API-nycklar kunde inte uppdateras.';}
  $settings=get_option('dennis_wms_delivery_settings',[]);foreach(['dhl_key','dsv_tracking_key','dsv_tracking_secondary_key','dsv_connect_access_key'] as $field){$old=(string)($settings[$field]??'');if($old===''||strpos($old,'v2:')===0||strpos($old,'v3:')===0)continue;$plain=(strpos($old,'v1:')===0||strpos($old,'plain:')===0)?Dennis_WMS_Multi_Shop::decrypt($old):$old;$encrypted=self::encrypt($plain);if($plain!==''&&!is_wp_error($encrypted))$settings[$field]=$encrypted;else $errors[]='En äldre trackingnyckel behöver anges igen.';}if($settings)update_option('dennis_wms_delivery_settings',$settings,false);
  foreach(['dennis_wms_receipt_images','dennis_wms_freight_docs'] as $suffix){$t=$wpdb->prefix.$suffix;if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$t))!==$t)continue;
   $cursor=(int)get_option('dennis_wms_security_cursor_'.$suffix,0);$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE id>%d ORDER BY id ASC LIMIT 25",$cursor));
   foreach($rows as $r){if($suffix==='dennis_wms_receipt_images')$images[(int)$r->attachment_id]=true;else $documents[(int)$r->id]=true;$cursor=(int)$r->id;}update_option('dennis_wms_security_cursor_'.$suffix,$cursor,false);if(count($rows)===25)$more=true;
  }
  if(!get_option('dennis_wms_security_orders_done')){$page=max(1,(int)get_option('dennis_wms_security_order_page',1));$orders=wc_get_orders(['limit'=>25,'page'=>$page,'meta_query'=>[['key'=>Dennis_WMS_Order_Images::META,'compare'=>'EXISTS']]]);foreach($orders as $order)foreach(Dennis_WMS_Order_Images::rows($order) as $r)if(!empty($r['attachment_id']))$images[(int)$r['attachment_id']]=true;if(count($orders)===25){update_option('dennis_wms_security_order_page',$page+1,false);$more=true;}else update_option('dennis_wms_security_orders_done',1,false);}
  foreach(array_slice(array_keys($images),0,50) as $id){$ok=self::protect_attachment((int)$id);if(is_wp_error($ok))$errors[]='Bild #'.$id.': '.$ok->get_error_message();else unset($images[$id]);}
  foreach(array_slice(array_keys($documents),0,25) as $id){$r=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.Dennis_WMS_Delivery::docs_table().' WHERE id=%d',(int)$id));if(!$r){unset($documents[$id]);continue;}$ok=self::seal($r->path);if(is_wp_error($ok))$errors[]='Fraktdokument #'.$id.': '.$ok->get_error_message();else unset($documents[$id]);}
  update_option('dennis_wms_security_pending',['images'=>$images,'documents'=>$documents],false);if($more||count($images)>50||count($documents)>25)$errors[]='Skydd av äldre filer fortsätter nästa gång en adminsida öppnas.';
  $errors=array_values(array_unique($errors));update_option('dennis_wms_security_issues',$errors,false);if(!$errors&&!$images&&!$documents&&!$more)update_option('dennis_wms_security_migrated','2.0.76',false);
 }
 static function notice(){if(!current_user_can('manage_options'))return;if(!self::ready())echo '<div class="notice notice-error"><p>Dennis WMS: OpenSSL eller Sodium krävs för säker lagring av API-nycklar och privata filer. Nya sådana uppgifter kan inte sparas förrän krypteringsstödet är aktiverat.</p></div>';foreach((array)get_option('dennis_wms_security_issues',[]) as $issue)echo '<div class="notice notice-warning"><p>Dennis WMS: '.esc_html($issue).'</p></div>';}
}
Dennis_WMS_Security::boot();
