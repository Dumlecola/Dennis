<?php
if (!defined('ABSPATH')) exit;
/** Shipping deadline / flag system. Before 12:00 => 12:00 same day; from 12:00 => 12:00 next day. */
final class Dennis_WMS_Deadline {
 const SCHEMA='1.9.5'; const CAP='pb_wms_manage';
 static function table(){global $wpdb;return $wpdb->prefix.'dennis_wms_deadlines';}
 static function boot(){add_action('admin_post_dennis_wms_deadline_save',[__CLASS__,'save']);add_action('admin_init',[__CLASS__,'upgrade']);}
 static function install(){global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$c=$wpdb->get_charset_collate();$t=self::table();dbDelta("CREATE TABLE $t (id bigint(20) unsigned NOT NULL AUTO_INCREMENT,shop_key varchar(80) NOT NULL,order_ref bigint(20) unsigned NOT NULL,mode varchar(20) NOT NULL DEFAULT 'auto',custom_deadline datetime NULL,reason text NULL,dispatched_at datetime NULL,history longtext NULL,updated_at datetime NOT NULL,updated_by bigint(20) unsigned NOT NULL DEFAULT 0,PRIMARY KEY (id),UNIQUE KEY order_key (shop_key,order_ref),KEY deadline_mode (mode,custom_deadline)) $c;");update_option('dennis_wms_deadline_schema',self::SCHEMA);}
 static function upgrade(){if(get_option('dennis_wms_deadline_schema')!==self::SCHEMA)self::install();}
 static function record($shop,$ref){global $wpdb;return $wpdb->get_row($wpdb->prepare('SELECT * FROM '.self::table().' WHERE shop_key=%s AND order_ref=%d',$shop,absint($ref)));}
 static function history($r){$h=$r&&isset($r->history)?json_decode((string)$r->history,true):[];return is_array($h)?$h:[];}
 static function tz(){return function_exists('wp_timezone')?wp_timezone():new DateTimeZone('UTC');}
 static function parse_local($s){if(!$s)return null;try{return new DateTimeImmutable($s,self::tz());}catch(Exception $e){return null;}}
 static function created($shop,$ref,$object=null){
  if($shop==='local'){$o=$object;if(!$o&&function_exists('wc_get_order'))$o=wc_get_order($ref);if($o&&is_a($o,'WC_Order')&&$o->get_date_created()){try{return new DateTimeImmutable($o->get_date_created()->date('Y-m-d H:i:s'),self::tz());}catch(Exception $e){}}}
  elseif($object&&isset($object->date_created)&&$object->date_created){$d=self::parse_local((string)$object->date_created);if($d)return $d;}
  elseif(class_exists('Dennis_WMS_Multi_Shop')){$r=Dennis_WMS_Multi_Shop::get_cached_order($ref);if($r&&!empty($r->date_created)){$d=self::parse_local((string)$r->date_created);if($d)return $d;}}
  return null;
 }
 static function delivery_record($shop,$ref){return class_exists('Dennis_WMS_Delivery')?Dennis_WMS_Delivery::record($shop,$ref):null;}
 static function due($shop,$ref,$object=null){
  $r=self::record($shop,$ref);if($r&&$r->mode==='none')return null;
  if($r&&$r->mode==='custom'&&!empty($r->custom_deadline))return self::parse_local($r->custom_deadline);
  $created=self::created($shop,$ref,$object);if(!$created)return null;
  return ((int)$created->format('Hi')<1200)?$created->setTime(12,0,0):$created->modify('+1 day')->setTime(12,0,0);
 }
 static function state($shop,$ref,$object=null){
  $r=self::record($shop,$ref);$dr=self::delivery_record($shop,$ref);$method=$dr?(string)$dr->method:'';
  if(in_array($method,['pickup','internal'],true))return ['key'=>'inactive','label'=>'Ingen fraktdeadline','kind'=>'gray','due'=>null,'exception'=>false];
  if($r&&$r->mode==='none')return ['key'=>'none','label'=>'Undantag · ingen deadline','kind'=>'purple','due'=>null,'exception'=>true];
  $due=self::due($shop,$ref,$object);$exception=$r&&$r->mode==='custom';
  if(!$due)return ['key'=>'unknown','label'=>'Deadline saknas','kind'=>'gray','due'=>null,'exception'=>$exception];
  $dispatch='';if($r&&!empty($r->dispatched_at))$dispatch=(string)$r->dispatched_at;elseif($dr&&$dr->method==='ship'&&$dr->status==='dispatched')$dispatch=(string)$dr->updated_at;
  if($dispatch){$dt=self::parse_local($dispatch);$late=$dt&&$dt>$due;return ['key'=>$late?'sent_late':'sent_ok','label'=>$late?'Skickad för sent':'Skickad i tid','kind'=>$late?'orange':'green','due'=>$due,'exception'=>$exception];}
  $now=new DateTimeImmutable('now',self::tz());$seconds=$due->getTimestamp()-$now->getTimestamp();
  if($seconds<0)return ['key'=>'overdue','label'=>'Försenad','kind'=>'red','due'=>$due,'exception'=>$exception];
  if($due->format('Y-m-d')===$now->format('Y-m-d')){if($seconds<=2*HOUR_IN_SECONDS)return ['key'=>'urgent','label'=>'Brådskande','kind'=>'red','due'=>$due,'exception'=>$exception];return ['key'=>'today','label'=>'Ska skickas idag','kind'=>'yellow','due'=>$due,'exception'=>$exception];}
  return ['key'=>'ontime','label'=>'I tid','kind'=>'green','due'=>$due,'exception'=>$exception];
 }
 static function badge($shop,$ref,$object=null){$s=self::state($shop,$ref,$object);$due=$s['due'];$prefix=$s['exception']?'🟣 ':'';$icons=['overdue'=>'🚨 ','urgent'=>'🔴 ','today'=>'🟡 ','ontime'=>'🟢 ','sent_ok'=>'✅ ','sent_late'=>'⚠️ ','inactive'=>'','none'=>''];$icon=$prefix?:($icons[$s['key']]??'');$style=['red'=>'background:#ffe3e3;color:#9b1c1c;border-color:#ffb3b3','yellow'=>'background:#fff4cc;color:#735c00;border-color:#f0d36b','green'=>'background:#ddf7e5;color:#176b35;border-color:#9ad8ae','purple'=>'background:#f2e6ff;color:#6b2ca0;border-color:#d3b1ef','orange'=>'background:#ffe9d6;color:#8a4300;border-color:#ffc58f','gray'=>'background:#f1f3f5;color:#59636e;border-color:#d8dde2'][$s['kind']]??'background:#eef6ff;color:#24557a;border-color:#c9def2';$text=$icon.$s['label'];if($due)$text.=' · '.$due->format('j M H:i');return '<span class="dw-deadline-badge" style="display:inline-block;border:1px solid;padding:4px 8px;border-radius:999px;font-weight:700;white-space:nowrap;'.$style.'">'.esc_html($text).'</span>';}
 static function sort_value($order){$s=self::state('local',$order->get_id(),$order);if(in_array($s['key'],['sent_ok','sent_late','inactive','none'],true))return PHP_INT_MAX-1000;if(!$s['due'])return PHP_INT_MAX;return $s['due']->getTimestamp();}
 static function dashboard_counts(){$out=['today'=>0,'urgent'=>0,'overdue'=>0];if(function_exists('wc_get_orders')){$orders=wc_get_orders(['status'=>['processing','on-hold'],'limit'=>-1,'return'=>'objects']);foreach($orders as $o){self::add_count($out,self::state('local',$o->get_id(),$o));}}if(class_exists('Dennis_WMS_Multi_Shop')){foreach(Dennis_WMS_Multi_Shop::remote_orders(1000) as $r)self::add_count($out,self::state('remote:'.(int)$r->shop_id,(int)$r->id,$r));}return $out;}
 static function add_count(&$out,$s){if($s['key']==='overdue')$out['overdue']++;if($s['key']==='urgent'){$out['urgent']++;$out['today']++;}elseif($s['key']==='today')$out['today']++;}
 static function capture_dispatch($shop,$ref,$status){if($status!=='dispatched')return;$r=self::record($shop,$ref);if($r&&!empty($r->dispatched_at))return;global $wpdb;$now=current_time('mysql');if($r)Dennis_WMS_Audit::update(self::table(),['dispatched_at'=>$now,'updated_at'=>$now,'updated_by'=>get_current_user_id()],['id'=>$r->id]);else Dennis_WMS_Audit::insert(self::table(),['shop_key'=>$shop,'order_ref'=>absint($ref),'mode'=>'auto','dispatched_at'=>$now,'history'=>'[]','updated_at'=>$now,'updated_by'=>get_current_user_id()]);}
 static function save(){
  if(!current_user_can(self::CAP))wp_die('Åtkomst nekad.',403);check_admin_referer('dennis_wms_deadline_save');self::install();$shop=sanitize_text_field(wp_unslash($_POST['shop_key']??'local'));if($shop!=='local'&&!preg_match('/^remote:\d+$/',$shop))wp_die('Ogiltig shop.',400);$ref=absint($_POST['order_ref']??0);if(!$ref)wp_die('Order saknas.',400);$action=sanitize_key(wp_unslash($_POST['deadline_action']??''));$reason=sanitize_textarea_field(wp_unslash($_POST['reason']??''));$old=self::record($shop,$ref);$old_due=self::due($shop,$ref);$mode='auto';$custom=null;
  if(in_array($action,['tomorrow','custom','none'],true)&&$reason==='')wp_die('Ange en anledning till undantaget.',400);
  if($action==='tomorrow'){$mode='custom';$custom=(new DateTimeImmutable('tomorrow',self::tz()))->setTime(12,0)->format('Y-m-d H:i:s');}
  elseif($action==='custom'){$date=sanitize_text_field(wp_unslash($_POST['deadline_date']??''));$time=sanitize_text_field(wp_unslash($_POST['deadline_time']??'12:00'));if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date)||!preg_match('/^\d{2}:\d{2}$/',$time))wp_die('Välj ett giltigt datum och klockslag.',400);$d=self::parse_local($date.' '.$time.':00');if(!$d)wp_die('Ogiltig deadline.',400);$mode='custom';$custom=$d->format('Y-m-d H:i:s');}
  elseif($action==='none'){$mode='none';}
  elseif($action==='auto'){$mode='auto';$reason='Återställd till standardregeln.';}else wp_die('Ogiltigt val.',400);
  $hist=self::history($old);array_unshift($hist,['time'=>current_time('mysql'),'user'=>get_current_user_id(),'action'=>$action,'reason'=>$reason,'old_deadline'=>$old_due?$old_due->format('Y-m-d H:i:s'):'','new_deadline'=>$custom?:($mode==='none'?'ingen':'auto')]);$data=['shop_key'=>$shop,'order_ref'=>$ref,'mode'=>$mode,'custom_deadline'=>$custom,'reason'=>$reason,'history'=>wp_json_encode(array_slice($hist,0,100),JSON_UNESCAPED_UNICODE),'updated_at'=>current_time('mysql'),'updated_by'=>get_current_user_id()];if($old){$wpdb=$GLOBALS['wpdb'];Dennis_WMS_Audit::update(self::table(),$data,['id'=>$old->id]);}else{$wpdb=$GLOBALS['wpdb'];Dennis_WMS_Audit::insert(self::table(),$data);}
  $return=sanitize_key(wp_unslash($_POST['return_to']??'local'));$url=$return==='remote'?admin_url('admin.php?page=dennis-wms-shops&view=order&remote_order_id='.$ref):admin_url('admin.php?page=dennis-wms-orders&order_id='.$ref);wp_safe_redirect(add_query_arg('dw_deadline_saved','1',$url));exit;
 }
 static function render_order_section($shop,$ref,$return='local',$object=null){
  $s=self::state($shop,$ref,$object);$r=self::record($shop,$ref);$due=$s['due'];$tomorrow=(new DateTimeImmutable('tomorrow',self::tz()))->format('j F Y');echo '<section id="dw-deadline" class="dw-order-section" style="margin-top:16px"><div class="dw-section-head"><div><span class="dashicons dashicons-clock"></span><div><h2>Skickdeadline</h2><p>Huvudregel: order före kl. 12:00 försöker vi skicka senast kl. 12:00 samma dag. Order från kl. 12:00 får deadline kl. 12:00 nästa dag.</p></div></div></div><div style="padding:16px">';echo '<p>'.self::badge($shop,$ref,$object).'</p>';if($due)echo '<p><strong>Aktuell deadline:</strong> '.esc_html($due->format('Y-m-d H:i')).'</p>';if($s['key']==='inactive')echo '<div class="notice notice-info inline"><p>Kundhämtning/intern order har ingen fraktdeadline.</p></div>';
  echo '<div class="dw-deadline-actions" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px">';
  echo self::exception_form($shop,$ref,$return,'tomorrow','Skickas imorgon','Flytta deadline till '.$tomorrow.' kl. 12:00',false);
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="border:1px solid #dcdcde;border-radius:10px;padding:12px">'.self::hidden($shop,$ref,$return).'<h3>Specifikt datum</h3><p><input type="date" name="deadline_date" required> <input type="time" name="deadline_time" value="12:00" required></p><p><textarea name="reason" required rows="2" style="width:100%" placeholder="Anledning"></textarea></p><button class="button button-primary" name="deadline_action" value="custom">Spara datum</button></form>';
  echo self::exception_form($shop,$ref,$return,'none','Ingen deadline','Undanta ordern helt från fraktdeadline.',true);
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="border:1px solid #dcdcde;border-radius:10px;padding:12px">'.self::hidden($shop,$ref,$return).'<h3>Återställ</h3><p>Tillbaka till standard: före kl. 12:00 = kl. 12:00 samma dag; från kl. 12:00 = kl. 12:00 nästa dag.</p><button class="button" name="deadline_action" value="auto">Återställ standard</button></form></div>';
  $h=self::history($r);if($h){echo '<details style="margin-top:14px"><summary>Undantagshistorik ('.count($h).')</summary><table class="widefat striped" style="margin-top:8px"><thead><tr><th>Tid</th><th>Användare</th><th>Ändring</th><th>Anledning</th></tr></thead><tbody>';foreach(array_slice($h,0,20) as $e){$u=get_userdata((int)($e['user']??0));echo '<tr><td>'.esc_html($e['time']??'').'</td><td>'.esc_html($u?$u->display_name:'Okänd').'</td><td>'.esc_html($e['action']??'').'</td><td>'.esc_html($e['reason']??'').'</td></tr>';}echo '</tbody></table></details>';}echo '</div></section>';
 }
 static function hidden($shop,$ref,$return){return wp_nonce_field('dennis_wms_deadline_save','_wpnonce',true,false).'<input type="hidden" name="action" value="dennis_wms_deadline_save"><input type="hidden" name="shop_key" value="'.esc_attr($shop).'"><input type="hidden" name="order_ref" value="'.esc_attr($ref).'"><input type="hidden" name="return_to" value="'.esc_attr($return).'">';}
 static function exception_form($shop,$ref,$return,$action,$title,$desc,$danger=false){return '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="border:1px solid #dcdcde;border-radius:10px;padding:12px">'.self::hidden($shop,$ref,$return).'<h3>'.esc_html($title).'</h3><p>'.esc_html($desc).'</p><p><textarea name="reason" required rows="2" style="width:100%" placeholder="Anledning"></textarea></p><button class="button'.($danger?'':' button-primary').'" name="deadline_action" value="'.esc_attr($action).'">'.esc_html($title).'</button></form>';}
}
Dennis_WMS_Deadline::boot();
