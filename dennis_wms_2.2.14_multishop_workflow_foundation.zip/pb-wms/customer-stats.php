<?php
if(!defined('ABSPATH'))exit;
final class Dennis_WMS_Customer_Stats {
 static function boot(){add_action('admin_menu',[__CLASS__,'menu'],108);}
 static function menu(){add_submenu_page('pb-wms','Statistik per säljare','Statistik per säljare','pb_wms_view','dennis-wms-customer-stats',[__CLASS__,'page']);}
 static function normalize($name){$name=preg_replace('/\s+/u',' ',trim((string)$name));return function_exists('mb_strtolower')?mb_strtolower($name,'UTF-8'):strtr(strtolower($name),['Å'=>'å','Ä'=>'ä','Ö'=>'ö']);}
 static function destination($order){
  $parts=[];foreach(['shipping_company','shipping_address_1','shipping_address_2'] as $field){$method='get_'.$field;$value=trim((string)$order->$method());if($value!=='')$parts[]=$value;}
  $town=trim($order->get_shipping_postcode().' '.$order->get_shipping_city());if($town!=='')$parts[]=$town;$country=trim((string)$order->get_shipping_country());if($country!=='')$parts[]=$country;
  return $parts?implode(', ',$parts):'Leveransplats ej angiven';
 }
 static function aggregate($orders,$delivery,$search='',$product_id=0){
  $rows=[];$search=self::normalize($search);
  foreach($orders as $o){$items=$o->get_items('line_item');if($product_id){$items=array_filter($items,fn($item)=>(int)($item->get_variation_id()?:$item->get_product_id())===$product_id);if(!$items)continue;}$name=trim((string)$o->get_formatted_billing_full_name());if($name==='')$name='Namn saknas';$key=self::normalize($name);if($search!==''&&strpos($key,$search)===false)continue;
   if(!isset($rows[$key]))$rows[$key]=['name'=>$name,'orders'=>0,'units'=>0,'ship'=>0,'pickup'=>0,'internal'=>0,'other'=>0,'carriers'=>[],'products'=>[],'details'=>[],'destinations'=>[]];
   $r=&$rows[$key];$r['orders']++;$units=0;
   foreach($items as $item){$q=max(0,(float)$item->get_quantity());$units+=$q;$p=$item->get_product();$sku=$p?$p->get_sku():'';$product_key=$p?'id:'.$p->get_id():'name:'.$item->get_name();if(!isset($r['products'][$product_key]))$r['products'][$product_key]=['name'=>$item->get_name(),'sku'=>$sku,'units'=>0];$r['products'][$product_key]['units']+=$q;}
   $r['units']+=$units;$d=$delivery[$o->get_id()]??null;$method='other';$carrier='';
   if($d&&in_array($d->method,['ship','pickup','internal'],true)&&$d->status===Dennis_WMS_Delivery::final_status($d->method)){$method=$d->method;if($method==='ship'){$carrier=$d->carrier!==''?strtoupper($d->carrier):'Ej angiven';$r['carriers'][$carrier]=($r['carriers'][$carrier]??0)+1;}}
   $destination=self::destination($o);$dest_key=self::normalize($destination);if(!isset($r['destinations'][$dest_key]))$r['destinations'][$dest_key]=['name'=>$destination,'orders'=>0,'units'=>0,'ship'=>0,'pickup'=>0,'internal'=>0,'other'=>0,'carriers'=>[]];$place=&$r['destinations'][$dest_key];$place['orders']++;$place['units']+=$units;$place[$method]++;if($carrier!=='')$place['carriers'][$carrier]=($place['carriers'][$carrier]??0)+1;unset($place);
   $r[$method]++;$date=$o->get_date_created();$r['details'][]=['id'=>$o->get_id(),'number'=>$o->get_order_number(),'date'=>$date?$date->date_i18n('Y-m-d H:i'):'–','units'=>$units,'destination'=>$destination,'method'=>$method,'carrier'=>$carrier];unset($r);
  }
  uasort($rows,fn($a,$b)=>strnatcasecmp(self::normalize($a['name']),self::normalize($b['name'])));return array_values($rows);
 }
 static function data($days,$search='',$product_id=0){
  $after=(new DateTimeImmutable('now',wp_timezone()))->modify('-'.absint($days).' days')->format('Y-m-d H:i:s');$orders=[];$page=1;
  do{$result=wc_get_orders(['date_created'=>'>='.$after,'status'=>['pending','on-hold','processing','completed'],'limit'=>100,'page'=>$page,'paginate'=>true,'orderby'=>'date','order'=>'DESC']);foreach($result->orders as $o)$orders[]=$o;$page++;}while($page<=(int)$result->max_num_pages);
  global $wpdb;$t=Dennis_WMS_Delivery::table();$delivery=[];foreach($wpdb->get_results("SELECT order_ref,method,status,carrier FROM $t WHERE shop_key='local'") as $r)$delivery[(int)$r->order_ref]=$r;
  return self::aggregate($orders,$delivery,$search,$product_id);
 }
 static function render($rows,$details=false){
  echo '<p>Huvudshoppen: säljare grupperas efter beställarens faktureringsnamn på ordern. Leveransplats hämtas från leveransadressen (företag, gata, postnummer, ort och land). Samma namn räknas ihop, även för olika kundkonton. Perioden gäller när ordern skapades. Avbrutna, misslyckade och helt återbetalda order ingår inte. Leveranskolumnerna visar aktuell avslutad WMS-status för dessa order.</p><table class="widefat striped"><thead><tr><th>Säljarens namn</th><th>Order</th><th>Beställda enheter</th><th>Skickade</th><th>Kundhämtade</th><th>Utlämnade internt</th><th>Övriga / ej avslutade</th><th>Antal order per transportör</th></tr></thead><tbody>';
  foreach($rows as $r){$carriers=[];foreach($r['carriers'] as $name=>$n)$carriers[]=$name.': '.$n.' order';echo '<tr><td><strong>'.esc_html($r['name']).'</strong></td>';foreach(['orders','units','ship','pickup','internal','other'] as $k)echo '<td>'.esc_html($r[$k]).'</td>';echo '<td>'.esc_html($carriers?implode(' · ',$carriers):'–').'</td></tr>';}
  if(!$rows)echo '<tr><td colspan="8">Inga säljare matchar vald period och namn.</td></tr>';echo '</tbody></table>';
  foreach($rows as $r){echo '<h3>'.esc_html($r['name']).' – per leveransplats</h3><table class="widefat striped"><thead><tr><th>Leveransplats</th><th>Order</th><th>Beställda enheter</th><th>Skickade</th><th>Kundhämtade</th><th>Internt utlämnade</th><th>Övriga / ej avslutade</th><th>Antal order per transportör</th></tr></thead><tbody>';foreach($r['destinations'] as $d){$carriers=[];foreach($d['carriers'] as $carrier=>$n)$carriers[]=$carrier.': '.$n.' order';echo '<tr><td>'.esc_html($d['name']).'</td>';foreach(['orders','units','ship','pickup','internal','other'] as $k)echo '<td>'.esc_html($d[$k]).'</td>';echo '<td>'.esc_html($carriers?implode(' · ',$carriers):'–').'</td></tr>';}echo '</tbody></table>';}
  if($details)foreach($rows as $r){echo '<details class="dw-customer-details"><summary>'.esc_html($r['name']).' – order och artiklar</summary><table class="widefat striped"><thead><tr><th>Order</th><th>Skapad</th><th>Leveransplats</th><th>Enheter</th><th>Leverans</th><th>Transportör</th></tr></thead><tbody>';foreach($r['details'] as $o){$method=['ship'=>'Skickad','pickup'=>'Hämtad av kund','internal'=>'Utlämnad internt','other'=>'Övrig / ej avslutad'][$o['method']];echo '<tr><td><a href="'.esc_url(Dennis_WMS_Orders::url($o['id'])).'">#'.esc_html($o['number']).'</a></td><td>'.esc_html($o['date']).'</td><td>'.esc_html($o['destination']).'</td><td>'.esc_html($o['units']).'</td><td>'.esc_html($method).'</td><td>'.esc_html($o['carrier']?:'–').'</td></tr>';}echo '</tbody></table><table class="widefat striped"><thead><tr><th>Produkt</th><th>SKU</th><th>Beställda enheter</th></tr></thead><tbody>';foreach($r['products'] as $p)echo '<tr><td>'.esc_html($p['name']).'</td><td>'.esc_html($p['sku']?:'–').'</td><td>'.esc_html($p['units']).'</td></tr>';echo '</tbody></table></details>';}
 }
 static function page(){
  if(!current_user_can('pb_wms_view'))wp_die('Åtkomst nekad.',403);$days=absint($_GET['dw_days']??30);if(!in_array($days,[7,30,90,365],true))$days=30;$name=sanitize_text_field(wp_unslash($_GET['customer_name']??''));
  echo '<div class="wrap"><h1>Statistik per säljare</h1><form method="get"><input type="hidden" name="page" value="dennis-wms-customer-stats"><label>Säljarens namn <input name="customer_name" value="'.esc_attr($name).'" placeholder="Sök namn"></label> <label>Period <select name="dw_days">';foreach([7,30,90,365] as $d)echo '<option value="'.$d.'" '.selected($d,$days,false).'>'.$d.' dagar</option>';echo '</select></label> <button class="button">Visa</button></form><p>Senaste '.esc_html($days).' dagarna'.($name!==''?' · Namn: '.esc_html($name):'').'</p>';self::render(self::data($days,$name),true);echo '</div>';
 }
}
Dennis_WMS_Customer_Stats::boot();
