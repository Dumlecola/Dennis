<?php
if (!defined('ABSPATH')) exit;
/** SKU recipes. Finished kits use native Woo stock; pick-time kits consume their components. */
final class Dennis_WMS_Kits {
 const META='_dennis_wms_kit';
 const SNAPSHOT='_dennis_wms_kit_recipe';
 const SCHEMA='1';
 static $failed=[],$refund_context=[];
 static function table(){global $wpdb;return $wpdb->prefix.'dennis_wms_kit_operations';}
 static function boot(){
  add_action('admin_menu',[__CLASS__,'menu'],107);
  add_action('admin_init',[__CLASS__,'upgrade']);
  add_action('admin_init',[__CLASS__,'repair_physical_stock_status']);
  add_action('admin_post_dennis_wms_restore_stock_control',[__CLASS__,'restore_stock_control']);
  add_action('admin_post_dennis_wms_product_packing',[__CLASS__,'save_product_packing']);
  add_action('admin_post_dennis_wms_kit_save',[__CLASS__,'save']);
  add_action('admin_post_dennis_wms_kit_assemble',[__CLASS__,'assemble']);
  add_action('admin_post_dennis_wms_kit_retry',[__CLASS__,'retry']);
  add_action('wp_ajax_dennis_wms_kit_lookup',[__CLASS__,'lookup']);
  add_action('admin_enqueue_scripts',[__CLASS__,'assets']);
  add_action('woocommerce_checkout_create_order_line_item',[__CLASS__,'checkout_snapshot'],10,4);
  add_action('woocommerce_new_order_item',[__CLASS__,'new_item'],10,3);
  add_action('woocommerce_before_order_item_object_save',[__CLASS__,'protect_item'],10,2);
  add_filter('woocommerce_can_reduce_order_stock',[__CLASS__,'reduce'],9999,2);
  add_action('woocommerce_restore_order_stock',[__CLASS__,'restore'],10);
  add_action('woocommerce_create_refund',[__CLASS__,'refund_context'],10,2);
  add_action('woocommerce_refund_created',[__CLASS__,'clear_refund_context'],10,2);
  add_filter('woocommerce_can_restock_refunded_items',[__CLASS__,'refund'],9999,3);
  add_action('shutdown',[__CLASS__,'reset_failed_flags']);
  add_filter('woocommerce_product_get_manage_stock',[__CLASS__,'manage_stock'],9999,2);
  add_filter('woocommerce_product_get_stock_quantity',[__CLASS__,'stock_quantity'],9999,2);
  add_filter('woocommerce_product_get_stock_status',[__CLASS__,'stock_status'],9999,2);
  add_filter('woocommerce_product_is_in_stock',[__CLASS__,'in_stock'],9999,2);
  add_filter('woocommerce_product_backorders_allowed',[__CLASS__,'backorders'],9999,3);
  add_filter('woocommerce_admin_stock_html',[__CLASS__,'admin_stock_html'],9999,2);
  add_filter('woocommerce_add_to_cart_validation',[__CLASS__,'cart_add'],9999,6);
  add_action('woocommerce_check_cart_items',[__CLASS__,'cart_check']);
 }
 static function menu(){add_submenu_page('pb-wms','För-packade produkter','För-packade produkter','pb_wms_view','dennis-wms-kits',[__CLASS__,'page']);}
 static function install(){
  global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::table();$c=$wpdb->get_charset_collate();
  dbDelta("CREATE TABLE $t (
 id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
 operation_key varchar(190) NOT NULL,
 kind varchar(20) NOT NULL,
 product_id bigint(20) unsigned NOT NULL,
 order_id bigint(20) unsigned NOT NULL DEFAULT 0,
 item_id bigint(20) unsigned NOT NULL DEFAULT 0,
 quantity decimal(18,4) NOT NULL,
 remaining decimal(18,4) NOT NULL DEFAULT 0,
 recipe longtext NOT NULL,
 allocations longtext NOT NULL,
 user_id bigint(20) unsigned NOT NULL DEFAULT 0,
 created_at datetime NOT NULL,
 PRIMARY KEY  (id),
 UNIQUE KEY operation_key (operation_key),
 KEY order_item (order_id,item_id),
 KEY product_id (product_id)
) $c;");
  if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$t))===$t)update_option('dennis_wms_kit_schema',self::SCHEMA,false);
 }
 static function upgrade(){if(current_user_can('manage_options')&&get_option('dennis_wms_kit_schema')!==self::SCHEMA)self::install();}
 static function ready(){if(get_option('dennis_wms_kit_schema')!==self::SCHEMA)throw new Exception('Registret för För-packade produkter behöver uppdateras. Öppna WMS som administratör först.');if(get_option('woocommerce_manage_stock')!=='yes')throw new Exception('Aktivera lagerhantering i WooCommerce innan ni använder förpackning.');}
 static function recipe($id){$r=get_post_meta((int)$id,self::META,true);return is_array($r)&&in_array($r['mode']??'',['pick','packed'],true)&&!empty($r['components'])?$r:[];}
 static function on_demand($product){return $product&&(self::recipe($product->get_id())['mode']??'')==='pick';}
 static function item_recipe($item){$r=$item->get_meta(self::SNAPSHOT,true);return is_array($r)&&in_array($r['mode']??'',['pick','packed'],true)&&!empty($r['components'])?$r:self::recipe($item->get_variation_id()?:$item->get_product_id());}
 static function item_on_demand($item){return (self::item_recipe($item)['mode']??'')==='pick';}
 static function checkout_snapshot($item,$key,$values,$order){$p=$item->get_product();if($p&&($r=self::recipe($p->get_id())))$item->add_meta_data(self::SNAPSHOT,$r,true);}
 static function new_item($id,$item,$order_id){if(!is_a($item,'WC_Order_Item_Product')||$item->get_meta(self::SNAPSHOT,true))return;$p=$item->get_product();if($p&&($r=self::recipe($p->get_id()))){$item->add_meta_data(self::SNAPSHOT,$r,true);$item->save_meta_data();}}
 static function active($order_id,$item_id){global $wpdb;$t=self::table();return $wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE kind='order' AND order_id=%d AND item_id=%d AND remaining>0 ORDER BY id DESC LIMIT 1",$order_id,$item_id));}
 static function protect_item($item,$store){
  if(!is_a($item,'WC_Order_Item_Product')||!$item->get_id()||!self::item_on_demand($item))return;
  $changes=$item->get_changes();if(!array_intersect(['quantity','product_id','variation_id'],array_keys($changes)))return;
  if(self::active($item->get_order_id(),$item->get_id()))throw new Exception('Förpackningens lager är redan uttaget. Återställ orderlagret innan SKU eller antal ändras.');
 }
 static function integer($value){$v=filter_var($value,FILTER_VALIDATE_INT,['options'=>['min_range'=>1,'max_range'=>1000000]]);if($v===false)throw new Exception('Ange ett helt antal mellan 1 och 1 000 000.');return $v;}
 static function validate($main,$mode,$rows,$base=false,$accompanying=false){
  if(!$accompanying&&$main&&get_post_meta($main->get_id(),'_dennis_wms_kit_component_used',true)==='yes')throw new Exception('Denna SKU används eller har använts som ingående produkt. Välj en egen huvud-SKU.');
  if(!$main||!$main->is_type('simple')||$main->get_sku()==='')throw new Exception('Förpackningens SKU måste vara en enkel WooCommerce-produkt med SKU.');
  if(!in_array($mode,['pick','packed'],true))throw new Exception('Välj hur förpackningen ska packas.');
  if(count($rows)<1||count($rows)>100)throw new Exception('Lägg till 1–100 komponenter.');$out=[];
  foreach($rows as $row){$sku=trim((string)($row['sku']??''));$q=$row['qty']??'';if($sku===''&&($q===''||$q===null))continue;$n=self::integer($q);$id=wc_get_product_id_by_sku($sku);$p=$id?wc_get_product($id):false;
   if(!$p||$p->get_sku()===''||!$p->is_type(['simple','variation'])||(!$p->managing_stock()&&!($accompanying&&!empty(self::recipe($id)['accompanying'])&&self::base_product($id)))||$p->get_stock_managed_by_id()!==$p->get_id()||$p->get_stock_quantity('edit')===null)throw new Exception('Komponenten '.$sku.' behöver ett eget lagerstyrt saldo.');
   if($id===$main->get_id()||(self::recipe($id)&&!($accompanying&&!empty(self::recipe($id)['accompanying'])&&self::base_product($id))))throw new Exception('Ett förpackning kan inte innehålla sig självt eller ett annat förpackning.');
   if(isset($out[$id]))throw new Exception('SKU '.$sku.' finns redan i förpackningen.');
   $out[$id]=['product_id'=>$id,'sku'=>$p->get_sku(),'name'=>$p->get_name(),'qty'=>$n];
  }
  if(!$out)throw new Exception('Lägg till minst en komponent.');if($base){if($main->get_stock_quantity('edit')===null||$main->get_stock_managed_by_id()!==$main->get_id())throw new Exception('Huvudprodukten behöver eget saldo.');$out[$main->get_id()]=['product_id'=>$main->get_id(),'sku'=>$main->get_sku(),'name'=>$main->get_name(),'qty'=>1,'base_product'=>true];}ksort($out);return ['mode'=>$mode,'components'=>array_values($out)]+($base?['base_product_id'=>$main->get_id()]:[]);
 }
 /** No backorders: a registered ledger limits availability, including zero and expired rows. */
 static function base_product($id){return (int)(self::recipe($id)['base_product_id']??0)===(int)$id;}
 static function available($id){
  global $wpdb;$p=wc_get_product($id);if(!$p||(!$p->managing_stock()&&!self::base_product($id))||$p->get_stock_managed_by_id()!==$id||(self::on_demand($p)&&!self::base_product($id))||$p->get_stock_quantity('edit')===null)return 0;
  $q=max(0,(float)$p->get_stock_quantity('edit'));$b=Dennis_WMS_Batches::table('balances');$l=Dennis_WMS_Locations_V14::table('balances');
  if($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $b WHERE product_id=%d",$id))){$today=current_time('Y-m-d');$free=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(quantity),0) FROM $b WHERE product_id=%d AND quantity>0 AND (expiry IS NULL OR expiry>=%s) AND (last_order_date IS NULL OR last_order_date>=%s)",$id,$today,$today));$q=min($q,max(0,$free));}
  elseif($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $l WHERE product_id=%d",$id)))$q=min($q,max(0,(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(quantity),0) FROM $l WHERE product_id=%d",$id))));
  return $q;
 }
 static function capacity_from($components,$stock){$max=null;foreach($components as $c){$n=(int)($c['qty']??0);if($n<1)return 0;$v=(int)floor(max(0,(float)($stock[$c['product_id']]??0))/$n);$max=$max===null?$v:min($max,$v);}return $max??0;}
 static function capacity($recipe){
  $components=$recipe['components']??[];
  // Kit (accompanying) huvudprodukten är en virtuell sälj-SKU och får aldrig begränsa
  // kapaciteten med sitt eget WooCommerce-saldo. Endast de verkliga ingående SKU:erna styr.
  if(!empty($recipe['accompanying']))$components=array_values(array_filter($components,fn($c)=>empty($c['base_product'])));
  $stock=[];foreach($components as $c){$id=(int)$c['product_id'];$stock[$id]=self::available($id);if(($recipe['mode']??'')==='packed'&&$id===(int)($recipe['base_product_id']??0))$stock[$id]=max(0,$stock[$id]-Dennis_WMS_Product_Packing::quantity(wc_get_product($id)));}return self::capacity_from($components,$stock);
 }
 static $physical_access=[];
 static function preorder_product($p){return $p&&get_post_meta($p->get_id(),'_dennis_wms_preorder',true)==='yes';}
 static function manage_stock($value,$p){if(!empty(self::$physical_access[$p->get_id()]))return true;if(self::preorder_product($p))return true;return ($r=self::recipe($p->get_id()))?$r['mode']==='packed':$value;}
 static function stock_quantity($value,$p){if(self::preorder_product($p))return $p->get_stock_quantity('edit');return self::on_demand($p)?self::capacity(self::recipe($p->get_id())):$value;}
 static function stock_status($value,$p){if(self::preorder_product($p)){ $raw=$p->get_stock_quantity('edit'); return $raw!==null&&$raw>0?'instock':'outofstock'; }if(self::base_product($p->get_id())&&!self::on_demand($p))return (float)$p->get_stock_quantity('edit')>0?'instock':'outofstock';return self::on_demand($p)?(self::capacity(self::recipe($p->get_id()))>0?'instock':'outofstock'):$value;}
 static function in_stock($value,$p){if(self::preorder_product($p)){ $raw=$p->get_stock_quantity('edit'); return $raw!==null&&$raw>0; }if(self::base_product($p->get_id())&&!self::on_demand($p))return (float)$p->get_stock_quantity('edit')>0;return self::on_demand($p)?self::capacity(self::recipe($p->get_id()))>0:$value;}
 static function backorders($value,$id,$p){if(self::preorder_product($p))return $value;return self::recipe($id)?false:$value;}
 static function admin_stock_html($html,$p){
  if(!$p||!self::on_demand($p))return $html;
  // A pick-time Kit has no independent physical stock. Its sellable stock is always
  // the number of complete kits that can be built from the CURRENT component stock.
  // This is calculated live, so a component sold separately immediately lowers the Kit stock.
  $qty=max(0,(int)self::capacity(self::recipe($p->get_id())));
  if($qty<=0)return '<mark class="outofstock">'.esc_html__('Out of stock','woocommerce').'</mark>';
  // Match WooCommerce admin presentation: only the status is coloured; quantity stays normal text.
  return '<mark class="instock">'.esc_html__('In stock','woocommerce').'</mark> ('.esc_html(wc_format_stock_quantity_for_display($qty,$p)).')';
 }

 static function repair_physical_stock_status(){
  if(!current_user_can('manage_woocommerce')||get_option('dennis_wms_physical_status_repair')==='2.1.2')return;
  global $wpdb;$cursor=(int)get_option('dennis_wms_physical_status_cursor',0);$ids=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key=%s AND post_id>%d ORDER BY post_id LIMIT 100",self::META,$cursor));
  foreach($ids as $id){$r=self::recipe($id);if(($r['mode']??'')==='packed'&&self::base_product($id)){$p=self::fresh($id);if($p&&$p->get_stock_quantity('edit')!==null){$status=(float)$p->get_stock_quantity('edit')>0?'instock':'outofstock';if($p->get_stock_status('edit')!==$status){$old=$p->get_stock_status('edit');$p->set_stock_status($status);if(!$p->save())return;Dennis_WMS_Audit::record('Lagerstatus korrigerad','product',$id,['lagerstatus'=>$old],['lagerstatus'=>$status,'saldo'=>$p->get_stock_quantity('edit')],'WMS','success',$p->get_sku());}}}update_option('dennis_wms_physical_status_cursor',(int)$id,false);}
  if(count($ids)<100){update_option('dennis_wms_physical_status_repair','2.1.2',false);delete_option('dennis_wms_physical_status_cursor');}
 }

 static function fresh($id){clean_post_cache($id);wp_cache_delete($id,'post_meta');return wc_get_product($id);}
 static function locks($ids){
  global $wpdb;$ids=array_values(array_unique(array_map('absint',$ids)));sort($ids,SORT_NUMERIC);
  foreach($ids as $id){if(!$wpdb->get_var($wpdb->prepare("SELECT ID FROM {$wpdb->posts} WHERE ID=%d FOR UPDATE",$id)))throw new Exception('Produkten finns inte längre.');$wpdb->get_results($wpdb->prepare("SELECT meta_id FROM {$wpdb->postmeta} WHERE post_id=%d AND meta_key='_stock' FOR UPDATE",$id));self::fresh($id);}
 }
 static function transaction($ids,$callback){
  if(Dennis_WMS_Audit::query('START TRANSACTION')===false)throw new Exception('Kunde inte starta lagerändringen.');
  try{self::locks($ids);$result=$callback();if(Dennis_WMS_Audit::query('COMMIT')===false)throw new Exception('Kunde inte spara lagerändringen.');return $result;}
  catch(Throwable $e){Dennis_WMS_Audit::query('ROLLBACK');throw $e;}
  finally{foreach(array_unique($ids) as $id){clean_post_cache($id);wp_cache_delete($id,'post_meta');wc_delete_product_transients($id);}}
 }
 static function operation($key){global $wpdb;$t=self::table();return $wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE operation_key=%s",$key));}
 static function insert_operation($key,$kind,$pid,$qty,$r,$alloc,$oid=0,$iid=0){
  if(!Dennis_WMS_Audit::insert(self::table(),['operation_key'=>$key,'kind'=>$kind,'product_id'=>$pid,'order_id'=>$oid,'item_id'=>$iid,'quantity'=>$qty,'remaining'=>$kind==='order'?$qty:0,'recipe'=>wp_json_encode($r),'allocations'=>wp_json_encode($alloc),'user_id'=>get_current_user_id(),'created_at'=>current_time('mysql')]))throw new Exception('Kunde inte spara kithistoriken.');
 }
 static function stock_change($id,$qty){$p=self::fresh($id);if(!$p||(!$p->managing_stock()&&!self::base_product($id))||$p->get_stock_quantity('edit')===null)throw new Exception('SKU saknar eget lagerstyrt saldo.');if($qty<0&&(float)$p->get_stock_quantity('edit')<abs($qty))throw new Exception('Otillräckligt saldo för SKU '.$p->get_sku().'.');$packed_before=class_exists('Dennis_WMS_Product_Packing')?Dennis_WMS_Product_Packing::quantity($p):0;self::$physical_access[$id]=true;try{$v=wc_update_product_stock($p,abs($qty),$qty<0?'decrease':'increase');}finally{unset(self::$physical_access[$id]);}if(is_wp_error($v)||!is_numeric($v)||($qty<0&&(float)$v<0))throw new Exception('Kunde inte uppdatera saldo för SKU '.$p->get_sku().'.');return $qty<0&&class_exists('Dennis_WMS_Product_Packing')?Dennis_WMS_Product_Packing::component_take($id,abs($qty),$packed_before):0;}
 /** The outer kit transaction owns commit/rollback; all Plockordning rows are kept for returns. */
 static function consume($id,$qty,$key,$source){
  global $wpdb;if(self::available($id)<$qty)throw new Exception('Otillräckligt tillgängligt saldo för SKU '.wc_get_product($id)->get_sku().'.');
  $b=Dennis_WMS_Batches::table('balances');$l=Dennis_WMS_Locations_V14::table('balances');$today=current_time('Y-m-d');$alloc=[];$left=$qty;
  if($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $b WHERE product_id=%d",$id))){
   $order=Dennis_WMS_Batches::pick_order_sql();$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $b WHERE product_id=%d AND quantity>0 AND (expiry IS NULL OR expiry>=%s) AND (last_order_date IS NULL OR last_order_date>=%s) ORDER BY $order FOR UPDATE",$id,$today,$today));
   foreach($rows as $row){$take=min($left,(float)$row->quantity);if($take<=0)break;
    if(!Dennis_WMS_Batches::movement($id,$row->batch,$row->expiry,$row->location,-$take,'kit_component','dennis_wms_kit',0,$key.'-batch-'.$row->id,$source,$row->last_order_date,true))throw new Exception('Kunde inte ta ut komponentens batch.');
    $alloc[]=['product_id'=>$id,'source'=>'batch','slot_id'=>(int)$row->id,'batch'=>$row->batch,'expiry'=>$row->expiry,'last_order_date'=>$row->last_order_date,'location'=>$row->location,'qty'=>$take];$left-=$take;
   }
  }else{
   $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $l WHERE product_id=%d AND quantity>0 ORDER BY CASE WHEN kind='pick' THEN 0 ELSE 1 END,id FOR UPDATE",$id));
   foreach($rows as $row){$take=min($left,(float)$row->quantity);if($take<=0)break;
    if(Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $l SET quantity=quantity-%f WHERE id=%d AND quantity>=%f",$take,$row->id,$take))!==1)throw new Exception('Lagerplatsen saknar tillräckligt saldo.');
    $alloc[]=['product_id'=>$id,'source'=>'location','slot_id'=>(int)$row->id,'batch'=>'','expiry'=>null,'last_order_date'=>null,'location'=>$row->location,'qty'=>$take];$left-=$take;
   }
   if(!$rows&&!$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $l WHERE product_id=%d",$id))){$alloc[]=['product_id'=>$id,'source'=>'woo','slot_id'=>0,'batch'=>'','expiry'=>null,'last_order_date'=>null,'location'=>Dennis_WMS_Orders::location($id),'qty'=>$left];$left=0;}
  }
  if($left>0.00001)throw new Exception('Komponentens lagerfördelning räcker inte. Stäm av saldot.');$packed=self::stock_change($id,-$qty);foreach($alloc as &$a){$a['packed_qty']=min($packed,$a['qty']);$packed-=$a['packed_qty'];}unset($a);return $alloc;
 }

 static function build($pid,$qty,$key,$details=[]){
  self::ready();$qty=self::integer($qty);$r=self::recipe($pid);if(($r['mode']??'')!=='packed')throw new Exception('Detta förpackning packas vid plockning.');
  $ids=array_merge([$pid],array_column($r['components'],'product_id'));
  return self::transaction($ids,function()use($pid,$qty,$key,$details,$r){
   if(self::operation($key))return 'already';if(self::recipe($pid)!==$r)throw new Exception('Förpackningen ändrades. Ladda om sidan.');
   if($qty>self::capacity($r))throw new Exception('Ni kan just nu förpacka högst '.self::capacity($r).' förpackning. Inget saldo ändrades.');$alloc=[];
   foreach($r['components'] as $c){if(!empty($c['base_product']))continue;$alloc=array_merge($alloc,self::consume((int)$c['product_id'],$qty*$c['qty'],$key.'-'.$c['product_id'],'Förpackning av '.$qty.' förpackning: '.wc_get_product($pid)->get_sku()));}
   if(!empty($r['base_product_id'])){Dennis_WMS_Product_Packing::write($pid,Dennis_WMS_Product_Packing::quantity(wc_get_product($pid))+$qty);self::insert_operation($key,'assembly',$pid,$qty,$r,$alloc);Dennis_WMS_Audit::record('Förpackning förpackade på befintlig produkt','product',$pid,[],['antal_kit'=>$qty,'komponenter'=>$alloc],'WMS','success',wc_get_product($pid)->get_sku());return 'built';}
   // Do not accidentally add a partial batch register to previously unallocated stock.
   global $wpdb;$b=Dennis_WMS_Batches::table('balances');$l=Dennis_WMS_Locations_V14::table('balances');$old=(float)wc_get_product($pid)->get_stock_quantity('edit');
   $registered=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(quantity),0) FROM $b WHERE product_id=%d",$pid));
   if(abs($old-$registered)>0.00001)throw new Exception('Fördela huvud-SKU:s befintliga saldo på batcher innan fler förpackning förpackas.');
   if($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $l WHERE product_id=%d",$pid))&&!$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $b WHERE product_id=%d",$pid)))throw new Exception('Lägg batchuppgifter på huvud-SKU:s lagerplatssaldo först.');
   $expiry=$details['expiry']??null;$last=$details['last_order_date']??null;
   // A finished kit must not outlive the oldest component in its assembly lot.
   foreach($alloc as $a){if(!empty($a['expiry'])&&(!$expiry||$a['expiry']<$expiry))$expiry=$a['expiry'];if(!empty($a['last_order_date'])&&(!$last||$a['last_order_date']<$last))$last=$a['last_order_date'];}
   self::stock_change($pid,$qty);
   if(!Dennis_WMS_Batches::movement($pid,($details['batch']??'')?:'KIT-'.substr(hash('sha256',$key),0,12),$expiry,$details['location']??'',$qty,'kit_assembled','dennis_wms_kit',0,$key.'-finished','Förpackade förpackning',$last,true))throw new Exception('Kunde inte spara de färdiga förpackningarnas batchsaldo.');
   self::insert_operation($key,'assembly',$pid,$qty,$r,$alloc);Dennis_WMS_Audit::record('Förpackning förpackade','product',$pid,[],['antal_kit'=>$qty,'komponenter'=>$alloc],'WMS','success',wc_get_product($pid)->get_sku());return 'built';
  });
 }
 static function refresh_unconsumed_accompanying($order){foreach($order->get_items('line_item') as $item){if($item->get_meta('_reduced_stock',true)||self::active($order->get_id(),$item->get_id()))continue;$pid=$item->get_variation_id()?:$item->get_product_id();$current=self::recipe($pid);$old=$item->get_meta(self::SNAPSHOT,true);
   // Legacy multi-SKU packing with no ready main units can use ordinary pick-time stock.
   if(($current['mode']??'')==='packed'&&!empty($current['base_product_id'])&&Dennis_WMS_Product_Packing::quantity($item->get_product())===0){$current=self::transaction(array_column($current['components'],'product_id'),function()use($pid){$fresh=self::recipe($pid);if(($fresh['mode']??'')!=='packed'||empty($fresh['base_product_id'])||Dennis_WMS_Product_Packing::quantity(wc_get_product($pid))!==0)return $fresh;$next=$fresh;$next['mode']='pick';$next['accompanying']=true;update_post_meta($pid,self::META,$next);if(get_post_meta($pid,self::META,true)!==$next)throw new Exception('Kit-kopplingen kunde inte uppdateras.');wc_delete_product_transients($pid);Dennis_WMS_Audit::record('Äldre koppling ändrad till Kit med vanligt saldo','product',$pid,$fresh,$next,'WMS','success');return $next;});}
   if(empty($current['accompanying'])||!is_array($old)||!empty($old['accompanying']))continue;$item->update_meta_data(self::SNAPSHOT,$current);$item->save_meta_data();Dennis_WMS_Audit::record('Äldre orderkoppling uppdaterad till Kit','order',$order->get_id(),$old,$current,'WMS','success');}}

 /** Runs only when Woo intends to reduce order stock. Checks shared components across all lines. */
 static function reduce($allowed,$order){
  if(!$allowed||!$order)return $allowed;try{self::refresh_unconsumed_accompanying($order);}catch(Throwable $e){self::order_error($order,$e->getMessage());return false;}$work=[];$ids=[];$normal=[];
  foreach($order->get_items('line_item') as $iid=>$item){$r=self::item_recipe($item);$p=$item->get_product();if(($r['mode']??'')==='pick'){$work[]=['item'=>$item,'recipe'=>$r];$ids[]=$item->get_product_id();$ids=array_merge($ids,array_column($r['components'],'product_id'));}
   elseif($p&&$p->managing_stock()&&!$item->get_meta('_reduced_stock',true)){$id=$p->get_stock_managed_by_id();$normal[$id]=($normal[$id]??0)+max(0,(float)$item->get_quantity());$ids[]=$id;}}
  $packed_demand=[];foreach($order->get_items('line_item') as $item){$r=self::item_recipe($item);if(($r['mode']??'')==='packed'&&!empty($r['base_product_id'])&&!$item->get_meta('_reduced_stock',true)&&($packed_demand[$item->get_product_id()]=($packed_demand[$item->get_product_id()]??0)+$item->get_quantity())>Dennis_WMS_Product_Packing::quantity($item->get_product())){self::order_error($order,'För få färdiga förpackning. Förpacka fler innan orderns lageruttag.');return false;}}
  if(!$work)return $allowed;
  try{self::ready();self::transaction($ids,function()use($order,$work,$normal){
   $demand=$normal;$pending=[];
   foreach($work as $w){$item=$w['item'];$q=self::integer($item->get_quantity());$active=self::active($order->get_id(),$item->get_id());if($active){if(abs((float)$active->quantity-$q)>0.00001)throw new Exception('Kitantalet ändrades efter lageruttaget. Återställ orderlagret först.');continue;}
    // A fully restocked refund must not be deducted again by a repeated stock hook.
    if((float)$item->get_meta('_dennis_wms_kit_refunded',true)>0)continue;
    foreach($w['recipe']['components'] as $c){if(!empty($w['recipe']['accompanying'])&&!empty($c['base_product']))continue;$id=(int)$c['product_id'];$demand[$id]=($demand[$id]??0)+$q*$c['qty'];}$pending[]=$w;
   }
   foreach($demand as $id=>$qty){$p=self::fresh($id);$available=self::available((int)$id);if(self::base_product($id)&&!self::on_demand($p))$available=min($available,Dennis_WMS_Product_Packing::quantity($p));if($available<$qty)throw new Exception('SKU '.($p?$p->get_sku():$id).': behöver '.$qty.' st, tillgängligt '.$available.' st.');}
   foreach($pending as $w){$item=$w['item'];$q=(int)$item->get_quantity();$key='kit-order-'.$order->get_id().'-'.$item->get_id().'-'.wp_generate_uuid4();$alloc=[];
    foreach($w['recipe']['components'] as $c){if(!empty($w['recipe']['accompanying'])&&!empty($c['base_product']))continue;$alloc=array_merge($alloc,self::consume((int)$c['product_id'],$q*$c['qty'],$key.'-'.$c['product_id'],'Order #'.$order->get_order_number().' · Kit '.$item->get_name()));}
    if(!$item->get_meta(self::SNAPSHOT,true)){$item->update_meta_data(self::SNAPSHOT,$w['recipe']);$item->save_meta_data();}
    self::insert_operation($key,'order',$item->get_product_id(),$q,$w['recipe'],$alloc,$order->get_id(),$item->get_id());
   }
  });$order->delete_meta_data('_dennis_wms_kit_stock_error');$order->save_meta_data();unset(self::$failed[$order->get_id()]);return $allowed;
  }catch(Throwable $e){self::order_error($order,$e->getMessage());self::$failed[$order->get_id()]=true;return false;}
 }
 static function order_error($order,$message){$text='Förpackning: '.$message;if($order->get_meta('_dennis_wms_kit_stock_error',true)!==$text)$order->add_order_note($text);$order->update_meta_data('_dennis_wms_kit_stock_error',$text);$order->save_meta_data();Dennis_WMS_Audit::record('Förpackningsåtgärd stoppad','order',$order->get_id(),[],['orsak'=>$message],'WMS','failed');}
 static function reset_failed_flags(){foreach(self::$failed as $id=>$v){$o=wc_get_order($id);if($o&&$o->get_meta('_dennis_wms_kit_stock_error',true))$o->get_data_store()->set_stock_reduced($id,false);}}
 static function release($order,$requests,$key){
  self::ready();$ids=[];global $wpdb;$t=self::table();$ops=$wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE kind='order' AND order_id=%d AND remaining>0 ORDER BY id",$order->get_id()));
  foreach($ops as $op){if(!array_key_exists($op->item_id,$requests))continue;$ids[]=(int)$op->product_id;foreach(json_decode($op->allocations,true)?:[] as $a)$ids[]=(int)$a['product_id'];}
  if(!$ids)return;
  self::transaction($ids,function()use($order,$requests,$key,$t){
   global $wpdb;$ops=$wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE kind='order' AND order_id=%d AND remaining>0 ORDER BY id FOR UPDATE",$order->get_id()));
   foreach($ops as $op){if(!array_key_exists($op->item_id,$requests))continue;$opkey=$key.'-'.$op->id;if(self::operation($opkey))continue;$requested=$requests[$op->item_id];$n=$requested===null?(float)$op->remaining:self::integer($requested);if($n>(float)$op->remaining)throw new Exception('Returen överstiger det kvarvarande förpackningsuttaget.');$alloc=json_decode($op->allocations,true);$recipe=json_decode($op->recipe,true);if(!is_array($alloc)||!is_array($recipe))throw new Exception('Förpackningens uttagshistorik saknas.');$returns=[];$needed=[];
    foreach($recipe['components'] as $c)$needed[(int)$c['product_id']]=$n*$c['qty'];
    // Return whole component units, from the last allocated batch first. Keep original allocations intact.
    for($index=count($alloc)-1;$index>=0;$index--){$a=$alloc[$index];$pid=(int)$a['product_id'];$left=(float)($a['remaining_qty']??$a['qty']);$qty=min($left,$needed[$pid]??0);if($qty<=0)continue;
     if($a['source']==='batch'){if(!Dennis_WMS_Batches::movement($pid,$a['batch'],$a['expiry'],$a['location'],$qty,'kit_return','dennis_wms_kit',$order->get_id(),$opkey.'-'.$index,'Återlagt från kitorder',$a['last_order_date'],true))throw new Exception('Kunde inte återställa ingående produktens batch.');}
     elseif($a['source']==='location'){if(Dennis_WMS_Audit::query($wpdb->prepare('UPDATE '.Dennis_WMS_Locations_V14::table('balances').' SET quantity=quantity+%f WHERE id=%d AND product_id=%d',$qty,$a['slot_id'],$pid))!==1)throw new Exception('Den ursprungliga lagerplatsen finns inte längre.');}
     self::stock_change($pid,$qty);$packed_return=min($qty,(float)($a['remaining_packed_qty']??$a['packed_qty']??0));if(class_exists('Dennis_WMS_Product_Packing'))Dennis_WMS_Product_Packing::component_return($pid,$packed_return);$alloc[$index]['remaining_packed_qty']=max(0,(float)($a['remaining_packed_qty']??$a['packed_qty']??0)-$packed_return);$alloc[$index]['remaining_qty']=$left-$qty;$needed[$pid]-=$qty;$returns[]=$a+['returned_qty'=>$qty];
    }
    foreach($needed as $left)if($left>0.00001)throw new Exception('Det kvarvarande batchuttaget räcker inte för returen.');
    if(Dennis_WMS_Audit::update($t,['remaining'=>(float)$op->remaining-$n,'allocations'=>wp_json_encode($alloc)],['id'=>(int)$op->id])===false)throw new Exception('Kunde inte spara återställningen.');self::insert_operation($opkey,'return',(int)$op->product_id,$n,$recipe,$returns,$order->get_id(),(int)$op->item_id);
    if(strpos($key,'refund-')===0){$item=$order->get_item($op->item_id);$item->update_meta_data('_dennis_wms_kit_refunded',(float)$item->get_meta('_dennis_wms_kit_refunded',true)+$n);$item->save_meta_data();}
   }
  });
 }
 static function restore($order){if(is_numeric($order))$order=wc_get_order($order);if(!$order)return false;$requests=[];foreach($order->get_items('line_item') as $id=>$item)if(self::item_on_demand($item))$requests[$id]=null;if(!$requests)return true;try{self::release($order,$requests,'cancel-'.$order->get_id());$order->delete_meta_data('_dennis_wms_kit_stock_error');$order->save_meta_data();return true;}catch(Throwable $e){self::order_error($order,$e->getMessage());return false;}}
 static function refund_context($refund,$args){if(!empty($args['restock_items']))self::$refund_context[(int)$args['order_id']]=['refund'=>$refund,'lines'=>$args['line_items']];}
 static function clear_refund_context($id,$args){unset(self::$refund_context[(int)$args['order_id']]);}
 static function refund($allowed,$order,$lines){
  if(!$allowed)return false;$requests=[];foreach($lines as $id=>$line){$item=$order->get_item($id);if($item&&self::item_on_demand($item)&&($line['qty']??0)>0)$requests[$id]=$line['qty'];}if(!$requests)return $allowed;
  try{$context=self::$refund_context[$order->get_id()]??null;if($context&&$context['lines']===$lines)$refund_id=$context['refund']->get_id();else{$refunds=function_exists('wc_get_orders')?wc_get_orders(['type'=>'shop_order_refund','parent'=>$order->get_id(),'limit'=>1,'orderby'=>'ID','order'=>'DESC']):$order->get_refunds();$refund_id=0;foreach($refunds as $rf)$refund_id=max($refund_id,$rf->get_id());}if(!$refund_id)throw new Exception('Ingen sparad retur finns att koppla förpackningåterställningen till.');self::release($order,$requests,'refund-'.$refund_id);return $allowed;}catch(Throwable $e){self::order_error($order,$e->getMessage());throw new Exception('Ingående produkterna kunde inte återläggas: '.$e->getMessage());}
 }
 static function cart_demand($extra_id=0,$extra_qty=0){
  $demand=[];$has=false;$items=WC()->cart?WC()->cart->get_cart():[];if($extra_id)$items[]=['data'=>wc_get_product($extra_id),'quantity'=>$extra_qty];
  foreach($items as $line){$p=$line['data'];if(!$p)continue;$r=self::recipe($p->get_id());$q=(float)$line['quantity'];if($r)$has=true;if(($r['mode']??'')==='pick'){self::integer($q);foreach($r['components'] as $c){if(!empty($r['accompanying'])&&!empty($c['base_product']))continue;$demand[$c['product_id']]=($demand[$c['product_id']]??0)+$q*$c['qty'];}}elseif($p->managing_stock()){if(!empty($r['base_product_id'])&&$q>Dennis_WMS_Product_Packing::quantity($p))return 'För få färdiga förpackning.';$id=$p->get_stock_managed_by_id();$demand[$id]=($demand[$id]??0)+$q;}}
  if(!$has)return '';foreach($demand as $id=>$n){$p=wc_get_product($id);if(self::available((int)$id)<$n)return 'Saldot räcker inte för förpackning och övriga produkter i varukorgen (SKU '.$p->get_sku().').';}return '';
 }
 static function cart_add($allowed,$pid,$qty,$vid=0,$variation=[],$data=[]){if(!$allowed)return false;try{$error=self::cart_demand($vid?:$pid,$qty);}catch(Throwable $e){$error=$e->getMessage();}if($error){wc_add_notice($error,'error');return false;}return true;}
 static function cart_check(){try{$error=self::cart_demand();}catch(Throwable $e){$error=$e->getMessage();}if($error&&!wc_has_notice($error,'error'))wc_add_notice($error,'error');}
 /** Replace a pick-time kit with component rows, keeping the main SKU as packing instructions. */
 static function pick_rows($order,$item,$row,&$packed_budget=[]){
  $r=self::item_recipe($item);$op=self::active($order->get_id(),$item->get_id());if($op){$recorded=json_decode($op->recipe,true);if(is_array($recorded)&&!empty($recorded['components']))$r=$recorded;}else{$current=self::recipe($item->get_variation_id()?:$item->get_product_id());if(($current['mode']??'')==='packed'&&!empty($current['base_product_id'])&&Dennis_WMS_Product_Packing::quantity($item->get_product())===0){$current['mode']='pick';$current['accompanying']=true;$current['preview_only']=true;}if(!empty($current['accompanying'])&&empty($r['accompanying'])){$r=$current;$r['preview_only']=true;}}if(($r['mode']??'')!=='pick'){if(($r['mode']??'')==='packed'){if(!empty($r['base_product_id'])){$planned=Dennis_WMS_Product_Packing::item_meta($item,'_dennis_wms_packed_planned');$ready=$planned!==''?(int)$planned:Dennis_WMS_Product_Packing::quantity($item->get_product());$row=Dennis_WMS_Product_Packing::describe_pick($row,min($row['qty'],$ready));}else{$row=Dennis_WMS_Product_Packing::describe_pick($row,$row['qty']);}$contents=[];foreach($r['components'] as $c){$cp=wc_get_product($c['product_id']);$contents[]=($cp?$cp->get_sku():$c['sku']).' · '.($cp?$cp->get_name():$c['name']).' · '.($row['qty']*$c['qty']).' st totalt ('.$c['qty'].' per förpackning)';}$row['kit_instruction']="Innehåll i förpackningarna:\n".implode("\n",$contents).($row['unpacked_qty']>0?"\nOBS: ".$row['unpacked_qty']." st saknar registrerad förpackning i denna äldre koppling. Använd Kit för plock av medföljande SKU från vanligt saldo.":"\nInnehållet är redan förpackat och ska inte plockas separat.");}elseif(class_exists('Dennis_WMS_Product_Packing'))$row=Dennis_WMS_Product_Packing::pick_row($item,$row,$packed_budget,$order);return [$row];}$out=[];$op=self::active($order->get_id(),$item->get_id());$alloc=$op?(json_decode($op->allocations,true)?:[]):[];
  $pick_components=$r['components'];if(!empty($r['accompanying']))usort($pick_components,fn($a,$b)=>(int)!empty($b['base_product'])<=>(int)!empty($a['base_product']));
  foreach($pick_components as $c){if(!empty($r['accompanying'])&&!empty($c['base_product']))continue;$p=wc_get_product($c['product_id']);$kit_qty=$op?(float)$op->remaining:(float)$item->get_quantity();$q=$kit_qty*$c['qty'];$rows=[];$packed=0;
   foreach($alloc as $a)if((int)$a['product_id']===(int)$c['product_id']&&($a['remaining_qty']??$a['qty'])>0){$packed+=(int)($a['remaining_packed_qty']??$a['packed_qty']??0);$rows[]=['batch'=>$a['batch'],'expiry'=>$a['expiry'],'location'=>$a['location'],'qty'=>$a['remaining_qty']??$a['qty']];}
   $component_row=['name'=>($p?$p->get_name():$c['name']).' · förpackning '.$row['sku'],'sku'=>$p?$p->get_sku():$c['sku'],'qty'=>$q,'location'=>Dennis_WMS_Orders::location($c['product_id']),'item_id'=>$row['item_id'],'product_id'=>$c['product_id'],'image'=>Dennis_WMS_Orders::product_image_url($p),'kit_instruction'=>'Packa '.$kit_qty.' förpackning av '.$row['name'].' ('.$row['sku'].'). '.$c['qty'].' st av denna komponent per förpackning.','purchase_note'=>Dennis_WMS_Orders::purchase_note($p)]+($rows?['kit_allocation'=>['rows'=>$rows,'missing'=>0]]:[]);
   if(!empty($r['accompanying'])){$component_row['name']=($p?$p->get_name():$c['name']);$component_row['accompanying_group']=$order->get_id().':'.$item->get_id();$component_row['kit_parent_name']=$row['name'];$component_row['kit_parent_sku']=$row['sku'];$component_row['kit_order_qty']=$kit_qty;$component_row['kit_component_per']=$c['qty'];$component_row['kit_instruction']=!empty($c['base_product'])?'Beställd huvudprodukt: '.$kit_qty.' st.':'Kitkomponent: '.$c['qty'].' st per kit × '.$kit_qty.' kit = '.$q.' st att plocka.';}
   if(!empty($r['preview_only']))$component_row['kit_instruction'].=' OBS: Förhandsvisning av aktuell koppling. Dessa medföljande artiklar är inte registrerade som lageruttag på den äldre ordern.';
   if(!$op&&$p){$id=$p->get_id();if(!isset($packed_budget[$id]))$packed_budget[$id]=Dennis_WMS_Product_Packing::quantity($p);$packed=min($packed_budget[$id],$q);$packed_budget[$id]-=$packed;}
   $described=Dennis_WMS_Product_Packing::describe_pick($component_row,$packed,true);if(!empty($r['accompanying']))$described['packing_instruction']=$packed>0?'Plocka '.$packed.' för-packade'.($q>$packed?' och '.($q-$packed).' oförpackade':'').' st.':'';$out[]=$described;
  }return $out;
 }
 static function guard($nonce){if(!current_user_can('pb_wms_manage')||!current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad.',403);check_admin_referer($nonce);}
 static function url($args=[]){return add_query_arg(['page'=>'dennis-wms-kits']+$args,admin_url('admin.php'));}
 static function save(){self::guard('dennis_wms_kit_save');wp_die('Förpackning stöder endast en SKU. Öppna För-packade produkter.',410);}
 static function assemble(){self::guard('dennis_wms_kit_assemble');wp_die('Förpackning stöder endast en SKU. Öppna För-packade produkter.',410);}
 static function retry(){
  self::guard('dennis_wms_kit_retry');$order=wc_get_order(absint($_POST['order_id']??0));if(!$order)wp_die('Ordern hittades inte.',404);
  if(in_array($order->get_status(),['cancelled','pending','failed'],true)){if(!self::restore($order))wp_die(esc_html($order->get_meta('_dennis_wms_kit_stock_error',true)),409);}
  elseif(in_array($order->get_status(),['processing','on-hold','completed'],true)){wc_reduce_stock_levels($order);if($order->get_meta('_dennis_wms_kit_stock_error',true))wp_die(esc_html($order->get_meta('_dennis_wms_kit_stock_error',true)),409);$order->get_data_store()->set_stock_reduced($order->get_id(),true);}
  else wp_die('Kontrollera orderns status innan lagerändring.',409);
  wp_safe_redirect(admin_url('admin.php?page=dennis-wms-orders&order_id='.$order->get_id()));exit;
 }
 static function pick_error($order){$e=$order->get_meta('_dennis_wms_kit_stock_error',true);if($e)return $e;foreach($order->get_items('line_item') as $item)if(self::item_on_demand($item)&&!self::active($order->get_id(),$item->get_id()))return 'Förpackningens komponenter har ännu inget registrerat orderuttag. Kontrollera orderstatus och saldo.';return ''; }
 static function error_panel($order){$error=$order->get_meta('_dennis_wms_kit_stock_error',true);if(!$error)return;echo '<div class="notice notice-error inline"><p><strong>'.esc_html($error).'</strong></p><p>Kontrollera komponenternas saldo innan ordern plockas.</p>';if(current_user_can('pb_wms_manage')&&current_user_can('manage_woocommerce')){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_kit_retry');echo '<input type="hidden" name="action" value="dennis_wms_kit_retry"><input type="hidden" name="order_id" value="'.(int)$order->get_id().'"><button class="button button-primary">'.(in_array($order->get_status(),['cancelled','pending','failed'],true)?'Försök återställning igen':'Försök lageruttag igen').'</button></form>';}echo '</div>';}
 static function suggestions($term,$scope='component'){
  global $wpdb;$term=trim((string)$term);if(strlen($term)<3||strlen($term)>120)return [];
  // Search the catalogue first. Eligibility must not silently hide an existing SKU.
  $like='%'.$wpdb->esc_like($term).'%';
  $ids=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT p.ID,s.meta_value FROM {$wpdb->posts} p JOIN {$wpdb->postmeta} s ON s.post_id=p.ID AND s.meta_key='_sku' WHERE p.post_type IN ('product','product_variation') AND p.post_status NOT IN ('trash','auto-draft') AND s.meta_value<>'' AND s.meta_value LIKE %s ORDER BY CASE WHEN s.meta_value=%s THEN 0 ELSE 1 END,s.meta_value,p.ID LIMIT 12",$like,$term));$out=[];
  foreach($ids as $id){$p=wc_get_product($id);if(!$p||$p->get_sku()==='')continue;$reason='';
   if(self::recipe($id)&&!(!empty(self::recipe($id)['accompanying'])&&self::base_product($id)))$reason='Denna SKU har redan kopplade artiklar eller en förpackningskoppling.';
   elseif($scope==='main'){
    if(!$p->is_type('simple'))$reason='Förpackningens SKU måste vara en enkel produkt.';
    elseif(get_post_meta($id,'_dennis_wms_kit_component_used',true)==='yes'&&($_GET['accompanying']??'')!=='1')$reason='Används som ingående produkt. Välj en separat SKU för förpackningen.';
    elseif($p->get_stock_quantity('edit')===null)$reason='Ange huvudproduktens eget saldo i WooCommerce.';

   }elseif(!$p->is_type(['simple','variation'])||(!$p->managing_stock()&&empty(self::recipe($id)['accompanying']))||$p->get_stock_managed_by_id()!==$p->get_id()||$p->get_stock_quantity('edit')===null)$reason='Aktivera Hantera lager och ange eget saldo i WooCommerce för denna SKU.';
   $out[]=['sku'=>$p->get_sku(),'name'=>$p->get_name(),'available'=>$scope==='main'||$reason!==''?0:self::available((int)$id),'eligible'=>$reason==='','reason'=>$reason];
  }return $out;
 }
 static function lookup(){if(!current_user_can('pb_wms_view'))wp_send_json_error(['message'=>'Åtkomst nekad'],403);check_ajax_referer('dennis_wms_kit_lookup','nonce');if(isset($_GET['query'])){$term=sanitize_text_field(wp_unslash($_GET['query']));$scope=($_GET['scope']??'')==='main'?'main':'component';wp_send_json_success(['results'=>self::suggestions($term,$scope)]);} $sku=sanitize_text_field(wp_unslash($_GET['sku']??''));$p=wc_get_product(wc_get_product_id_by_sku($sku));if(!$p)wp_send_json_error(['message'=>'SKU hittades inte']);wp_send_json_success(['sku'=>$p->get_sku(),'name'=>$p->get_name(),'stock'=>$p->get_stock_quantity(),'available'=>self::recipe($p->get_id())?0:self::available($p->get_id())]);}
 static function assets(){if(!in_array($_GET['page']??'',['dennis-wms-kits','dennis-wms-accompanying'],true))return;wp_enqueue_script('dennis-wms-kits',plugins_url('kits.js',__FILE__),[],PB_WMS_VERSION,true);wp_localize_script('dennis-wms-kits','DennisKits',['url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('dennis_wms_kit_lookup')]);}
 static function fields($pid=0){$p=$pid?wc_get_product($pid):false;$r=self::recipe($pid);echo '<form class="dw-kit-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_kit_save');echo '<input type="hidden" name="action" value="dennis_wms_kit_save"><input type="hidden" name="product_id" value="'.$pid.'"><input type="hidden" name="use_base_product" value="1"><label>Huvudproduktens SKU<input name="main_sku" class="dw-kit-sku" value="'.esc_attr($p?$p->get_sku():'').'" required '.($p?'readonly':'').'><small class="dw-kit-result">'.esc_html($p?$p->get_name():'Produktnamnet hämtas från SKU.').'</small></label><input type="hidden" name="mode" value="packed"><p>Produkter förpackas i förväg. Ingående tillbehör dras från saldo när du registrerar antalet förpackade.</p><h3>Produkter som ingår i förpackningen</h3><p>Huvudprodukten ingår automatiskt med 1 st per förpackning. Lägg endast till de andra produkterna här, med antal per förpackning.</p><div class="dw-kit-components">';$components=isset($r['components'])?array_values(array_filter($r['components'],fn($c)=>empty($c['base_product']))):[['sku'=>'','qty'=>1]];foreach($components as $c)self::component_field($c);echo '</div><button type="button" class="button dw-kit-add">＋ Lägg till komponent</button><p><button class="button button-primary">Spara innehåll</button></p></form>';}
 static function component_field($c){echo '<div class="dw-kit-component"><label>SKU<input class="dw-kit-sku" name="component_sku[]" value="'.esc_attr($c['sku']).'" required><small class="dw-kit-result">'.esc_html($c['name']??'').'</small></label><label>Antal per förpackning<input type="number" name="component_qty[]" min="1" max="1000000" step="1" value="'.(int)$c['qty'].'" required></label><button type="button" class="button dw-kit-remove" aria-label="Ta bort komponent">Ta bort</button></div>';}
 static function save_product_packing(){
  self::guard('dennis_wms_product_packing');$sku=sanitize_text_field(wp_unslash($_POST['sku']??''));$p=wc_get_product(wc_get_product_id_by_sku($sku));
  if(!$p)wp_die('SKU hittades inte.',400);
  try{Dennis_WMS_Product_Packing::set_quantity($p->get_id(),$_POST['packed_quantity']??'');wp_safe_redirect(self::url(['tab'=>'products','sku'=>$sku,'notice'=>'packing']));exit;}catch(Throwable $e){wp_die(esc_html($e->getMessage()),409);}
 }

 static function unlock_old_product($pid){
  if(!current_user_can('pb_wms_manage')||!current_user_can('manage_woocommerce'))throw new Exception('Åtkomst nekad.');
  return self::transaction([$pid],function()use($pid){$p=self::fresh($pid);$r=self::recipe($pid);if(!$p||!$r)throw new Exception('Produkten har ingen tidigare förpackningsinställning.');$stock=$p->get_stock_quantity('edit');
   if(update_post_meta($pid,'_dennis_wms_previous_packing_recipe',$r)===false&&get_post_meta($pid,'_dennis_wms_previous_packing_recipe',true)!==$r)throw new Exception('Kunde inte bevara tidigare inställning.');
   if(!delete_post_meta($pid,self::META))throw new Exception('Kunde inte återställa saldohanteringen.');
   $p=self::fresh($pid);$p->set_manage_stock(true);if(!$p->save())throw new Exception('Kunde inte aktivera lagerhantering.');
   Dennis_WMS_Audit::record('Vanlig saldohantering återställd','product',$pid,$r,['saldo'=>$stock,'lagerhantering'=>true],'WMS','success',$p->get_sku());return $stock;
  });
 }
 static function restore_stock_control(){
  self::guard('dennis_wms_restore_stock_control');$pid=absint($_POST['product_id']??0);
  try{self::unlock_old_product($pid);}catch(Throwable $e){wp_die(esc_html($e->getMessage()),409);}
  $p=wc_get_product($pid);wp_safe_redirect(self::url(['tab'=>'products','sku'=>$p->get_sku(),'notice'=>'stock_control_restored']));exit;
 }
 static function old_stock_notice($p,$edit){
  if(!$p||!self::recipe($p->get_id()))return;
  echo '<div class="notice notice-warning inline"><p>Den här produkten har en tidigare förpackningsinställning. Återställ vanlig saldohantering för att förpacka enbart denna SKU. Eget sparat saldo: <strong>'.esc_html((string)$p->get_stock_quantity('edit')).'</strong>.</p>';
  if($edit){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_restore_stock_control');echo '<input type="hidden" name="action" value="dennis_wms_restore_stock_control"><input type="hidden" name="product_id" value="'.(int)$p->get_id().'"><button class="button button-primary">Återställ vanlig saldohantering</button><p>Det sparade saldot och tidigare orderuttag behålls. Därefter kan du uppdatera saldot som på en vanlig produkt.</p></form>';}
  echo '</div>';
 }

 static function packing_page($edit){
  $sku=sanitize_text_field(wp_unslash($_GET['sku']??''));$p=$sku?wc_get_product(wc_get_product_id_by_sku($sku)):false;
  echo '<section class="dw-kit-card"><h2>Vanliga produkter</h2><p>Ange hur många av produktens befintliga saldo som faktiskt är förpackade. Totalsaldot ändras inte. Antalet kan aldrig överstiga saldot.</p><form method="get"><input type="hidden" name="page" value="dennis-wms-kits"><input type="hidden" name="tab" value="products"><label>SKU<input name="sku" value="'.esc_attr($sku).'" required></label><p><button class="button">Visa produkt</button></p></form>';
  self::old_stock_notice($p,$edit);
  if($p&&!self::recipe($p->get_id())){$n=Dennis_WMS_Product_Packing::quantity($p);$total=max(0,(int)$p->get_stock_quantity('edit'));echo '<h3>'.esc_html($p->get_name()).'</h3><p>SKU '.esc_html($p->get_sku()).' · Saldo '.$total.' st · Förpackade '.$n.' st · Oförpackade '.max(0,$total-$n).' st</p>';if(get_post_meta($p->get_id(),'_dennis_wms_prepacked',true)==='yes'&&get_post_meta($p->get_id(),Dennis_WMS_Product_Packing::META,true)==='')echo '<p>Tidigare packningsmarkering saknar antal. Ange hur många som faktiskt är förpackade.</p>';if($edit){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_product_packing');echo '<input type="hidden" name="action" value="dennis_wms_product_packing"><input type="hidden" name="sku" value="'.esc_attr($p->get_sku()).'"><label>Antal faktiskt förpackade<input type="number" name="packed_quantity" min="0" max="'.$total.'" step="1" value="'.$n.'" required></label><p>Av totalt '.$total.' st i saldo. Skriv 0 om ingen är förpackad.</p><p><button class="button button-primary">Spara antal förpackade</button></p></form>';}}
  elseif($sku!=='')echo '<p>SKU hittades inte eller behöver först återställas till vanlig saldohantering.</p>';echo '</section>';
  global $wpdb;$ids=$wpdb->get_col($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key=%s AND meta_value='yes' ORDER BY post_id DESC LIMIT 100",'_dennis_wms_prepacked'));echo '<section class="dw-kit-card"><h2>För-packade produkter</h2><div class="dw-kit-scroll"><table class="widefat striped"><thead><tr><th>SKU</th><th>Produkt</th><th>Saldo</th><th>Förpackade</th><th>Oförpackade</th><th></th></tr></thead><tbody>';foreach($ids as $id){$p=wc_get_product($id);if(!$p||self::recipe($id))continue;$n=Dennis_WMS_Product_Packing::quantity($p);$total=max(0,(int)$p->get_stock_quantity('edit'));echo '<tr><td>'.esc_html($p->get_sku()).'</td><td>'.esc_html($p->get_name()).'</td><td>'.$total.'</td><td>'.$n.'</td><td>'.max(0,$total-$n).'</td><td><a class="button" href="'.esc_url(self::url(['tab'=>'products','sku'=>$p->get_sku()])).'">Ändra antal</a></td></tr>';}if(!$ids)echo '<tr><td colspan="6">Inga produkter markerade ännu.</td></tr>';echo '</tbody></table></div></section>';
 }

 static function page(){
  if(!current_user_can('pb_wms_view'))wp_die('Åtkomst nekad.',403);
  $edit=current_user_can('pb_wms_manage')&&current_user_can('manage_woocommerce');
  if(empty($_GET['sku'])&&!empty($_GET['kit'])){$p=wc_get_product(absint($_GET['kit']));if($p)$_GET['sku']=$p->get_sku();}
  echo '<div class="wrap dw-kits"><h1>För-packade produkter</h1>';
  if(isset($_GET['notice']))echo '<div class="notice notice-success"><p>'.(($_GET['notice']??'')==='stock_control_restored'?'Vanlig saldohantering är återställd.':'Antalet förpackade är sparat.').'</p></div>';
  self::packing_page($edit);echo '</div>';
 }

}
Dennis_WMS_Kits::boot();
