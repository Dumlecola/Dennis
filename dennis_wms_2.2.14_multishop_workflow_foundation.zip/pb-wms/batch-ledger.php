<?php
if (!defined('ABSPATH')) exit;
/**
 * Dennis WMS batch/lot ledger.
 * Keeps batch, expiry date and location quantities separate from WooCommerce total stock.
 * Plockordning allocations are read-only suggestions on pick lists in v1.7.3.
 */
final class Dennis_WMS_Batches {
 const SCHEMA='1.7.8';
 const CAP='pb_wms_manage';
 static function table($suffix){global $wpdb;return $wpdb->prefix.'dennis_wms_batch_'.$suffix;}
 static function install(){
  global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$c=$wpdb->get_charset_collate();
  $b=self::table('balances');$m=self::table('movements');
  dbDelta("CREATE TABLE $b (
 id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
 product_id bigint(20) unsigned NOT NULL,
 batch varchar(120) NOT NULL DEFAULT '',
 expiry date NULL,
 last_order_date date NULL,
 location varchar(120) NOT NULL DEFAULT '',
 quantity decimal(18,4) NOT NULL DEFAULT 0,
 created_at datetime NOT NULL,
 updated_at datetime NOT NULL,
 PRIMARY KEY  (id),
 UNIQUE KEY batch_slot (product_id,batch,expiry,location),
 KEY product_id (product_id),
 KEY expiry (expiry)
) $c;");
  dbDelta("CREATE TABLE $m (
 id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
 product_id bigint(20) unsigned NOT NULL,
 batch varchar(120) NOT NULL DEFAULT '',
 expiry date NULL,
 last_order_date date NULL,
 location varchar(120) NOT NULL DEFAULT '',
 quantity decimal(18,4) NOT NULL DEFAULT 0,
 action varchar(40) NOT NULL,
 source_type varchar(40) NOT NULL DEFAULT '',
 source_id bigint(20) unsigned NOT NULL DEFAULT 0,
 source_key varchar(190) NOT NULL DEFAULT '',
 note text NULL,
 user_id bigint(20) unsigned NOT NULL DEFAULT 0,
 created_at datetime NOT NULL,
 PRIMARY KEY  (id),
 UNIQUE KEY source_key (source_key),
 KEY product_date (product_id,created_at),
 KEY expiry (expiry)
) $c;");
  // Repair existing tables even if a previous dbDelta run marked the upgrade complete.
  foreach(['balances','movements'] as $suffix){$table=self::table($suffix);if(!self::has_last_order_column($table))Dennis_WMS_Audit::query("ALTER TABLE `$table` ADD COLUMN last_order_date date NULL");}
  if(!self::schema_ready()){delete_option('dennis_wms_batch_schema');return false;}
  update_option('dennis_wms_batch_schema',self::SCHEMA);return true;
 }
 static function boot(){add_action('admin_menu',[__CLASS__,'menu'],104);add_action('admin_init',[__CLASS__,'upgrade']);add_action('admin_post_dennis_wms_batch_adjust',[__CLASS__,'adjust']);add_action('admin_post_dennis_wms_batch_set_location',[__CLASS__,'set_location']);add_action('admin_post_dennis_wms_batch_edit_meta',[__CLASS__,'edit_meta']);add_action('admin_post_dennis_wms_batch_discard_expired',[__CLASS__,'discard_expired']);add_action('admin_post_dennis_wms_batch_distribute',[__CLASS__,'distribute']);}
 static function has_last_order_column($table){global $wpdb;return (bool)$wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$table` LIKE %s",'last_order_date'));}
 static function schema_ready(){return self::has_last_order_column(self::table('balances'))&&self::has_last_order_column(self::table('movements'));}
 static function require_schema(){if(!self::schema_ready())wp_die('Batchregistret behöver uppdateras. Öppna en WMS-sida som administratör och försök igen.',503);}
 static function upgrade(){
  if(!current_user_can('manage_options'))return;
  $previous=get_option('dennis_wms_batch_schema');
  if($previous!==self::SCHEMA||!self::schema_ready()){
   if(self::install()){if(!$previous||version_compare($previous,'1.7.6','<'))self::backfill_receipts();}
   else add_action('admin_notices',[__CLASS__,'schema_notice']);
  }
 }
 static function schema_notice(){echo '<div class="notice notice-error"><p>Dennis WMS kunde inte uppdatera batchregistrets datumfält. Last order date kan inte sparas ännu. Kontrollera databasloggen och ladda om sidan för att försöka igen.</p></div>';}
 static function menu(){add_submenu_page('pb-wms','Batcher & lagerplatser','Batcher & lagerplatser','pb_wms_view','dennis-wms-batches',[__CLASS__,'page']);}
 static function normalize_expiry($expiry){$expiry=trim((string)$expiry);if(!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/',$expiry,$parts))return null;return checkdate((int)$parts[2],(int)$parts[3],(int)$parts[1])?$expiry:null;}
 static function can_discard_expiry($value){$expiry=self::normalize_expiry($value);return $expiry!==null&&$expiry<=current_time('Y-m-d');}
 static function posted_last_order_date($value){$value=trim((string)wp_unslash($value));$date=self::normalize_expiry($value);if($value!==''&&!$date)wp_die('Ange ett giltigt Last order date.',400);return $date;}
 static function movement($product_id,$batch,$expiry,$location,$qty,$action,$source_type,$source_id,$source_key,$note='',$last_order_date=null,$in_transaction=false){
  if(!self::schema_ready())return false;
  global $wpdb;$product_id=absint($product_id);$qty=(float)$qty;if(!$product_id||$qty==0||$source_key==='')return false;
  $batch=sanitize_text_field($batch);$location=sanitize_text_field($location);$expiry=self::normalize_expiry($expiry);$m=self::table('movements');$b=self::table('balances');
  if($wpdb->get_var($wpdb->prepare("SELECT id FROM $m WHERE source_key=%s",$source_key)))return true;
  $now=current_time('mysql');$last_order_date=self::normalize_expiry($last_order_date);if(!$in_transaction&&Dennis_WMS_Audit::query('START TRANSACTION')===false)return false;
  try{
   $slot=$wpdb->get_row($wpdb->prepare("SELECT * FROM $b WHERE product_id=%d AND batch=%s AND ((expiry=%s) OR (expiry IS NULL AND %s='')) AND location=%s FOR UPDATE",$product_id,$batch,$expiry?:'', $expiry?:'', $location));
   if($slot&&!empty($slot->last_order_date)){if($last_order_date&&$last_order_date!==$slot->last_order_date)throw new Exception('date-conflict');$last_order_date=$slot->last_order_date;}
   $ok=Dennis_WMS_Audit::insert($m,['product_id'=>$product_id,'batch'=>$batch,'expiry'=>$expiry,'last_order_date'=>$last_order_date,'location'=>$location,'quantity'=>$qty,'action'=>$action,'source_type'=>$source_type,'source_id'=>absint($source_id),'source_key'=>$source_key,'note'=>$note,'user_id'=>get_current_user_id(),'created_at'=>$now]);
   if(!$ok)throw new Exception('movement');
   $row=$slot;
   if($row){$new=(float)$row->quantity+$qty;if($new<0)throw new Exception('negative');if(Dennis_WMS_Audit::update($b,['quantity'=>$new,'last_order_date'=>$last_order_date,'updated_at'=>$now],['id'=>$row->id])===false)throw new Exception('balance-update');}
   else {if($qty<0)throw new Exception('negative');if(!Dennis_WMS_Audit::insert($b,['product_id'=>$product_id,'batch'=>$batch,'expiry'=>$expiry,'last_order_date'=>$last_order_date,'location'=>$location,'quantity'=>$qty,'created_at'=>$now,'updated_at'=>$now]))throw new Exception('balance-insert');}
   if(!$in_transaction&&Dennis_WMS_Audit::query('COMMIT')===false)throw new Exception('commit');return true;
  }catch(Exception $e){if(!$in_transaction)Dennis_WMS_Audit::query('ROLLBACK');return false;}
 }
 static function record_receipt($line,$qty){
  if(!$line||$qty<=0)return false;
  return self::movement((int)$line->product_id,(string)$line->batch,(string)$line->expiry,(string)$line->location,(float)$qty,'receipt','dennis_wms_receipt',(int)$line->receipt_id,'receipt-line-'.$line->id.'-posted-'.((int)$line->posted_qty+(int)$qty),'IN-'.$line->receipt_id.' rad '.$line->id,$line->last_order_date??null);
 }
 static function backfill_receipts(){
  global $wpdb;$l=$wpdb->prefix.'dennis_wms_receipt_lines';if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$l))!==$l)return;
  $rows=$wpdb->get_results("SELECT * FROM $l WHERE posted_qty>0 AND (batch<>'' OR expiry IS NOT NULL) ORDER BY id ASC");
  foreach($rows as $line)self::movement((int)$line->product_id,(string)$line->batch,(string)$line->expiry,(string)$line->location,(float)$line->posted_qty,'receipt_backfill','dennis_wms_receipt',(int)$line->receipt_id,'receipt-backfill-'.$line->id,'Historisk bokförd inleverans');
 }
 static function pick_order_sql(){return "CASE WHEN last_order_date IS NULL OR last_order_date='' THEN 1 ELSE 0 END,last_order_date ASC,CASE WHEN expiry IS NULL OR expiry='' THEN 1 ELSE 0 END,expiry ASC,id ASC";}
 static function balances($product_id){
  global $wpdb;$b=self::table('balances');$today=current_time('Y-m-d');$order=self::pick_order_sql();return $wpdb->get_results($wpdb->prepare("SELECT * FROM $b WHERE product_id=%d AND quantity>0 AND (expiry IS NULL OR expiry >= %s) AND (last_order_date IS NULL OR last_order_date >= %s) ORDER BY $order",absint($product_id),$today,$today));
 }
 static function all_balances($product_id){
  global $wpdb;$b=self::table('balances');$order=self::pick_order_sql();return $wpdb->get_results($wpdb->prepare("SELECT * FROM $b WHERE product_id=%d AND quantity>0 ORDER BY $order",absint($product_id)));
 }
 static function summary($days=30){
  global $wpdb;$b=self::table('balances');$m=self::table('movements');$today=current_time('Y-m-d');$d30=wp_date('Y-m-d',strtotime($today.' +30 days'));$d60=wp_date('Y-m-d',strtotime($today.' +60 days'));$d90=wp_date('Y-m-d',strtotime($today.' +90 days'));$after=(new DateTimeImmutable('now',wp_timezone()))->modify('-'.absint($days).' days')->format('Y-m-d H:i:s');
  $base=$wpdb->get_row("SELECT COUNT(*) slots,COUNT(DISTINCT product_id) products,COALESCE(SUM(quantity),0) units FROM $b WHERE quantity>0",ARRAY_A);
  $base['expired']=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(quantity),0) FROM $b WHERE quantity>0 AND expiry IS NOT NULL AND expiry < %s",$today));
  $base['d30']=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(quantity),0) FROM $b WHERE quantity>0 AND expiry BETWEEN %s AND %s",$today,$d30));
  $base['d60']=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(quantity),0) FROM $b WHERE quantity>0 AND expiry > %s AND expiry <= %s",$d30,$d60));
  $base['d90']=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(quantity),0) FROM $b WHERE quantity>0 AND expiry > %s AND expiry <= %s",$d60,$d90));
  $base['movements']=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $m WHERE created_at >= %s",$after));
  return $base;
 }
 static function last_order_summary(){
  $empty=['passed'=>0,'today'=>0,'soon'=>0,'undated'=>0];if(!self::schema_ready())return $empty;
  global $wpdb;$table=self::table('balances');$today=current_time('Y-m-d');$until=(new DateTimeImmutable('today',wp_timezone()))->modify('+'.Dennis_WMS_Warnings::last_order_days().' days')->format('Y-m-d');
  $row=$wpdb->get_row($wpdb->prepare("SELECT COALESCE(SUM(CASE WHEN last_order_date<%s THEN quantity ELSE 0 END),0) passed,COALESCE(SUM(CASE WHEN last_order_date=%s THEN quantity ELSE 0 END),0) today,COALESCE(SUM(CASE WHEN last_order_date>%s AND last_order_date<=%s THEN quantity ELSE 0 END),0) soon,COALESCE(SUM(CASE WHEN last_order_date IS NULL THEN quantity ELSE 0 END),0) undated FROM $table WHERE quantity>0",$today,$today,$today,$until),ARRAY_A);
  return is_array($row)?array_merge($empty,$row):$empty;
 }
 static function report_balances(){global $wpdb;$b=self::table('balances');return $wpdb->get_results("SELECT * FROM $b ORDER BY product_id,batch,expiry,location,id");}
 static function report_movements($days){global $wpdb;$m=self::table('movements');$after=(new DateTimeImmutable('now',wp_timezone()))->modify('-'.absint($days).' days')->format('Y-m-d H:i:s');return $wpdb->get_results($wpdb->prepare("SELECT * FROM $m WHERE created_at>=%s ORDER BY id DESC",$after));}
 static function rows_for_product($product_id){return self::balances($product_id);}
 static function recent_movements($days=30,$limit=500){global $wpdb;$m=self::table('movements');$after=(new DateTimeImmutable('now',wp_timezone()))->modify('-'.absint($days).' days')->format('Y-m-d H:i:s');return $wpdb->get_results($wpdb->prepare("SELECT * FROM $m WHERE created_at >= %s ORDER BY id DESC LIMIT %d",$after,absint($limit)));}
 static function expiring_rows($limit=500){global $wpdb;$b=self::table('balances');return $wpdb->get_results($wpdb->prepare("SELECT * FROM $b WHERE quantity>0 AND expiry IS NOT NULL ORDER BY expiry ASC,id ASC LIMIT %d",absint($limit)));}

 static function allocate($product_id,$needed){
  $needed=(float)$needed;$out=[];foreach(self::balances($product_id) as $r){if($needed<=0)break;$take=min($needed,(float)$r->quantity);if($take<=0)continue;$out[]=['batch'=>$r->batch,'expiry'=>$r->expiry,'location'=>$r->location,'qty'=>$take,'available'=>(float)$r->quantity];$needed-=$take;}
  return ['rows'=>$out,'missing'=>max(0,$needed)];
 }
 static function adjust(){
  self::require_schema();
  if(!current_user_can(self::CAP)||!current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad',403);check_admin_referer('dennis_wms_batch_adjust');
  $sku=sanitize_text_field(wp_unslash($_POST['sku']??''));$pid=$sku?wc_get_product_id_by_sku($sku):0;$p=$pid?wc_get_product($pid):false;if(!$p)wp_die('SKU hittades inte.',400);
  $batch=sanitize_text_field(wp_unslash($_POST['batch']??''));$expiry=sanitize_text_field(wp_unslash($_POST['expiry']??''));$location=sanitize_text_field(wp_unslash($_POST['location']??''));$qty=(float)($_POST['quantity']??0);if($qty==0)wp_die('Ange en justering som inte är 0.',400);
  $last_order_date=self::posted_last_order_date($_POST['last_order_date']??'');
  $key='manual-'.get_current_user_id().'-'.wp_generate_uuid4();if(!self::movement($pid,$batch,$expiry,$location,$qty,'manual_adjustment','manual',0,$key,sanitize_textarea_field(wp_unslash($_POST['note']??'')),$last_order_date))wp_die('Justeringen kunde inte sparas. Kontrollera saldot och att Last order date stämmer med befintlig batchpost. Ändra befintligt datum via Batch / datum.',409);
  wp_safe_redirect(add_query_arg(['page'=>'dennis-wms-batches','sku'=>$sku,'dw_batch_notice'=>'saved'],admin_url('admin.php')));exit;
 }

 static function distribution_panel($prod,$return_locations=false){
  if(!current_user_can(self::CAP)||!current_user_can("manage_woocommerce"))return;
  $pid=$prod->get_id();$sku=$prod->get_sku();
   $wc=(float)$prod->get_stock_quantity();$existing=self::all_balances($pid);$distributed=0;foreach($existing as $er)$distributed+=(float)$er->quantity;$remaining=$wc-$distributed;
   echo '<div style="background:#fff;border:2px solid #1D949C;border-radius:12px;padding:16px;margin:18px 0"><h2 style="margin-top:0">📦 Fördela WooCommerce-saldo</h2><p style="font-size:16px"><strong>WooCommerce: '.esc_html(wc_format_localized_decimal($wc)).' st</strong> · Fördelat: '.esc_html(wc_format_localized_decimal($distributed)).' st · <strong>Kvar: '.esc_html(wc_format_localized_decimal($remaining)).' st</strong></p><p class="description">Fördela hela WooCommerce-saldot på batchrader. Lagerplats, batch, expire och Last order date är valfria. Lagerplats kan läggas till senare via Spara plats. Last order date gäller den enskilda batchposten. Detta ändrar inte WooCommerce-saldot.</p>';
   echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" id="dw-distribute-form">';wp_nonce_field('dennis_wms_batch_distribute');echo '<input type="hidden" name="action" value="dennis_wms_batch_distribute"><input type="hidden" name="sku" value="'.esc_attr($sku).'"><input type="hidden" name="return_locations" value="'.($return_locations?'1':'0').'"><div style="overflow-x:auto"><table class="widefat striped" id="dw-dist-table"><thead><tr><th>Lagerplats (valfri)</th><th>Batch (valfri)</th><th>Expire (valfri)</th><th>Last order date (valfri)</th><th>Antal</th><th></th></tr></thead><tbody>';
   if($existing){foreach($existing as $er)echo '<tr><td><input name="dist_location[]" value="'.esc_attr($er->location).'" placeholder="Kan anges senare"></td><td><input name="dist_batch[]" value="'.esc_attr($er->batch).'" placeholder="Valfri"></td><td><input type="date" name="dist_expiry[]" value="'.esc_attr($er->expiry).'"></td><td><input type="date" name="dist_last_order_date[]" value="'.esc_attr($er->last_order_date??'').'"></td><td><input class="dw-dist-qty" type="number" min="0" step="1" name="dist_qty[]" value="'.esc_attr(wc_format_decimal($er->quantity,0)).'" style="width:90px"></td><td><button type="button" class="button dw-dist-remove">Ta bort</button></td></tr>';}
   else echo '<tr><td><input name="dist_location[]" placeholder="Kan anges senare"></td><td><input name="dist_batch[]" placeholder="Valfri"></td><td><input type="date" name="dist_expiry[]"></td><td><input type="date" name="dist_last_order_date[]"></td><td><input class="dw-dist-qty" type="number" min="0" step="1" name="dist_qty[]" value="0" style="width:90px"></td><td><button type="button" class="button dw-dist-remove">Ta bort</button></td></tr>';
   echo '</tbody></table></div><p><button type="button" class="button" id="dw-dist-add">+ Lägg till rad</button> <strong id="dw-dist-live"></strong></p><p><button class="button button-primary">Spara fördelning</button></p></form>';
   echo '<script>(function(){const body=document.querySelector("#dw-dist-table tbody"),wc='.wp_json_encode($wc).';function calc(){let n=0;document.querySelectorAll(".dw-dist-qty").forEach(x=>n+=parseFloat(x.value)||0);const k=wc-n,e=document.querySelector("#dw-dist-live");e.textContent="Fördelat: "+n+" · Kvar: "+k;e.style.color=Math.abs(k)<0.0001?"#008a20":"#b32d2e"}function bind(){document.querySelectorAll(".dw-dist-qty").forEach(x=>x.oninput=calc);document.querySelectorAll(".dw-dist-remove").forEach(x=>x.onclick=function(){this.closest("tr").remove();calc()})}document.querySelector("#dw-dist-add").onclick=function(){const tr=document.createElement("tr");tr.innerHTML=`<td><input name="dist_location[]" placeholder="Kan anges senare"></td><td><input name="dist_batch[]" placeholder="Valfri"></td><td><input type="date" name="dist_expiry[]"></td><td><input type="date" name="dist_last_order_date[]"></td><td><input class="dw-dist-qty" type="number" min="0" step="1" name="dist_qty[]" value="0" style="width:90px"></td><td><button type="button" class="button dw-dist-remove">Ta bort</button></td>`;body.appendChild(tr);bind();calc()};bind();calc()})();</script></div>';
 }
 static function distribute(){
  self::require_schema();
  if(!current_user_can(self::CAP)||!current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad',403);check_admin_referer('dennis_wms_batch_distribute');
  $sku=sanitize_text_field(wp_unslash($_POST['sku']??''));$pid=$sku?wc_get_product_id_by_sku($sku):0;$p=$pid?wc_get_product($pid):false;if(!$p||!$p->managing_stock())wp_die('SKU hittades inte eller saknar WooCommerce-lagerhantering.',400);
  $locations=(array)($_POST['dist_location']??[]);$batches=(array)($_POST['dist_batch']??[]);$expiries=(array)($_POST['dist_expiry']??[]);$quantities=(array)($_POST['dist_qty']??[]);$last_dates=(array)($_POST['dist_last_order_date']??[]);
  $new=[];$total=0.0;$n=max(count($locations),count($batches),count($expiries),count($quantities));
  for($i=0;$i<$n;$i++){$loc=sanitize_text_field(wp_unslash($locations[$i]??''));$batch=sanitize_text_field(wp_unslash($batches[$i]??''));$expiry=self::normalize_expiry(wp_unslash($expiries[$i]??''));$last_date=self::posted_last_order_date($last_dates[$i]??'');$q=(float)wc_format_decimal(wp_unslash($quantities[$i]??0),4);if($q<0)wp_die('Antal kan inte vara negativt.',400);if($q==0)continue;$key=$loc."\x1f".$batch."\x1f".($expiry?:'');if(isset($new[$key])){if($new[$key]['last_order_date']!==$last_date)wp_die('Samma batch, utgångsdatum och lagerplats måste ha samma Last order date.',400);$new[$key]['quantity']+=$q;}else$new[$key]=['location'=>$loc,'batch'=>$batch,'expiry'=>$expiry,'last_order_date'=>$last_date,'quantity'=>$q];$total+=$q;}
  $wc=(float)$p->get_stock_quantity();if(abs($total-$wc)>0.0001)wp_die('Fördelningen måste vara exakt samma som WooCommerce-saldot. WooCommerce: '.esc_html(wc_format_localized_decimal($wc)).' · Fördelat: '.esc_html(wc_format_localized_decimal($total)),409);
  global $wpdb;$bt=self::table('balances');$mt=self::table('movements');$old=$wpdb->get_results($wpdb->prepare("SELECT * FROM $bt WHERE product_id=%d AND quantity>0",$pid));$now=current_time('mysql');$token='distribution-'.$pid.'-'.wp_generate_uuid4();Dennis_WMS_Audit::query('START TRANSACTION');
  try{
   foreach($old as $r){if(!Dennis_WMS_Audit::insert($mt,['product_id'=>$pid,'batch'=>(string)$r->batch,'expiry'=>self::normalize_expiry($r->expiry),'last_order_date'=>$r->last_order_date??null,'location'=>(string)$r->location,'quantity'=>-(float)$r->quantity,'action'=>'distribution_out','source_type'=>'manual','source_id'=>0,'source_key'=>$token.'-out-'.$r->id,'note'=>'Omfördelning från WooCommerce-saldo','user_id'=>get_current_user_id(),'created_at'=>$now]))throw new Exception('log-out');}
   if(Dennis_WMS_Audit::query($wpdb->prepare("DELETE FROM $bt WHERE product_id=%d",$pid))===false)throw new Exception('delete');
   $j=0;foreach($new as $r){$j++;if(!Dennis_WMS_Audit::insert($bt,['product_id'=>$pid,'batch'=>$r['batch'],'expiry'=>$r['expiry'],'last_order_date'=>$r['last_order_date'],'location'=>$r['location'],'quantity'=>$r['quantity'],'created_at'=>$now,'updated_at'=>$now]))throw new Exception('balance');if(!Dennis_WMS_Audit::insert($mt,['product_id'=>$pid,'batch'=>$r['batch'],'expiry'=>$r['expiry'],'last_order_date'=>$r['last_order_date'],'location'=>$r['location'],'quantity'=>$r['quantity'],'action'=>'distribution_in','source_type'=>'manual','source_id'=>0,'source_key'=>$token.'-in-'.$j,'note'=>'Fördelning från WooCommerce-saldo','user_id'=>get_current_user_id(),'created_at'=>$now]))throw new Exception('log-in');}
   Dennis_WMS_Audit::query('COMMIT');
  }catch(Exception $e){Dennis_WMS_Audit::query('ROLLBACK');wp_die('Fördelningen kunde inte sparas. Inga ändringar genomfördes.',500);}
  wp_safe_redirect(add_query_arg(!empty($_POST['return_locations'])?['page'=>'dennis-wms-locations','sku'=>$sku,'dw_loc_notice'=>'distributed']:['page'=>'dennis-wms-batches','sku'=>$sku,'dw_batch_notice'=>'distributed'],admin_url('admin.php')));exit;
 }

 /** Record a date cause only if this operation introduced a discrepancy from a balanced state. */
 static function log_discard_difference($p,$ledger_before,$wc_before,$reason,$date,$batch){
  if(!class_exists('Dennis_WMS_Audit')||!Dennis_WMS_Audit::$ready||$ledger_before===null||abs($ledger_before-$wc_before)>=0.00001)return;
  global $wpdb;$pid=(int)$p->get_id();$b=self::table('balances');$m=self::table('movements');$sum=$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(quantity),0) FROM $b WHERE product_id=%d",$pid));if($sum===null)return;
  $fresh=wc_get_product($pid);if(!$fresh)return;$wc=(float)$fresh->get_stock_quantity();$diff=(float)$sum-$wc;if(abs($diff)<0.00001)return;
  $latest=(int)$wpdb->get_var($wpdb->prepare("SELECT MAX(id) FROM $m WHERE product_id=%d",$pid));
  Dennis_WMS_Audit::record('Differens vid datumkassering','product',$pid,['batchsaldo'=>$ledger_before,'wc_saldo'=>$wc_before,'differens'=>$ledger_before-$wc_before],['batchsaldo'=>(float)$sum,'wc_saldo'=>$wc,'differens'=>$diff,'orsak'=>$reason,'datum'=>$date,'batch'=>$batch,'senaste_batchhandelse'=>$latest],'WMS','failed',$p->get_sku());
 }
 static function discard_expired(){
  self::require_schema();
  if(!current_user_can(self::CAP)||!current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad',403);$id=absint($_POST['balance_id']??0);check_admin_referer('dennis_wms_batch_discard_expired_'.$id);
  global $wpdb;$b=self::table('balances');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $b WHERE id=%d",$id));if(!$row)wp_die('Batchposten hittades inte.',404);
  $reason=sanitize_key(wp_unslash($_POST['discard_reason']??'expiry'));if(!in_array($reason,['expiry','last_order'],true))wp_die('Ogiltig kasseringsorsak.',400);
  $expiry=self::normalize_expiry($row->expiry);$last_order=self::normalize_expiry($row->last_order_date??'');$date=$reason==='last_order'?$last_order:$expiry;
  if(!self::can_discard_expiry($date))wp_die($reason==='last_order'?'Batchen kan kasseras från och med Last order date.':'Batchen kan kasseras från och med sitt utgångsdatum.',409);$qty=(float)$row->quantity;if($qty<=0)wp_die('Batchen saknar saldo.',409);
  $p=wc_get_product((int)$row->product_id);if(!$p||!$p->managing_stock())wp_die('Produkten saknar WooCommerce-lagerhantering.',409);$wc=(float)$p->get_stock_quantity();if($wc<$qty)wp_die('WooCommerce-saldot är lägre än batchen. Stäm av lagret innan kassering.',409);
  $ledger_before=$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(quantity),0) FROM $b WHERE product_id=%d",(int)$row->product_id));$ledger_before=$ledger_before===null?null:(float)$ledger_before;
  $action=$reason==='last_order'?'last_order_discard':'expired_discard';$note=($reason==='last_order'?'Kassering på grund av Last order date':'Kassering på grund av utgångsdatum').': '.$date.'; SKU: '.$p->get_sku().'; batchpost: #'.$id;
  $token=$action.'-'.$id.'-'.wp_generate_uuid4();if(!self::movement((int)$row->product_id,(string)$row->batch,$expiry,(string)$row->location,-$qty,$action,'manual',0,$token,$note,$last_order))wp_die('Kunde inte kassera batchen.',500);
  $new_wc=wc_update_product_stock($p,$qty,'decrease');if($new_wc===false||is_wp_error($new_wc)){self::movement((int)$row->product_id,(string)$row->batch,$expiry,(string)$row->location,$qty,$action.'_rollback','manual',0,$token.'-rollback','Återställning efter misslyckad WooCommerce-uppdatering; '.$note,$last_order);self::log_discard_difference($p,$ledger_before,$wc,$action,$date,(string)$row->batch);wp_die('WooCommerce-saldot kunde inte uppdateras. Batchen återställdes.',500);}
  self::log_discard_difference($p,$ledger_before,$wc,$action,$date,(string)$row->batch);
  wp_safe_redirect(add_query_arg(['page'=>'dennis-wms-batches','sku'=>$p->get_sku(),'dw_batch_notice'=>'expired_discarded'],admin_url('admin.php')));exit;
 }

 static function edit_meta(){
  self::require_schema();
  if(!current_user_can(self::CAP)||!current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad',403);check_admin_referer('dennis_wms_batch_edit_meta');
  global $wpdb;$b=self::table('balances');$m=self::table('movements');$id=absint($_POST['balance_id']??0);
  $batch=sanitize_text_field(wp_unslash($_POST['batch']??''));$expiry=self::normalize_expiry(wp_unslash($_POST['expiry']??''));$last=self::posted_last_order_date($_POST['last_order_date']??'');
  Dennis_WMS_Audit::query('START TRANSACTION');
  try{
   $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $b WHERE id=%d FOR UPDATE",$id));if(!$row)throw new Exception('Batchposten hittades inte.');
   $target=$wpdb->get_row($wpdb->prepare("SELECT * FROM $b WHERE product_id=%d AND batch=%s AND ((expiry=%s) OR (expiry IS NULL AND %s='')) AND location=%s AND id<>%d FOR UPDATE",$row->product_id,$batch,$expiry?:'',$expiry?:'',$row->location,$id));
   if($target&&($target->last_order_date?:'')!==($last?:''))throw new Exception('Batchen på målplatsen har ett annat Last order date. Välj ett annat batchnummer eller ändra datumet först.');
   $now=current_time('mysql');$q=(float)$row->quantity;
   if($target){if(Dennis_WMS_Audit::update($b,['quantity'=>(float)$target->quantity+$q,'updated_at'=>$now],['id'=>$target->id])===false||Dennis_WMS_Audit::delete($b,['id'=>$id])===false)throw new Exception('Kunde inte uppdatera batchen.');}
   elseif(Dennis_WMS_Audit::update($b,['batch'=>$batch,'expiry'=>$expiry,'last_order_date'=>$last,'updated_at'=>$now],['id'=>$id])===false)throw new Exception('Kunde inte uppdatera batchen.');
   $token=wp_generate_uuid4();foreach(['out','in'] as $direction){$is_out=$direction==='out';if(!Dennis_WMS_Audit::insert($m,['product_id'=>$row->product_id,'batch'=>$is_out?$row->batch:$batch,'expiry'=>$is_out?$row->expiry:$expiry,'last_order_date'=>$is_out?($row->last_order_date??null):$last,'location'=>$row->location,'quantity'=>$is_out?-$q:$q,'action'=>'reclassify_'.$direction,'source_type'=>'manual','source_id'=>0,'source_key'=>'batch-meta-'.$direction.'-'.$token,'note'=>'Batch, expire och Last order date uppdaterade i WMS','user_id'=>get_current_user_id(),'created_at'=>$now]))throw new Exception('Kunde inte logga datumändringen.');}
   Dennis_WMS_Audit::query('COMMIT');
  }catch(Exception $e){Dennis_WMS_Audit::query('ROLLBACK');wp_die(esc_html($e->getMessage()),409);}
  $p=wc_get_product($row->product_id);wp_safe_redirect(add_query_arg(['page'=>'dennis-wms-batches','sku'=>$p?$p->get_sku():'','dw_batch_notice'=>'meta_saved'],admin_url('admin.php')));exit;
 }

 static function set_location(){
  self::require_schema();
  if(!current_user_can(self::CAP)||!current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad',403);
  check_admin_referer('dennis_wms_batch_set_location');
  global $wpdb;$b=self::table('balances');$m=self::table('movements');
  $id=absint($_POST['balance_id']??0);$location=sanitize_text_field(wp_unslash($_POST['location']??''));
  if(!$id||$location===''||strlen($location)>80)wp_die('Ange en lagerplats.',400);
  Dennis_WMS_Audit::query('START TRANSACTION');
  try{
   $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $b WHERE id=%d FOR UPDATE",$id));
   if(!$row)throw new Exception('Batchposten hittades inte.');
   if((string)$row->location===$location)throw new Exception('Välj en annan lagerplats.');
   $now=current_time('mysql');$qty=(float)$row->quantity;$expiry=self::normalize_expiry($row->expiry);
   $target=$wpdb->get_row($wpdb->prepare("SELECT * FROM $b WHERE product_id=%d AND batch=%s AND ((expiry=%s) OR (expiry IS NULL AND %s='')) AND location=%s FOR UPDATE",$row->product_id,$row->batch,$expiry?:'',$expiry?:'',$location));
   if($target&&($target->last_order_date?:'')!==($row->last_order_date?:''))throw new Exception('date-conflict');
   if($target){$ok=Dennis_WMS_Audit::update($b,['quantity'=>(float)$target->quantity+$qty,'updated_at'=>$now],['id'=>$target->id]);if($ok===false)throw new Exception('target');$ok=Dennis_WMS_Audit::delete($b,['id'=>$id]);if(!$ok)throw new Exception('delete');}
   else {$ok=Dennis_WMS_Audit::update($b,['location'=>$location,'updated_at'=>$now],['id'=>$id]);if($ok===false)throw new Exception('update');}
   $base='set-location-'.get_current_user_id().'-'.wp_generate_uuid4();
   $common=['product_id'=>(int)$row->product_id,'batch'=>(string)$row->batch,'expiry'=>$expiry,'last_order_date'=>$row->last_order_date??null,'action'=>'set_location','source_type'=>'manual','source_id'=>0,'note'=>'Lagerplats ändrad: '.($row->location?:'Ingen plats').' → '.$location,'user_id'=>get_current_user_id(),'created_at'=>$now];
   $a=$common;$a['location']=$row->location;$a['quantity']=-$qty;$a['source_key']=$base.'-from';if(!Dennis_WMS_Audit::insert($m,$a))throw new Exception('log-from');
   $a=$common;$a['location']=$location;$a['quantity']=$qty;$a['source_key']=$base.'-to';if(!Dennis_WMS_Audit::insert($m,$a))throw new Exception('log-to');
   Dennis_WMS_Audit::query('COMMIT');
  }catch(Exception $e){Dennis_WMS_Audit::query('ROLLBACK');wp_die('Lagerplatsen kunde inte sparas.',500);}
  $p=wc_get_product($row->product_id);$sku=$p?$p->get_sku():'';
  wp_safe_redirect(add_query_arg(['page'=>'dennis-wms-batches','sku'=>$sku,'dw_batch_notice'=>'location_saved'],admin_url('admin.php')));exit;
 }
 static function last_order_cell($row){
  $date=$row->last_order_date??'';if(!$date)return '–';$html=esc_html($date);
  if((float)$row->quantity>0&&class_exists('Dennis_WMS_Warnings')){$days=Dennis_WMS_Warnings::days_until($date);if($days!==null&&$days<=Dennis_WMS_Warnings::last_order_days())$html.='<br><strong style="color:#b32d2e">'.esc_html(Dennis_WMS_Warnings::label($days,'last')).'</strong>';}
  return $html;
 }
 static function action_label($action){
  if($action==='arrival_updated')return 'Ankomstuppgifter ändrade';
  $labels=['receipt'=>'Godkänd inleverans bokförd','receipt_backfill'=>'Historisk inleverans införd','manual_adjustment'=>'Manuell saldojustering','inventory'=>'Inventeringsdifferens','distribution_out'=>'Omfördelning – från tidigare plats','distribution_in'=>'Omfördelning – till ny plats','last_order_discard'=>'Batch kasserad – Last order date nådd','last_order_discard_rollback'=>'Kassering för Last order date återställd efter fel','expired_discard'=>'Utgången batch kasserad','expired_discard_rollback'=>'Kassering återställd efter fel','reclassify_out'=>'Tidigare batch-/datumuppgifter ersatta','reclassify_in'=>'Nya batch-/datumuppgifter registrerade','reclassify_rollback'=>'Batch-/datumändring återställd efter fel','set_location'=>'Lagerplats angiven','order_created'=>'Lageruttag för kundorder','order_refund'=>'Kundretur till lager','order_restored'=>'Orderlager återfört','location_to_batch_base'=>'Lagerplatssaldo infört i batchregistret','classify_batch_out'=>'Saldo före batchregistrering','classify_batch_in'=>'Saldo till registrerad batch','classify_batch_rollback'=>'Batchregistrering återställd efter fel','location_transfer_out'=>'Lagerflytt – från plats','location_transfer_in'=>'Lagerflytt – till plats','location_transfer_rollback'=>'Lagerflytt återställd efter fel','location_adjustment'=>'Lagerplatssaldo justerat','location_adjustment_rollback'=>'Lagerplatsjustering återställd efter fel','created'=>'Inleverans skapad','updated'=>'Uppgifter uppdaterade','received'=>'Varor mottagna','approved'=>'Varor godkända','posted'=>'Godkänt antal bokfört till lager','rejected'=>'Varor avvisade','damage'=>'Skada registrerad'];
  return $labels[$action]??('Övrig händelse ('.$action.')');
 }
 static function source_label($type,$id=0){
  $labels=['manual'=>'Manuell registrering i WMS','locations'=>'Lagerplatsregistret','dennis_wms_receipt'=>'Inleverans i WMS','woocommerce_order'=>'Kundorder i WooCommerce','woocommerce_refund'=>'Återbetalning / retur i WooCommerce','count'=>'Inventering i WMS'];
  $label=$labels[$type]??($type!==''?'Annat ursprung ('.$type.')':'Ursprung ej angivet');
  if($id)$label.=$type==='dennis_wms_receipt'?' · IN-'.absint($id):' · #'.absint($id);return $label;
 }
 static function page($embedded=false){
  if(!current_user_can('pb_wms_view'))wp_die('Åtkomst nekad',403);global $wpdb;$b=self::table('balances');$sku=sanitize_text_field(wp_unslash($_GET['sku']??''));$pid=$sku?wc_get_product_id_by_sku($sku):0;
  echo '<div class="'.($embedded?'dw-batch-register':'wrap').'">'.($embedded?'<h2>Batcher och datum</h2>':'<h1>Batcher & utgångsdatum</h1>').'<p><strong>Detta är Dennis WMS centrala batchregister.</strong> Här hanteras och justeras batchsaldo. På övriga WMS-sidor visas batchinformationen endast för plock, inleverans eller statistik. Plockordning: Last order date styr först, därefter Expire date. Batcher utan Last order date sorteras efter dem som har ett datum.</p>';
  if(!$embedded&&class_exists('Dennis_WMS_Multi_Shop')&&class_exists('Dennis_WMS_Remote_Stock_Details')){
   $dw_shop=absint($_GET['dw_batch_shop']??0);
   echo '<section class="dw-multishop-stock"><h2>Shopfilter – anslutna shoppar</h2><form method="get"><input type="hidden" name="page" value="dennis-wms-batches"><label>Shop <select name="dw_batch_shop"><option value="0">Alla anslutna shoppar</option>';
   foreach(Dennis_WMS_Multi_Shop::shops() as $dw_s)echo '<option value="'.absint($dw_s->id).'" '.selected($dw_shop,(int)$dw_s->id,false).'>'.esc_html($dw_s->name).'</option>';
   echo '</select></label> <button class="button">Filtrera</button></form>';
   Dennis_WMS_Remote_Stock_Details::render($dw_shop,'batches');echo '</section><hr style="margin:30px 0"><h2>Huvudshop – batchregister</h2>';
  }
  if(isset($_GET['dw_batch_notice'])){ $msg=$_GET['dw_batch_notice']==='location_saved'?'Lagerplatsen är sparad. Batchsaldot är oförändrat.':($_GET['dw_batch_notice']==='meta_saved'?'Batch / expire / Last order date är uppdaterad utan att totalsaldot ändrades.':($_GET['dw_batch_notice']==='expired_discarded'?'Batchen är kasserad och loggad. WooCommerce-saldot har minskats med samma antal.':($_GET['dw_batch_notice']==='distributed'?'Fördelningen är sparad. WooCommerce-saldot är oförändrat.':($_GET['dw_batch_notice']==='warning_settings'?'Varningsgränserna är sparade.':'Batchsaldot är uppdaterat.')))); echo '<div class="notice notice-success"><p>'.esc_html($msg).'</p></div>'; }
  if(!$embedded)echo '<form method="get"><input type="hidden" name="page" value="dennis-wms-batches"><label>Visa SKU <input name="sku" value="'.esc_attr($sku).'" placeholder="SKU"></label> <button class="button">Visa</button></form>'; 
  if(class_exists('Dennis_WMS_Warnings')&&current_user_can('manage_woocommerce')){echo '<details style="background:#fff;border:1px solid #ddd;border-radius:9px;padding:10px 14px;margin:12px 0"><summary style="cursor:pointer;font-weight:600">⚙️ Datumvarningar</summary><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:flex;gap:14px;align-items:end;flex-wrap:wrap;margin-top:12px">';wp_nonce_field('dennis_wms_warning_settings');echo '<input type="hidden" name="action" value="dennis_wms_warning_settings"><label>Varna expire före<br><input type="number" min="1" max="365" name="expiry_days" value="'.esc_attr(Dennis_WMS_Warnings::expiry_days()).'" style="width:90px"> dagar</label><label>Varna Last order date före<br><input type="number" min="1" max="365" name="last_order_days" value="'.esc_attr(Dennis_WMS_Warnings::last_order_days()).'" style="width:90px"> dagar</label><button class="button button-primary">Spara varningsgränser</button></form></details>'; }
  if($pid&&($prod=wc_get_product($pid))&&$prod->managing_stock()){
   self::distribution_panel($prod);
  }
  $where=$pid?$wpdb->prepare(' WHERE product_id=%d',$pid):'';$order=self::pick_order_sql();$rows=$wpdb->get_results("SELECT * FROM $b".$where." ORDER BY product_id,$order LIMIT 1000");
  echo '<h2>Aktuella batchsaldon</h2><table class="widefat striped"><thead><tr><th>SKU</th><th>Produkt</th><th>Batch</th><th>Expire date</th><th>Last order date</th><th>Lagerplats</th><th>Antal</th><th>Plockordning</th><th>Åtgärd</th></tr></thead><tbody>';
  $last=0;$rank=0;$today=current_time('Y-m-d');foreach($rows as $r){$p=wc_get_product($r->product_id);$has_stock=(float)$r->quantity>0;$expired=$has_stock&&!empty($r->expiry)&&$r->expiry<$today;$days=(!empty($r->expiry)&&class_exists('Dennis_WMS_Warnings'))?Dennis_WMS_Warnings::days_until($r->expiry):null;$soon=($has_stock&&!$expired&&$days!==null&&$days<=Dennis_WMS_Warnings::expiry_days());if($last!=$r->product_id){if($last)echo '<tr class="dw-batch-sku-divider" aria-hidden="true"><td colspan="9" style="height:16px;padding:0;background:#f4f8fa;border-top:3px solid #1D949C"></td></tr>';$last=$r->product_id;$rank=0;}$last_passed=$has_stock&&!empty($r->last_order_date)&&$r->last_order_date<$today;if($has_stock&&!$expired&&!$last_passed)$rank++;$fefo=!$has_stock?'Inget saldo':(($expired||$last_passed)?'–':'#'.$rank);echo '<tr'.($expired?' style="background:#fff1f1"':($soon?' style="background:#fff8e5"':'')).'><td><strong>'.esc_html($p?$p->get_sku():'#'.$r->product_id).'</strong></td><td>'.esc_html($p?$p->get_name():'Produkt borttagen').'</td><td>'.esc_html($r->batch?:'–').'</td><td>'.($expired?'<strong style="color:#b32d2e">'.esc_html($r->expiry).' · UTGÅNGEN</strong>':($soon?'<strong style="color:#996800">'.esc_html($r->expiry).' · '.esc_html(Dennis_WMS_Warnings::label($days,'expiry')).'</strong>':esc_html($r->expiry?:'–'))).'</td><td>'.self::last_order_cell($r).'</td><td>'.esc_html($r->location?:'–').'</td><td>'.esc_html(wc_format_localized_decimal($r->quantity)).'</td><td>'.esc_html($fefo).'</td><td>';
   if(current_user_can(self::CAP)&&current_user_can('manage_woocommerce')){
    $discard_reason=self::can_discard_expiry($r->expiry)?'expiry':(self::can_discard_expiry($r->last_order_date??'')?'last_order':'');
    if($discard_reason!==''&&$r->quantity>0){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-bottom:8px" onsubmit="return confirm(\'Kassera hela batchen? Samma antal dras även från WooCommerce och kasseringen loggas.\')">';wp_nonce_field('dennis_wms_batch_discard_expired_'.$r->id);echo '<input type="hidden" name="action" value="dennis_wms_batch_discard_expired"><input type="hidden" name="balance_id" value="'.esc_attr($r->id).'"><input type="hidden" name="discard_reason" value="'.esc_attr($discard_reason).'"><button class="button button-small" style="color:#b32d2e;border-color:#b32d2e">'.esc_html($discard_reason==='last_order'?'🗑 Kassera – Last order date nådd':'🗑 Kassera utgången batch').'</button></form>';}
    {echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin-bottom:6px">';wp_nonce_field('dennis_wms_batch_set_location');echo '<input type="hidden" name="action" value="dennis_wms_batch_set_location"><input type="hidden" name="balance_id" value="'.esc_attr($r->id).'"><input name="location" required maxlength="80" value="'.esc_attr($r->location).'" placeholder="Lagerplats" style="width:120px"><button class="button button-small">📍 Spara plats</button></form>';}
    echo '<details><summary style="cursor:pointer">✏️ Batch / datum</summary><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:grid;gap:5px;margin-top:6px;min-width:180px">';wp_nonce_field('dennis_wms_batch_edit_meta');echo '<input type="hidden" name="action" value="dennis_wms_batch_edit_meta"><input type="hidden" name="balance_id" value="'.esc_attr($r->id).'"><input name="batch" value="'.esc_attr($r->batch).'" placeholder="Batch"><input type="date" name="expiry" value="'.esc_attr($r->expiry).'"><label>Last order date<input type="date" name="last_order_date" value="'.esc_attr($r->last_order_date??'').'"></label><button class="button button-small">Spara</button></form></details>';
   }else echo '–';echo '</td></tr>';
  }
  if(!$rows)echo '<tr><td colspan="9">Inga batchsaldon registrerade ännu.</td></tr>';echo '</tbody></table>';
  $sum=self::summary(30);echo '<h2>Batchstatistik</h2><div style="display:flex;gap:10px;flex-wrap:wrap">';foreach(['Aktiva batchposter'=>$sum['slots'],'SKU med batchsaldo'=>$sum['products'],'Enheter i batchlager'=>$sum['units'],'Utgångna enheter'=>$sum['expired'],'Utgår 0–30 dagar'=>$sum['d30'],'Utgår 31–60 dagar'=>$sum['d60'],'Utgår 61–90 dagar'=>$sum['d90'],'Batchhändelser 30 dagar'=>$sum['movements']] as $k=>$v)echo '<div style="background:#fff;border:1px solid #ddd;border-radius:9px;padding:12px 16px;min-width:145px"><small>'.esc_html($k).'</small><strong style="display:block;font-size:22px;color:#ED6B7C">'.esc_html(number_format_i18n((float)$v)).'</strong></div>';echo '</div>';
  $lod=self::last_order_summary();echo '<h2>Last order date – aktuellt batchlager</h2><p>Antal enheter med sista orderdag inom vald varningsgräns. Endast batchposter med saldo ingår.</p><div style="display:flex;gap:10px;flex-wrap:wrap">';foreach(['Sista orderdag passerad'=>$lod['passed'],'Sista orderdag idag'=>$lod['today'],'Sista orderdag närmar sig'=>$lod['soon'],'Utan sista orderdag'=>$lod['undated']] as $label=>$value)echo '<div class="dw-kpi" style="padding:12px"><small>'.esc_html($label).'</small><strong style="display:block">'.esc_html(number_format_i18n((float)$value)).' st</strong></div>';echo '</div>';
  $moves=self::recent_movements(30,100);echo '<h2>Senaste batchhändelser</h2><p><strong>Händelse</strong> beskriver vad som gjordes. <strong>Ursprung / referens</strong> visar var ändringen kom ifrån och vilken order, inleverans eller inventering den hör till.</p><table class="widefat striped"><thead><tr><th>Tid</th><th>SKU</th><th>Batch</th><th>Expire date</th><th>Last order date</th><th>Plats</th><th>Antal</th><th>Händelse</th><th>Ursprung / referens</th><th>Användare</th><th>Detaljer / orsak</th></tr></thead><tbody>';foreach($moves as $mv){$p=wc_get_product($mv->product_id);$user=get_userdata($mv->user_id);echo '<tr><td>'.esc_html($mv->created_at).'</td><td><strong>'.esc_html($p?$p->get_sku():'#'.$mv->product_id).'</strong></td><td>'.esc_html($mv->batch?:'–').'</td><td>'.esc_html($mv->expiry?:'–').'</td><td>'.esc_html($mv->last_order_date??'–').'</td><td>'.esc_html($mv->location?:'–').'</td><td>'.esc_html(wc_format_localized_decimal($mv->quantity)).'</td><td>'.esc_html(self::action_label($mv->action)).'</td><td>'.esc_html(self::source_label($mv->source_type,$mv->source_id)).'</td><td>'.esc_html($user?$user->display_name:'#'.$mv->user_id).'</td><td>'.esc_html($mv->note??'').'</td></tr>';}if(!$moves)echo '<tr><td colspan="11">Inga batchhändelser senaste 30 dagarna.</td></tr>';echo '</tbody></table></div>';
 }
}
Dennis_WMS_Batches::boot();
