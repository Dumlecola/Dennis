# Händelselogg – Dennis WMS 2.0.81

Öppna **System → Händelselogg** som administratör. Loggningen startar när en administratör öppnar WordPress efter uppdateringen och loggtabellen har skapats. Därefter fungerar loggning även för personal, WooCommerce, API-anrop till WooCommerce och schemalagda körningar som använder de observerade funktionerna.

## Vad registreras?

- Pluginets skrivningar i egna WMS-tabeller: mottagning, godkännande, avvisning, bilder, inventering, batcher, datum, kassering, lagerplatser, leverans och tracking, externa shoppar och synkronisering.
- Produkt- och ordermetadata, produktens titel/status och radering, WooCommerce stock API, orderstatus och order-CRUD inklusive HPOS.

Sidbesök, inloggningar, användaradministration, inställningsändringar och allmänna HTTP-begäranden registreras inte i denna lagerlogg. Äldre sådana poster visas inte heller i vyn, CSV eller utskrift. De tas inte bort ur databasen, och tidigare lagerhistorik bevaras. Användaren som gör en lagerändring visas fortfarande på ändringens loggrad.

Användare och SKU sparas när uppgifterna finns tillgängliga. Orderhändelser får en rad per relaterad SKU. Tiden visas i svensk tid (Europe/Stockholm) med datum och HH:mm. Nya händelser har en separat UTC-tidsstämpel. Datumfilter, export och utskrift använder samma svenska tidszon. Äldre loggrader tolkas med WordPress tidszon vid visning; om den tidszonen ändrats efter registreringen kan den ursprungliga tidszonen inte säkert återskapas. Före/efter innehåller uppgifter som faktiskt kan observeras; saknad tidigare uppgift visas som null.

**Genomförd** gäller en observerad skrivning. Framgångsrika skrivningar inom WMS-transaktioner loggas efter COMMIT. ROLLBACK registrerar återställning utan att visa de återställda skrivningarna som genomförda. Flera lågnivåskrivningar kan höra till samma arbetsmoment; identifieraren Begäran kopplar ihop dem.

Sök efter SKU, namn, händelse eller objekt-ID. CSV och Skriv ut alla träffar använder samma filter och tar med alla träffar, inte bara sidan med 50 rader. CSV skyddar mot formelinjektion. Detaljer och kommentarer HTML-escapas. Uppgifter visas i en läsbar tabell, medan tekniska rådata och begärans ID finns bakom en separat detaljpanel.

## Säkerhet och avgränsning

Endast `manage_options` ger läsning och export. Export kräver nonce. Loggen har ingen radera-/redigera-knapp och trimmas inte automatiskt. Säkerhetskopiera databasen för att bevara den.

Identifierade lösenords-, token- och API-nyckelfält maskeras, inklusive krypterade nycklar. Privata filvägar maskeras. Rå SQL, råa HTTP-payloads och headers lagras inte. Skriv aldrig lösenord i fritextkommentarer.

Loggningen kan inte observera direkt SQL, serverändringar, varje klick, ändringar genom andra plugins som kringgår observerade hooks eller tidigare ologgade handlingar. Tidigare inleverans-/batchhistorik finns kvar i ursprungliga vyer. Detta är ingen manipulationssäker extern loggtjänst; någon med databasåtkomst kan ändra loggen. Vid masskrivningar begränsas detaljerade före/efter-urval till 101 rader; antalet berörda rader finns i händelsen där det kan observeras. Loggfel skriver en generell PHP-loggvarning och visas för administratören.

Inventeringslistan, korrigeringshistoriken, produktstatistikens inventeringar och rapportens inventeringsdel visar datum och HH:mm. Databasens fullständiga tidsstämplar bevaras.

## Leverans och differenser

Leveransvyn innehåller leveranssätt, status, avsändare, transportör, kolli, tracking-/sändningsnummer och fraktdokument. Automatisk fraktberäkning och vikt-/måttfält visas inte. Tidigare sparade mått bevaras när en skickad leverans sparas. Produktfält för automatisk pall-/kolliberäkning visas inte längre. Inga boknings-API-anrop finns; API används enbart för DHL/DSV Tracking.

Differensvyn visar bara totalsaldona och skillnaden. Rutan Varför finns en differens? med generell förklaring och historik är borttagen.

En kort rad med Expire date eller Last order date och batch visas endast när registrerade före-/eftersaldon visar att en datumkassering introducerade en differens från ett avstämt saldo. De aktuella saldona måste fortfarande matcha den dokumenterade differensen, och efterföljande batch-/saldoändringar gör datumförklaringen inaktuell. En gammal kassering eller ett passerat datum används aldrig ensamt som bevis. Historiska differenser utan sådant underlag får ingen extra förklaring. Uppgifterna börjar registreras i 2.0.81.

En normal kassering ska minska WooCommerce- och batchsaldo lika mycket och skapar då ingen differens. En ny differens vid datumkassering loggas som ett fel med före/efter för felsökning.

## Testa på en kopia

1. Öppna WMS som administratör för att skapa loggtabellen. Kontrollera att Händelselogg visas.
2. Registrera en mottagning som personal. Godkänn den. Kontrollera SKU, användare, mottaget antal och ändrat lager i loggen.
3. Ändra en produkt i WooCommerce, gör en inventering och flytta en batch. Kontrollera före/efter och att totalsaldot fortfarande är rätt.
4. Kassera en testbatch på expire date eller Last order date. Kontrollera båda saldona, kasseringen och datumhistoriken.
5. Gör en manuell saldoändring i WooCommerce för att skapa en kontrollerad differens. Kontrollera att vanlig differens visas utan extra förklaringsruta; lagerändringen syns i Händelselogg.
6. Filtrera loggen per SKU/användare, exportera CSV och skriv ut alla träffar. Personal utan administratörsbehörighet ska nekas logg/export.
7. Kontrollera att API-nycklar inte syns i loggen, och att leveransvyn saknar fraktberäkning och vikt-/måttfält.

Lokala verifieringar använder isolerade WordPress/WooCommerce-fixtures. Kör även dessa användarflöden i er Playground före produktionsuppdatering.

## Uppgradering från äldre versioner

Öppna WMS som administratör efter installation av 2.0.80. Den befintliga tabellen uppgraderas utan att radera historik. En extra kontroll lägger till den nullable UTC-kolumnen om dbDelta inte redan har gjort det. Uppgraderingen kan köras igen utan dubbla kolumner.
