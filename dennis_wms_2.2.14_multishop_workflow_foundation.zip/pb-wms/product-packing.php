<?php
if (!defined('ABSPATH')) exit;
/** Counts packed ordinary units as a subset of the SKU's total physical stock. */
final class Dennis_WMS_Product_Packing {
 const META='_dennis_wms_prepacked_qty';
 static $changed=[],$refunds=[];
 static function boot(){
  add_action('woocommerce_product_before_set_stock',[__CLASS__,'stock_before']);
  add_action('woocommerce_variation_before_set_stock',[__CLASS__,'stock_before']);
  add_action('woocommerce_product_set_stock',[__CLASS__,'stock_before']);
  add_action('woocommerce_variation_set_stock',[__CLASS__,'stock_before']);
  add_action('shutdown',[__CLASS__,'reconcile']);
  add_action('woocommerce_reduce_order_item_stock',[__CLASS__,'order_take'],5,3);
  add_action('woocommerce_restore_order_stock',[__CLASS__,'order_restore'],5);
  add_action('woocommerce_create_refund',[__CLASS__,'refund_context'],11,2);
  add_action('woocommerce_refund_created',[__CLASS__,'refund_clear'],11,2);
  add_action('woocommerce_restock_refunded_item',[__CLASS__,'refund_restore'],5,5);
 }
 static function raw($pid){return max(0,(int)get_post_meta($pid,self::META,true));}
 static function quantity($p){if(!$p||(Dennis_WMS_Kits::recipe($p->get_id())&&!Dennis_WMS_Kits::base_product($p->get_id())))return 0;return min(self::raw($p->get_id()),max(0,(int)$p->get_stock_quantity('edit')));}
 static function valid_product($p){return $p&&$p->get_sku()!==''&&$p->is_type(['simple','variation'])&&(!Dennis_WMS_Kits::recipe($p->get_id())||(Dennis_WMS_Kits::base_product($p->get_id())&&!Dennis_WMS_Kits::on_demand($p)))&&$p->managing_stock()&&$p->get_stock_managed_by_id()===$p->get_id()&&$p->get_stock_quantity('edit')!==null;}
 static function count_value($value,$stock){$n=filter_var($value,FILTER_VALIDATE_INT,['options'=>['min_range'=>0,'max_range'=>1000000000]]);if($n===false)throw new Exception('Ange ett helt antal förpackade produkter, minst 0.');if($n>max(0,(int)$stock))throw new Exception('Antalet förpackade får inte överstiga saldot ('.max(0,(int)$stock).' st).');return $n;}
 static function write($pid,$n){$n=max(0,(int)$n);$result=update_post_meta($pid,self::META,$n);if($result===false&&self::raw($pid)!==$n)throw new Exception('Kunde inte spara antalet förpackade produkter.');update_post_meta($pid,'_dennis_wms_prepacked',$n>0?'yes':'no');}
 static function set_quantity($pid,$value){
  return Dennis_WMS_Kits::transaction([$pid],function()use($pid,$value){$p=Dennis_WMS_Kits::fresh($pid);if(!self::valid_product($p)||Dennis_WMS_Kits::recipe($pid))throw new Exception('Välj en vanlig produkt eller variant med SKU och eget lagerstyrt saldo.');$n=self::count_value($value,$p->get_stock_quantity('edit'));$old=self::quantity($p);self::write($pid,$n);Dennis_WMS_Audit::record('Antal förpackade ändrat','product',$pid,['förpackade'=>$old],['förpackade'=>$n,'saldo'=>$p->get_stock_quantity('edit')],'WMS','success',$p->get_sku());return $n;});
 }
 static function stock_before($p){if($p&&(!Dennis_WMS_Kits::recipe($p->get_id())||Dennis_WMS_Kits::base_product($p->get_id())))self::$changed[$p->get_id()]=true;}
 // Woo's item hook follows its stock update; defer clamping until that hook can debit the packed subset.
 static function reconcile(){foreach(self::$changed as $id=>$unused){$p=Dennis_WMS_Kits::fresh($id);if(!$p||(Dennis_WMS_Kits::recipe($id)&&!Dennis_WMS_Kits::base_product($id)))continue;try{Dennis_WMS_Kits::transaction([$id],function()use($id){$p=Dennis_WMS_Kits::fresh($id);if($p&&self::raw($id)>self::quantity($p))self::write($id,self::quantity($p));});}catch(Throwable $e){error_log('Dennis WMS: förpackat antal kunde inte stämmas av för produkt '.(int)$id);}}self::$changed=[];}
 /** Called inside the kit transaction, with the count captured before its stock change. */
 static function component_take($pid,$qty,$before){$n=min(max(0,(int)$before),(int)$qty);self::write($pid,max(0,(int)$before-$n));return $n;}
 static function component_return($pid,$qty){if($qty<=0)return;$p=Dennis_WMS_Kits::fresh($pid);self::write($pid,min(self::raw($pid)+(int)$qty,max(0,(int)$p->get_stock_quantity('edit'))));}
 static function item_meta($item,$key){if(function_exists('wc_get_order_item_meta')){wp_cache_delete($item->get_id(),'order_item_meta');return wc_get_order_item_meta($item->get_id(),$key,true);}return $item->get_meta($key,true);}
 static function order_take($item,$change,$order){
  $p=$item?$item->get_product():false;if(!self::valid_product($p)||!is_array($change)||!isset($change['from'],$change['to']))return;$id=$p->get_id();$qty=max(0,(int)$change['from']-(int)$change['to']);if(!$qty)return;$key=(string)$change['from'].'>'.(string)$change['to'];
  try{Dennis_WMS_Kits::transaction([$id],function()use($item,$p,$qty,$key,$change){if(self::item_meta($item,'_dennis_wms_packed_change')===$key)return;$before=min(self::raw($p->get_id()),max(0,(int)$change['from']));$take=min($before,$qty);self::write($p->get_id(),min($before-$take,max(0,(int)Dennis_WMS_Kits::fresh($p->get_id())->get_stock_quantity('edit'))));$item->update_meta_data('_dennis_wms_packed_taken',(int)self::item_meta($item,'_dennis_wms_packed_taken')+$take);$item->update_meta_data('_dennis_wms_packed_planned',$take);$item->update_meta_data('_dennis_wms_packed_change',$key);$item->save_meta_data();});}
  catch(Throwable $e){Dennis_WMS_Kits::order_error($order,'Förpackat antal kunde inte uppdateras: '.$e->getMessage());}
 }
 static function return_item($order,$item,$qty,$key){
  $p=$item->get_product();if(!self::valid_product($p))return;
  Dennis_WMS_Kits::transaction([$p->get_id()],function()use($item,$p,$qty,$key){$marker='_dennis_wms_packed_return_'.$key;if(self::item_meta($item,$marker)==='yes')return;$remaining=max(0,(int)self::item_meta($item,'_dennis_wms_packed_taken'));$take=min($remaining,(int)$qty);self::component_return($p->get_id(),$take);$item->update_meta_data('_dennis_wms_packed_taken',$remaining-$take);$item->update_meta_data($marker,'yes');$item->save_meta_data();});
 }
 static function order_restore($order){
  if(is_numeric($order))$order=wc_get_order($order);if(!$order)return;
  foreach($order->get_items('line_item') as $item){$n=(int)self::item_meta($item,'_dennis_wms_packed_taken');if($n<1){$item->update_meta_data('_dennis_wms_packed_change','');$item->save_meta_data();continue;}try{self::return_item($order,$item,$n,'cancel-'.wp_generate_uuid4());$item->update_meta_data('_dennis_wms_packed_change','');$item->save_meta_data();}catch(Throwable $e){Dennis_WMS_Kits::order_error($order,'Förpackat antal kunde inte återställas: '.$e->getMessage());}}
 }
 static function refund_context($refund,$args){if(!empty($args['restock_items']))self::$refunds[(int)$args['order_id']]=['refund'=>$refund,'lines'=>$args['line_items']];}
 static function refund_clear($id,$args){unset(self::$refunds[(int)$args['order_id']]);}
 static function refund_restore($pid,$old,$new,$order,$product){
  $context=self::$refunds[$order->get_id()]??null;if(!$context||$new<=$old)return;
  foreach($context['lines'] as $iid=>$line){$item=$order->get_item($iid);$p=$item?$item->get_product():false;if(!$p||$p->get_stock_managed_by_id()!==(int)$pid||($line['qty']??0)<=0)continue;$key='refund-'.$context['refund']->get_id();if(self::item_meta($item,'_dennis_wms_packed_return_'.$key)==='yes')continue;try{self::return_item($order,$item,min((int)$line['qty'],(int)($new-$old)),$key);}catch(Throwable $e){Dennis_WMS_Kits::order_error($order,'Förpackat antal på returen behöver kontrolleras.');}break;}
 }
 static function pick_instruction($n,$loose,$component=false){
  if($n>0)return 'Plocka först '.$n.' förpackade '.($component?'komponenter':'produkter').'.'.($loose?' Plocka därefter '.$loose.($component?' oförpackade komponenter till förpackningen.':' oförpackade produkter som behöver packas.'):'');
  return $loose>0?($component?'Plocka '.$loose.' oförpackade komponenter till förpackningen.':'Förpackade exemplar saknas för denna rad. Packa '.$loose.' produkter.'):'';
 }
 static function describe_pick($row,$packed,$component=false){
  $n=min(max(0,(int)$packed),max(0,(int)$row['qty']));$loose=max(0,(int)$row['qty']-$n);$row['packed_qty']=$n;$row['unpacked_qty']=$loose;$row['base_name']=$row['name'];$row['packing_component_only']=$component;
  $row['packing_instruction']=self::pick_instruction($n,$loose,$component);return $row;
 }
 static function pick_row($item,$row,&$budget=[],$order=null){
  $p=$item->get_product();if(!$p||Dennis_WMS_Kits::recipe($p->get_id()))return $row;
  $planned=self::item_meta($item,'_dennis_wms_packed_planned');$n=$planned!==''?min(max(0,(int)$planned),(int)$row['qty']):0;
  $waiting=!$order||$order->get_meta('_dennis_wms_pick_status',true)!=='done';
  if($planned===''||$waiting){$id=$p->get_id();if(!isset($budget[$id]))$budget[$id]=self::quantity($p);$extra=min($budget[$id],max(0,(int)$row['qty']-$n));$budget[$id]-=$extra;$n+=$extra;}
  return self::describe_pick($row,$n);
 }
 // Convert the preview into a reservation only when the employee starts picking.
 static function reserve_for_pick($order){
  $items=$order->get_items('line_item');$ids=[];foreach($items as $item){$p=$item->get_product();if($p&&!Dennis_WMS_Kits::item_recipe($item)&&self::valid_product($p))$ids[]=$p->get_id();}
  if(!$ids)return;
  Dennis_WMS_Kits::transaction($ids,function()use($order,$items){
   foreach($items as $item){$p=$item->get_product();if(!$p||Dennis_WMS_Kits::item_recipe($item)||!self::valid_product($p))continue;
    $planned=self::item_meta($item,'_dennis_wms_packed_planned');if($planned==='')continue; // Woo has not yet reduced this line's stock.
    $n=max(0,(int)$planned);$p=Dennis_WMS_Kits::fresh($p->get_id());$extra=min(self::quantity($p),max(0,(int)$item->get_quantity()-$n));if(!$extra)continue;
    self::write($p->get_id(),self::quantity($p)-$extra);$item->update_meta_data('_dennis_wms_packed_planned',$n+$extra);$item->update_meta_data('_dennis_wms_packed_taken',(int)self::item_meta($item,'_dennis_wms_packed_taken')+$extra);$item->save_meta_data();
    Dennis_WMS_Audit::record('För-packade reserverade vid plockstart','order',$order->get_id(),['förpackade'=>$n],['förpackade'=>$n+$extra,'artikel_id'=>$p->get_id()],'WMS','success',$p->get_sku());
   }
  });
 }
 static function prioritize($rows){
  // Preserve the existing order within each packing group, including location/Plockordning details.
  $units=[];foreach($rows as $key=>$row){$group=!empty($row['accompanying_group'])?'kit:'.$row['accompanying_group']:'row:'.$key;$units[$group][$key]=$row;}$all=[];$mixed=[];$loose=[];foreach($units as $unit){$priority=2;foreach($unit as $row){$n=(int)($row['packed_qty']??0);if($n>0)$priority=min($priority,$n>=(float)$row['qty']?0:1);}if($priority===0)$all+=$unit;elseif($priority===1)$mixed+=$unit;else $loose+=$unit;}return $all+$mixed+$loose;
 }

}
Dennis_WMS_Product_Packing::boot();
