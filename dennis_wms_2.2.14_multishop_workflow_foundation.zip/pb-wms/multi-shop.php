<?php
if (!defined('ABSPATH')) exit;
/**
 * Dennis WMS Multi-Shop beta.
 * One central Dennis WMS installation can connect to multiple independent WooCommerce shops.
 * Remote WooCommerce data is read-only in v1.8.3; credentials are never rendered back to the browser.
 */
final class Dennis_WMS_Multi_Shop {
 const SCHEMA='1.9.0';
 const CAP='pb_wms_manage';
 static function table($name){global $wpdb;return $wpdb->prefix.'dennis_wms_ms_'.$name;}
 static function boot(){
  add_action('admin_menu',[__CLASS__,'menu'],109);
  add_action('admin_init',[__CLASS__,'upgrade']);
  add_action('admin_post_dennis_wms_shop_save',[__CLASS__,'save_shop']);
  add_action('admin_post_dennis_wms_shop_test',[__CLASS__,'test_shop_action']);
  add_action('admin_post_dennis_wms_shop_sync',[__CLASS__,'sync_shop_action']);
  add_action('admin_post_dennis_wms_shop_delete',[__CLASS__,'delete_shop']);
  add_action('admin_post_dennis_wms_remote_pick_print',[__CLASS__,'print_remote_pick']);
  add_filter('cron_schedules',[__CLASS__,'cron_schedules']);
  add_action('dennis_wms_multishop_auto_sync',[__CLASS__,'auto_sync']);
  add_action('init',[__CLASS__,'ensure_auto_sync']);
 }
 static function menu(){add_submenu_page('pb-wms','Anslutna shoppar','Anslutna shoppar','pb_wms_view','dennis-wms-shops',[__CLASS__,'page']);}
 static function cron_schedules($schedules){
  if(!isset($schedules['dennis_wms_every_minute']))$schedules['dennis_wms_every_minute']=['interval'=>60,'display'=>'Varje minut (Dennis WMS)'];
  return $schedules;
 }
 static function ensure_auto_sync(){
  if(!wp_next_scheduled('dennis_wms_multishop_auto_sync'))wp_schedule_event(time()+60,'dennis_wms_every_minute','dennis_wms_multishop_auto_sync');
 }
 static function auto_sync(){
  if(get_transient('dennis_wms_multishop_auto_sync_lock'))return;
  set_transient('dennis_wms_multishop_auto_sync_lock',1,55);
  foreach(self::shops() as $shop){
   $r=self::sync_shop_fast($shop);
   if(is_wp_error($r)){global $wpdb;Dennis_WMS_Audit::update(self::table('shops'),['status'=>'error','last_error'=>'Automatisk synk: '.$r->get_error_message(),'updated_at'=>current_time('mysql')],['id'=>$shop->id]);}
  }
  delete_transient('dennis_wms_multishop_auto_sync_lock');
  update_option('dennis_wms_multishop_last_auto_sync',current_time('mysql'),false);
 }
 static function install(){
  global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$c=$wpdb->get_charset_collate();
  $s=self::table('shops');$p=self::table('products');$o=self::table('orders');
  dbDelta("CREATE TABLE $s (id bigint(20) unsigned NOT NULL AUTO_INCREMENT,name varchar(190) NOT NULL,url varchar(255) NOT NULL,consumer_key longtext NOT NULL,consumer_secret longtext NOT NULL,status varchar(30) NOT NULL DEFAULT 'new',last_tested datetime NULL,last_sync datetime NULL,last_error text NULL,created_at datetime NOT NULL,updated_at datetime NOT NULL,PRIMARY KEY (id),UNIQUE KEY url (url)) $c;");
  dbDelta("CREATE TABLE $p (id bigint(20) unsigned NOT NULL AUTO_INCREMENT,shop_id bigint(20) unsigned NOT NULL,remote_product_id bigint(20) unsigned NOT NULL,remote_parent_id bigint(20) unsigned NOT NULL DEFAULT 0,sku varchar(190) NOT NULL DEFAULT '',name text NOT NULL,type varchar(40) NOT NULL DEFAULT '',status varchar(40) NOT NULL DEFAULT '',stock_quantity decimal(18,4) NULL,image_url text NULL,categories_json longtext NULL,attributes_json longtext NULL,updated_at datetime NOT NULL,PRIMARY KEY (id),UNIQUE KEY remote_product (shop_id,remote_product_id),KEY shop_sku (shop_id,sku),KEY shop_id (shop_id)) $c;");
  dbDelta("CREATE TABLE $o (id bigint(20) unsigned NOT NULL AUTO_INCREMENT,shop_id bigint(20) unsigned NOT NULL,remote_order_id bigint(20) unsigned NOT NULL,order_number varchar(100) NOT NULL DEFAULT '',status varchar(40) NOT NULL DEFAULT '',date_created datetime NULL,date_completed datetime NULL,customer_name varchar(190) NOT NULL DEFAULT '',shipping_json longtext NULL,items_json longtext NULL,updated_at datetime NOT NULL,PRIMARY KEY (id),UNIQUE KEY remote_order (shop_id,remote_order_id),KEY shop_status (shop_id,status),KEY order_date (date_created)) $c;");
  update_option('dennis_wms_multishop_schema',self::SCHEMA);
 }
 static function upgrade(){if(current_user_can('manage_options')&&get_option('dennis_wms_multishop_schema')!==self::SCHEMA)self::install();}
 static function crypt_key(){return hash('sha256',wp_salt('auth').'|dennis-wms-multishop',true);}
 static function encrypt($value){$value=(string)$value;if($value==='')return '';$out=Dennis_WMS_Security::encrypt($value);if(is_wp_error($out))wp_die(esc_html($out->get_error_message()),503);return $out;}
 static function decrypt($value){
  $value=(string)$value;if($value===''||!Dennis_WMS_Security::ready())return '';if(strpos($value,'v2:')===0||strpos($value,'v3:')===0){$out=Dennis_WMS_Security::decrypt($value);return is_wp_error($out)?'':$out;}
  if(strpos($value,'v1:')===0&&function_exists('openssl_decrypt')){$raw=base64_decode(substr($value,3),true);if($raw!==false&&strlen($raw)>16){$out=openssl_decrypt(substr($raw,16),'AES-256-CBC',self::crypt_key(),OPENSSL_RAW_DATA,substr($raw,0,16));return $out===false?'':$out;}}
  if(strpos($value,'plain:')===0){$out=base64_decode(substr($value,6),true);return $out===false?'':$out;}
  return '';
 }
 static function normalize_url($url){$url=untrailingslashit(esc_url_raw(trim((string)$url)));if(!$url)return ''; $parts=wp_parse_url($url);if(empty($parts['scheme'])||empty($parts['host'])||!in_array(strtolower($parts['scheme']),['https','http'],true))return '';return $url;}
 static function get_shop($id){global $wpdb;$s=self::table('shops');return $wpdb->get_row($wpdb->prepare("SELECT * FROM $s WHERE id=%d",absint($id)));}
 static function shops(){global $wpdb;$s=self::table('shops');return $wpdb->get_results("SELECT * FROM $s ORDER BY name ASC,id ASC");}
 static function auth_headers($shop){return ['Authorization'=>'Basic '.base64_encode(self::decrypt($shop->consumer_key).':'.self::decrypt($shop->consumer_secret)),'Accept'=>'application/json'];}
 static function api($shop,$endpoint,$query=[]){
  if(!self::decrypt($shop->consumer_key)||!self::decrypt($shop->consumer_secret))return new WP_Error('dw_crypto','API-nycklarna kan inte läsas. Kontrollera serverns krypteringsstöd och ange nycklarna igen.');
  $url=trailingslashit($shop->url).'wp-json/wc/v3/'.ltrim($endpoint,'/');if($query)$url=add_query_arg($query,$url);
  $r=wp_safe_remote_get($url,['timeout'=>20,'redirection'=>0,'headers'=>self::auth_headers($shop),'user-agent'=>'Dennis-WMS/'.(defined('PB_WMS_VERSION')?PB_WMS_VERSION:'1.8.3')]);
  if(is_wp_error($r))return $r;$code=(int)wp_remote_retrieve_response_code($r);$body=wp_remote_retrieve_body($r);$data=json_decode($body,true);
  if($code<200||$code>=300){$msg=is_array($data)&&!empty($data['message'])?$data['message']:'HTTP '.$code;return new WP_Error('remote_api',sanitize_text_field($msg),['status'=>$code]);}
  // Do not turn an empty/non-JSON HTTP 200 response into an empty product.
  // Some proxies/Playground instances reply 200 without forwarding the WooCommerce payload.
  if(!is_array($data)){
   $type=(string)wp_remote_retrieve_header($r,'content-type');
   $error=json_last_error_msg();
   return new WP_Error('remote_invalid_json',sprintf('API returnerade HTTP %d men inget giltigt JSON-objekt. Svarslängd: %d byte. Content-Type: %s. JSON: %s. Kontrollera ansluten shops REST API-adress och eventuella omdirigeringar.', $code,strlen((string)$body),sanitize_text_field($type?:'saknas'),sanitize_text_field($error)),['status'=>$code]);
  }
  if($data===[] && preg_match('~^products/\d+(?:/variations/\d+)?$~',trim((string)$endpoint,'/'))){
   return new WP_Error('remote_empty_product','API returnerade HTTP 200 men ett tomt JSON-objekt för produktadressen. Kontrollera att ansluten shop verkligen levererar produktdata via REST API. Ingen lagerändring utfördes.',['status'=>$code]);
  }
  return ['data'=>$data,'headers'=>wp_remote_retrieve_headers($r),'code'=>$code];
 }
 static function test_shop($shop){$r=self::api($shop,'products',['per_page'=>1,'page'=>1,'_fields'=>'id,name']);if(is_wp_error($r))return $r;return true;}
 static function notice_url($type,$msg='',$shop_id=0){return add_query_arg(['page'=>'dennis-wms-shops','dw_ms_notice'=>$type,'dw_ms_msg'=>rawurlencode($msg),'shop_id'=>$shop_id?:false],admin_url('admin.php'));}
 static function save_shop(){
  if(!current_user_can(self::CAP)||!current_user_can('manage_options'))wp_die('Åtkomst nekad.',403);check_admin_referer('dennis_wms_shop_save');global $wpdb;$s=self::table('shops');$id=absint($_POST['shop_id']??0);
  $name=sanitize_text_field(wp_unslash($_POST['name']??''));$url=self::normalize_url(wp_unslash($_POST['url']??''));if($url){$parts=wp_parse_url($url);$host=strtolower((string)($parts['host']??''));if(strtolower((string)($parts['scheme']??''))!=='https'&&!in_array($host,['localhost','127.0.0.1','::1'],true))wp_die('Använd HTTPS för externa WooCommerce-shoppar så att API-nycklarna skyddas under överföringen.',400);}$key=sanitize_text_field(wp_unslash($_POST['consumer_key']??''));$secret=sanitize_text_field(wp_unslash($_POST['consumer_secret']??''));if($name===''||$url==='')wp_die('Namn och shop-URL krävs.',400);
  $now=current_time('mysql');$data=['name'=>$name,'url'=>$url,'updated_at'=>$now];
  if($id){$old=self::get_shop($id);if(!$old)wp_die('Shoppen finns inte.',404);if($key!=='')$data['consumer_key']=self::encrypt($key);if($secret!=='')$data['consumer_secret']=self::encrypt($secret);Dennis_WMS_Audit::update($s,$data,['id'=>$id]);}
  else {if($key===''||$secret==='')wp_die('Consumer Key och Consumer Secret krävs.',400);$data+=['consumer_key'=>self::encrypt($key),'consumer_secret'=>self::encrypt($secret),'status'=>'new','created_at'=>$now];$ok=Dennis_WMS_Audit::insert($s,$data);if(!$ok)wp_die('Shoppen kunde inte sparas. Kontrollera att URL:en inte redan finns.',409);$id=(int)$wpdb->insert_id;}
  wp_safe_redirect(self::notice_url('saved','Shoppen är sparad. Testa anslutningen innan synkronisering.',$id));exit;
 }
 static function test_shop_action(){
  if(!current_user_can(self::CAP)||!current_user_can('manage_options'))wp_die('Åtkomst nekad.',403);$id=absint($_POST['shop_id']??0);check_admin_referer('dennis_wms_shop_test_'.$id);global $wpdb;$s=self::table('shops');$shop=self::get_shop($id);if(!$shop)wp_die('Shoppen finns inte.',404);$r=self::test_shop($shop);$now=current_time('mysql');if(is_wp_error($r)){Dennis_WMS_Audit::update($s,['status'=>'error','last_tested'=>$now,'last_error'=>$r->get_error_message(),'updated_at'=>$now],['id'=>$id]);wp_safe_redirect(self::notice_url('error','Anslutningen misslyckades: '.$r->get_error_message(),$id));}else{Dennis_WMS_Audit::update($s,['status'=>'connected','last_tested'=>$now,'last_error'=>'','updated_at'=>$now],['id'=>$id]);wp_safe_redirect(self::notice_url('connected','Anslutningen fungerar.',$id));}exit;
 }
 static function sync_collection($shop,$endpoint,$query,$callback){
  $page=1;$seen=0;$max_pages=30;do{$r=self::api($shop,$endpoint,array_merge($query,['per_page'=>100,'page'=>$page]));if(is_wp_error($r) && isset($query['after']) && strpos($r->get_error_message(),'after')!==false){
    // Compatibility with remote shops rejecting the after parameter. Do not stop order sync.
    // Fallback fetches newest orders first, subject to the normal page limit.
    $fallback=$query;unset($fallback['after']);$r=self::api($shop,$endpoint,array_merge($fallback,['per_page'=>100,'page'=>$page]));
   }
   if(is_wp_error($r))return $r;
   $rows=$r['data'];
   if($rows!==[] && array_keys($rows)!==range(0,count($rows)-1))return new WP_Error('remote_collection_shape','API-svar för '.sanitize_text_field($endpoint).' är inte en JSON-lista. Kontrollera rätt shop och REST API.');
   foreach($rows as $row){
    if(!is_array($row)||empty($row['id']))return new WP_Error('remote_collection_row','API-svar för '.sanitize_text_field($endpoint).' innehåller en post utan giltigt ID.');
    call_user_func($callback,$shop,$row);$seen++;
   }
   $headers=$r['headers'];$total_pages=(int)($headers['x-wp-totalpages']??$headers['X-WP-TotalPages']??1);$page++;}while($rows&&$page<=$total_pages&&$page<=$max_pages);return $seen;
 }
 static function save_remote_product($shop,$row){global $wpdb;$t=self::table('products');$img='';if(!empty($row['images'][0]['src']))$img=esc_url_raw($row['images'][0]['src']);$cats=[];foreach(($row['categories']??[]) as $c)if(!empty($c['name']))$cats[]=sanitize_text_field($c['name']);$attrs=[];foreach(($row['attributes']??[]) as $a)$attrs[]=['name'=>sanitize_text_field($a['name']??''),'options'=>array_map('sanitize_text_field',(array)($a['options']??[]))];$data=['shop_id'=>(int)$shop->id,'remote_product_id'=>absint($row['id']??0),'remote_parent_id'=>absint($row['parent_id']??0),'sku'=>sanitize_text_field($row['sku']??''),'name'=>sanitize_text_field($row['name']??''),'type'=>sanitize_key($row['type']??''),'status'=>sanitize_key($row['status']??''),'stock_quantity'=>isset($row['stock_quantity'])&&$row['stock_quantity']!==null?(float)$row['stock_quantity']:null,'image_url'=>$img,'categories_json'=>wp_json_encode($cats),'attributes_json'=>wp_json_encode($attrs),'updated_at'=>current_time('mysql')];if(!$data['remote_product_id'])return;$id=$wpdb->get_var($wpdb->prepare("SELECT id FROM $t WHERE shop_id=%d AND remote_product_id=%d",$shop->id,$data['remote_product_id']));if($id)Dennis_WMS_Audit::update($t,$data,['id'=>$id]);else Dennis_WMS_Audit::insert($t,$data);}
 static function save_remote_order($shop,$row){global $wpdb;$t=self::table('orders');$ship=(array)($row['shipping']??[]);$first=trim(sanitize_text_field($ship['first_name']??'').' '.sanitize_text_field($ship['last_name']??''));if($first===''){$bill=(array)($row['billing']??[]);$first=trim(sanitize_text_field($bill['first_name']??'').' '.sanitize_text_field($bill['last_name']??''));}$items=[];foreach(($row['line_items']??[]) as $li){$img='';$pid=absint($li['variation_id']??0)?:absint($li['product_id']??0);$pt=self::table('products');$pr=$wpdb->get_row($wpdb->prepare("SELECT image_url FROM $pt WHERE shop_id=%d AND remote_product_id=%d",$shop->id,$pid));if(!$pr&&absint($li['product_id']??0)!==$pid)$pr=$wpdb->get_row($wpdb->prepare("SELECT image_url FROM $pt WHERE shop_id=%d AND remote_product_id=%d",$shop->id,absint($li['product_id']??0)));if($pr)$img=$pr->image_url;$items[]=['item_id'=>absint($li['id']??0),'product_id'=>absint($li['product_id']??0),'variation_id'=>absint($li['variation_id']??0),'name'=>sanitize_text_field($li['name']??''),'sku'=>sanitize_text_field($li['sku']??''),'qty'=>(float)($li['quantity']??0),'image'=>$img];}$date=!empty($row['date_created'])?mysql2date('Y-m-d H:i:s',sanitize_text_field($row['date_created']),false):null;$completed=!empty($row['date_completed'])?mysql2date('Y-m-d H:i:s',sanitize_text_field($row['date_completed']),false):null;$data=['shop_id'=>(int)$shop->id,'remote_order_id'=>absint($row['id']??0),'order_number'=>sanitize_text_field($row['number']??($row['id']??'')),'status'=>sanitize_key($row['status']??''),'date_created'=>$date,'date_completed'=>$completed,'customer_name'=>$first,'shipping_json'=>wp_json_encode($ship),'items_json'=>wp_json_encode($items),'updated_at'=>current_time('mysql')];if(!$data['remote_order_id'])return;$id=$wpdb->get_var($wpdb->prepare("SELECT id FROM $t WHERE shop_id=%d AND remote_order_id=%d",$shop->id,$data['remote_order_id']));if($id)Dennis_WMS_Audit::update($t,$data,['id'=>$id]);else Dennis_WMS_Audit::insert($t,$data);}
 static function sync_shop_fast($shop){
  global $wpdb;$s=self::table('shops');$ot=self::table('orders');
  // Minute sync is deliberately incremental: changed products + all currently open orders + recently completed orders.
  // This keeps new orders fast without downloading a full 365-day history every minute.
  $last=!empty($shop->last_sync)?strtotime($shop->last_sync.' UTC'):0;
  $modified_after=wp_date('Y-m-d\TH:i:s',max(time()-600,$last?($last-300):time()-DAY_IN_SECONDS),wp_timezone());
  $products=self::sync_collection($shop,'products',['status'=>'publish','modified_after'=>$modified_after,'orderby'=>'modified','order'=>'asc'],[__CLASS__,'save_remote_product']);
  if(is_wp_error($products)){
   // Some older WooCommerce APIs do not expose modified_after for products. Orders must still continue syncing every minute.
   $products=0;
  }
  $stale='2000-01-01 00:00:00';
  Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $ot SET updated_at=%s WHERE shop_id=%d AND status IN ('processing','on-hold')",$stale,$shop->id));
  $orders=0;
  foreach(['processing','on-hold'] as $status){$n=self::sync_collection($shop,'orders',['status'=>$status,'orderby'=>'date','order'=>'desc'],[__CLASS__,'save_remote_order']);if(is_wp_error($n))return $n;$orders+=$n;}
  $completed_after=wp_date('Y-m-d\TH:i:s',max(time()-600,$last?($last-300):time()-DAY_IN_SECONDS),wp_timezone());
  $n=self::sync_collection($shop,'orders',['status'=>'completed','after'=>$completed_after,'orderby'=>'date','order'=>'desc'],[__CLASS__,'save_remote_order']);if(is_wp_error($n))return $n;$orders+=$n;
  Dennis_WMS_Audit::query($wpdb->prepare("DELETE FROM $ot WHERE shop_id=%d AND updated_at=%s",$shop->id,$stale));
  $now=current_time('mysql');Dennis_WMS_Audit::update($s,['status'=>'connected','last_sync'=>$now,'last_error'=>'','updated_at'=>$now],['id'=>$shop->id]);
  return ['products'=>$products,'orders'=>$orders];
 }
 static function sync_shop($shop){
  global $wpdb;$s=self::table('shops');$test=self::test_shop($shop);if(is_wp_error($test))return $test;
  $products=self::sync_collection($shop,'products',['status'=>'publish'],[__CLASS__,'save_remote_product']);if(is_wp_error($products))return $products;
  // Mark the old open-order cache before fetching. Successfully fetched rows get a fresh updated_at.
  $ot=self::table('orders');$stale='2000-01-01 00:00:00';Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $ot SET updated_at=%s WHERE shop_id=%d AND status IN ('processing','on-hold')",$stale,$shop->id));
  $orders=0;foreach(['processing','on-hold'] as $status){$n=self::sync_collection($shop,'orders',['status'=>$status,'orderby'=>'date','order'=>'desc'],[__CLASS__,'save_remote_order']);if(is_wp_error($n))return $n;$orders+=$n;} // Keep up to 365 days of completed orders so per-shop statistics have history.
  $after=wp_date('Y-m-d\TH:i:s',time()-365*DAY_IN_SECONDS,wp_timezone());$n=self::sync_collection($shop,'orders',['status'=>'completed','after'=>$after,'orderby'=>'date','order'=>'desc'],[__CLASS__,'save_remote_order']);if(is_wp_error($n))return $n;$orders+=$n;Dennis_WMS_Audit::query($wpdb->prepare("DELETE FROM $ot WHERE shop_id=%d AND status='completed' AND date_created < %s",$shop->id,gmdate('Y-m-d H:i:s',time()-366*DAY_IN_SECONDS)));
  // Only after both status collections succeeded: remove stale rows that are no longer open remotely.
  Dennis_WMS_Audit::query($wpdb->prepare("DELETE FROM $ot WHERE shop_id=%d AND updated_at=%s",$shop->id,$stale));$now=current_time('mysql');Dennis_WMS_Audit::update($s,['status'=>'connected','last_tested'=>$now,'last_sync'=>$now,'last_error'=>'','updated_at'=>$now],['id'=>$shop->id]);return ['products'=>$products,'orders'=>$orders];
 }
 static function sync_shop_action(){
  if(!current_user_can(self::CAP)||!current_user_can('manage_options'))wp_die('Åtkomst nekad.',403);$id=absint($_POST['shop_id']??0);check_admin_referer('dennis_wms_shop_sync_'.$id);$shop=self::get_shop($id);if(!$shop)wp_die('Shoppen finns inte.',404);$r=self::sync_shop($shop);if(is_wp_error($r)){global $wpdb;Dennis_WMS_Audit::update(self::table('shops'),['status'=>'error','last_error'=>$r->get_error_message(),'updated_at'=>current_time('mysql')],['id'=>$id]);wp_safe_redirect(self::notice_url('error','Synkronisering misslyckades: '.$r->get_error_message(),$id));}else {
   $message='Synkroniserat: '.$r['products'].' produkter och '.$r['orders'].' orderposter (öppna + statistikhistorik).';
   if((int)$r['orders']===0){
    $probe=self::api($shop,'orders',['per_page'=>1,'page'=>1]);
    if(is_wp_error($probe))$message.=' Orderdiagnostik: '.$probe->get_error_message();
    else {
     $headers=$probe['headers'];$total=(int)($headers['x-wp-total']??$headers['X-WP-Total']??0);
     $first=$probe['data'][0]??null;
     $message.=' Orderdiagnostik: API utan statusfilter rapporterar '.$total.' ordrar';
     if(is_array($first))$message.='; senaste order-ID '.absint($first['id']??0).' har status '.sanitize_key($first['status']??'okänd');
     $message.='. Kontrollera att anslutningen pekar på rätt WooCommerce-installation och att API-nyckeln kan läsa ordrar.';
    }
   }
   wp_safe_redirect(self::notice_url('synced',$message,$id));
  }exit;
 }
 static function delete_shop(){
  if(!current_user_can(self::CAP)||!current_user_can('manage_options'))wp_die('Åtkomst nekad.',403);$id=absint($_POST['shop_id']??0);check_admin_referer('dennis_wms_shop_delete_'.$id);global $wpdb;Dennis_WMS_Audit::delete(self::table('products'),['shop_id'=>$id]);Dennis_WMS_Audit::delete(self::table('orders'),['shop_id'=>$id]);Dennis_WMS_Audit::delete(self::table('shops'),['id'=>$id]);wp_safe_redirect(self::notice_url('deleted','Shoppen och dess lokala WMS-cache är borttagen.'));exit;
 }
 static function remote_orders($limit=100){global $wpdb;$o=self::table('orders');$s=self::table('shops');return $wpdb->get_results($wpdb->prepare("SELECT o.*,s.name shop_name,s.url shop_url FROM $o o JOIN $s s ON s.id=o.shop_id WHERE o.status IN ('processing','on-hold') ORDER BY o.date_created DESC,o.id DESC LIMIT %d",absint($limit)));}
 static function shipping_label($json){$a=json_decode((string)$json,true);if(!is_array($a))return '';$parts=[];foreach(['address_1','address_2','postcode','city','country'] as $k)if(!empty($a[$k]))$parts[]=sanitize_text_field($a[$k]);return implode(', ',$parts);}
 static function remote_pick_url($row){return add_query_arg(['page'=>'dennis-wms-shops','view'=>'order','remote_order_id'=>$row->id],admin_url('admin.php'));}
 static function render_remote_orders($shop_id=0){
  $rows=self::remote_orders(100);if($shop_id>0)$rows=array_values(array_filter($rows,static function($r)use($shop_id){return (int)$r->shop_id===$shop_id;}));if(class_exists('Dennis_WMS_Deadline'))usort($rows,function($a,$b){$as=Dennis_WMS_Deadline::state('remote:'.(int)$a->shop_id,(int)$a->id,$a);$bs=Dennis_WMS_Deadline::state('remote:'.(int)$b->shop_id,(int)$b->id,$b);$av=$as['due']?$as['due']->getTimestamp():PHP_INT_MAX;$bv=$bs['due']?$bs['due']->getTimestamp():PHP_INT_MAX;return $av<=>$bv;});if(!$rows)return;echo '<h2 style="margin-top:28px">Order från anslutna shoppar – märkta per shop</h2><p>Dessa order är hämtade via WooCommerce REST API. <strong>v1.8.3 läser ordern men skriver inte tillbaka till den externa shoppen.</strong></p><table class="widefat striped"><thead><tr><th>Shop</th><th>Order</th><th>Kund / leverans</th><th>Datum</th><th>Deadline</th><th>Status</th><th>Artiklar</th><th></th></tr></thead><tbody>';foreach($rows as $r){$items=json_decode((string)$r->items_json,true);echo '<tr><td><span class="dw-shop-badge" title="Shop-ID '.absint($r->shop_id).'">🏬 '.esc_html($r->shop_name).'</span></td><td><a href="'.esc_url(self::remote_pick_url($r)).'"><strong>#'.esc_html($r->order_number).'</strong></a><br><small>Shop '.absint($r->shop_id).'</small></td><td>'.esc_html($r->customer_name).'<br><small>'.esc_html(self::shipping_label($r->shipping_json)).'</small></td><td>'.esc_html($r->date_created?:'–').'</td><td>'.(class_exists('Dennis_WMS_Deadline')?Dennis_WMS_Deadline::badge('remote:'.(int)$r->shop_id,(int)$r->id,$r):'–').'</td><td>'.esc_html(class_exists('Dennis_WMS_Delivery')&&Dennis_WMS_Delivery::method_for_order('remote:'.(int)$r->shop_id,(int)$r->id)?Dennis_WMS_Delivery::workflow_label('remote:'.(int)$r->shop_id,(int)$r->id):($r->status==='processing'?'Behandlas':'Väntande')).'</td><td>'.esc_html((string)count((array)$items)).'</td><td><a class="button" href="'.esc_url(self::remote_pick_url($r)).'">Öppna plocklista</a></td></tr>';}echo '</tbody></table>';
 }
 static function get_cached_order($id){global $wpdb;$o=self::table('orders');$s=self::table('shops');return $wpdb->get_row($wpdb->prepare("SELECT o.*,s.name shop_name,s.url shop_url FROM $o o JOIN $s s ON s.id=o.shop_id WHERE o.id=%d",absint($id)));}
 static function render_remote_order($row){Dennis_WMS_Order_UI::render_remote($row);}
 static function print_remote_pick(){
  if(!current_user_can('pb_wms_view'))wp_die('Åtkomst nekad.',403);
  $id=absint($_GET['remote_order_id']??0);check_admin_referer('dennis_wms_remote_pick_print_'.$id);
  $r=self::get_cached_order($id);if(!$r)wp_die('Ordern finns inte.',404);
  nocache_headers();header('Content-Type: text/html; charset='.get_option('blog_charset'));
  echo '<!doctype html><html lang="sv"><head><meta charset="utf-8"><title>Plocklista '.esc_html($r->shop_name).' #'.esc_html($r->order_number).'</title><style>body{font:14px Arial;margin:24px;color:#222}table{border-collapse:collapse;width:100%}th,td{border:1px solid #999;padding:9px;text-align:left;vertical-align:middle}th{background:#eee}.dw-barcode-svg{max-width:190px!important;max-height:48px}button{margin-bottom:20px}@media print{button{display:none}}</style></head><body><button onclick="window.print()">Skriv ut</button><h1>Dennis WMS – '.esc_html($r->shop_name).' – #'.esc_html($r->order_number).'</h1><p><strong>Kund:</strong> '.esc_html($r->customer_name).' <strong>Leverans:</strong> '.esc_html(self::shipping_label($r->shipping_json)).'</p>';
  Dennis_WMS_Order_UI::remote_rows($r,true);echo '</body></html>';exit;
 }
 static function page(){
  if(!current_user_can('pb_wms_view'))wp_die('Åtkomst nekad.',403);self::install();$view=sanitize_key(wp_unslash($_GET['view']??''));if($view==='order'){$r=self::get_cached_order(absint($_GET['remote_order_id']??0));if(!$r)wp_die('Ordern finns inte i Multi-Shop-cachen.',404);self::render_remote_order($r);return;}
  global $wpdb;$shops=self::shops();$edit_id=absint($_GET['shop_id']??0);$edit=$edit_id?self::get_shop($edit_id):null;$notice=sanitize_key(wp_unslash($_GET['dw_ms_notice']??''));$msg=isset($_GET['dw_ms_msg'])?sanitize_text_field(rawurldecode(wp_unslash($_GET['dw_ms_msg']))):'';
  echo '<div class="wrap"><h1>Anslutna shoppar <span style="font-size:12px;background:#1D949C;color:#fff;border-radius:999px;padding:4px 8px;vertical-align:middle">MULTI-SHOP BETA</span></h1><p>Installera Dennis WMS på <strong>en central WordPress/WooCommerce-backend</strong> och anslut övriga WooCommerce-shoppar här via REST API. Produkter och öppna order hålls separerade per shop.</p><div class="notice notice-success inline"><p><strong>⚡ Automatisk synk: varje minut</strong> · Nya/ändrade order och ändrade produkter hämtas automatiskt. Senaste automatiska körning: '.esc_html(get_option('dennis_wms_multishop_last_auto_sync','Inte körd ännu')).'. <small>WordPress Cron kör när sajten får trafik; för exakt 60-sekundersdrift i produktion kan server-cron användas.</small></p></div>';
  if($notice&&$msg)echo '<div class="notice '.($notice==='error'?'notice-error':'notice-success').' inline"><p>'.esc_html($msg).'</p></div>';
  if(current_user_can(self::CAP)&&current_user_can('manage_options')){echo '<div class="dw-ms-grid"><section class="dw-ms-card"><h2>'.($edit?'Redigera shop':'Anslut WooCommerce-shop').'</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_shop_save');echo '<input type="hidden" name="action" value="dennis_wms_shop_save"><input type="hidden" name="shop_id" value="'.esc_attr((string)($edit->id??0)).'"><p><label><strong>Namn</strong><br><input class="regular-text" name="name" required value="'.esc_attr($edit->name??'').'" placeholder="Ex. Triomed Sverige"></label></p><p><label><strong>Shop-URL</strong><br><input class="regular-text" type="url" name="url" required value="'.esc_attr($edit->url??'').'" placeholder="https://shop.example.se"></label></p><p><label><strong>Consumer Key</strong><br><input class="regular-text" type="password" autocomplete="new-password" name="consumer_key" placeholder="'.($edit?'Lämna tomt för att behålla befintlig':'ck_…').'" ></label></p><p><label><strong>Consumer Secret</strong><br><input class="regular-text" type="password" autocomplete="new-password" name="consumer_secret" placeholder="'.($edit?'Lämna tomt för att behålla befintlig':'cs_…').'" ></label></p><p class="description">Nycklarna lagras krypterat när OpenSSL finns tillgängligt och visas aldrig igen i gränssnittet.</p><button class="button button-primary">'.($edit?'Spara ändringar':'Lägg till shop').'</button>'.($edit?' <a class="button" href="'.esc_url(admin_url('admin.php?page=dennis-wms-shops')).'">Avbryt</a>':'').'</form></section><section class="dw-ms-card"><h2>Så fungerar v1.8.3</h2><ol><li>Lägg till shop och API-nycklar.</li><li>Tryck <strong>Testa anslutning</strong>.</li><li>Tryck <strong>Synkronisera</strong>.</li><li>Öppna <strong>Pågående order</strong> – externa order visas där tillsammans med den lokala shoppen.</li></ol><p><strong>Säker testgräns:</strong> externa shoppar är read-only i denna beta. Vi börjar inte ändra deras lager/order förrän anslutning, produkt-ID och SKU-mappning är verifierad.</p></section></div>';}
  echo '<h2>Anslutningar</h2><div class="notice notice-info inline"><p><strong>'.esc_html(get_bloginfo('name')?:'Huvudshop').'</strong> är huvudshoppen där pluginet är installerat. Den läses direkt och kräver ingen API-nyckel.</p></div><table class="widefat striped"><thead><tr><th>Shop</th><th>URL</th><th>Status</th><th>Senast testad</th><th>Senast synkad</th><th>Cache</th><th>Åtgärder</th></tr></thead><tbody>';
  foreach($shops as $s){$pc=(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM '.self::table('products').' WHERE shop_id=%d',$s->id));$oc=(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM '.self::table('orders').' WHERE shop_id=%d AND status IN (\'processing\',\'on-hold\')',$s->id));$sc=(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM '.self::table('orders').' WHERE shop_id=%d AND status=\'completed\'',$s->id));$status=$s->status==='connected'?'🟢 Ansluten':($s->status==='error'?'🔴 Fel':'⚪ Ej testad');echo '<tr><td><strong>'.esc_html($s->name).'</strong></td><td>'.esc_html($s->url).'</td><td>'.esc_html($status).($s->last_error?'<br><small>'.esc_html($s->last_error).'</small>':'').'</td><td>'.esc_html($s->last_tested?:'–').'</td><td>'.esc_html($s->last_sync?:'–').'</td><td>'.esc_html($pc.' produkter · '.$oc.' öppna · '.$sc.' skickade').'</td><td><div class="dw-ms-actions"><a class="button" href="'.esc_url(add_query_arg(['page'=>'dennis-wms-shops','shop_id'=>$s->id],admin_url('admin.php'))).'">Redigera</a>';if(current_user_can(self::CAP)&&current_user_can('manage_options')){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_shop_test_'.$s->id);echo '<input type="hidden" name="action" value="dennis_wms_shop_test"><input type="hidden" name="shop_id" value="'.esc_attr($s->id).'"><button class="button">Testa anslutning</button></form><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_shop_sync_'.$s->id);echo '<input type="hidden" name="action" value="dennis_wms_shop_sync"><input type="hidden" name="shop_id" value="'.esc_attr($s->id).'"><button class="button button-primary">Synkronisera</button></form><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" onsubmit="return confirm(\'Ta bort anslutningen och dess lokala cache? Den externa shoppen ändras inte.\')">';wp_nonce_field('dennis_wms_shop_delete_'.$s->id);echo '<input type="hidden" name="action" value="dennis_wms_shop_delete"><input type="hidden" name="shop_id" value="'.esc_attr($s->id).'"><button class="button">Ta bort</button></form>';}echo '</div></td></tr>';}
  if(!$shops)echo '<tr><td colspan="7">Inga externa shoppar anslutna ännu.</td></tr>';echo '</tbody></table>';
  $orders=self::remote_orders(25);if($orders){echo '<h2>Senast synkade öppna order</h2><table class="widefat striped"><thead><tr><th>Shop</th><th>Order</th><th>Kund</th><th>Datum</th><th>Status</th><th></th></tr></thead><tbody>';foreach($orders as $r)echo '<tr><td>'.esc_html($r->shop_name).'</td><td><strong>#'.esc_html($r->order_number).'</strong></td><td>'.esc_html($r->customer_name).'</td><td>'.esc_html($r->date_created?:'–').'</td><td>'.esc_html($r->status).'</td><td><a class="button" href="'.esc_url(self::remote_pick_url($r)).'">Öppna</a></td></tr>';echo '</tbody></table>';}
  echo '</div>';
 }
}
Dennis_WMS_Multi_Shop::boot();
