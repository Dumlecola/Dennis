<?php
if (!defined('ABSPATH')) exit;
final class Dennis_WMS_Order_Status {
 static function boot(){add_action('admin_post_dennis_wms_order_status',[__CLASS__,'save']);}
 static function form($order){
  if(!current_user_can('pb_wms_manage')||!current_user_can('edit_shop_orders'))return;
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:10px"><input type="hidden" name="action" value="dennis_wms_order_status"><input type="hidden" name="order_id" value="'.absint($order->get_id()).'"><input type="hidden" name="previous_status" value="'.esc_attr($order->get_status()).'">';
  wp_nonce_field('dennis_wms_order_status_'.$order->get_id());
  echo '<label for="dw-order-status">Ändra orderstatus</label><select id="dw-order-status" name="order_status" style="width:100%;margin:6px 0">';
  foreach(wc_get_order_statuses() as $key=>$label){echo '<option value="'.esc_attr(substr($key,3)).'" '.selected('wc-'.$order->get_status(),$key,false).'>'.esc_html($label).'</option>';}
  echo '</select><button class="button button-primary" type="submit">Spara status</button><p style="font-size:12px">Sparas i WooCommerce och händelseloggen.</p></form>';
 }
 static function change($order,$status,$previous){
  if(!isset(wc_get_order_statuses()['wc-'.$status]))throw new RuntimeException('Ogiltig orderstatus.');
  if($order->get_status()!==$previous)throw new RuntimeException('Statusen har ändrats sedan sidan öppnades. Ladda om ordern och försök igen.');
  if($status===$previous)return;
  if(!$order->update_status($status,'Dennis WMS: orderstatus ändrad manuellt.',true))throw new RuntimeException('Orderstatus kunde inte sparas.');
 }
 static function save(){
  if(!current_user_can('pb_wms_manage')||!current_user_can('edit_shop_orders'))wp_die('Åtkomst nekad.',403);
  $id=absint($_POST['order_id']??0);check_admin_referer('dennis_wms_order_status_'.$id);
  $order=wc_get_order($id);if(!$order||$order->get_type()!=='shop_order'||$order->get_status()==='trash')wp_die('Ordern finns inte.',404);
  try{self::change($order,sanitize_key(wp_unslash($_POST['order_status']??'')),sanitize_key(wp_unslash($_POST['previous_status']??'')));}catch(RuntimeException $e){wp_die(esc_html($e->getMessage()),'Orderstatus',['response'=>409,'back_link'=>true]);}
  $url=Dennis_WMS_Orders::url($id);if($order->get_status()==='completed')$url=add_query_arg('orders_tab','completed',$url);
  wp_safe_redirect($url);exit;
 }
}
Dennis_WMS_Order_Status::boot();
