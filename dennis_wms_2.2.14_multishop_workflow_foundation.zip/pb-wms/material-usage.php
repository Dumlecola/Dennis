<?php
if (!defined('ABSPATH')) exit;
final class Dennis_WMS_Material_Usage {
 const META='_dennis_wms_material_returns';
 static function boot(){
  add_action('admin_post_dennis_wms_material_return',[__CLASS__,'save_return']);
  add_action('admin_post_dennis_wms_material_print',[__CLASS__,'print_report']);
 }
 static function events($order){$v=$order->get_meta(self::META,true);return is_array($v)?$v:[];}
 static function returned_by_item($order){$out=[];foreach(self::events($order) as $e){$iid=(int)($e['item_id']??0);$out[$iid]=($out[$iid]??0)+(float)($e['qty']??0);}return $out;}
 static function picked_qty($order,$item){return (float)$item->get_quantity();}
 static function render($order){
  $id=$order->get_id();$ret=self::returned_by_item($order);$events=self::events($order);
  echo '<section id="dw-material" class="dw-order-section"><div class="dw-section-head"><div><span class="dashicons dashicons-chart-bar"></span><div><h2>Materialredovisning</h2><p>Registrera material som kommer tillbaka. Förbrukat = plockat − returnerat.</p></div></div><a class="button" target="_blank" rel="noopener" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=dennis_wms_material_print&order_id='.$id),'dennis_wms_material_print_'.$id)).'">Skriv ut materialredovisning</a></div>';
  echo '<div class="dw-material-summary"><table class="widefat striped"><thead><tr><th>Produkt</th><th>SKU</th><th>Plockat</th><th>Returnerat</th><th>Förbrukat</th><th>Registrerade batchuttag</th><th>Registrera retur</th></tr></thead><tbody>';
  $tp=$tr=$tu=0;
  foreach($order->get_items('line_item') as $item){$iid=$item->get_id();$p=$item->get_product();$picked=self::picked_qty($order,$item);$returned=(float)($ret[$iid]??0);$used=max(0,$picked-$returned);$tp+=$picked;$tr+=$returned;$tu+=$used;$alloc=self::recorded_batches($order,$item);$batch_txt=[];foreach($alloc['rows'] as $ar)$batch_txt[]=($ar['batch']?:'–').' · '.($ar['expiry']?:'–').' · '.($ar['location']?:'–').' · '.wc_format_localized_decimal($ar['qty']).' st';if($alloc['missing']>0)$batch_txt[]='Saknar batchsaldo: '.wc_format_localized_decimal($alloc['missing']).' st';
   echo '<tr><td>'.esc_html($item->get_name()).'</td><td>'.esc_html($p?$p->get_sku():'').'</td><td>'.esc_html(wc_format_localized_decimal($picked)).'</td><td><strong>'.esc_html(wc_format_localized_decimal($returned)).'</strong></td><td><strong>'.esc_html(wc_format_localized_decimal($used)).'</strong></td><td>'.esc_html($batch_txt?implode(' | ',$batch_txt):'–').'</td><td>';
   if($returned<$picked){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="dw-material-form">';wp_nonce_field('dennis_wms_material_return_'.$id);echo '<input type="hidden" name="action" value="dennis_wms_material_return"><input type="hidden" name="order_id" value="'.esc_attr((string)$id).'"><input type="hidden" name="item_id" value="'.esc_attr((string)$iid).'"><input type="number" name="qty" min="0.01" max="'.esc_attr((string)($picked-$returned)).'" step="0.01" required placeholder="Antal" style="width:85px">';self::batch_choices($p,$order,$item);echo ' <input type="text" name="location" maxlength="80" placeholder="Lagerplats" style="width:105px"> <input type="text" name="comment" maxlength="250" placeholder="Kommentar" style="width:150px"> <label style="white-space:nowrap"><input type="checkbox" name="restore_stock" value="1" checked> Lägg tillbaka i WC-lager</label> <button class="button button-primary">Registrera</button></form>';}else echo 'Allt returnerat';
   echo '</td></tr>';
  }
  echo '</tbody><tfoot><tr><th colspan="2">Totalt</th><th>'.esc_html(wc_format_localized_decimal($tp)).'</th><th>'.esc_html(wc_format_localized_decimal($tr)).'</th><th>'.esc_html(wc_format_localized_decimal($tu)).'</th><th></th><th></th></tr></tfoot></table></div>';
  if($events){echo '<h3>Returhistorik</h3><table class="widefat striped"><thead><tr><th>Tid</th><th>Produkt</th><th>Antal</th><th>Lagerplats</th><th>Lager uppdaterat</th><th>Användare</th><th>Kommentar</th></tr></thead><tbody>';foreach(array_reverse($events) as $e){$u=get_userdata((int)($e['user_id']??0));echo '<tr><td>'.esc_html($e['time']??'').'</td><td>'.esc_html(($e['product_name']??'').(!empty($e['batch'])?' · Batch: '.$e['batch']:'').(!empty($e['expiry'])?' · Expire: '.$e['expiry']:'').(!empty($e['last_order_date'])?' · Last order date: '.$e['last_order_date']:'')).'</td><td>'.esc_html((string)($e['qty']??0)).'</td><td>'.esc_html($e['location']??'').'</td><td>'.(!empty($e['stock_restored'])?'Ja':'Nej').'</td><td>'.esc_html($u?$u->display_name:'Okänd').'</td><td>'.esc_html($e['comment']??'').'</td></tr>';}echo '</tbody></table>';}
  echo '</section>';
 }

 static function recorded_batches($order,$item){global $wpdb;$rows=$wpdb->get_results($wpdb->prepare('SELECT batch,expiry,location,quantity FROM '.Dennis_WMS_Locations_V14::order_alloc_table()." WHERE order_id=%d AND order_item_id=%d AND source='batch' ORDER BY id",$order->get_id(),$item->get_id()));$out=[];foreach($rows as $r)$out[]=['batch'=>$r->batch,'expiry'=>$r->expiry,'location'=>$r->location,'qty'=>$r->quantity];return ['rows'=>$out,'missing'=>0];}
 static function shipped_batches($order,$item){
  $p=$item->get_product();if(!$p)return [];global $wpdb;$pid=$p->get_stock_managed_by_id();$alloc=$wpdb->get_results($wpdb->prepare('SELECT batch,expiry,location,SUM(quantity) quantity FROM '.Dennis_WMS_Locations_V14::order_alloc_table()." WHERE order_id=%d AND order_item_id=%d AND product_id=%d AND source='batch' GROUP BY batch,expiry,location",$order->get_id(),$item->get_id(),$pid));$out=[];
  foreach($alloc as $a){$rows=$wpdb->get_results($wpdb->prepare('SELECT * FROM '.Dennis_WMS_Batches::table('balances')." WHERE product_id=%d AND batch=%s AND COALESCE(expiry,'')=%s AND location=%s",$pid,$a->batch,$a->expiry?:'',$a->location));if(count($rows)!==1)continue;$row=$rows[0];$remaining=(float)$a->quantity;foreach(self::events($order) as $e)if((int)($e['item_id']??0)===$item->get_id()&&(int)($e['batch_id']??0)===(int)$row->id)$remaining-=(float)$e['qty'];$row->returnable=max(0,$remaining);if($row->returnable>0)$out[(int)$row->id]=$row;
  }return $out;
 }
 static function batch_choices($p,$order,$item){
  if(!$p)return;$rows=self::shipped_batches($order,$item);if(!$rows){echo '<p>Ingen kvarvarande skickad batch finns registrerad för denna orderrad.</p>';return;}
  echo '<fieldset style="flex-basis:100%;margin:6px 0"><legend>Välj skickad batch för returen</legend>';
  foreach($rows as $r)echo '<label style="display:block;margin:5px 0"><input type="radio" name="return_batch_id" value="'.esc_attr($r->id).'" required> '.esc_html(($r->batch?:'Utan batchnummer').' · Kan returneras: '.$r->returnable.' st · Expire: '.($r->expiry?:'–').' · Plats: '.($r->location?:'Ej angiven')).'</label>';
  echo '<small>Endast batcher som registrerats som uttagna på denna orderrad visas. Registrera en batch i taget.</small></fieldset>';
 }
 static function record_return($order,$item,$qty,$restore,$batch_id,$location,$comment){
  if(!current_user_can('pb_wms_manage')||($restore&&!current_user_can('manage_woocommerce')))throw new Exception('Åtkomst nekad.');
  $p=$item->get_product();if(!$p)throw new Exception('Produkten saknas.');$pid=$p->get_stock_managed_by_id();$iid=$item->get_id();
  if($restore&&Dennis_WMS_Kits::recipe($p->get_id()))throw new Exception('Kitreturer med lageråterföring registreras via WooCommerce-retur så att samtliga komponenter återförs korrekt.');
  return Dennis_WMS_Kits::transaction([$pid],function()use($order,$item,$qty,$restore,$batch_id,$location,$comment,$pid,$iid){
   global $wpdb;if(method_exists($order,'read_meta_data'))$order->read_meta_data(true);$p=Dennis_WMS_Kits::fresh($pid);$ret=self::returned_by_item($order);if(!is_finite($qty)||$qty<=0||($ret[$iid]??0)+$qty>self::picked_qty($order,$item)+0.00001)throw new Exception('Ogiltigt returantal.');
   $t=Dennis_WMS_Batches::table('balances');$exists=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE product_id=%d",$pid));$batch=null;
   if($exists&&!$batch_id)throw new Exception('Välj batchen som kommit tillbaka.');
   if($batch_id){$batch=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d AND product_id=%d FOR UPDATE",$batch_id,$pid));if(!$batch)throw new Exception('Batchen tillhör inte denna SKU.');}
   if($batch_id){$sent=self::shipped_batches($order,$item);if(!isset($sent[$batch_id]))throw new Exception('Batchen finns inte bland orderradens skickade batcher eller är redan helt returnerad.');if($qty>(float)$sent[$batch_id]->returnable+0.00001)throw new Exception('Returen överstiger skickat antal kvar för denna batch ('.$sent[$batch_id]->returnable.' st).');}
   $location=$location!==''?$location:($batch?$batch->location:'');$restored=false;
   if($restore){if(!$p->managing_stock()||$p->get_stock_quantity('edit')===null)throw new Exception('Produkten saknar eget lagerstyrt saldo.');$old=(float)$p->get_stock_quantity('edit');$result=wc_update_product_stock($p,$qty,'increase');if(is_wp_error($result)||!is_numeric($result)||abs((float)$result-($old+$qty))>0.0001)throw new Exception('Kunde inte återföra WooCommerce-saldo.');
    $key='material-return-'.$order->get_id().'-'.$iid.'-'.wp_generate_uuid4();
    if($batch){if(!Dennis_WMS_Batches::movement($pid,$batch->batch,$batch->expiry,$location,$qty,'material_return','woocommerce_order',$order->get_id(),$key,$comment,$batch->last_order_date,true))throw new Exception('Kunde inte återföra saldot till vald batch.');}
    else{$lb=Dennis_WMS_Locations_V14::table('balances');if($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $lb WHERE product_id=%d",$pid))){if(!$location)throw new Exception('Ange lagerplats för returen.');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $lb WHERE product_id=%d AND location=%s",$pid,$location));if(!$row||Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $lb SET quantity=quantity+%f WHERE id=%d",$qty,$row->id))!==1)throw new Exception('Välj en befintlig lagerplats.');}}
    $restored=true;
   }
   $events=self::events($order);$event=['time'=>current_time('Y-m-d H:i'),'user_id'=>get_current_user_id(),'item_id'=>$iid,'product_id'=>$pid,'variation_id'=>$item->get_variation_id(),'product_name'=>$item->get_name(),'sku'=>$p->get_sku(),'qty'=>$qty,'location'=>$location,'comment'=>$comment,'stock_restored'=>$restored,'batch_id'=>$batch_id,'batch'=>$batch?$batch->batch:'','expiry'=>$batch?$batch->expiry:null,'last_order_date'=>$batch?$batch->last_order_date:null];$events[]=$event;$order->update_meta_data(self::META,$events);$order->save_meta_data();Dennis_WMS_Audit::record('Materialretur registrerad','order',$order->get_id(),[], $event,'WMS','success',$p->get_sku());return $event;
  });
 }

 static function save_return(){
  if(!current_user_can(PB_WMS_V03::MANAGE))wp_die('Åtkomst nekad',403);$oid=absint($_POST['order_id']??0);$iid=absint($_POST['item_id']??0);check_admin_referer('dennis_wms_material_return_'.$oid);$order=wc_get_order($oid);if(!$order)wp_die('Ordern hittades inte.',404);$item=$order->get_item($iid);if(!$item||!is_a($item,'WC_Order_Item_Product'))wp_die('Orderraden hittades inte.',404);
  try{self::record_return($order,$item,(float)wc_format_decimal(wp_unslash($_POST['qty']??0)),!empty($_POST['restore_stock']),absint($_POST['return_batch_id']??0),sanitize_text_field(wp_unslash($_POST['location']??'')),sanitize_text_field(wp_unslash($_POST['comment']??'')));}catch(Throwable $e){wp_die(esc_html($e->getMessage()),409);}

  wp_safe_redirect(add_query_arg(['page'=>'dennis-wms-orders','order_id'=>$oid,'material_saved'=>1],admin_url('admin.php')).'#dw-material');exit;
 }
 static function print_report(){
  if(!current_user_can(PB_WMS_V03::VIEW))wp_die('Åtkomst nekad',403);$oid=absint($_GET['order_id']??0);check_admin_referer('dennis_wms_material_print_'.$oid);$order=wc_get_order($oid);if(!$order)wp_die('Ordern hittades inte.',404);$ret=self::returned_by_item($order);$events=self::events($order);
  echo '<!doctype html><html lang="sv"><head><meta charset="utf-8"><title>Materialredovisning #'.esc_html($order->get_order_number()).'</title><style>body{font:14px Arial,sans-serif;margin:28px;color:#17202a}h1{margin-bottom:4px}button{padding:9px 14px}table{border-collapse:collapse;width:100%;margin:18px 0}th,td{border:1px solid #bbb;padding:9px;text-align:left}th{background:#f3f4f6}.tot{font-weight:bold}@media print{button{display:none}}</style></head><body><button onclick="window.print()">Skriv ut</button><h1>Dennis WMS – Materialredovisning</h1><p>Order #'.esc_html($order->get_order_number()).' · Utskriven '.esc_html(current_time('Y-m-d H:i')).'</p><table><thead><tr><th>Produkt</th><th>SKU</th><th>Plockat</th><th>Returnerat</th><th>Förbrukat</th><th>Registrerade batchuttag</th></tr></thead><tbody>';
  $tp=$tr=$tu=0;foreach($order->get_items('line_item') as $item){$p=$item->get_product();$picked=self::picked_qty($order,$item);$returned=(float)($ret[$item->get_id()]??0);$used=max(0,$picked-$returned);$tp+=$picked;$tr+=$returned;$tu+=$used;$alloc=self::recorded_batches($order,$item);$bt=[];foreach($alloc['rows'] as $ar)$bt[]=($ar['batch']?:'–').' / '.($ar['expiry']?:'–').' / '.($ar['location']?:'–').' / '.$ar['qty'].' st';if($alloc['missing']>0)$bt[]='Saknar batchsaldo: '.$alloc['missing'].' st';echo '<tr><td>'.esc_html($item->get_name()).'</td><td>'.esc_html($p?$p->get_sku():'').'</td><td>'.esc_html((string)$picked).'</td><td>'.esc_html((string)$returned).'</td><td>'.esc_html((string)$used).'</td><td>'.esc_html($bt?implode(' | ',$bt):'–').'</td></tr>';}
  echo '<tr class="tot"><td colspan="2">Totalt</td><td>'.esc_html((string)$tp).'</td><td>'.esc_html((string)$tr).'</td><td>'.esc_html((string)$tu).'</td><td></td></tr></tbody></table>';
  if($events){echo '<h2>Returhistorik</h2><table><thead><tr><th>Tid</th><th>Produkt</th><th>Antal</th><th>Lagerplats</th><th>Användare</th><th>Kommentar</th></tr></thead><tbody>';foreach($events as $e){$u=get_userdata((int)($e['user_id']??0));echo '<tr><td>'.esc_html($e['time']??'').'</td><td>'.esc_html(($e['product_name']??'').(!empty($e['batch'])?' · Batch: '.$e['batch']:'').(!empty($e['expiry'])?' · Expire: '.$e['expiry']:'').(!empty($e['last_order_date'])?' · Last order date: '.$e['last_order_date']:'')).'</td><td>'.esc_html((string)($e['qty']??0)).'</td><td>'.esc_html($e['location']??'').'</td><td>'.esc_html($u?$u->display_name:'Okänd').'</td><td>'.esc_html($e['comment']??'').'</td></tr>';}echo '</tbody></table>';}
  echo '</body></html>';exit;
 }
}
Dennis_WMS_Material_Usage::boot();
