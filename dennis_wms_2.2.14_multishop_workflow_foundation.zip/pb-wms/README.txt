2.1.36 – Pre-order lagerisolering. Pre-order använder alltid sitt egna WooCommerce-saldo och påverkas inte av Kit/För-packad kapacitetsfilter. När Pre-order sparas säkerställs lagerhantering och lagerstatus från det faktiska saldot.
2.1.34 – Pre-orders + korrigerad WooCommerce Stock-visning. Pre-order använder vanligt WooCommerce-saldo som antal kvar att förbeställa. Kitens fysiska saldo visas korrekt i produktlistan, med endast lagerstatusen färgmarkerad.

2.1.29 – Plocklistan visar vanliga produkter utan batchregister utan felaktig batchsaldo-varning. Registrerade batchbrister varnas fortfarande. Äldre Kit utan för-packad huvudprodukt visar medföljande SKU som egna rader även före nytt lageruttag, tydligt märkta som förhandsvisning.

2.1.28 – Äldre koppling med flera SKU och noll för-packade huvudprodukter kan övergå till vanligt Kit-uttag. Huvudprodukt och medföljande SKU dras från egna saldon, med för-packade artiklar först. Uppdateringen loggas; redan gjorda orderuttag behålls.

2.1.27 – Äldre förpackningskopplingar visar verkligt tillgängligt eller reserverat antal för-packade på plocklistan, i stället för att anta att hela orderantalet är färdigförpackat.

2.1.26 – Äldre orderrader med krav på färdiga förpackningar använder aktuell Kit-koppling när inget lager ännu dragits. Vanligt tillgängligt saldo kan då plockas, med för-packat först. Redan registrerade uttag ändras inte.

2.1.25 – Avgränsaren håller samman huvudprodukt och medföljande SKU i samma Kit. Linjen visas först mellan beställda produkter/kit, i vy och utskrift.

2.1.24 – Tydlig turkos avgränsare och luft mellan nya SKU i plocklistan, inklusive sampackning och utskrift. Batchrader inom samma SKU hålls samman.

2.1.23 – Renare plocklista för Kit: beställd huvudprodukt först, medföljande SKU direkt under, korta antalstexter utan dubblerad innehållslista. Kit hålls ihop även när medföljande artiklar är för-packade.

2.1.22 – Plocklista och utskrift visar medföljande artiklars SKU, produkttitel och totalt antal i en sammanställning vid huvudprodukten samt på egna plockrader.

2.1.21 – Medföljande artiklar heter nu Kit och visas under LAGER direkt efter För-packade produkter i sidomenyn.

2.1.20 – Medföljande SKU kan delas mellan flera huvudprodukter med olika antal. SKU med egna medföljande artiklar kan ingå som fysisk artikel; dess egen lista expanderas inte rekursivt. Gemensamma saldon kontrolleras samlat per order.

2.1.19 – Plocklistan läser registrerat innehåll från orderns uttag och bortser från tomma/ogiltiga innehållssnapshots. Äldre order utan registrerat uttag visar aktuell koppling som tydligt märkt förhandsvisning. Inga saldoändringar vid visning eller utskrift.

2.1.18 – Medföljande artiklar: huvud-SKU med eget fysiskt saldo och flera medföljande SKU med antal per huvudprodukt. Gemensam saldokontroll, orderuttag, återlagring och separata plockrader via befintligt transaktionsregister. Egen WMS-sida och SKU-sökning.

2.1.17 – Egen flik för godkända inleveranser. Pågående och godkända visas separat; sökning behåller vald flik. Inleveranser med nya obehandlade antal visas åter bland pågående.

2.1.16 – Orderstatus kan ändras direkt i WMS-orderpanelen. Behörighet, nonce, validering och kontroll av ändrad status. WooCommerce utför statusbytet och befintlig händelselogg registrerar det.

Dennis WMS 2.1.15
SQLite: ersätter exakt WooCommerce HPOS-månadsfilterfråga med MIN/MAX utan UNION. Riktad anropsdiagnostik för WooCommerce rapportvarningar, utan argument eller kunddata. Varningar undertrycks inte.

Dennis WMS 2.1.14
Egen flik Slutförda order i ordervyn, WooCommerce completed, 25 per sida, senaste först. Öppna order och plocklista.

Dennis WMS 2.1.13
Materialreturer begränsas till registrerade batchuttag för samma orderrad. Kontrollerar kvarvarande returantal per batch även i backend. Äldre order utan batchhistorik tillåter inte godtyckligt batchval.

Dennis WMS 2.1.12
Transportörstatistik förtydligad: Antal order per transportör, exempelvis DSV: 2 order. Gäller säljar- och leveransplatsvyer samt rapporter som återger dessa.

Dennis WMS 2.1.11
Rättar felaktigt elseDennis_WMS_Audit i leveransregistrering, shoppsynk och lagerplatsallokering.

Dennis WMS 2.1.10
Tillfällig förvaring flyttad till underflik i Inleveranser. Lagerplatser visar enbart ordinarie plats- och saldohantering. Tidigare länkar omdirigeras.

Dennis WMS 2.1.9
Tillfällig förvaring: Skapa inleverans med en knapp. Beskrivning, kommentar, lagerplats och bild följer med. Öppna samma inleverans igen utan dubbletter. Posten behandlas när mottagningen sparas. Saldo ändras först vid godkännande.

Dennis WMS 2.1.8
Tillfällig förvaring hanteras fristående: markera som behandlad och visa i egen flik. Inleveranskoppling borttagen. 48-timmarsvarning och loggning behålls.

Dennis WMS 2.1.7
Tillfällig förvaring: tydliga kort, statusmärken, samlade åtgärder, sökning och hopfällt nyregistreringsformulär. Mobilanpassat.

Dennis WMS 2.1.6
Tillfällig förvaring utan SKU under Lagerplatser: beskrivning, kommentar, lagerplats och bild. Koppla till inleverans när SKU finns. Varning efter 48 timmar på dashboard och förvaringsvy. Alla ändringar loggas; ingen lagerbokföring innan ordinarie godkännande.

Dennis WMS 2.1.5
Plocklistan använder även produkter som för-packats efter orderns saldoavdrag. Reserveras vid plockstart, med returhantering och utan att ändra totalsaldot.

Dennis WMS 2.1.4
Benämningen korrigerad till För-packade i menyer och vyer.

Dennis WMS 2.1.3
För-packade produkter förenklat till en SKU. Flera-SKU-formulär och registrering borttagna. Händelselogg enbart i sidomenyn. Befintliga saldon och historiska order bevaras; tidigare förpackningsinställning kan återställas via SKU-vyn.

Dennis WMS 2.1.2

- Lagerstatus för För-packade produkter med flera SKU följer fysiskt saldo, inte antalet färdiga förpackningar.
- Felaktigt sparad lagerstatus korrigeras vid öppning av admin, med logg och oförändrat saldo.

- Produkter med flera SKU visar eget fysiskt totalsaldo separat från antalet färdiga förpackningar.
- För-packade produkter → En SKU kan återställa gamla inställningar för packning vid plockning till vanlig saldohantering. Sparat saldo och orderhistorik behålls; åtgärden loggas.

- Benämningen är För-packade produkter i menyer, formulär, sökresultat, plockinstruktioner, felmeddelanden och nya logghändelser.
- Sökresultat hänvisar till Flera SKU och förpackningsinnehåll istället för borttagna kitflikar.

- Kitvyer ersatta av Förpackade produkter: En SKU och Flera SKU. Nya sammansättningar förpackas enbart i förväg.
- Befintlig huvudprodukt ingår automatiskt med 1 st. Övriga SKU har antal per förpackning.
- Förpackat antal begränsas av saldo och ingående innehåll visas på plocklista/utskrift. Historiska orderuttag behålls.

- Förpackade kit visar innehållet på plocklistan och utskrift: SKU, produktnamn, totalantal och antal per kit, en produkt per rad.
- Kit vid plockning visas som separata komponentrader. Förpackat innehåll är kontrollinformation och dras inte igen.

- Nya kit använder befintlig huvudprodukt med saldo som bas. Huvudprodukten ingår automatiskt med 1 st per kit.
- Vid plockning dras huvudprodukt och tillbehör en gång. Vid förpackning dras tillbehör och huvudprodukter markeras som färdiga; fysiskt huvudsaldot ökas inte.
- Materialreturer får val av rätt batch, även tomma batcher. Batchsaldo, WooCommerce, datum och returhistorik uppdateras tillsammans.
- Äldre kit med separat SKU behåller sitt upplägg. Kitreturer med komponentåterföring hanteras via WooCommerce-returer.

- Kitet har egen SKU. Den befintliga huvudprodukten och tillbehör ingår som vanliga komponenter.
- Receptet drar inget saldo vid sparande. Komponenter dras vid förpackning eller orderuttag enligt vald metod.
- Automatisk omvandling av befintligt produktsaldo till färdiga kit från 2.0.95 är borttagen.

- Lagerplatser fördelas med plats/antal-rader, Lägg till rad och gemensam Spara fördelning. Kvar visas löpande.
- Batchartiklar använder samma fördelningsformulär som batchregistret, med befintliga batchdatum.
- Fördelningen loggas, totalsaldot bevaras och fel totalsumma stoppas. Fler åtgärder ligger hopfällda.

- Lagerplats är valfri vid fördelning av WooCommerce-saldo och kan anges senare.
- FEFO heter nu Plockordning i vyer och utskrifter.

- Last order date har första prioritet i batchernas plockordning. Tidigast datum först; vid lika Last order date avgör Expire date.
- Batcher utan Last order date kommer efter daterade batcher och sorteras efter Expire date.
- Samma ordning används i batchregistret, lagerplatsvyn, plockförslag och kitens verkliga komponentuttag.
- Passerat Last order date eller utgångsdatum utesluts från plockförslag och aktiva FEFO-nummer.

Dennis WMS 2.0.91

- Batchregistret får en tydlig turkos avdelare och mellanrum när nästa SKU börjar. Samma SKU behåller sina batchrader samlade.
- Avdelaren finns även vid utskrift. FEFO-numrering och batchuppgifter behålls.

Dennis WMS 2.0.90

- FEFO-kolumnen i batchregistret visar plockordning #1, #2, #3 per SKU. Datumvarningar visas endast i datumkolumnen.
- Utgångna batcher får ingen plockordning. Tomma batcher behåller Inget saldo.

Dennis WMS 2.0.89

- Plock- och förpackningsinformation visas i en egen turkos ruta Plock & pack. Produktens Purchase note behåller sin ursprungliga text.
- Gäller ordervy, gemensam plocklista och båda utskrifterna. Kitinstruktioner visas också i Plock & pack.
- Produktnamnet innehåller inte längre tillagda förpackningsantal; dessa visas i den egna rutan.
- Förpackade exemplar prioriteras fortsatt. Lageruttag och återläggning behålls.

Dennis WMS 2.0.88

- Plocklistor visar förpackade produkter först: helt förpackade rader, därefter blandade och slutligen oförpackade.
- Samma SKU tar registrerat förpackat antal först; endast överskjutande antal behöver förpackas. Det tidigare förpackade lageruttaget behålls.
- Instruktionerna finns i ordervyn, gemensamma plocklistor och utskrifter, även för kitkomponenter.
- Tilldelat förpackat antal sparas vid lageruttag och visas även efter att det dragits från tillgängligt saldo.
- Förhandsvisning delar tillgängligt förpackat antal mellan upprepade SKU-rader och flera order utan att dubbelräkna.

Dennis WMS 2.0.87

- Datumvarningar kan markeras som behandlade och flyttas till en egen ruta under Aktiva varningar.
- Behandlade varningar ger inga datum-påminnelser, ordervarningar eller pulsering. Saldo, datum och kitens lagervalidation ändras inte.
- Behandling sparas per datumtyp, källa och datum. Nya datum/batcher ger nya varningar.
- Behandlade visar tid (timmar/minuter) och användare, kan sökas och återaktiveras. Listan har 25 poster per sida.
- Hantering och återaktivering kräver lagerbehörighet och WooCommerce-behörighet samt giltig nonce, och loggas med SKU.

Dennis WMS 2.0.86

- Produktens äldre utgångsdatum ger ingen separat varning när utgångsdatum redan registrerats per batch. Detta gäller även uttömda batchposter.
- Batchposter med saldo 0 visar Inget saldo och inga aktiva utgångsvarningar. Datum och historik behålls.
- Datumfliken får tydligare pulsering vid datum idag eller passerat datum. Datumtypens flikar får samma markering. Systeminställningen för minskad rörelse respekteras med en statisk markering.

Dennis WMS 2.0.85

- Kit söker i hela SKU och visar även träffar som kräver lagerinställningar eller en annan huvud-SKU. Orsaken visas utan att lagerreglerna kringgås.
- Datumvarningar inkluderar produktens utgångsdatum, varianter, ärvda datum och utkast. Batchvarningar behålls. Idag-markeringen använder båda datumtyperna.
- Kalenderdatum valideras och varningsgränser beräknas i WordPress tidszon.

=== v2.0.84 – Antal förpackade och SKU-förslag ===
- Vanliga produkter får ett faktiskt förpackat antal, begränsat till SKU:s saldo.
- Produktvy och kortvy visar förpackade samt oförpackade enheter. Packning öppnas från produktvyn.
- Antalet följer lageruttag, kitkomponentuttag, valda lagerreturer och avbrutna ordrar. Registrering av förpackning ändrar inte totalsaldot.
- Kitformuläret söker automatiskt efter tre tecken av SKU och visar väljbara produktförslag med namn och komponenternas tillgängliga saldo.
- Stöd för klick och piltangenter/Enter. Endast lämpliga huvudprodukter/komponenter föreslås.
- Tidigare packningsmarkering utan antal behöver kompletteras med faktisk mängd. Se KIT_TESTING.md.

=== v2.0.83 – Kit och förpackade produkter ===
- Ny kitvy med huvud-SKU, komponenter och antal per kit.
- Välj Packas vid plockning eller Förpackas i förväg när kitet skapas.
- Maxantal baseras på komponenternas tillgängliga saldo, batcher och datum; saldot kontrolleras igen vid lagerändringen.
- Förpackning minskar komponenterna och ökar färdiga kits saldo. Färdiga kit förbrukar sedan endast huvud-SKU:s saldo.
- Kit vid plockning tar ut komponenterna vid WooCommerce-orderuttaget. Plocklistor och utskrifter visar komponenterna och huvud-SKU.
- Uttag, återställningar, receptändringar och packningsval loggas. Skydd mot dubbla uttag och återläggning.
- Vanliga produkter kan markeras Förpackad utan att SKU eller saldo ändras; syns i produktvyn och plocklistan.
- Mobilanpassade formulär. Se KIT_TESTING.md för installation och testflöden.

=== v2.0.82 – Enklare batchvy via Visa SKU ===
- Det fristående formuläret Registrera / justera batchsaldo är borttaget.
- Använd Visa SKU för att välja artikeln och fördela saldo eller ändra den valda artikelns batcher, datum och lagerplatser.
- Befintlig batchhistorik och sparade saldon bevaras.

=== v2.0.81 – Enkel differensinformation ===
- Rutan Varför finns en differens?, generell förklaring och historik tas bort från lagerplatsvyn.
- Endast en kort datum-/batchrad visas när en registrerad datumkassering faktiskt introducerat den aktuella differensen.
- Utan bekräftad datumorsak visas enbart den vanliga saldoraden och skillnaden.
- En normal kassering där båda saldona minskar lika mycket skapar ingen datumförklaring.

=== v2.0.80 – Händelselogg enbart för lagret ===
- Loggar artiklar, saldo, inleveranser, inventering, batcher, lagerplatser, ordrar, leveranser och trackingändringar.
- Sidbesök, HTTP-begäranden, inloggningar, användaradministration och allmänna inställningsändringar loggas inte längre.
- Tidigare sådana händelser är dolda i både loggvyn, CSV och utskrift. Tidigare lagerhistorik bevaras.
- Lagerrelaterade databasfel och återställda transaktioner finns kvar.

=== v2.0.79 – Rättad uppgradering av loggtabellen ===
- Databasdefinitionen är uppdelad per rad så dbDelta kan uppgradera befintliga loggtabeller.
- Extra idempotent kontroll lägger till den nya UTC-kolumnen om den fortfarande saknas.
- Befintliga loggrader bevaras; misslyckad uppgradering markeras inte som genomförd.

=== v2.0.78 – Tydligare händelselogg och svensk tid ===
- Sidbesök visar sidans namn, t.ex. Översikt eller Händelselogg, utan missvisande objekt-ID #0.
- Läsbara uppgifter/före/efter; rådata och begärans UUID finns bakom Tekniska detaljer.
- Tid, datumfilter, CSV och utskrift använder Europe/Stockholm med automatisk sommar-/vintertid.
- Nya logghändelser sparar även en UTC-tidsstämpel; befintliga loggrader bevaras.

=== v2.0.77 – Händelselogg och renare trackingvy ===
- Ny samlad Händelselogg under System (administratör): användare, tid, SKU, före/efter och resultat.
- WMS-databasändringar, WooCommerce produkt-/orderändringar och stock API, inställningar, inloggningar och behörigheter loggas.
- Sökning, filter, paginering, CSV och fullständig utskrift av alla filtrerade träffar.
- Bokningsrelaterad fraktberäkning och vikt-/måttfälten är borttagna från leveransvyn. Endast DHL/DSV Tracking API används.
- Differens visar senaste lagerhändelser med kassering, expire och Last order date; okänd orsak markeras tydligt.
- Inventeringens datum/tid visas utan sekunder i listor, ändringshistorik och rapporter.
- Se ACTIVITY_LOG.md för täckning, begränsningar och teststeg.

=== v2.0.0 – Batch och expire på inventeringslistan ===
- Inventeringslistan visar Batch och Utgångsdatum som standardkolumner.
- Centrala batchregistret används när batchsaldo finns; samma SKU med flera batcher blir separata inventeringsrader.
- Lagerplats och saldo hämtas per batch/lagerplats så rätt kombination kan räknas.
- Batchrader följer batchregistrets FEFO-ordning före vald listsortering och kan filtreras på batch, expire och lagerplats.
- Produkter utan centralt batchsaldo fortsätter fungera med befintlig produktinformation.

=== v1.9.9 – Batch + lagerplats i samma arbetsvy ===
- Lagerplatssaldon känner nu av batchhanterade SKU:er.
- Visar Produkt → Lagerplats → Batch → utgångsdatum → saldo.
- Faktiskt batchsaldo kan korrigeras direkt och WooCommerce totalsaldo följer differensen.
- Batch kan flyttas mellan lagerplatser utan att WooCommerce totalsaldo ändras.
- FEFO-prioritet visas per batch.
- Avstämning jämför summan av alla batch/lagerplatssaldon mot WooCommerce.
- Mobilanpassad batchvy och batchhistorik.

=== v1.9.8 – Förenklade lagerplatssaldon ===
- Ny arbetsvy för Lagerplatssaldon med SKU-sökning/scanning och mobilanpassade lagerplatskort.
- Visar WooCommerce totalsaldo mot summan av lagerplatser med tydlig Avstämt/Differens-status.
- Personal kan ange faktiskt antal direkt på en lagerplats; Dennis WMS räknar differensen och justerar WooCommerce totalsaldo med samma differens.
- Enklare lagerflytt Från → Till → Antal utan att totalsaldot ändras.
- Lägg till lagerplats med enkelt formulär. Första platsen får hela WooCommerce-saldot; extra platser skapas tomma och fylls via lagerflytt.
- Alla justeringar och flyttar loggas med användare, tid och kommentar.

=== v1.9.7 – Leveransstatus i Tracking & Orders in Progress ===
- Transport & Tracking är nu ett samlat Leveranscenter för Frakt, Kundhämtning och Interna order.
- Filter: Alla, Frakt, Kundhämtning, Interna, aktiva, skickade/levererade, problem, DHL och DSV.
- Samma leveransstatus visas i ordern, Orders in Progress och Leveranscenter.
- DHL/DSV tracking är fortsatt separat och visas endast för fraktorder med trackingnummer.
- Orders in Progress visar leveranssätt + leveransstatus under WMS-statusen.

=== v1.9.6 – Orderinformation layout ===
- Tydligare tvåkolumnslayout i Orderinformation med större avstånd mellan etikett och värde.
- WooCommerce-status visas som en kompakt statusbadge.
- Smala mobilvyer staplar etikett och värde för att undvika överlappning.

=== v1.9.5 – Ny cutoff-regel för skickdeadline ===
- Order skapad före kl. 12:00 får deadline kl. 12:00 samma dag.
- Order skapad kl. 12:00 eller senare får deadline kl. 12:00 nästa kalenderdag.
- Deadlineförklaringen och orderns Deadline-panel visar den nya regeln.
- Undantag (Skickas imorgon, specifikt datum/tid och ingen deadline) fungerar som tidigare.

=== v1.9.4 – Tydligare deadlinepanel ===
- Deadlineförklaringen ovanför Orders in Progress är nu uppdelad i tydliga rader/kort i stället för en lång textrad.
- Statusräknare ligger på en egen rad.
- Förklaringar visas i två kolumner på dator och en kolumn på mobil.
- Standardregeln ligger på en egen rad längst ned.

=== v1.9.3 – Förklaring av deadline-symboler ===
- Orders in Progress visar nu en tydlig symbolförklaring ovanför orderlistan.
- Förklaringen anger uttryckligen att standardregeln är senast kl. 12:00 dagen efter att ordern lades.
- Förklarar även skickas idag, brådskande, försenad, undantag och skickad i tid/för sent.


=== v1.9.2 – Skickdeadline och flaggor ===
- Standarddeadline för vanliga order: kl. 12:00 kalenderdagen efter orderdatum.
- Orderlistan prioriteras automatiskt efter närmaste deadline.
- Flaggor: I tid, Ska skickas idag, Brådskande, Försenad, Skickad i tid och Skickad för sent.
- Undantag per order: Skickas imorgon kl. 12, specifikt datum + tid, ingen deadline eller återställ standard.
- Undantag kräver anledning och sparas i historik med användare/tid.
- Kundhämtning och interna order undantas automatiskt från fraktdeadline.
- Deadline visas i lokal och Multi-Shop ordervy. Externa shoppar förblir read-only mot WooCommerce; deadline lagras bara i Dennis WMS.
- Dashboard visar antal som ska skickas idag, brådskande och försenade.

Dennis WMS 1.8.2
Multi-Shop statistics beta: local main shop + external WooCommerce shops, per-shop order/product statistics and 365-day completed-order cache for statistics.

Dennis WMS v1.7.0 – Produktbilder på plocklistor
- Produktbild på vanlig ordervy/plocklista
- Produktbild på sampackningens gemensamma plocklista
- Produktbild på utskrivna plocklistor
- Variation använder föräldraproduktens bild som fallback
- WooCommerce placeholder används när bild saknas

Dennis WMS 1.6.8 – ATUM Inventory Logs customer returns in statistics
Dennis WMS 0.7.0 – Produktanalys

Installera ZIP-filen via WordPress > Tillägg > Lägg till nytt > Ladda upp tillägg. Ersätt tidigare version efter säkerhetskopia, helst i Playground/staging.

Produktanalys: artikel-/variationsantal, lagersaldo, lagerplatser, kategorier, lågt saldo, utgångsdatum per produkt, orderrader/enheter, inventeringsdifferenser, plocktider och artikelfördjupning. Inga priser eller betalningsuppgifter visas i Analytics.

Begränsningar: periodfilter gäller order/inventering/plockning, inte aktuella saldon. Högst 1000 order per period och 10000 produkter; rapporten varnar vid gräns. Ingen historisk saldokurva utan separat insamling. ATUM Multi-Inventory, flera batcher per produkt och lagerplatskapacitet är ännu inte integrerade. Inga prisuppgifter behövs.

VARNING: Den äldre inventeringsfunktionen uppdaterar WooCommerce standardsaldo automatiskt. Använd endast i testmiljö tills ATUM-konfigurationen och samtidig orderhantering verifierats. Uppgradering behåller samma pb-wms-mapp, meta-nycklar och inventeringstabell.

v1.1.0 Receiving beta:
- Inleveranser and Inleveransstatistik are available in Dennis WMS admin.
- Enter WooCommerce product ID, expected quantity, received and approved quantity. Posting increases WooCommerce standard stock exactly once per claimed line quantity in normal sequential operation.
- Do not post a receipt already posted via ATUM/WooCommerce. ATUM Multi-Inventory and purchase-order syncing are not supported.
- Batch and location are descriptive fields on a receipt line; multiple receipts with different batches should be separate lines. This is not a batch stock ledger.
- Test with a backup in WordPress Playground. Concurrent posting and external stock updates require integration testing before production.

1.2.0: Orders in Progress shows depot status and location when waiting, clickable order numbers use WooCommerce order edit URLs (HPOS compatible), and finished pick/pack can be reopened with a reason. Prior time totals and an audit snapshot are retained. Reopening does not change stock, WooCommerce status or already picked quantities; staff must verify the remaining quantities manually. Test on Playground before production.

v1.5.0 – Modern Order Workspace & Order Images
- Ny modern ordervy inspirerad av Dennis WMS-designskissen.
- Orderkort för kund, leverans, frakt och arbetsstatus.
- Snabbnavigering mellan orderrader, plock, pack, depå, bilder och historik.
- Orderbilder kopplas till WooCommerce-order via WordPress Media Library.
- Bildkategorier: Plockning, Packning, Depå, Avvikelse och Övrigt.
- Kommentar, uppladdare och tidpunkt sparas per bildkoppling.
- Bilder kan tas bort från ordern utan att Media Library-filen raderas.

v1.5.1 – Product Data Quality
- New Dennis WMS > Produktkontroll screen.
- Configure required WooCommerce global or custom attributes.
- Warning or critical severity per rule.
- Product status list with direct links to edit incomplete products.
- Product-data badge is also shown in the main Dennis WMS product/inventory table.


== 1.5.7 ==
- Fast rosa och turkos WMS-design.
- Ingen koppling till Elementor-färger.
- Rosa/turkos används för navigation, knappar, diagramaccenter och markeringar.

== 1.5.8 ==
- Fix: Inventering – period kraschar inte när vald period saknar inventeringsdata.
- Behåller Order Debug från 1.5.7.

v1.7.2 – Batch / Lot + FEFO
- Samma SKU kan ha flera batcher, expire dates och lagerplatser med separata kvantiteter.
- Ny sida: Dennis WMS -> Batcher & utgångsdatum.
- Bokförda Dennis WMS-inleveranser förs till batchsaldot.
- Befintliga bokförda inleveransrader med batch/expiry backfillas en gång vid schema-uppgradering.
- Vanliga och sampackade plocklistor visar FEFO-förslag och delar upp antal över flera batcher.
- Utskrivna plocklistor visar batch, expire date och lagerplats.
- Manuell batchjustering finns för startsaldo/korrigering och ändrar inte WooCommerce totalsaldo.
- v1.7.2 reserverar eller drar INTE batchsaldo automatiskt när plockning startas/slutförs; FEFO-raderna är plockförslag. Detta minskar risken för dubbel lagerbokning mot WooCommerce/ATUM medan funktionen testas.


v1.7.3 – Batchstatistik överallt
- Dashboardens utgångsdatum bygger nu på Dennis WMS batchsaldo (enheter), inte gamla produktanteckningar.
- Nya dashboard-KPI: aktiva batchposter och enheter med batchsaldo.
- Produktanalys visar batch/expire-statistik och batchsaldo/FEFO per vald SKU.
- Lagerflöde och inleveransstatistik visar lagerplats, batch och expire date.
- Statistikrapport har valbar sektion Batcher & utgångsdatum med saldo och händelser.
- Materialredovisning och utskrift visar FEFO-batchförslag för förbrukat material.
- Batchsidan visar KPI och senaste batchhändelser.
OBS: order/plock drar fortfarande inte batchsaldo automatiskt i denna testversion. Därför är order/material-batch ett FEFO-förslag, inte bokförd historisk utleverans.

v1.7.4
- Ny utfällbar och grupperad vänstermeny för Dennis WMS.
- Aktiv menygrupp öppnas automatiskt och öppet/stängt läge sparas i webbläsaren.
- Batchhantering tydliggjord: Lager > Batcher & utgångsdatum är centralt register; övriga sidor visar batchdata i sitt sammanhang.
- Korrigerad orderfördelning i sampackning så varje FEFO/batchrad visar exakt vilka order och antal som hör till raden.


v1.7.5
- Produktregler kan nu begränsas till en eller flera WooCommerce-kategorier.
- Valfritt stöd för underkategorier.
- Samma attribut kan ha separata regler för olika kategorier.
- Äldre regler utan kategori fortsätter gälla alla kategorier.

v1.8.0 Multi-Shop beta
- Central Dennis WMS installation can connect to multiple independent WooCommerce shops via REST API.
- System > Anslutna shoppar: add/edit/test/sync/delete connections.
- Remote products and open processing/on-hold orders are cached separately per shop (shop_id + remote ID).
- Open remote orders appear in Pågående order and have a read-only printable pick list.
- Remote shops are deliberately read-only in this beta: no external stock/order status writes yet.
- API credentials are encrypted with OpenSSL AES-256-CBC when available and are never rendered back in admin UI.

1.8.2:
- Skickade order = WooCommerce completed.
- Skickade order per shop, KPI, jämförelsetabell och trend över tid.
- Externa order sparar date_completed för korrekt periodstatistik efter synkronisering.

v1.8.3 – Leverans & transport beta
- Valfri leveransmodul: Skickas / Hämtas av kund / Intern order.
- Flera avsändaradresser.
- DHL/DSV-inställningar och säker testgräns; livebokning är inte aktiverad i denna beta.
- Kolli, vikt, mått, tracking, projekt/kostnadsställe och anteckning per order.
- Leveranskö för skickat, kundhämtning och interna order.
- WooCommerce completed redovisas som Slutförd; WMS-leveranssätt redovisas separat.
- Automatisk Completed-status är valfri och av som standard.


v1.8.4 – Dynamiska leveransfält
- Fraktfält (DHL/DSV, avsändare, kolli, vikt, mått, tracking) visas endast när leveranssättet är Skickas.
- Kundhämtning visar endast relevanta hämtningsstatusar och anteckning.
- Intern order visar intern status, projekt/kostnadsställe och anteckning.
- Servern nollställer fraktdata om ordern ändras till Kundhämtning eller Intern order.
- Vikt och mått är frivilliga i testflödet.


v1.8.5 – Dynamisk WMS-orderstatus
- WMS-status följer plock, pack och valt leveranssätt.
- Skickas: Väntar på frakt → Klar för frakt → Transport klar → Skickad.
- Kundhämtning: Väntar på kundhämtning → Klar för hämtning → Hämtad.
- Intern order: Väntar på intern utlämning → Klar internt → Utlämnad internt.
- Orderlistan visar WMS-status separat från WooCommerce-status och Plock/Pack visas på svenska.


v1.8.6 – Tracking beta
- Trackingstatus och trackinghistorik för order med leveranssätt Skickas.
- Testläge kan simulera flödet: Registrerad → Hämtad av transportör → Under transport → På terminal → På väg för leverans → Levererad.
- Tracking visas inte för Kundhämtning eller Intern order.
- Leveranskön visar trackingnummer och aktuell trackingstatus.
- Riktiga automatiska DHL/DSV-trackinganrop är fortfarande avstängda tills respektive API-koppling aktiveras.


v1.8.7 – Automatisk DHL/DSV tracking
- Riktig DHL Shipment Tracking – Unified via DHL-API-Key.
- Riktig DSV Tracking v2 via OAuth 2.0, Subscription Key och myDSV-inloggning.
- Automatisk uppdatering ungefär en gång per timme via WordPress Cron.
- Manuell knapp “Hämta riktig trackingstatus nu” på ordern.
- Trackinghistorik uppdateras bara när transportörens status faktiskt ändras.
- När transportören har hämtat försändelsen eller den är i transit markeras WMS-leveransen som Skickad.
- Simuleringsknappen finns kvar i Test/Demo-läge.
- DHL/DSV transportbokning är fortfarande avstängd; v1.8.7 läser endast tracking.


=== v1.8.9 – Mobile tracking & adjustable intervals ===
- Transport & Tracking is rebuilt for mobile: tabs, search, KPI cards and shipment rows adapt to phones.
- Tracking table becomes touch-friendly shipment cards on small screens.
- Delivery settings, sender forms, order delivery fields and delivery queue are mobile responsive.
- Automatic tracking interval can be set to 1, 2, 3, 6, 12 or 24 hours.
- Attention threshold can be set to 12, 24, 48, 72 or 96 hours without a new tracking update.
- Delivered shipments remain excluded from automatic polling.


=== v1.9.0 – Automatisk Multi-Shop-synk varje minut ===
- Externa WooCommerce-shoppar synkroniseras automatiskt varje minut via WordPress Cron.
- Öppna order (processing/on-hold) kontrolleras varje minut så nya order snabbt visas i Dennis WMS.
- Nyligen slutförda order hämtas inkrementellt för statistik och status.
- Ändrade produkter/lagersaldon hämtas inkrementellt varje minut när WooCommerce API stöder modified_after.
- Full manuell synk finns kvar för första synk, historik och felsökning.
- Synken har ett 55-sekunders lås som hindrar överlappande körningar.
- Huvudshoppen läses fortfarande direkt och behöver ingen REST-synk.
- API-nycklar och övriga inställningar ligger kvar vid pluginuppdatering.
- Observera: WP-Cron är trafikstyrt. För exakt minutdrift på en produktionsserver bör wp-cron.php triggas av server-cron varje minut.


v2.0.1 – Lagerplats för batch utan plats
- Aktuella batchsaldon visar Ange plats när en batch saknar lagerplats.
- Befintligt batchsaldo flyttas till vald lagerplats utan att ändra antal eller WooCommerce totalsaldo.
- Händelsen loggas i batchhistoriken.


2.0.2
- Lagerplats fungerar fortsatt för alla lagerstyrda artiklar, även utan batch/expire.
- Batch och expire kan läggas till i efterhand från Lagerplatssaldon utan att WooCommerce totalsaldo ändras.
- Befintliga batchposter kan kompletteras/ändras med batchnummer och expire date.
- Del av ett lagerplatssaldo kan klassificeras till batch/expire; resterande ligger kvar oklassificerat.


== 2.0.3 ==
* Renare Lagerplatssaldon: lagerplats och antal separeras tydligt från batchinformation.
* Saknad batch visas som Ej angiven och saknat/0000-00-00 expire som Ej angivet.
* FEFO visas endast när giltigt expire date finns.
* Tydligare knapp för att lägga till eller ändra batch/expire.


== 2.0.4 ==
* Fixar kritiskt fel i Lagerplatssaldon för batchartiklar (odefinierad produktvariabel).
* Återställer tydlig lagerplatshantering i batchvyn.
* Lägg till lagerplats finns även för batchartiklar.
* Flytta batch/saldo mellan lagerplatser är tydligt åtkomligt från varje lagerplats.
* Behåller förenklad batch/expire-layout och mobilanpassning.


v2.0.5 – DSV Road API test setup
- Separata DSV-nycklar för Access Token, Booking, Tracking och Label.
- DSV test-MDM kan sparas.
- Testknapp verifierar OAuth 2.0 mot DSV Demo utan att skapa transport.
- Befintliga API-uppgifter bevaras vid uppgradering.


v2.0.7 – DSV Connect Booking DEMO v1
- DSV-testet använder Connect Booking DEMO v1 i stället för Generic OAuth.
- Primary Key skickas som DSV-Subscription-Key.
- myDSV-användarnamn/lösenord behövs inte för detta test.
- Testet skapar ingen bokning; det verifierar endpoint och API-nyckel säkert med en tom SOAP-förfrågan.


v2.0.8 – DSV Connect Tracking DEMO
- Connect Tracking DEMO v1 använder DSV:s SOAP-endpoint /connect-demo/tracking/v1/trackingWebServiceV3.
- Gemensamt test kontrollerar både Booking och Tracking endpoints utan att skapa bokning.
- Stöd för separat Tracking Primary Key; annars återanvänds Booking Primary Key.
- Connect Access Key kan sparas separat och används för riktig trackingförfrågan.
- DSV tracking kräver inte längre Generic OAuth/myDSV-fälten i Connect-läget.


v2.0.9 – DSV Connect DEMO booking + label test
- Skapa riktig Land-bokning i Connect DEMO med testdata.
- Booking ID visas och sparas tillfälligt för användaren.
- Hämta barcode/fraktsedel som Base64-PDF via getBookingBarcodeRequest.
- DEMO-funktionerna är hårdlåsta till testläge och kan inte anropa produktion.

v2.0.10 – DSV Connect DEMO diagnostics
- Shows HTTP status, Request ID, Booking ID and raw SOAP/XML response after a demo booking attempt.
- Success is only shown when DSV actually returns a Booking ID.
- Corrected Connect Tracking endpoint to /TrackingWebService.

2.0.34 – Leveransstatus
- Separata formulär för leverans och fraktpapper; status och sparaknapp fungerar även när PDF-uppladdning visas.
- Sparad status renderas direkt och databasfel visas vid misslyckad sparning.

2.0.35 – Last order date per batch i WMS
- Ange datum under Batcher & utgångsdatum vid registrering eller fördelning, eller via Batch / datum på en befintlig rad.
- Varje batchpost har sitt eget datum; befintliga poster börjar med ett tomt fält.
- Datumvarningar ställer in antal dagar före. Varning visas på WMS-sidorna och i batchlistan för poster med saldo, även efter datumet.
- Lokala order visar berörda lagerbatcher som behöver kontrolleras; varningen innebär inte att just den batchen har valts på ordern.
- Datumändringar loggas i batchhändelser och ändrar inte WooCommerce-saldot. Inget automatiskt köpstopp införs.

2.0.36 – Reparation av databasuppgradering
- dbDelta använder en kolumn per rad. Saknade last_order_date-kolumner skapas dessutom uttryckligen och kontrolleras i båda batchtabellerna.
- Uppgraderingen markeras klar först när kolumnerna finns. Befintliga saldon och batcher behålls.
- Öppna en WMS-sida som administratör efter uppdateringen och spara sedan datumet igen.

2.0.37 – Statistik och utskrift
- Last order date-statistik: enheter med passerad orderdag, orderdag idag, inom varningsgränsen och utan datum.
- Fullständig batchrapport med Last order date, varningar och datumhistorik, även för batcher utan expire.
- Rapportens fasta radgränser är borttagna. Inventerings- och tidsdetaljer finns med när Visa detaljtabeller är valt.
- Alla WMS-sidor får utskriftsknapp. Utskrift av denna vy följer sidans visade data och filter; rapportbyggaren tar med samtliga poster i vald period för sina rapportdelar.
- Utskriftslayout använder liggande A4, långa tabeller kan fortsätta över flera sidor, fältvärden och utfällda avsnitt följer med.

2.0.38 – Inventering per lagerplats och batch
- Öppna Inventera alla lagerplatser / batcher på produkten i Inventering. Fyll i alla registrerade rader, även tomma och utgångna batcher.
- Expire och Last order date följer med på inventeringsrader, historik och inventeringsutskrift. Datum ändras i batchregistret.
- Räknade delsaldo sparas tillsammans och summeras till WooCommerce-saldot. Orsak är obligatorisk. Extra antal utan plats registreras som ofördelat saldo.
- Radernas gamla saldo, räknat antal, differenser och datum sparas och kan skrivas ut i statistikrapporten.
- Ändrat lager eller datum sedan formuläret öppnades stoppar sparningen. Databasfel innan saldouppdateringen stoppar inventeringen.
- Korrigering av en inventering med delsaldo görs genom en ny fullständig inventering; totalsaldo kan inte korrigeras separat från batcherna.
- Nya batcher och platser läggs upp i respektive register före inventeringen. ATUM Multi-Inventory stöds fortfarande inte.

2.0.39 – Leveransstatistik
- Dashboard: skickade, hämtade av kund, interna utlämningar och transportörsfördelning.
- Produktstatistik samt Statistik per shop visar avslutade leveranser och transportörer (DHL, DSV, ej angiven).
- Statistikrapport har en separat valbar del Leveranssätt och transportörer med order, status, transportör, tracking och datum. Rapportdelen gäller huvudshoppen.
- Perioden använder separat avslutsdatum. Trackinguppdateringar flyttar inte datumet. Äldre leveranser använder senaste sparade datum som uppskattning och markeras i rapporten.
- Endast avslutade leveransflöden räknas; borttagna lokala order och saknade externa cacheorder utesluts. WooCommerce Completed räknas inte automatiskt som skickad.

2.0.40 – Ta bort statistikmallar
- Sparade mallar under Statistikrapport har en Ta bort-knapp med bekräftelse. Endast den inloggade användarens mall tas bort.

2.0.41 – Tydligare statistikbegrepp
- Typ heter Händelse och visar svenska beskrivningar. Källa heter Ursprung / referens och visar system samt order-, IN- eller inventeringsnummer.
- Samma beskrivningar används i batchstatistik, statistikrapporter och inleveransloggar.

2.0.42 – Statistik per kundnamn
- Ny sida Statistik per kund med namnsökning, period, antal order, beställda enheter och leverans/transportörsfördelning.
- Detaljer visar kundens order och produkter/SKU. Utskrift och statistikrapport stöds.
- Gäller huvudshoppen och faktureringsnamnet i WooCommerce. Identiska namn grupperas ihop oavsett kundkonto.
- Perioden gäller orderns skapandedatum, leveranser visar dessa orders aktuella avslutade WMS-status. Avbrutna, misslyckade och helt återbetalda order ingår inte.

2.0.43 – Statistik per säljare och leveransplats
- Kundnamnet på beställningen används som säljarens namn. Meny och rapportdel heter Statistik per säljare.
- Varje säljare delas upp efter leveransadressen på ordern (företag, gata, postnummer, ort och land).
- Antal order, beställda enheter, leveranssätt och transportörer visas per leveransplats och följer med i rapporten.
- Saknad leveransadress visas som Leveransplats ej angiven.

2.0.44 – Enbart tracking-API
- API-bokning, testbokning och API-hämtning av fraktsedlar är borttagna. Äldre bokningsnycklar rensas när administratören öppnar WordPress.
- DHL- och DSV-tracking finns kvar. DSV använder enbart Tracking Primary Key, aldrig Booking-nyckel som reserv.
- Bokning görs externt. Ange därefter tracking-/sändningsnummer på WMS-ordern och ladda upp fraktpapper som PDF vid behov.
- Testa DSV Tracking hämtar tracking för ett befintligt nummer i vald miljö, utan bokningsanrop.

=== v2.1.33 – Pre-orders ===
- Ny kryssruta "Pre-order-produkt" under Produktdata > Lager för enkla produkter.
- Stöd för samma markering på variationer.
- WooCommerce-saldot används som antal kvar att förbeställa.
- Pågående order med Pre-order-produkt hålls utanför vanlig plockkö.
- Ny sida Dennis WMS > Pre-orders visar väntande order och kvarvarande förbeställningssaldo.
