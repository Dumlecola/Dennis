(function () {
  'use strict';
  var opened = [], values = [];
  function prepare() {
    restore();
    var root = document.querySelector('#wpbody-content');
    if (!root) return;
    root.querySelectorAll('details:not([open])').forEach(function (el) { opened.push(el); el.open = true; });
    root.querySelectorAll('input,select,textarea').forEach(function (el) {
      if (['hidden', 'password', 'file', 'submit', 'button'].indexOf(el.type) !== -1 || el.closest('[hidden]')) return;
      var text = el.value;
      if (el.tagName === 'SELECT') text = Array.from(el.selectedOptions).map(function (o) { return o.textContent; }).join(', ');
      if (el.type === 'checkbox' || el.type === 'radio') text = el.checked ? '☑' : '☐';
      var span = document.createElement('span');span.className = 'dw-print-value';span.textContent = text || '–';
      el.insertAdjacentElement('afterend', span);values.push(span);
    });
  }
  function restore() { values.forEach(function (el) { el.remove(); });opened.forEach(function (el) { el.open = false; });values = [];opened = []; }
  window.addEventListener('beforeprint', prepare);
  window.addEventListener('afterprint', restore);
}());
