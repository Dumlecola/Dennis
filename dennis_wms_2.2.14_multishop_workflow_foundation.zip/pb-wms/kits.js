(() => {
  'use strict';
  document.addEventListener('DOMContentLoaded', () => {
    const states = new WeakMap();
    let nextId = 0;
    function stateFor(input) {
      if (states.has(input)) return states.get(input);
      const label = input.closest('label');
      const options = document.createElement('div');
      options.id = 'dw-kit-options-' + (++nextId);
      options.className = 'dw-kit-options';
      options.setAttribute('role', 'listbox');
      options.hidden = true;
      label.appendChild(options);
      input.setAttribute('role', 'combobox');
      input.setAttribute('aria-autocomplete', 'list');
      input.setAttribute('aria-expanded', 'false');
      input.setAttribute('aria-controls', options.id);
      input.setAttribute('autocomplete', 'off');
      const state = {options, result: label.querySelector('.dw-kit-result'), items: [], active: -1, seq: 0};
      state.result.setAttribute('aria-live', 'polite');
      states.set(input, state);
      return state;
    }
    function hide(input, state) {
      state.options.hidden = true;
      input.setAttribute('aria-expanded', 'false');
      input.removeAttribute('aria-activedescendant');
      state.active = -1;
    }
    function choose(input, state, index) {
      const item = state.items[index];
      if (!item) return;
      if (item.eligible === false) {state.result.textContent = item.name + ' · ' + item.reason; return;}
      input.value = item.sku;
      state.seq++;
      clearTimeout(state.timer);
      state.controller?.abort();
      state.result.textContent = item.name + (input.name === 'main_sku' ? '' : ' · Tillgängligt: ' + item.available + ' st');
      hide(input, state);
      input.focus();
      input.dispatchEvent(new Event('change', {bubbles: true}));
    }
    function activate(input, state, index) {
      if (!state.items.length) return;
      state.active = (index + state.items.length) % state.items.length;
      Array.from(state.options.children).forEach((button, i) => button.setAttribute('aria-selected', i === state.active ? 'true' : 'false'));
      const button = state.options.children[state.active];
      input.setAttribute('aria-activedescendant', button.id);
      button.scrollIntoView({block: 'nearest'});
    }
    document.querySelectorAll('.dw-kit-form').forEach(form => {
      const list = form.querySelector('.dw-kit-components');
      form.querySelector('.dw-kit-add')?.addEventListener('click', () => {
        if (list.children.length >= 100) return;
        const row = list.firstElementChild.cloneNode(true);
        row.querySelectorAll('.dw-kit-options').forEach(el => el.remove());
        const input = row.querySelector('[name="component_sku[]"]');
        input.value = '';
        ['aria-controls', 'aria-activedescendant', 'aria-expanded'].forEach(attr => input.removeAttribute(attr));
        row.querySelector('[name="component_qty[]"]').value = '1';
        row.querySelector('.dw-kit-result').textContent = '';
        list.appendChild(row);
        input.focus();
      });
      form.addEventListener('click', event => {
        if (event.target.closest('.dw-kit-remove') && list.children.length > 1) {
          const row = event.target.closest('.dw-kit-component');
          const state = states.get(row.querySelector('.dw-kit-sku'));
          clearTimeout(state?.timer);
          state?.controller?.abort();
          row.remove();
        }
      });
      form.addEventListener('input', event => {
        const input = event.target;
        if (!input.matches('.dw-kit-sku') || input.readOnly) return;
        const state = stateFor(input);
        clearTimeout(state.timer);
        state.controller?.abort();
        const seq = ++state.seq;
        const query = input.value.trim();
        state.items = [];
        hide(input, state);
        state.options.replaceChildren();
        state.result.textContent = query.length < 3 ? 'Skriv minst 3 tecken av SKU för att söka.' : 'Söker produkter…';
        if (query.length < 3) return;
        state.timer = setTimeout(async () => {
          state.controller = new AbortController();
          try {
            const params = new URLSearchParams({action: 'dennis_wms_kit_lookup', nonce: DennisKits.nonce, query, scope: input.name === 'main_sku' ? 'main' : 'component', accompanying: location.search.includes('dennis-wms-accompanying') ? '1' : '0'});
            const response = await fetch(DennisKits.url + '?' + params, {credentials: 'same-origin', signal: state.controller.signal});
            const data = await response.json();
            if (seq !== state.seq || !input.isConnected) return;
            if (!response.ok || !data.success) throw new Error('lookup');
            state.items = Array.isArray(data.data.results) ? data.data.results : [];
            state.result.textContent = state.items.length ? 'Välj produkt i listan.' : 'Inga produkter matchar denna SKU.';
            state.items.forEach((item, index) => {
              const button = document.createElement('button');
              button.type = 'button';
              button.id = state.options.id + '-' + index;
              button.setAttribute('role', 'option');
              button.setAttribute('aria-selected', 'false');
              button.tabIndex = -1;
              button.textContent = item.sku + ' · ' + item.name + (item.eligible === false ? ' · ' + item.reason : (input.name === 'main_sku' ? '' : ' · ' + item.available + ' st'));
              if (item.eligible === false) button.setAttribute('aria-disabled', 'true');
              button.addEventListener('click', () => choose(input, state, index));
              state.options.appendChild(button);
            });
            state.options.hidden = !state.items.length;
            input.setAttribute('aria-expanded', state.items.length ? 'true' : 'false');
          } catch (error) {
            if (error.name !== 'AbortError' && seq === state.seq) state.result.textContent = 'Sökningen kunde inte slutföras. Försök igen eller skriv hela SKU.';
          }
        }, 300);
      });
      form.addEventListener('keydown', event => {
        const input = event.target;
        if (!input.matches('.dw-kit-sku')) return;
        const state = states.get(input);
        if (!state || state.options.hidden) return;
        if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
          event.preventDefault();
          activate(input, state, state.active < 0 ? (event.key === 'ArrowDown' ? 0 : state.items.length - 1) : state.active + (event.key === 'ArrowDown' ? 1 : -1));
        } else if (event.key === 'Enter') {
          event.preventDefault();
          choose(input, state, state.active < 0 ? 0 : state.active);
        } else if (event.key === 'Escape') {
          event.preventDefault();
          hide(input, state);
        }
      });
      form.addEventListener('focusout', event => {
        const input = event.target;
        if (!input.matches('.dw-kit-sku')) return;
        const state = states.get(input);
        if (state) setTimeout(() => { if (!input.closest('label').contains(document.activeElement)) hide(input, state); }, 150);
      });
    });
  });
})();
