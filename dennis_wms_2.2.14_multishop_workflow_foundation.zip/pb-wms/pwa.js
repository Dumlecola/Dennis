(function () {
 'use strict';
 if (/playground\.wordpress\.net|wordpress-playground|playground\.wordpress/i.test(location.hostname) || window.self !== window.top) return;
 if (!window.isSecureContext || !('serviceWorker' in navigator) || !window.DennisWMSPWA) return;
 navigator.serviceWorker.register(window.DennisWMSPWA.worker, {
  scope: window.DennisWMSPWA.scope, updateViaCache: 'none'
 }).catch(function (error) { console.warn('Dennis WMS: PWA kunde inte aktiveras', error); });
})();
