<?php
if (!defined('ABSPATH')) exit;
final class Dennis_WMS_Product_View {
 static function boot(){add_action('admin_menu',[__CLASS__,'menu'],106);add_action('admin_post_dw_product_shop_name',[__CLASS__,'save_shop_name']);add_action('admin_post_dw_remote_barcode_save',[__CLASS__,'save_remote_barcode']);add_filter('woocommerce_product_data_store_cpt_get_products_query',[__CLASS__,'name_search'],10,2);}
 static function menu(){add_submenu_page('pb-wms','Produktvy','Produktvy','pb_wms_view','dennis-wms-products',[__CLASS__,'page']);}
 static function name_search($args,$vars){if(!empty($vars['dennis_wms_name_search']))$args['s']=$vars['dennis_wms_name_search'];return $args;}
 static function layout(){return ($_GET['product_layout']??'list')==='cards'?'cards':'list';}
 static function per_page(){$limit=absint($_GET['per_page']??25);return in_array($limit,[25,50,100],true)?$limit:25;}
 static function query_args(){
  $kind=sanitize_key(wp_unslash($_GET['product_kind']??'products'));$kind=$kind==='variations'?'variations':'products';
  $search=trim(sanitize_text_field(wp_unslash($_GET['product_search']??'')));$by=($_GET['search_by']??'name')==='sku'?'sku':'name';$stock=sanitize_key(wp_unslash($_GET['stock_filter']??''));
  $args=['limit'=>self::per_page(),'page'=>max(1,absint($_GET['product_page']??1)),'paginate'=>true,'orderby'=>'name','order'=>'ASC','status'=>['publish','private','draft','pending','future']];
  $category=absint($_GET['product_category']??0);
  if($category && term_exists($category,'product_cat'))$args['category']=[get_term($category,'product_cat')->slug];
  if($kind==='variations' && $category){
   unset($args['category']);
   $parent_ids=get_posts(['post_type'=>'product','post_status'=>'any','fields'=>'ids','posts_per_page'=>-1,'tax_query'=>[['taxonomy'=>'product_cat','field'=>'term_id','terms'=>[$category],'include_children'=>true]]]);
   $args['parent']=$parent_ids?:[0];
  }
  if($kind==='variations')$args['type']='variation';
  if($search!=='')$args[$by==='sku'?'sku':'dennis_wms_name_search']=$search;
  if(in_array($stock,['instock','outofstock','onbackorder'],true))$args['stock_status']=$stock;
  if($kind==='variations'&&!empty($_GET['parent_id']))$args['parent']=absint($_GET['parent_id']);
  return $args;
 }
 static function url($changes=[]){$keys=['product_kind','product_search','search_by','stock_filter','product_category','parent_id','product_layout','per_page','remote_page','dw_shop'];$args=['page'=>'dennis-wms-products'];foreach($keys as $key)if(isset($_GET[$key]))$args[$key]=sanitize_text_field(wp_unslash($_GET[$key]));return add_query_arg(array_merge($args,$changes),admin_url('admin.php'));}
 static function locations($products){
  global $wpdb;$ids=array_map(function($p){return $p->get_id();},$products);if(!$ids)return [];$locations=[];
  $tables=[];if(class_exists('Dennis_WMS_Batches'))$tables[]=Dennis_WMS_Batches::table('balances');if(class_exists('Dennis_WMS_Locations_V14'))$tables[]=Dennis_WMS_Locations_V14::table('balances');
  foreach($tables as $table){if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$table))!==$table)continue;$placeholders=implode(',',array_fill(0,count($ids),'%d'));$rows=$wpdb->get_results($wpdb->prepare("SELECT DISTINCT product_id,location FROM $table WHERE product_id IN ($placeholders) AND quantity>0 AND location<>''",...$ids));foreach($rows as $row)$locations[$row->product_id][$row->location]=true;}
  return $locations;
 }
 static function is_preorder($p){return class_exists('Dennis_WMS_Preorders')&&Dennis_WMS_Preorders::is_product($p);}
 static function type_label($p){
  if(self::is_preorder($p))return 'Pre-order';
  if(class_exists('Dennis_WMS_Kits')&&($r=Dennis_WMS_Kits::recipe($p->get_id())))return !empty($r['accompanying'])?'Kit':(!empty($r['mode'])&&$r['mode']==='packed'?'För-packad':'Förpackning');
  if(class_exists('Dennis_WMS_Product_Packing')&&Dennis_WMS_Product_Packing::valid_product($p)&&Dennis_WMS_Product_Packing::quantity($p)>0)return 'För-packad';
  return 'Vanlig';
 }
 static function packing_label($p){if(self::is_preorder($p))return '';if(class_exists('Dennis_WMS_Kits')&&($r=Dennis_WMS_Kits::recipe($p->get_id())))return !empty($r['accompanying'])?'Medföljande artiklar · beställningsbart '.Dennis_WMS_Kits::capacity($r).' st':($r['mode']==='packed'?'Förpackade: '.(!empty($r['base_product_id'])?Dennis_WMS_Product_Packing::quantity($p):max(0,(int)$p->get_stock_quantity('edit'))).' st · Flera SKU':'Förpackning · packas vid plockning');if(class_exists('Dennis_WMS_Product_Packing')&&Dennis_WMS_Product_Packing::valid_product($p)&&Dennis_WMS_Product_Packing::quantity($p)>0){$n=Dennis_WMS_Product_Packing::quantity($p);$total=max(0,(int)$p->get_stock_quantity('edit'));return 'Förpackade: '.$n.' st · Oförpackade: '.max(0,$total-$n).' st';}return '';}
 static function barcode_display($p){
  if(!class_exists('Dennis_WMS_Barcodes'))return '';
  $code=(string)$p->get_meta(Dennis_WMS_Barcodes::META,true);
  if($code==='' && current_user_can('pb_wms_manage') && current_user_can('manage_woocommerce'))$code=Dennis_WMS_Barcodes::ensure($p->get_id());
  if($code==='')return '<small class="dw-product-barcode-missing">Streckkod saknas</small>';
  $svg=Dennis_WMS_Barcodes::svg($code,38);
  if($svg==='')return '<small class="dw-product-barcode-missing">Streckkoden kan inte visas</small>';
  return '<div class="dw-product-barcode" aria-label="Streckkod">'.$svg.'<small>'.esc_html($code).'</small><a href="'.esc_url(Dennis_WMS_Barcodes::url(['product_id'=>$p->get_id()])).'">Skriv ut etikett</a></div>';
 }
 static function links($p){$id=$p->get_id();$sku=$p->get_sku();
   echo '<a href="'.esc_url(Dennis_WMS_Barcodes::url(['product_id'=>$id])).'">Streckkod</a>';
   if($sku!==''){foreach(['dennis-wms-batches'=>'Batcher','dennis-wms-locations'=>'Lagerplatser'] as $page=>$label)echo '<a href="'.esc_url(add_query_arg(['page'=>$page,'sku'=>$sku],admin_url('admin.php'))).'">'.esc_html($label).'</a>';}
   if($sku!==''&&class_exists('Dennis_WMS_Kits')&&$p->is_type(['simple','variation'])){$kit=Dennis_WMS_Kits::recipe($id);echo '<a href="'.esc_url((!empty($kit['accompanying'])?Dennis_WMS_Accompanying::url($sku):Dennis_WMS_Kits::url(['sku'=>$sku]))).'">'.(!empty($kit['accompanying'])?'Kit':($kit?'Förpackning':'Packning')).'</a>';}
   if($p->is_type('variable'))echo '<a href="'.esc_url(self::url(['product_kind'=>'variations','parent_id'=>$id,'product_page'=>1,'product_search'=>''])).'">Visa varianter</a>';
   if(current_user_can('edit_post',$id)){$edit=get_edit_post_link($p->is_type('variation')?$p->get_parent_id():$id,'raw');if($edit)echo '<a href="'.esc_url($edit).'">Öppna i WooCommerce</a>';}
 }
 static function central_name(){
  $name=trim((string)get_option('dw_wms_central_shop_name',''));
  if($name==='')$name=trim((string)get_option('blogname',''));
  return $name!==''?$name:(string)wp_parse_url(home_url(),PHP_URL_HOST);
 }
 static function save_shop_name(){
  if(!current_user_can('manage_options'))wp_die('Åtkomst nekad.',403);
  check_admin_referer('dw_product_shop_name');
  update_option('dw_wms_central_shop_name',sanitize_text_field(wp_unslash($_POST['shop_name']??'')),false);
  wp_safe_redirect(self::url(['shop_saved'=>1]));exit;
 }
 static function remote_codes(){ $v=get_option('dw_wms_remote_barcodes',[]);return is_array($v)?$v:[]; }
 static function remote_code($r,$create=true){
  $key=(string)absint($r->shop_id).':'.(string)absint($r->remote_product_id);
  $codes=self::remote_codes();
  if(!empty($codes[$key]))return (string)$codes[$key];
  if(!$create||!current_user_can('manage_woocommerce'))return '';
  $code='DW'.strtoupper(substr(hash('sha256',home_url('/')),0,8)).'S'.absint($r->shop_id).'P'.absint($r->remote_product_id);
  $codes[$key]=$code;update_option('dw_wms_remote_barcodes',$codes,false);
  return $code;
 }
 static function save_remote_barcode(){
  if(!current_user_can('manage_woocommerce')||!current_user_can('pb_wms_manage'))wp_die('Åtkomst nekad.',403);
  check_admin_referer('dw_remote_barcode_save');
  $id=absint($_POST['remote_id']??0);$r=self::remote_product($id);
  if(!$r)wp_die('Produkten hittades inte.',404);
  $code=trim(sanitize_text_field(wp_unslash($_POST['barcode']??'')));
  if($code===''||strlen($code)>64||!preg_match('/^[\\x20-\\x7E]+$/D',$code))wp_die('Ange 1–64 giltiga tecken.',400);
  $codes=self::remote_codes();$key=absint($r->shop_id).':'.absint($r->remote_product_id);
  foreach($codes as $other=>$value)if($other!==$key&&$value===$code)wp_die('Streckkoden används redan av en annan ansluten produkt.',409);
  if(class_exists('Dennis_WMS_Barcodes')&&!Dennis_WMS_Barcodes::unique($code))wp_die('Streckkoden används redan av en lokal produkt.',409);
  $codes[$key]=$code;update_option('dw_wms_remote_barcodes',$codes,false);
  wp_safe_redirect(self::remote_url($id));exit;
 }
 static function remote_type_label($v){
  return ['simple'=>'Vanlig','variable'=>'Variabel','variation'=>'Variation','grouped'=>'Grupperad','external'=>'Extern'][(string)$v]??ucfirst((string)$v);
 }
 static function remote_status_label($v){
  return ['publish'=>'Publicerad','private'=>'Privat','draft'=>'Utkast','pending'=>'Väntar på granskning','future'=>'Schemalagd'][(string)$v]??ucfirst((string)$v);
 }
 static function remote_product($cache_id){
  if(!class_exists('Dennis_WMS_Multi_Shop'))return null;
  global $wpdb;$p=Dennis_WMS_Multi_Shop::table('products');$shops=Dennis_WMS_Multi_Shop::table('shops');
  return $wpdb->get_row($wpdb->prepare("SELECT p.*,s.name shop_name,s.url shop_url FROM $p p INNER JOIN $shops s ON s.id=p.shop_id WHERE p.id=%d",absint($cache_id)));
 }
 static function remote_url($id){return add_query_arg(['page'=>'dennis-wms-products','dw_remote_product_id'=>absint($id)],admin_url('admin.php'));}
 static function remote_detail($r){
  echo '<div class="wrap dw-product-view"><p><a href="'.esc_url(self::url(['dw_remote_product_id'=>false])).'">← Alla produkter</a></p><h1>Produktvy · '.esc_html($r->shop_name).'</h1><article class="dw-product-card" style="max-width:760px;padding:20px">';
  if($r->image_url)echo '<div class="dw-product-image"><img src="'.esc_url($r->image_url).'" alt="" style="max-width:220px;height:auto"></div>';
  echo '<div class="dw-product-card-body"><h2>'.esc_html($r->name).'</h2><p><strong>Shop:</strong> '.esc_html($r->shop_name).'</p><p><strong>SKU:</strong> '.esc_html($r->sku?:'Saknas').'</p><p><strong>WooCommerce produkt-ID:</strong> '.esc_html($r->remote_product_id).'</p><p><strong>Lagersaldo i ansluten shop:</strong> '.esc_html($r->stock_quantity===null?'Ej angivet':wc_format_localized_decimal($r->stock_quantity)).'</p><p><strong>Typ:</strong> '.esc_html(self::remote_type_label($r->type)).'</p><p><strong>Status:</strong> '.esc_html(self::remote_status_label($r->status)).'</p><p><strong>Senast synkroniserad:</strong> '.esc_html($r->updated_at).'</p><p><a class="button button-primary" href="'.esc_url(add_query_arg(['page'=>'pb-wms','dw_inventory_shop'=>absint($r->shop_id),'dw_inventory_product'=>absint($r->id)],admin_url('admin.php'))).'">Inventera produkten – ange räknat antal</a></p>';
  $code=self::remote_code($r);
  if($code!==''&&class_exists('Dennis_WMS_Barcodes')){
   echo '<div class="dw-label" style="background:#fff;color:#111;border:1px solid #ddd;padding:16px;display:inline-block;text-align:center;margin:12px 0"><strong>'.esc_html($r->name).'</strong><div>'.Dennis_WMS_Barcodes::svg($code).'</div><small>'.esc_html($code).'</small><br><small>SKU: '.esc_html($r->sku).'</small></div><p><button class="button" onclick="window.print()">Skriv ut etikett</button></p>';
  }
  if(current_user_can('manage_woocommerce')&&current_user_can('pb_wms_manage')){
   echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
   wp_nonce_field('dw_remote_barcode_save');
   echo '<input type="hidden" name="action" value="dw_remote_barcode_save"><input type="hidden" name="remote_id" value="'.absint($r->id).'"><label>Streckkod / EAN <input name="barcode" value="'.esc_attr($code).'" maxlength="64" size="32"></label> <button class="button">Spara streckkod</button></form>';
  }
  echo '</div></article></div>';
 }
 static function remote_rows($search,$by,$kind,$limit,$page,$stock='',$shop_id=0){
  if(!class_exists('Dennis_WMS_Multi_Shop'))return [[],0];
  global $wpdb;$p=Dennis_WMS_Multi_Shop::table('products');$shops=Dennis_WMS_Multi_Shop::table('shops');
  $where=$kind==='variations'?" WHERE p.type='variation' ":" WHERE p.type<>'variation' ";$params=[];
  if($search!==''){$like='%'.$wpdb->esc_like($search).'%';if($by==='sku'){$where.=' AND p.sku LIKE %s ';$params[]=$like;}else{$where.=' AND (p.name LIKE %s OR p.sku LIKE %s) ';$params[]=$like;$params[]=$like;}}
  if($shop_id>0){$where.=' AND p.shop_id=%d ';$params[]=$shop_id;}
  if($stock==='instock')$where.=' AND p.stock_quantity>0 ';
  if($stock==='outofstock')$where.=' AND p.stock_quantity<=0 ';
  if($stock==='onbackorder')return [[],0]; // Remote cache does not store backorder state.
  $from=" FROM $p p INNER JOIN $shops s ON s.id=p.shop_id ";
  $sql='SELECT COUNT(*)'.$from.$where;
  $total=(int)$wpdb->get_var($params?$wpdb->prepare($sql,...$params):$sql);
  $sql='SELECT p.*,s.name shop_name'.$from.$where.' ORDER BY s.name ASC,p.name ASC,p.id ASC LIMIT %d OFFSET %d';
  $rows=$wpdb->get_results($wpdb->prepare($sql,...array_merge($params,[$limit,($page-1)*$limit])));
  return [$rows?:[],$total];
 }
 static function remote_barcode($r){
  // Remote cache contains SKU but no barcode metadata. Never fabricate a barcode.
  $code=self::remote_code($r);
  if($code===''||!class_exists('Dennis_WMS_Barcodes'))return '<small class="dw-product-barcode-missing">Streckkod saknas</small>';
  $svg=Dennis_WMS_Barcodes::svg($code,38);
  return '<div class="dw-product-barcode">'.$svg.'<small>'.esc_html($code).'</small><a href="'.esc_url(self::remote_url($r->id)).'">Visa / skriv ut etikett</a></div>';
 }
 static function remote_item($r,$layout){
  $image=$r->image_url?'<img src="'.esc_url($r->image_url).'" alt="" loading="lazy">':'<span class="dashicons dashicons-format-image" aria-label="Ingen produktbild"></span>';
  $stock=$r->stock_quantity===null?'Ej angivet':wc_format_localized_decimal($r->stock_quantity);
  $status=$r->stock_quantity===null?'Ej angiven':((float)$r->stock_quantity>0?'I lager':'Slut i lager');
  $url=esc_url(self::remote_url($r->id));
  $inventory='<small>Ej inventerad</small>';
  if(class_exists('Dennis_WMS_Remote_Inventory')){
   foreach(Dennis_WMS_Remote_Inventory::history() as $h){
    if((int)($h['shop_id']??0)===(int)$r->shop_id&&(int)($h['product_id']??0)===(int)$r->remote_product_id){
     $inventory='<strong>Räknat: '.esc_html((string)$h['count']).'</strong><small>'.esc_html((string)$h['time']).' · '.esc_html((string)$h['status']).'</small>';break;
    }
   }
  }
  $inventory.='<br><a href="'.esc_url(add_query_arg(['page'=>'pb-wms','dw_inventory_shop'=>absint($r->shop_id),'dw_inventory_product'=>absint($r->id)],admin_url('admin.php'))).'">Ange räknat antal</a>';
  if($layout==='list'){
   echo '<tr><td class="dw-product-list-image">'.$image.'</td><td class="dw-product-list-name"><strong>'.esc_html($r->name).'</strong>'.self::remote_barcode($r).'<small>'.esc_html(self::remote_status_label($r->status)).'</small></td><td>'.esc_html($r->shop_name).'</td><td>'.esc_html($r->sku?:'Saknas').'</td><td><span class="dw-product-type">'.esc_html(self::remote_type_label($r->type)).'</span></td><td class="dw-product-list-qty">'.esc_html($stock).'</td><td>Ej kopplad</td><td><span class="dw-product-stock">'.esc_html($status).'</span></td><td>'.$inventory.'</td><td><a class="button" href="'.$url.'">Öppna</a></td></tr>';
  }else{
   echo '<article class="dw-product-card"><div class="dw-product-image">'.$image.'</div><div class="dw-product-card-body"><div class="dw-product-card-top"><span class="dw-product-stock">'.esc_html($status).'</span><small>'.esc_html($r->shop_name).'</small></div><h2>'.esc_html($r->name).'</h2><p><span class="dw-product-type">'.esc_html(self::remote_type_label($r->type)).'</span></p><p class="dw-product-sku">SKU: <strong>'.esc_html($r->sku?:'Saknas').'</strong></p>'.self::remote_barcode($r).'<div class="dw-product-inventory"><h3>Inventeringsstatus</h3>'.$inventory.'</div><dl><div><dt>Saldo (shop)</dt><dd>'.esc_html($stock).'</dd></div><div><dt>Lagerplats</dt><dd>Ej kopplad</dd></div></dl><div class="dw-product-links"><a href="'.$url.'">Öppna produkt</a></div></div></article>';
  }
 }
 static function page(){
  if(!current_user_can('pb_wms_view'))wp_die('Åtkomst nekad',403);
  $remote_id=absint($_GET['dw_remote_product_id']??0);
  if($remote_id){$remote=self::remote_product($remote_id);if(!$remote)wp_die('Produkten finns inte i synkroniserade shopdata.',404);self::remote_detail($remote);return;}
  // Direct product detail opened by barcode/SKU scanning; read-only view.
  $scanned_id=absint($_GET['dw_product_id']??0);
  if($scanned_id){
   $p=wc_get_product($scanned_id);
   if(!$p){echo '<div class="wrap"><h1>Produkten hittades inte</h1></div>';return;}
   $id=$p->get_id();$sku=$p->get_sku();$stock=$p->get_stock_quantity();
   $image_id=$p->get_image_id();$image=$image_id?wp_get_attachment_image($image_id,'medium'):'';
   $loc=self::locations([$p]);$places=array_keys($loc[$id]??[]);
   if(!$places&&class_exists('Dennis_WMS_Orders')){$base=Dennis_WMS_Orders::location($id);if($base)$places[]=$base;}
   $details=class_exists('Dennis_WMS_Inventory_Followup')?Dennis_WMS_Inventory_Followup::latest_details([$id]):[];
   echo '<div class="wrap dw-product-view dw-scanned-product"><p><a href="'.esc_url(admin_url('admin.php?page=dennis-wms-scanner')).'">← Scanna igen</a> · <a href="'.esc_url(admin_url('admin.php?page=dennis-wms-products')).'">Alla produkter</a></p><h1>Produktvy</h1><article class="dw-product-card" style="max-width:760px;padding:20px">';
   if($image)echo '<div class="dw-product-image">'.wp_kses_post($image).'</div>';
   echo '<div class="dw-product-card-body"><h2>'.esc_html($p->get_name()).'</h2><p><strong>SKU:</strong> '.esc_html($sku?:'Saknas').'</p><p><strong>Lagersaldo:</strong> '.esc_html($stock===null?'Ej lagerhanterad':wc_format_localized_decimal($stock)).'</p><p><strong>Lagerplatser:</strong> '.esc_html($places?implode(', ',$places):'Ej angivna').'</p>';
   echo '<p><strong>Lagerstatus:</strong> '.esc_html($p->get_stock_status()).'</p>';
   if(class_exists('Dennis_WMS_Inventory_Followup'))echo '<div class="dw-product-inventory"><h3>Inventeringsstatus</h3>'.Dennis_WMS_Inventory_Followup::product_status_html($details[$id]??null).'</div>';
   echo '<div class="dw-product-links">';self::links($p);echo '</div></div></article></div>';
   return;
  }
  $central_shop_name=self::central_name();$layout=self::layout();$args=self::query_args();$shop_choice=sanitize_text_field(wp_unslash($_GET['dw_shop']??'all'));$shop_filter=ctype_digit($shop_choice)?absint($shop_choice):0;$local_only=$shop_choice==='central';$remote_only=$shop_filter>0;$results=wc_get_products($args);$products=$remote_only?[]:$results->products;$locations=self::locations($products);$inventory_details=class_exists('Dennis_WMS_Inventory_Followup')?Dennis_WMS_Inventory_Followup::latest_details(array_map(static function($p){return $p->get_id();},$products)):[];$kind=($args['type']??'')==='variation'?'variations':'products';
  $search=trim(sanitize_text_field(wp_unslash($_GET['product_search']??'')));$by=($_GET['search_by']??'name')==='sku'?'sku':'name';$stock=$args['stock_status']??'';$category=absint($_GET['product_category']??0);list($remote_rows,$remote_total)=$local_only?[[],0]:self::remote_rows($search,$by,$kind,self::per_page(),$args['page'],$stock,$shop_filter);$local_total=$remote_only?0:(int)$results->total;$total=$local_total+$remote_total;
  echo '<div class="wrap dw-product-view"><style>.dw-shop-group-row th{background:#e9f3f4!important;border-top:3px solid #bfd4d9!important;border-bottom:1px solid #bfd4d9!important;color:#164854!important;font-size:16px!important;padding:15px 18px!important;text-align:left}.dw-shop-group-row .dashicons,.dw-shop-group-heading .dashicons{vertical-align:middle;margin-right:5px}.dw-shop-count{font-size:12px;font-weight:400;margin-left:12px;color:#52707a}.dw-shop-group-heading{grid-column:1/-1;background:#e9f3f4;border-top:3px solid #bfd4d9;border-radius:8px;padding:15px 18px;font-weight:700;font-size:16px;color:#164854;margin-top:12px}.dw-product-barcode{margin-top:7px;max-width:230px}.dw-product-barcode svg{display:block;max-width:100%;height:40px}.dw-product-barcode small{display:block;font:11px monospace;overflow-wrap:anywhere}.dw-product-barcode a{display:inline-block;margin-top:3px;font-size:11px}.dw-product-barcode-missing{display:block;color:#777}.dw-product-list .dw-product-barcode{min-width:130px}.dw-inventory-status{display:flex;flex-direction:column;gap:3px;min-width:140px}.dw-inventory-status small{font-size:11px;line-height:1.35}.dw-inventory-badge{display:inline-block;align-self:flex-start;padding:4px 8px;border-radius:6px;color:#fff;font-weight:600;font-size:11px}@media print{.dw-product-barcode svg{height:40px!important}.dw-product-barcode a{display:none}}</style><h1>Produktvy</h1><p>Produkter grupperade efter shop, med samma produktkolumner och filter. Externa saldon är senast synkroniserade och ändras inte här. Lagerplatser och inventeringshistorik visas bara där de är kopplade.</p>';
  if(current_user_can('manage_options')){
   echo '<details style="margin:10px 0 18px"><summary>Ändra namn på centrala shoppen</summary><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
   wp_nonce_field('dw_product_shop_name');
   echo '<input type="hidden" name="action" value="dw_product_shop_name"><input type="text" name="shop_name" value="'.esc_attr(get_option('dw_wms_central_shop_name','')).'" placeholder="'.esc_attr(get_option('blogname')).'"> <button class="button">Spara shopnamn</button></form></details>';
  }
  echo '<nav class="dw-product-tabs" aria-label="Produkturval">';
  foreach(['products'=>'Produkter','variations'=>'Varianter'] as $key=>$label)echo '<a class="'.($key===$kind?'active':'').'" '.($key===$kind?'aria-current="page"':'').' href="'.esc_url(self::url(['product_kind'=>$key,'product_page'=>1,'parent_id'=>0])).'">'.esc_html($label).'</a>';
  echo '</nav><nav class="dw-product-layout" aria-label="Produktvisning">';foreach(['list'=>'Kompakt lista','cards'=>'Kortvy'] as $view=>$label)echo '<a class="'.($layout===$view?'active':'').'" '.($layout===$view?'aria-current="page"':'').' href="'.esc_url(self::url(['product_layout'=>$view])).'">'.esc_html($label).'</a>';echo '</nav><form method="get"  class="dw-product-filters"><input type="hidden" name="page" value="dennis-wms-products"><input type="hidden" name="product_kind" value="'.esc_attr($kind).'">';
  echo '<input type="hidden" name="product_layout" value="'.esc_attr($layout).'">';
  if(!empty($args['parent']))echo '<input type="hidden" name="parent_id" value="'.esc_attr($args['parent']).'">';
  echo '<label>Sök <input type="search" name="product_search" value="'.esc_attr($search).'" placeholder="Produktnamn eller SKU"></label><label>Sök i <select name="search_by"><option value="name" '.selected($by,'name',false).'>Produktnamn</option><option value="sku" '.selected($by,'sku',false).'>SKU</option></select></label><label>Lagerstatus <select name="stock_filter">';
  foreach([''=>'Alla','instock'=>'I lager','outofstock'=>'Slut i lager','onbackorder'=>'Restnoterad'] as $key=>$label)echo '<option value="'.esc_attr($key).'" '.selected($stock,$key,false).'>'.esc_html($label).'</option>';
  echo '</select></label><label>Kategori <select name="product_category"><option value="0">Alla kategorier</option>';
  $categories=get_terms(['taxonomy'=>'product_cat','hide_empty'=>false,'orderby'=>'name','order'=>'ASC']);
  if(!is_wp_error($categories))foreach($categories as $term)echo '<option value="'.esc_attr($term->term_id).'" '.selected($category,$term->term_id,false).'>'.esc_html($term->name).'</option>';
  echo '</select></label><label>Shop <select name="dw_shop"><option value="all" '.selected($shop_choice,'all',false).'>Alla shoppar</option><option value="central" '.selected($shop_choice,'central',false).'>'.esc_html($central_shop_name).'</option>';
  if(class_exists('Dennis_WMS_Multi_Shop'))foreach(Dennis_WMS_Multi_Shop::shops() as $shop)echo '<option value="'.esc_attr($shop->id).'" '.selected($shop_choice,(string)$shop->id,false).'>'.esc_html($shop->name).'</option>';
  echo '</select></label><label>Per sida <select name="per_page">';foreach([25,50,100] as $limit)echo '<option value="'.esc_attr($limit).'" '.selected($args['limit'],$limit,false).'>'.esc_html($limit).'</option>';echo '</select></label><button class="button button-primary">Visa produkter</button><a class="button" href="'.esc_url(add_query_arg('page','dennis-wms-products',admin_url('admin.php'))).'">Rensa</a></form><div class="dw-product-result-count">'.esc_html(number_format_i18n($total)).' '.($kind==='variations'?'varianter':'produkter').' · Sida '.esc_html($args['page']).' av '.esc_html(max(1,$remote_only?0:(int)$results->max_num_pages,(int)ceil($remote_total/self::per_page()))).'</div>';if($layout==='list')echo '<table class="widefat striped dw-product-list"><thead><tr><th>Bild</th><th>Produkt</th><th>Shop</th><th>SKU</th><th>Typ</th><th>Saldo</th><th>Lagerplats</th><th>Lagerstatus</th><th>Inventeringsstatus</th><th>Åtgärder</th></tr></thead><tbody>';else echo '<div class="dw-product-grid">';
  // Group each shop visually while retaining the existing columns, filters and pagination.
  $group_heading=static function($name,$count)use($layout){
   $title='<span class="dashicons dashicons-store" aria-hidden="true"></span> '.esc_html($name).' <span class="dw-shop-count">'.esc_html(number_format_i18n($count)).' på denna sida</span>';
   if($layout==='list')echo '<tr class="dw-shop-group-row"><th colspan="10" scope="colgroup">'.$title.'</th></tr>';
   else echo '<div class="dw-shop-group-heading" role="heading" aria-level="2">'.$title.'</div>';
  };
  if($products)$group_heading($central_shop_name,count($products));
  foreach($products as $p){$id=$p->get_id();$sku=$p->get_sku();$status=$p->get_stock_status();$image_id=$p->get_image_id();$image=$image_id?wp_get_attachment_image_url($image_id,$layout==='list'?'thumbnail':'medium'):false;$status_label=['instock'=>'I lager','outofstock'=>'Slut i lager','onbackorder'=>'Restnoterad'][$status]??$status;$recipe=class_exists('Dennis_WMS_Kits')?Dennis_WMS_Kits::recipe($id):null;$is_accompanying=!empty($recipe['accompanying']);$qty=$is_accompanying?Dennis_WMS_Kits::capacity($recipe):$p->get_stock_quantity();if(!$is_accompanying&&$p->managing_stock()==='parent'){$parent=wc_get_product($p->get_parent_id());$qty=$parent?$parent->get_stock_quantity():null;}$places=array_keys($locations[$id]??[]);$packing=self::packing_label($p);$preorder=self::is_preorder($p);$type=self::type_label($p);$inventory_html=$p->managing_stock()&&class_exists('Dennis_WMS_Inventory_Followup')?Dennis_WMS_Inventory_Followup::product_status_html($inventory_details[$id]??null):'<small>Ej lagerstyrd</small>';
   if(!$places&&class_exists('Dennis_WMS_Orders')){$base=Dennis_WMS_Orders::location($id);if($base)$places[]=$base;}
   if($layout==='list'){echo '<tr><td class="dw-product-list-image">'.($image?'<img src="'.esc_url($image).'" alt="" loading="lazy">':'<span class="dashicons dashicons-format-image" aria-label="Ingen produktbild"></span>').'</td><td class="dw-product-list-name"><strong>'.esc_html($p->get_name()).'</strong>'.($packing?'<small>'.esc_html($packing).'</small>':'').self::barcode_display($p).'<small>'.esc_html(['publish'=>'Publicerad','private'=>'Privat','draft'=>'Utkast','pending'=>'Väntar på granskning','future'=>'Schemalagd'][$p->get_status()]??$p->get_status()).'</small></td><td>'.esc_html($central_shop_name).'</td><td>'.esc_html($sku?:'Saknas').'</td><td><span class="dw-product-type '.($preorder?'preorder':'').'">'.esc_html($type).'</span></td><td class="dw-product-list-qty">'.esc_html($qty!==null?wc_format_localized_decimal($qty):($p->is_type('variable')?'Se varianter':'Ej lagerhanterad')).($preorder?'<small>Tillgängligt för förbeställning</small>':'').'</td><td>'.esc_html($places?implode(', ',$places):'Ej angiven').'</td><td><span class="dw-product-stock '.esc_attr($status).'">'.esc_html($status_label).'</span></td><td>'.$inventory_html.'</td><td><details class="dw-product-list-actions"><summary>Öppna</summary><div class="dw-product-links">';self::links($p);echo '</div></details></td></tr>';continue;}
   echo '<article class="dw-product-card"><div class="dw-product-image">'.($image?'<img src="'.esc_url($image).'" alt="'.esc_attr($p->get_name()).'" loading="lazy">':'<span class="dashicons dashicons-format-image" aria-label="Ingen produktbild"></span>').'</div><div class="dw-product-card-body"><div class="dw-product-card-top"><span class="dw-product-stock '.esc_attr($status).'">'.esc_html($status_label).'</span><small>'.esc_html($central_shop_name).'</small><small>'.esc_html(['publish'=>'Publicerad','private'=>'Privat','draft'=>'Utkast','pending'=>'Väntar på granskning','future'=>'Schemalagd'][$p->get_status()]??$p->get_status()).'</small></div><h2>'.esc_html($p->get_name()).'</h2><p><span class="dw-product-type '.($preorder?'preorder':'').'">'.esc_html($type).'</span></p>'.($packing?'<p>'.esc_html($packing).'</p>':'').'<p class="dw-product-sku">SKU: <strong>'.esc_html($sku?:'Saknas').'</strong></p>'.self::barcode_display($p).'<div class="dw-product-inventory"><h3>Inventeringsstatus</h3>'.$inventory_html.'</div><dl><div><dt>'.($preorder?'Tillgängligt för förbeställning':'Lagersaldo').'</dt><dd>'.esc_html($qty!==null?wc_format_localized_decimal($qty):($p->is_type('variable')?'Se varianter':'Ej lagerhanterad')).'</dd></div><div><dt>Lagerplats</dt><dd>'.esc_html($places?implode(', ',$places):'Ej angiven').'</dd></div></dl><div class="dw-product-links">';
   self::links($p);
   echo '</div></div></article>';
  }
  $last_remote_shop=null;
  foreach($remote_rows as $remote){
   $remote_key=(int)$remote->shop_id;
   if($last_remote_shop!==$remote_key){
    $shop_count=0;foreach($remote_rows as $r)if((int)$r->shop_id===$remote_key)$shop_count++;
    $group_heading($remote->shop_name,$shop_count);
    $last_remote_shop=$remote_key;
   }
   self::remote_item($remote,$layout);
  }
  if(!$products&&!$remote_rows)echo $layout==='list'?'<tr><td colspan="10" class="dw-product-empty">Inga produkter matchar urvalet.</td></tr>':'<p class="dw-product-empty">Inga produkter matchar urvalet.</p>';
  echo ($layout==='list'?'</tbody></table>':'</div>');echo '<nav class="dw-product-pagination" aria-label="Produktsidor">';if($args['page']>1)echo '<a class="button" href="'.esc_url(self::url(['product_page'=>$args['page']-1])).'">← Föregående</a>';if($args['page']<max($remote_only?0:(int)$results->max_num_pages,(int)ceil($remote_total/self::per_page())))echo '<a class="button" href="'.esc_url(self::url(['product_page'=>$args['page']+1])).'">Nästa →</a>';echo '</nav><p class="description">Sidindelning sker per datakälla (central shop och anslutna shoppar), så en sida kan innehålla fler än valt antal produkter. Kategori filtrerar endast central shop eftersom externa kategorier inte är kopplade. För Pre-order-produkter betyder saldot antal som fortfarande kan förbeställas, inte fysiskt lagersaldo. För övriga produkter hämtas lagersaldo från WooCommerce. Lagerplatser visas från WMS. Utskrift avser produkterna på denna sida.</p></div>';
 }
}
Dennis_WMS_Product_View::boot();
