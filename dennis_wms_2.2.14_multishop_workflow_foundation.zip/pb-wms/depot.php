<?php
if (!defined('ABSPATH')) exit;
/** Depot state is order metadata (HPOS compatible), independent of WooCommerce stock/status. */
final class Dennis_WMS_Depot {
 const CAP='pb_wms_view';
 static function state($order){return (string)$order->get_meta('_dennis_wms_depot_state',true);}
 static function events($order){$v=$order->get_meta('_dennis_wms_depot_events',true);return is_array($v)?$v:[];}
 static function menu(){add_submenu_page('pb-wms','Orders in Depot','Orders in Depot',self::CAP,'dennis-wms-depot',[__CLASS__,'page']);}
 static function url($id=0){return add_query_arg(['page'=>'dennis-wms-depot']+($id?['order_id'=>$id]:[]),admin_url('admin.php'));}
 static function log($order,$action,$detail=[]){$events=self::events($order);$events[]=['action'=>$action,'time'=>current_time('mysql'),'timestamp'=>time(),'user'=>get_current_user_id(),'detail'=>$detail];$order->update_meta_data('_dennis_wms_depot_events',$events);}
 static function pause_phase($order,$phase,$now){$prefix='_dennis_wms_'.$phase.'_';if(Dennis_WMS_Orders::phase_status($order,$phase)!=='active')return false;$since=(int)$order->get_meta($prefix.'since',true);$order->update_meta_data($prefix.'active_seconds',max(0,(int)$order->get_meta($prefix.'active_seconds',true))+max(0,$now-$since));$order->update_meta_data($prefix.'since',$now);$order->update_meta_data($prefix.'status','paused');return true;}
 static function submit(){
  if(!current_user_can(self::CAP)||!current_user_can('edit_shop_orders'))wp_die('Åtkomst nekad.',403);
  $id=isset($_POST['order_id'])?absint(wp_unslash($_POST['order_id'])):0;check_admin_referer('dennis_wms_depot_'.$id);
  $order=Dennis_WMS_Orders::order($id);$action=isset($_POST['depot_action'])?sanitize_key(wp_unslash($_POST['depot_action'])):'';$state=self::state($order);$now=time();
  if($action==='place'){
   if($state==='waiting')wp_die('Ordern står redan i depån. Ladda om.',409);
   if($state==='ready')wp_die('Ordern är redan markerad som redo.',409);
   $place=isset($_POST['place'])?sanitize_text_field(wp_unslash($_POST['place'])):'';
   $reason=isset($_POST['reason'])?sanitize_text_field(wp_unslash($_POST['reason'])):'';
   $note=isset($_POST['note'])?sanitize_textarea_field(wp_unslash($_POST['note'])):'';
   if(!$place||mb_strlen($place)>80||!$reason||mb_strlen($reason)>120||mb_strlen($note)>1000)wp_die('Ange depåplats och orsak inom tillåtna längder.',400);
   $missing=[];$valid=[];foreach($order->get_items('line_item') as $item)$valid[(int)$item->get_id()]=max(0,(int)$item->get_quantity());
   $raw=isset($_POST['missing'])&&is_array($_POST['missing'])?wp_unslash($_POST['missing']):[];
   foreach($raw as $key=>$qty){$item_id=absint($key);if(!isset($valid[$item_id])||!is_scalar($qty)||!preg_match('/^(0|[1-9][0-9]*)$/',(string)$qty)||(int)$qty>$valid[$item_id])wp_die('Ogiltigt antal saknade enheter.',400);if((int)$qty>0)$missing[$item_id]=(int)$qty;}
   if(!$missing)wp_die('Ange minst en saknad artikel.',400);
   self::pause_phase($order,'pick',$now);self::pause_phase($order,'pack',$now);
   $order->update_meta_data('_dennis_wms_depot_state','waiting');$order->update_meta_data('_dennis_wms_depot_place',$place);$order->update_meta_data('_dennis_wms_depot_reason',$reason);$order->update_meta_data('_dennis_wms_depot_note',$note);$order->update_meta_data('_dennis_wms_depot_missing',$missing);$order->update_meta_data('_dennis_wms_depot_since',$now);
   self::log($order,'placed',['place'=>$place,'reason'=>$reason,'missing'=>$missing,'note'=>$note]);
  }elseif($action==='release'){
   if($state!=='waiting')wp_die('Ordern står inte i depån.',409);
   $since=(int)$order->get_meta('_dennis_wms_depot_since',true);$order->update_meta_data('_dennis_wms_depot_total_seconds',max(0,(int)$order->get_meta('_dennis_wms_depot_total_seconds',true))+max(0,$now-$since));$order->update_meta_data('_dennis_wms_depot_since',0);$order->update_meta_data('_dennis_wms_depot_state','released');self::log($order,'released');
  }elseif($action==='ready'){
   if($state!=='released')wp_die('Ta först ut ordern ur depån.',409);
   if(Dennis_WMS_Orders::phase_status($order,'pick')!=='done'||Dennis_WMS_Orders::phase_status($order,'pack')!=='done')wp_die('Plockning och packning måste vara avslutade.',409);
   $order->update_meta_data('_dennis_wms_depot_state','ready');$order->update_meta_data('_dennis_wms_depot_missing',[]);self::log($order,'ready');
  }else wp_die('Ogiltig åtgärd.',400);
  $order->save();wp_safe_redirect(self::url($id));exit;
 }
 static function form($order,$action,$label){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_depot_'.$order->get_id());echo '<input type="hidden" name="action" value="dennis_wms_depot"><input type="hidden" name="order_id" value="'.esc_attr($order->get_id()).'"><input type="hidden" name="depot_action" value="'.esc_attr($action).'">';if($action==='place'){
  echo '<p><label>Depåplats <input required maxlength="80" name="place" value="'.esc_attr((string)$order->get_meta('_dennis_wms_depot_place',true)).'"></label></p><p><label>Orsak <select required name="reason"><option value="">Välj orsak</option>';foreach(['Inväntar inleverans','Material saknas på lager','Inväntar komplettering','Annat'] as $r)echo '<option>'.esc_html($r).'</option>';echo '</select></label></p><p><label>Kommentar<br><textarea name="note" maxlength="1000" rows="2" cols="55"></textarea></label></p><h4>Antal som saknas per orderrad</h4>';
  foreach($order->get_items('line_item') as $item)echo '<p><label>'.esc_html($item->get_name()).' (beställt '.esc_html((string)$item->get_quantity()).') <input type="number" min="0" max="'.esc_attr((string)max(0,(int)$item->get_quantity())).'" name="missing['.esc_attr($item->get_id()).']" value="0"></label></p>';
 }echo '<p><button class="button button-primary" type="submit">'.esc_html($label).'</button></p></form>';}
 static function detail($order){$state=self::state($order);$labels=['waiting'=>'Väntar i depå','released'=>'Uttagen ur depå','ready'=>'Redo för leverans'];echo '<h2>Depå – '.esc_html($labels[$state]??'Inte placerad').'</h2>';
  if($state==='waiting'){echo '<p>Depåplats: <strong>'.esc_html((string)$order->get_meta('_dennis_wms_depot_place',true)).'</strong> · Orsak: '.esc_html((string)$order->get_meta('_dennis_wms_depot_reason',true)).'</p><p>Kommentar: '.esc_html((string)$order->get_meta('_dennis_wms_depot_note',true)).'</p><p>Väntetid hittills: '.esc_html(Dennis_WMS_Orders::duration(max(0,time()-(int)$order->get_meta('_dennis_wms_depot_since',true)))).'</p>';
   $missing=$order->get_meta('_dennis_wms_depot_missing',true);if(is_array($missing)){echo '<h4>Saknat material</h4><ul>';foreach($missing as $item_id=>$qty){$item=$order->get_item((int)$item_id);if($item)echo '<li>'.esc_html($item->get_name()).': '.esc_html((string)$qty).' st</li>';}echo '</ul>';}
   self::form($order,'release','Materialet har kommit – ta ut ur depå');
  }elseif($state==='released'){echo '<p>Fortsätt plockning och packning under Orders in Progress. Kontrollera att allt material är med innan ordern markeras som redo.</p>';self::form($order,'place','Ställ tillbaka i depå');if(Dennis_WMS_Orders::phase_status($order,'pick')==='done'&&Dennis_WMS_Orders::phase_status($order,'pack')==='done')self::form($order,'ready','Markera redo för leverans');}
  elseif($state!=='ready')self::form($order,'place','Flytta till depå');
  echo '<h3>Depåhistorik</h3><table class="widefat striped"><thead><tr><th>Tid</th><th>Händelse</th><th>Användare</th><th>Detaljer</th></tr></thead><tbody>';foreach(array_reverse(self::events($order)) as $event){$user=get_userdata((int)$event['user']);$detail=$event['detail']??[];echo '<tr><td>'.esc_html($event['time']).'</td><td>'.esc_html($event['action']).'</td><td>'.esc_html($user?$user->display_name:'Okänd').'</td><td>'.esc_html(isset($detail['reason'])?$detail['reason'].' · '.($detail['place']??''):'–').'</td></tr>';}echo '</tbody></table>';
 }
 static function page(){if(!current_user_can(self::CAP))wp_die('Åtkomst nekad.',403);echo '<div class="wrap"><h1>Dennis WMS – Orders in Depot</h1><p>Depåstatus hanteras separat från WooCommerce. Ingen lagerjustering görs här.</p>';$id=isset($_GET['order_id'])?absint($_GET['order_id']):0;if($id){$order=Dennis_WMS_Orders::order($id);echo '<p><a href="'.esc_url(self::url()).'">Tillbaka</a> · <a href="'.esc_url(Dennis_WMS_Orders::url($id)).'">Öppna Pick & Pack</a></p><h2>Order #'.esc_html($order->get_order_number()).'</h2>';self::detail($order);}else{$orders=wc_get_orders(['limit'=>100,'meta_key'=>'_dennis_wms_depot_state','meta_value'=>'waiting','orderby'=>'date','order'=>'DESC']);echo '<table class="widefat striped"><thead><tr><th>Order</th><th>Depåplats</th><th>Orsak</th><th>Väntar sedan</th><th></th></tr></thead><tbody>';foreach($orders as $order)echo '<tr><td>#'.esc_html($order->get_order_number()).'</td><td>'.esc_html((string)$order->get_meta('_dennis_wms_depot_place',true)).'</td><td>'.esc_html((string)$order->get_meta('_dennis_wms_depot_reason',true)).'</td><td>'.esc_html((string)wp_date('Y-m-d H:i',(int)$order->get_meta('_dennis_wms_depot_since',true))).'</td><td><a href="'.esc_url(self::url($order->get_id())).'">Öppna</a></td></tr>';if(!$orders)echo '<tr><td colspan="5">Inga order i depån.</td></tr>';echo '</tbody></table><p>Visar högst 100 order.</p>';}echo '</div>';}
}
add_action('admin_menu',['Dennis_WMS_Depot','menu'],102);
add_action('admin_post_dennis_wms_depot',['Dennis_WMS_Depot','submit']);
