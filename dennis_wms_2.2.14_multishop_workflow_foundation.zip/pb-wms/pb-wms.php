<?php
/**
 * Plugin Name: Dennis WMS
 * Description: WooCommerce inventory counting with automatic stock updates, product and stock analytics, locations and batch notes. ATUM advanced stock features are not supported.
 * Version: 2.2.14-multishop-workflow-foundation
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * Text Domain: pb-wms
 */
if (!defined('ABSPATH')) { exit; }
define('PB_WMS_VERSION','2.2.14-multishop-workflow-foundation');
final class PB_WMS_V03 {
 const VIEW = 'pb_wms_view';
 const COUNT = 'pb_wms_count';
 const MANAGE = 'pb_wms_manage';
 static function boot() {
  add_action('admin_menu', [__CLASS__, 'menu']);
  add_action('admin_enqueue_scripts', [__CLASS__, 'modern_assets']);
  add_filter('admin_body_class', [__CLASS__, 'modern_body_class']);
  add_action('in_admin_header', [__CLASS__, 'app_header']);
  add_action('admin_menu', ['Dennis_WMS_Orders', 'menu'], 99);
  add_action('admin_menu', ['Dennis_WMS_Analytics', 'menu'], 100);
  add_action('admin_post_dennis_wms_pick', ['Dennis_WMS_Orders', 'save_pick']);
  add_action('admin_post_dennis_wms_reopen', ['Dennis_WMS_Orders', 'reopen']);
  add_action('admin_post_dennis_wms_pick_print', ['Dennis_WMS_Orders', 'print_pick']);
  add_action('admin_post_dennis_wms_group_print', ['Dennis_WMS_Orders', 'print_group']);
  add_action('admin_post_pb_wms_location', [__CLASS__, 'save_location']);
  add_action('admin_post_pb_wms_count', [__CLASS__, 'save_count']);
  add_action('admin_post_pb_wms_print', [__CLASS__, 'print_list']);
  add_action('admin_post_pb_wms_batch', [__CLASS__, 'save_batch']);
  add_action('admin_post_dennis_wms_revision', ['Dennis_WMS_Revisions', 'save']);
  add_action('admin_notices', [__CLASS__, 'notice']);
  add_action('admin_init', [__CLASS__, 'maybe_upgrade']);
 }
 static function is_wms_screen() {
  if (!is_admin() || !current_user_can(self::VIEW)) return false;
  $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
  return $page === 'pb-wms' || strpos($page, 'dennis-wms-') === 0;
 }
 static function modern_assets() {
  if (!self::is_wms_screen()) return;
  wp_enqueue_script('dennis-wms-print', plugins_url('print.js', __FILE__), [], PB_WMS_VERSION, true);

  wp_enqueue_script('dennis-wms-mobile', plugins_url('mobile.js', __FILE__), [], PB_WMS_VERSION, true);
  wp_enqueue_style('dennis-wms-mobile-app', plugins_url('mobile-app.css', __FILE__), ['dennis-wms-modern'], PB_WMS_VERSION);
  wp_enqueue_script('dennis-wms-mobile-app', plugins_url('mobile-app.js', __FILE__), [], PB_WMS_VERSION, true);
  wp_enqueue_style('dennis-wms-modern', plugins_url('modern-admin.css', __FILE__), [], PB_WMS_VERSION);
  wp_enqueue_script('dennis-wms-preorder-alert', plugins_url('preorder-alert.js', __FILE__), [], PB_WMS_VERSION, true);
  if(class_exists('Dennis_WMS_Preorders'))Dennis_WMS_Preorders::alert_assets();
  $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
  if ($page === 'dennis-wms-orders' && !empty($_GET['order_id'])) {
   wp_enqueue_media();
   wp_enqueue_script('dennis-wms-order-images', plugins_url('order-images.js', __FILE__), ['jquery'], '1.5.1', true);
  }
 }
 static function modern_body_class($classes) {
  return self::is_wms_screen() ? $classes . ' dennis-wms-modern' : $classes;
 }
 static function app_header() {
  if (!self::is_wms_screen()) return;
  wp_enqueue_script('dennis-wms-print', plugins_url('print.js', __FILE__), [], PB_WMS_VERSION, true);

  $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
  $nav = [
   ['dennis-wms-dashboard','dashicons-dashboard','Översikt'],
   ['dennis-wms-orders','dashicons-cart','Ordrar'],
   ['dennis-wms-preorders','dashicons-clock','Pre-orders'],
   ['dennis-wms-products','dashicons-products','Produkter'],
   ['dennis-wms-kits','dashicons-screenoptions','För-packade produkter'],
   ['dennis-wms-accompanying','dashicons-networking','Kit'],
   ['dennis-wms-tracking','dashicons-location-alt','Tracking'],
   ['dennis-wms-receiving','dashicons-download','Inleverans'],
   ['pb-wms','dashicons-clipboard','Inventering'],
   ['dennis-wms-batches','dashicons-database','Batcher & lagerplatser'],
   ['dennis-wms-date-warnings','dashicons-warning','Datumvarningar'],
   ['dennis-wms-shop-stats','dashicons-chart-bar','Statistik'],
  ];
  echo '<div class="dw-appbar">';
  echo '<div class="dw-brand"><div class="dw-brand-title"><span>DENNIS</span> <b>WMS</b></div><small>Warehouse Management System</small></div>';
  echo '<form class="dw-global-search" method="get" action="'.esc_url(admin_url('edit.php')).'"><span class="dashicons dashicons-search"></span><input type="hidden" name="post_type" value="product"><input type="search" name="s" placeholder="Sök produkt, SKU…" aria-label="Sök produkter"><button type="submit">Sök</button></form>';
  echo '<div class="dw-app-user"><span class="dashicons dashicons-admin-users"></span><strong>'.esc_html(wp_get_current_user()->display_name).'</strong></div>';
  echo '</div><nav class="dw-appnav" aria-label="Dennis WMS">';
  $date_urgency=class_exists('Dennis_WMS_Warnings')?Dennis_WMS_Warnings::urgency():'';
  foreach ($nav as $item) {
   [$slug,$icon,$label]=$item;
   $active = ($page===$slug) || ($slug==='pb-wms' && $page==='');
   $due=$slug==='dennis-wms-date-warnings'&&$date_urgency!=='';$due_label=$date_urgency==='overdue'?'Passerat':'Idag';$due_title=$date_urgency==='overdue'?'Utgångsdatum eller Last order date har passerat':'Utgångsdatum eller Last order date infaller idag';
   echo '<a class="'.($active?'active ':'').($due?'dw-date-due-today':'').'" '.($due?'title="'.esc_attr($due_title).'"':'').' href="'.esc_url(admin_url('admin.php?page='.$slug)).'"><span class="dashicons '.esc_attr($icon).'"></span>'.esc_html($label).($due?'<span class="dw-date-today-badge">'.esc_html($due_label).'</span><span class="screen-reader-text">'.esc_html($due_title).'.</span>':'').'</a>';
  }
  echo '</nav><div class="dw-print-toolbar" style="padding:10px 20px"><button type="button" class="button" onclick="window.print()">🖨 Skriv ut hela denna vy / spara PDF</button> <a class="button" href="'.esc_url(admin_url('admin.php?page=dennis-wms-report-builder')).'">Skapa fullständig statistikrapport</a></div>';
  if(class_exists('Dennis_WMS_Warnings'))Dennis_WMS_Warnings::render_global();
  if (in_array($page,['dennis-wms-customer-stats','dennis-wms-shop-stats','dennis-wms-analytics','dennis-wms-flow-stats','dennis-wms-receiving-stats','dennis-wms-sku-stats','dennis-wms-report-builder'],true)) {
   $stats_nav=[
    ['dennis-wms-shop-stats','◉','Per shop'],
    ['dennis-wms-customer-stats','♙','Per säljare'],
    ['dennis-wms-flow-stats','↕','Lagerflöde IN / UT'],
    ['dennis-wms-receiving-stats','↓','Inleveranser'],
    ['dennis-wms-analytics','▥','Produkter / lager'],
    ['dennis-wms-sku-stats','⌕','SKU-analys'],
    ['dennis-wms-report-builder','▣','Rapporter / utskrift'],
   ];
   echo '<div class="dw-stats-shell"><div class="dw-stats-tabs">';
   foreach($stats_nav as $sn){[$slug,$icon,$label]=$sn;echo '<a class="'.($page===$slug?'active':'').'" href="'.esc_url(admin_url('admin.php?page='.$slug)).'"><span>'.esc_html($icon).'</span>'.esc_html($label).'</a>';}
   echo '<div class="dw-stats-actions"><a class="button dw-report-button" href="'.esc_url(admin_url('admin.php?page=dennis-wms-report-builder')).'">🖨 Välj statistik / skriv ut</a><button type="button" class="button dw-print-current" onclick="window.print()">Skriv ut denna vy</button></div></div></div>';
  }
  // v1.7.4: grouped, collapsible native WordPress sidebar navigation.
  // Batch balances are managed only under Lager > Batcher & utgångsdatum.
  echo '<script>(function(){function ready(fn){if(document.readyState!=="loading")fn();else document.addEventListener("DOMContentLoaded",fn)}ready(function(){var root=document.querySelector("#toplevel_page_pb-wms .wp-submenu");if(!root||root.dataset.dwGrouped)return;root.dataset.dwGrouped="1";var map={"dennis-wms-dashboard":["START","🏠 Översikt"],"dennis-wms-orders":["ORDERHANTERING","📦 Pågående order / Plock & Pack"],"dennis-wms-preorders":["ORDERHANTERING","🕒 Pre-orders"],"dennis-wms-calendar":["ORDERHANTERING","📅 Kalender"],"dennis-wms-depot":["ORDERHANTERING","🏷️ Depå"],"dennis-wms-tracking":["ORDERHANTERING","🚚 Transport & Tracking"],"dennis-wms-receiving":["INLEVERANS","🚚 Inleveranser"],"pb-wms":["LAGER","📋 Inventering"],"dennis-wms-products":["LAGER","▤ Produktvy"],"dennis-wms-kits":["LAGER","▦ För-packade produkter"],"dennis-wms-accompanying":["LAGER","▦ Kit"],"dennis-wms-date-warnings":["LAGER","⚠️ Datumvarningar"],"dennis-wms-batches":["LAGER","🧪 Batcher & lagerplatser"],"dennis-wms-product-rules":["LAGER","⚠️ Produktkontroll"],"dennis-wms-packaging-materials":["LAGER","📦 Packmaterial"],"dennis-wms-customer-stats":["STATISTIK","♙ Statistik per säljare"],"dennis-wms-shop-stats":["STATISTIK","◉ Statistik per shop"],"dennis-wms-analytics":["STATISTIK","📊 Produktstatistik"],"dennis-wms-flow-stats":["STATISTIK","↕️ Lagerflöde IN / UT"],"dennis-wms-receiving-stats":["STATISTIK","📥 Inleveransstatistik"],"dennis-wms-sku-stats":["STATISTIK","🔎 SKU-analys"],"dennis-wms-report-builder":["STATISTIK","🖨️ Rapporter / utskrift"],"dennis-wms-activity-log":["SYSTEM","📜 Händelselogg"],"dennis-wms-order-debug":["SYSTEM","🛠️ Orderfelsökning"],"dennis-wms-shops":["SYSTEM","🔗 Anslutna shoppar"],"dennis-wms-delivery":["SYSTEM","🚚 Leverans & transport"]};var order=["START","ORDERHANTERING","INLEVERANS","LAGER","STATISTIK","SYSTEM"],icons={START:"⌂",ORDERHANTERING:"▣",INLEVERANS:"↓",LAGER:"▤",STATISTIK:"▥",SYSTEM:"⚙"},links=[].slice.call(root.querySelectorAll("a[href*=\"page=\"]")),buckets={};order.forEach(function(g){buckets[g]=[]});links.forEach(function(a){try{var slug=new URL(a.href,location.href).searchParams.get("page");if(!map[slug])return;a.textContent=map[slug][1];var li=a.parentElement;li.classList.add("dw-menu-item");li.dataset.dwGroup=map[slug][0];if(a.classList.contains("current")||li.classList.contains("current")){li.dataset.dwActive="1"}buckets[map[slug][0]].push(li)}catch(e){}});var warehouse=buckets.LAGER,kitIndex=warehouse.findIndex(function(li){return li.querySelector("a[href*=dennis-wms-accompanying]")}),packingIndex=warehouse.findIndex(function(li){return li.querySelector("a[href*=dennis-wms-kits]")});if(kitIndex>=0&&packingIndex>=0){var kitItem=warehouse.splice(kitIndex,1)[0];packingIndex=warehouse.findIndex(function(li){return li.querySelector("a[href*=dennis-wms-kits]")});warehouse.splice(packingIndex+1,0,kitItem);}order.forEach(function(group){if(!buckets[group].length)return;var h=document.createElement("li");h.className="dw-menu-group";h.dataset.dwGroupHeader=group;var b=document.createElement("button");b.type="button";b.className="dw-menu-group-toggle";b.innerHTML="<span class=\"dw-menu-group-icon\">"+icons[group]+"</span><span>"+group+"</span><span class=\"dw-menu-chevron\">⌄</span>";h.appendChild(b);root.appendChild(h);buckets[group].forEach(function(li){root.appendChild(li)});var hasActive=buckets[group].some(function(li){return li.dataset.dwActive==="1"});var stored=null;try{stored=localStorage.getItem("dennisWmsMenu:"+group)}catch(e){}var open=hasActive||stored===null||stored==="1";function apply(){h.classList.toggle("is-open",open);buckets[group].forEach(function(li){li.classList.toggle("dw-menu-hidden",!open)});b.setAttribute("aria-expanded",open?"true":"false")}b.addEventListener("click",function(){open=!open;try{localStorage.setItem("dennisWmsMenu:"+group,open?"1":"0")}catch(e){}apply()});apply()})})})();</script>';

 }
 static function activate() {
  foreach (['administrator' => [self::VIEW,self::COUNT,self::MANAGE], 'shop_manager' => [self::VIEW,self::COUNT,self::MANAGE]] as $role => $caps) {
   $r=get_role($role); if ($r) { foreach($caps as $cap) $r->add_cap($cap); }
  }
  self::table();
  Dennis_WMS_Revisions::table();
  update_option('pb_wms_schema_version','0.7.2');
 }
 static function maybe_upgrade() {
  if (get_option('pb_wms_schema_version') !== '0.7.2' && current_user_can('manage_options')) self::activate();
 }
 static function table() {
  global $wpdb;
  $table=$wpdb->prefix.'pb_wms_counts';
  $collate=$wpdb->get_charset_collate();
  require_once ABSPATH.'wp-admin/includes/upgrade.php';
  dbDelta("CREATE TABLE $table (
   id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
   product_id bigint(20) unsigned NOT NULL,
   counted_qty bigint(20) unsigned NOT NULL,
   reference_qty bigint(20) NULL,
   location varchar(80) NOT NULL DEFAULT '',
   user_id bigint(20) unsigned NOT NULL,
   counted_at datetime NOT NULL,
   applied_qty bigint(20) NULL,
   update_status varchar(30) NOT NULL DEFAULT 'legacy',
   PRIMARY KEY  (id),
   KEY product_id (product_id),
   KEY counted_at (counted_at)
  ) $collate;");
 }
 static function notice() {
  if (!current_user_can(self::VIEW) || !isset($_GET['page']) || sanitize_key(wp_unslash($_GET['page'])) !== 'pb-wms') return;
  if (!function_exists('wc_get_products')) echo '<div class="notice notice-error"><p>WooCommerce måste vara aktivt för att Dennis WMS ska fungera.</p></div>';
 }
 static function menu() { add_menu_page('Dennis WMS','Dennis WMS',self::VIEW,'pb-wms',[__CLASS__,'page'],'dashicons-archive',56); }
 static function allowed_product($id) {
  if (!function_exists('wc_get_product')) return false;
  $p=wc_get_product($id);
  if (!$p || !in_array($p->get_type(), ['simple','variation'], true)) return false;
  return $p;
 }
 static function request_product($cap,$nonce) {
  if (!current_user_can($cap)) wp_die('Åtkomst nekad',403);
  $id=isset($_POST['product_id']) ? absint(wp_unslash($_POST['product_id'])) : 0;
  check_admin_referer($nonce.'_'.$id);
  $p=self::allowed_product($id);
  if (!$p) wp_die('Produkten finns inte eller stöds inte.',400);
  return $p;
 }
 static function redirect($status) {
  wp_safe_redirect(add_query_arg(['page'=>'pb-wms','pb_status'=>$status],admin_url('admin.php'))); exit;
 }
 static function save_location() {
  $p=self::request_product(self::MANAGE,'pb_wms_location');
  $raw=isset($_POST['location']) ? wp_unslash($_POST['location']) : '';
  if (!is_string($raw)) wp_die('Ogiltig lagerplats',400);
  $location=sanitize_text_field($raw);
  if (mb_strlen($location)>80) wp_die('Lagerplatsen får vara högst 80 tecken',400);
  $p->update_meta_data('_pb_wms_location',$location); $p->save(); self::redirect('location');
 }
 static function save_count() {
  $p=self::request_product(self::COUNT,'pb_wms_count');
  if (!current_user_can('manage_woocommerce') || !current_user_can('edit_product',$p->get_id())) wp_die('Behörighet att ändra produktlager saknas.',403);
  if(Dennis_WMS_Inventory_Slots::rows($p->get_id())['rows'])wp_die('Inventera per lagerplats och batch så att alla delsaldo uppdateras tillsammans.',409);
  $raw=isset($_POST['count']) ? wp_unslash($_POST['count']) : '';
  if (!is_string($raw) || !preg_match('/^(0|[1-9][0-9]{0,8})$/',$raw)) wp_die('Ange ett heltal från 0 till 999999999.',400);
  if (!$p->managing_stock() || $p->get_stock_quantity()===null) wp_die('Aktivera lagerhantering för denna produkt i WooCommerce först.',400);
  if (get_post_meta($p->get_id(),'_atum_multi_inventory',true) || get_post_meta($p->get_id(),'_multi_inventory',true)) wp_die('Produkten kan använda ATUM Multi-Inventory. Automatisk uppdatering är spärrad för denna produkt.',400);
  $reason=sanitize_textarea_field(wp_unslash($_POST['reason']??''));if(strlen(trim($reason))<3||strlen($reason)>500)wp_die('Ange en orsak på 3–500 tecken.',400);
  $qty=(int)$raw;
  $reference=(int)$p->get_stock_quantity();
  // Optimistic check: the displayed balance must still match the current balance.
  $expected=isset($_POST['expected_stock']) ? wp_unslash($_POST['expected_stock']) : '';
  if (!is_string($expected) || !preg_match('/^-?[0-9]+$/',$expected) || (int)$expected!==$reference) wp_die('Saldot har ändrats sedan sidan öppnades. Ladda om och inventera på nytt.',409);
  global $wpdb;
  $table=$wpdb->prefix.'pb_wms_counts';
  // Do not mutate WooCommerce if the audit entry cannot be saved.
  $ok=Dennis_WMS_Audit::insert($table,[
   'product_id'=>$p->get_id(),'counted_qty'=>$qty,'reference_qty'=>$reference,
   'location'=>(string)$p->get_meta('_pb_wms_location',true),'user_id'=>get_current_user_id(),
   'counted_at'=>current_time('mysql'),'update_status'=>'pending'
  ],['%d','%d','%d','%s','%d','%s','%s']);
  if (!$ok) wp_die('Inventeringen kunde inte sparas. Inget saldo har ändrats.',500);
  $event_id=(int)$wpdb->insert_id;
  $snapshot=[['id'=>0,'location'=>(string)$p->get_meta('_pb_wms_location',true),'batch'=>(string)$p->get_meta('_pb_wms_batch',true),'expiry'=>(string)$p->get_meta('_pb_wms_expiry',true),'last_order_date'=>Dennis_WMS_Warnings::product_last_order_date($p),'quantity'=>$reference,'counted'=>$qty,'difference'=>$qty-$reference]];
  if(!Dennis_WMS_Audit::insert(Dennis_WMS_Inventory_Slots::table(),['count_id'=>$event_id,'reason'=>$reason,'snapshot'=>wp_json_encode($snapshot)])){Dennis_WMS_Audit::update($table,['update_status'=>'failed'],['id'=>$event_id]);wp_die('Inventeringsorsaken kunde inte sparas. Inget saldo har ändrats.',500);}
  try {
   $result=wc_update_product_stock($p,$qty,'set');
   if ($result===false) throw new Exception('WooCommerce kunde inte uppdatera saldot.');
   $fresh=wc_get_product($p->get_id());
   $actual=$fresh ? $fresh->get_stock_quantity() : null;
   if ($actual===null || (int)$actual!==$qty) throw new Exception('Saldot kunde inte verifieras. Kontrollera WooCommerce innan nytt försök.');
   Dennis_WMS_Audit::update($table,['applied_qty'=>(int)$actual,'update_status'=>'applied_details'],['id'=>$event_id],['%d','%s'],['%d']);
  } catch (Throwable $e) {
   Dennis_WMS_Audit::update($table,['update_status'=>'failed'],['id'=>$event_id],['%s'],['%d']);
   wp_die(esc_html($e->getMessage()).' Kontrollera lagerhistoriken och produkten innan du försöker igen.',500);
  }
  self::redirect('count');
 }
 static function save_batch() {
  $p=self::request_product(self::MANAGE,'pb_wms_batch');
  $batch=isset($_POST['batch']) ? sanitize_text_field(wp_unslash($_POST['batch'])) : '';
  $expiry=isset($_POST['expiry']) ? sanitize_text_field(wp_unslash($_POST['expiry'])) : '';
  if (strlen($batch)>80 || ($expiry!=='' && (!preg_match('/^\d{4}-\d{2}-\d{2}$/',$expiry) || !strtotime($expiry)))) wp_die('Ogiltigt batchnummer eller datum.',400);
  $p->update_meta_data('_pb_wms_batch',$batch);
  $p->update_meta_data('_pb_wms_expiry',$expiry);
  $p->save(); self::redirect('batch');
 }
 static function product_categories($p) {
  $id=$p->get_id();
  if ($p->is_type('variation') && $p->get_parent_id()) $id=$p->get_parent_id();
  $terms=wp_get_post_terms($id,'product_cat',['fields'=>'all']);
  if (is_wp_error($terms)) return [];
  return $terms;
 }
 static function request_values($key) {
  if (!isset($_GET[$key])) return [];
  $raw=wp_unslash($_GET[$key]);
  if (!is_array($raw)) $raw=[$raw];
  $out=[];
  foreach($raw as $v) if(is_scalar($v)) {$v=sanitize_text_field((string)$v); if($v!=='')$out[]=$v;}
  return array_values(array_unique($out));
 }
 static function product_terms_for_print($p,$taxonomy) {
  $id=$p->get_id();
  if($p->is_type('variation') && $p->get_parent_id()) $id=$p->get_parent_id();
  $terms=wp_get_post_terms($id,$taxonomy,['fields'=>'all']);
  return is_wp_error($terms)?[]:$terms;
 }
 static function product_attribute_for_print($p,$taxonomy) {
  $value=$p->get_attribute($taxonomy);
  if($value==='' && $p->is_type('variation') && $p->get_parent_id()) {
   $parent=wc_get_product($p->get_parent_id()); if($parent)$value=$parent->get_attribute($taxonomy);
  }
  return trim((string)$value);
 }
 static function print_list() {
  if (!current_user_can(self::VIEW)) wp_die('Åtkomst nekad',403);
  check_admin_referer('pb_wms_print');
  if (!function_exists('wc_get_products')) wp_die('WooCommerce måste vara aktivt.',400);

  $categories=array_map('sanitize_title',self::request_values('pb_print_categories'));
  $tags=array_map('sanitize_title',self::request_values('pb_print_tags'));
  $location=isset($_GET['pb_print_location'])?sanitize_text_field(wp_unslash($_GET['pb_print_location'])):'';
  $location_mode=isset($_GET['pb_print_location_mode'])?sanitize_key(wp_unslash($_GET['pb_print_location_mode'])):'contains';
  $stock_filter=isset($_GET['pb_print_stock'])?sanitize_key(wp_unslash($_GET['pb_print_stock'])):'all';
  $managed=isset($_GET['pb_print_managed'])?sanitize_key(wp_unslash($_GET['pb_print_managed'])):'all';
  $product_type=isset($_GET['pb_print_type'])?sanitize_key(wp_unslash($_GET['pb_print_type'])):'all';
  $search=isset($_GET['pb_print_search'])?sanitize_text_field(wp_unslash($_GET['pb_print_search'])):'';
  $sku_search=isset($_GET['pb_print_sku'])?sanitize_text_field(wp_unslash($_GET['pb_print_sku'])):'';
  $qty_min=(isset($_GET['pb_print_qty_min'])&&$_GET['pb_print_qty_min']!=='')?(int)$_GET['pb_print_qty_min']:null;
  $qty_max=(isset($_GET['pb_print_qty_max'])&&$_GET['pb_print_qty_max']!=='')?(int)$_GET['pb_print_qty_max']:null;
  $batch_filter=isset($_GET['pb_print_batch'])?sanitize_key(wp_unslash($_GET['pb_print_batch'])):'all';
  $expiry_filter=isset($_GET['pb_print_expiry'])?sanitize_key(wp_unslash($_GET['pb_print_expiry'])):'all';
  $attr_tax=isset($_GET['pb_print_attribute'])?sanitize_key(wp_unslash($_GET['pb_print_attribute'])):'';
  $attr_value=isset($_GET['pb_print_attribute_value'])?sanitize_text_field(wp_unslash($_GET['pb_print_attribute_value'])):'';
  $sort1=isset($_GET['pb_print_sort'])?sanitize_key(wp_unslash($_GET['pb_print_sort'])):'name';
  $sort2=isset($_GET['pb_print_sort2'])?sanitize_key(wp_unslash($_GET['pb_print_sort2'])):'none';
  $dir1=(isset($_GET['pb_print_dir'])&&strtoupper((string)$_GET['pb_print_dir'])==='DESC')?'DESC':'ASC';
  $dir2=(isset($_GET['pb_print_dir2'])&&strtoupper((string)$_GET['pb_print_dir2'])==='DESC')?'DESC':'ASC';
  $group=isset($_GET['pb_print_group'])?sanitize_key(wp_unslash($_GET['pb_print_group'])):'none';
  $shop_filter=isset($_GET['pb_print_shop'])?sanitize_text_field(wp_unslash($_GET['pb_print_shop'])):'local';
   $columns=array_map('sanitize_key',self::request_values('pb_print_columns'));
  if(!$columns)$columns=['name','sku','location','stock','batch','expiry','last_order_date'];
  $allowed_cols=['name','sku','category','location','stock','batch','expiry','last_order_date','type','status','id'];
  $columns=array_values(array_intersect($columns,$allowed_cols));
  // Systemsaldo must always be present on a physical stock-count worksheet.
  if(!in_array('stock',$columns,true))$columns[]='stock';
  $allowed_stock=['all','in_stock','out','low','backorder','no_location']; if(!in_array($stock_filter,$allowed_stock,true))$stock_filter='all';
  if(!in_array($managed,['all','yes','no'],true))$managed='all';
  if(!in_array($product_type,['all','simple','variation'],true))$product_type='all';
  if(!in_array($location_mode,['contains','exact','starts','missing'],true))$location_mode='contains';
  if(!in_array($batch_filter,['all','has','missing'],true))$batch_filter='all';
  if(!in_array($expiry_filter,['all','has','missing','expired','30','60','90'],true))$expiry_filter='all';
  $sort_keys=['name','sku','category','location','stock','batch','expiry','last_order_date','type','status','id'];
  if(!in_array($sort1,$sort_keys,true))$sort1='name'; if(!in_array($sort2,array_merge(['none'],$sort_keys),true))$sort2='none';
  if(!in_array($group,['none','category','location','type','status'],true))$group='none';
  if($attr_tax!=='' && strpos($attr_tax,'pa_')!==0)$attr_tax='';

  $rows=[];$page=1;$today=strtotime(current_time('Y-m-d'));$shop_name='Huvudshop';
   if(strpos($shop_filter,'remote:')===0 && class_exists('Dennis_WMS_Multi_Shop')){
    global $wpdb;$sid=absint(substr($shop_filter,7));$shop=Dennis_WMS_Multi_Shop::get_shop($sid);if(!$shop)wp_die('Vald shop finns inte.',404);$shop_name=$shop->name;$pt=Dennis_WMS_Multi_Shop::table('products');
    $remote=$wpdb->get_results($wpdb->prepare("SELECT * FROM $pt WHERE shop_id=%d AND status IN ('publish','private') ORDER BY name ASC,id ASC",$sid));
    foreach($remote as $rp){$qty=$rp->stock_quantity===null?null:(float)$rp->stock_quantity;if($managed==='yes'&&$qty===null)continue;if($managed==='no'&&$qty!==null)continue;if($qty_min!==null&&($qty===null||$qty<$qty_min))continue;if($qty_max!==null&&($qty===null||$qty>$qty_max))continue;if($search!==''&&stripos($rp->name,$search)===false&&stripos($rp->sku,$search)===false)continue;if($sku_search!==''&&stripos($rp->sku,$sku_search)===false)continue;
     $cats=json_decode((string)$rp->categories_json,true);if(!is_array($cats))$cats=[];$cat=implode(', ',$cats);$status=$qty===null?'Ej lagerstyrd':($qty<=0?'Slut':'I lager');if($stock_filter==='in_stock'&&($qty===null||$qty<=0))continue;if($stock_filter==='out'&&($qty===null||$qty>0))continue;if(in_array($stock_filter,['low','backorder','no_location'],true))continue;
     $rows[]=['name'=>$rp->name,'id'=>$rp->remote_product_id,'sku'=>$rp->sku,'category'=>$cat,'location'=>'','stock'=>$qty===null?'':wc_format_localized_decimal($qty),'batch'=>'','expiry'=>'','type'=>$rp->type?:'Produkt','status'=>$status];
    }
   } else {
  do {
   $result=wc_get_products(['limit'=>100,'page'=>$page,'paginate'=>true,'orderby'=>'title','order'=>'ASC','status'=>['publish','private'],'type'=>['simple','variation']]);
   foreach($result->products as $p) {
    $loc=(string)$p->get_meta('_pb_wms_location',true);
    $terms=self::product_categories($p);$cat_slugs=[];$cat_names=[];foreach($terms as $term){$cat_slugs[]=$term->slug;$cat_names[]=$term->name;}
    $tag_terms=self::product_terms_for_print($p,'product_tag');$tag_slugs=[];foreach($tag_terms as $term)$tag_slugs[]=$term->slug;
    if($categories && !array_intersect($categories,$cat_slugs))continue;
    if($tags && !array_intersect($tags,$tag_slugs))continue;
    if($product_type!=='all' && $p->get_type()!==$product_type)continue;
    if($search!=='' && stripos($p->get_name(),$search)===false && stripos((string)$p->get_sku(),$search)===false)continue;
    if($sku_search!=='' && stripos((string)$p->get_sku(),$sku_search)===false)continue;
    $qty=$p->managing_stock()?$p->get_stock_quantity():null;
    if($managed==='yes' && $qty===null)continue; if($managed==='no' && $qty!==null)continue;
    if($qty_min!==null && ($qty===null || (int)$qty<$qty_min))continue; if($qty_max!==null && ($qty===null || (int)$qty>$qty_max))continue;
    $threshold=$p->get_low_stock_amount();if($threshold===''||$threshold===null)$threshold=get_option('woocommerce_notify_low_stock_amount',2);
    if($stock_filter==='in_stock' && ($qty===null || (int)$qty<=0))continue;
    if($stock_filter==='out' && ($qty===null || (int)$qty>0))continue;
    if($stock_filter==='low' && ($qty===null || (int)$qty<=0 || (int)$qty>(int)$threshold))continue;
    if($stock_filter==='backorder' && !$p->backorders_allowed())continue;
    if($attr_tax!==''){$av=self::product_attribute_for_print($p,$attr_tax);if($attr_value===''&&$av==='')continue;if($attr_value!==''&&stripos($av,$attr_value)===false)continue;}
    $status=$qty===null?'Ej lagerstyrd':((int)$qty<=0?'Slut':((int)$qty<=(int)$threshold?'Lågt':'I lager'));
    $batch_rows=[];$inventory_rows=Dennis_WMS_Inventory_Slots::rows($p->get_id());foreach($inventory_rows['rows'] as $ir)$batch_rows[]=(object)$ir;
    $slots=[];
    if($batch_rows){
     foreach($batch_rows as $br)$slots[]=['location'=>(string)$br->location,'batch'=>(string)$br->batch,'expiry'=>(string)$br->expiry,'last_order_date'=>(string)$br->last_order_date,'slot_stock'=>wc_format_localized_decimal($br->quantity)];
    } else {
     $slots[]=['location'=>$loc,'batch'=>(string)$p->get_meta('_pb_wms_batch',true),'expiry'=>(string)$p->get_meta('_pb_wms_expiry',true),'last_order_date'=>Dennis_WMS_Warnings::product_last_order_date($p),'slot_stock'=>$qty===null?'':(int)$qty];
    }
    if($batch_rows&&$qty!==null){$distributed=array_sum(array_map(fn($br)=>(float)$br->quantity,$batch_rows));if((float)$qty>$distributed)$slots[]=['location'=>'','batch'=>'','expiry'=>'','last_order_date'=>'','slot_stock'=>(float)$qty-$distributed];}
    foreach($slots as $slot){
     $row_loc=$slot['location'];$batch=$slot['batch'];$expiry=$slot['expiry'];
     if($location_mode==='missing'){if($row_loc!=='')continue;} elseif($location!==''){
      if($location_mode==='exact'&&strcasecmp($row_loc,$location)!==0)continue;
      if($location_mode==='starts'&&stripos($row_loc,$location)!==0)continue;
      if($location_mode==='contains'&&stripos($row_loc,$location)===false)continue;
     }
     if($stock_filter==='no_location'&&$row_loc!=='')continue;
     if($batch_filter==='has'&&$batch==='')continue;if($batch_filter==='missing'&&$batch!=='')continue;
     $expiry_ts=preg_match('/^\d{4}-\d{2}-\d{2}$/',$expiry)?strtotime($expiry):false;
     if($expiry_filter==='has'&&!$expiry_ts)continue;if($expiry_filter==='missing'&&$expiry_ts)continue;
     if($expiry_filter==='expired'&&(!$expiry_ts||$expiry_ts>=$today))continue;
     if(in_array($expiry_filter,['30','60','90'],true)){if(!$expiry_ts)continue;$days=($expiry_ts-$today)/DAY_IN_SECONDS;if($days<0||$days>(int)$expiry_filter)continue;}
     $rows[]=['name'=>$p->get_name(),'id'=>$p->get_id(),'sku'=>$p->get_sku(),'location'=>$row_loc,'category'=>implode(', ',$cat_names),'stock'=>$slot['slot_stock'],'batch'=>$batch,'expiry'=>$expiry,'last_order_date'=>$slot['last_order_date']??'','type'=>$p->get_type()==='variation'?'Variation':'Enkel','status'=>$status];
    }
   }
   $page++;
  } while($page<=(int)$result->max_num_pages&&$page<=1000);
  }
  $cmp=static function($a,$b)use($sort1,$sort2,$dir1,$dir2){foreach([[$sort1,$dir1],[$sort2,$dir2],['name','ASC']] as $spec){[$k,$dir]=$spec;if($k==='none')continue;$av=$a[$k]??'';$bv=$b[$k]??'';$c=($k==='stock'||$k==='id')?((float)$av<=>(float)$bv):strnatcasecmp((string)$av,(string)$bv);if($c!==0)return $dir==='DESC'?-$c:$c;}return 0;};
  usort($rows,$cmp);
  nocache_headers();header('Content-Type: text/html; charset='.get_option('blog_charset'));
  echo '<!doctype html><html lang="sv"><head><meta charset="utf-8"><title>Inventeringslista – Dennis WMS</title><style>body{font:12px Arial,sans-serif;color:#111;margin:22px}h1{font-size:20px}.filters{background:#f3f4f6;border:1px solid #ddd;padding:10px;margin:10px 0 14px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #777;padding:7px;text-align:left;vertical-align:top}th{background:#eee}.group td{background:#dbeafe;font-weight:700;font-size:13px}.count{width:92px}.comment{min-width:130px}tr{break-inside:avoid}thead{display:table-header-group}.controls{margin-bottom:16px}@media print{.controls{display:none}body{margin:0}@page{size:A4 landscape;margin:8mm}}</style></head><body>';
  echo '<div class="controls"><button onclick="window.print()">Skriv ut</button> <button onclick="window.close()">Stäng</button></div><h1>Dennis WMS – Inventeringslista – '.esc_html($shop_name).'</h1><p>Datum: ____________________ &nbsp; Inventerad av: ____________________ &nbsp; Signatur: ____________________</p>';
  $parts=['Shop: '.$shop_name];if(strpos($shop_filter,'remote:')===0)$parts[]='Extern shop: senast synkade WooCommerce-saldon';if($categories)$parts[]='Kategorier: '.implode(', ',$categories);if($tags)$parts[]='Taggar: '.implode(', ',$tags);if($location!==''||$location_mode==='missing')$parts[]='Lagerplats: '.($location_mode==='missing'?'saknas':$location);if($stock_filter!=='all')$parts[]='Lagerfilter: '.$stock_filter;if($search!=='')$parts[]='Sök: '.$search;if($sku_search!=='')$parts[]='SKU: '.$sku_search;if($attr_tax!=='')$parts[]='Attribut: '.$attr_tax.($attr_value!==''?' = '.$attr_value:'');$parts[]='Sortering: '.$sort1.' '.$dir1.($sort2!=='none'?' → '.$sort2.' '.$dir2:'');if($group!=='none')$parts[]='Gruppering: '.$group;
  echo '<div class="filters"><strong>Urval:</strong> '.esc_html(implode(' · ',$parts)).'</div><p>Fyll i räknat antal per lagerplats och batch, även för utgångna batcher. Nya fynd noteras med plats, batch och datum i Kommentar. Systemsaldo visas alltid. Fyll i räknat antal och differens efter fysisk räkning.</p><table><thead><tr>';
  $labels=['name'=>'Artikel / produkt','sku'=>'SKU','category'=>'Kategori','location'=>'Lagerplats','stock'=>'Systemsaldo','batch'=>'Batch','expiry'=>'Utgångsdatum','last_order_date'=>'Last order date','type'=>'Produkttyp','status'=>'Lagerstatus','id'=>'Produkt-ID'];foreach($columns as $col)echo '<th>'.esc_html($labels[$col]).'</th>';echo '<th class="count">Räknat antal</th><th class="count">Differens</th><th class="comment">Kommentar</th></tr></thead><tbody>';
  $last_group=null;foreach($rows as $r){if($group!=='none'){$gv=(string)($r[$group]??'');if($gv==='')$gv='Ej angiven';if($gv!==$last_group){echo '<tr class="group"><td colspan="'.esc_attr((string)(count($columns)+3)).'">'.esc_html($gv).'</td></tr>';$last_group=$gv;}}echo '<tr>';foreach($columns as $col){$v=$r[$col]??'';if($col==='name')$v.=' #'.$r['id'];echo '<td>'.esc_html($v===''?'–':(string)$v).'</td>';}echo '<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';}
  if(!$rows)echo '<tr><td colspan="'.esc_attr((string)(count($columns)+3)).'">Inga artiklar matchar urvalet.</td></tr>';
  echo '</tbody></table><p>Antal inventeringsrader på listan: '.esc_html((string)count($rows)).'.</p></body></html>';exit;
 }
 static function stats() {
  global $wpdb;
  $table=$wpdb->prefix.'pb_wms_counts';
  $total=0; $stock_units=0; $stock_value=0.0; $known_value=0; $low=0; $out=0; $locations=[]; $expiring=0; $expired=0; $batches=0;
  if (!function_exists('wc_get_products')) return;
  $page=1;
  do {
   $r=wc_get_products(['limit'=>100,'page'=>$page,'paginate'=>true,'status'=>['publish','private'],'type'=>['simple','variation']]);
   foreach ($r->products as $p) {
    $total++; $loc=(string)$p->get_meta('_pb_wms_location',true); if($loc!=='') $locations[$loc]=($locations[$loc]??0)+1;
    $batch=(string)$p->get_meta('_pb_wms_batch',true); if($batch!=='') $batches++;
    $expiry=(string)$p->get_meta('_pb_wms_expiry',true);
    if($expiry!=='' && strtotime($expiry)) { $days=(strtotime($expiry)-strtotime(current_time('Y-m-d')))/86400; if($days<0) $expired++; elseif($days<=30) $expiring++; }
    if (!$p->managing_stock() || $p->get_stock_quantity()===null) continue;
    $qty=(int)$p->get_stock_quantity(); $stock_units+=$qty; if($qty<=0) $out++;
    $threshold=$p->get_low_stock_amount(); if($threshold==='' || $threshold===null) $threshold=get_option('woocommerce_notify_low_stock_amount',2);
    if($qty>0 && $qty<=(int)$threshold) $low++;
    // Valuation is based on stored ATUM/WooCommerce purchase-cost metadata when available, never on retail price.
    $cost=$p->get_meta('_purchase_price',true);
    if(is_numeric($cost)) { $stock_value+=max(0,$qty)*(float)$cost; $known_value++; }
   }
   $page++;
  } while ($page<=(int)$r->max_num_pages && $page<=1000);
  $counts=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table");
  $diff=$wpdb->get_var("SELECT SUM(ABS(counted_qty-reference_qty)) FROM $table WHERE reference_qty IS NOT NULL");
  $failed=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table WHERE update_status='failed'");
  echo '<h2>Statistik och analys</h2><p>Aktuella lagerdata; försäljning avser senaste 30 dagarna. Värde visas endast för artiklar med registrerat inköpspris.</p>';
  echo '<table class="widefat striped" style="max-width:1000px"><tbody>';
  $metrics=['Artiklar'=>$total,'Lagerstyrda enheter'=>$stock_units,'Slutsålda artiklar'=>$out,'Artiklar med lågt saldo'=>$low,'Lagerplatser'=>count($locations),'Inventeringar totalt'=>$counts,'Summa absoluta inventeringsdifferenser'=>$diff===null?'–':$diff,'Misslyckade saldouppdateringar – kontrollera manuellt'=>$failed,'Produkter med batchanteckning'=>$batches,'Utgångna produktdatum'=>$expired,'Utgångsdatum inom 30 dagar'=>$expiring,'Artiklar utan lagerplats'=>count(array_filter(array_keys($locations),static function($loc){return $loc==='';}))];
  foreach($metrics as $label=>$value) echo '<tr><th>'.esc_html($label).'</th><td>'.(is_string($value)&&strpos($value,'<')!==false?wp_kses_post($value):esc_html((string)$value)).'</td></tr>';
  echo '</tbody></table>';
  if(function_exists('wc_get_orders')) {
   $after=gmdate('Y-m-d H:i:s',time()-30*DAY_IN_SECONDS);
   $orders=wc_get_orders(['limit'=>-1,'status'=>['wc-processing','wc-completed'],'date_created'=>'>'.$after,'return'=>'objects']);
   $revenue=0; $units=0; $popular=[]; $order_count=0;
   foreach($orders as $order) { $order_count++; $revenue+=(float)$order->get_total(); foreach($order->get_items('line_item') as $item) { $q=(int)$item->get_quantity(); $units+=$q; $key=$item->get_product_id().':'.$item->get_variation_id(); if(!isset($popular[$key])) $popular[$key]=['name'=>$item->get_name(),'qty'=>0]; $popular[$key]['qty']+=$q; } }
   uasort($popular,function($a,$b){return $b['qty']<=>$a['qty'];});
   echo '<h3>Försäljning – senaste 30 dagarna</h3><p>Slutförda och behandlade order: '.esc_html((string)$order_count).' · Sålda enheter: '.esc_html((string)$units).' · Ordervärde inklusive moms och frakt: '.wp_kses_post(wc_price($revenue)).'. Återbetalningar är inte avräknade.</p>';
   echo '<table class="widefat striped" style="max-width:1000px"><thead><tr><th>Mest sålda produkt</th><th>Antal</th></tr></thead><tbody>';
   foreach(array_slice($popular,0,10) as $row) echo '<tr><td>'.esc_html($row['name']).'</td><td>'.esc_html((string)$row['qty']).'</td></tr>';
   echo '</tbody></table>';
   $pending=wc_orders_count('processing');
   echo '<p>Order som väntar på hantering (WooCommerce-status Behandlas): '.esc_html((string)$pending).'. Plocktid och plockade order kräver en separat plockmodul.</p>';
  }
  arsort($locations); echo '<h3>Artiklar per lagerplats</h3><table class="widefat striped" style="max-width:1000px"><thead><tr><th>Lagerplats</th><th>Antal artiklar</th></tr></thead><tbody>';
  foreach(array_slice($locations,0,30,true) as $loc=>$n) echo '<tr><td>'.esc_html($loc).'</td><td>'.esc_html((string)$n).'</td></tr>';
  echo '</tbody></table><p>Kapacitet och lediga lagerplatser kan inte beräknas förrän platskapacitet registreras.</p>';
 }
 static function page() {
  if (!current_user_can(self::VIEW)) wp_die('Åtkomst nekad',403);
  echo '<div class="wrap"><h1>Dennis WMS</h1>';
  if(class_exists('Dennis_WMS_Remote_Inventory'))Dennis_WMS_Remote_Inventory::render();
  if(class_exists('Dennis_WMS_Packaging_Materials'))Dennis_WMS_Packaging_Materials::render_inventory();
  if (!function_exists('wc_get_products')) { echo '<p>WooCommerce saknas.</p></div>'; return; }
  $cats=get_terms(['taxonomy'=>'product_cat','hide_empty'=>false]); if(is_wp_error($cats))$cats=[];
  $tags=get_terms(['taxonomy'=>'product_tag','hide_empty'=>false]); if(is_wp_error($tags))$tags=[];
  $attrs=function_exists('wc_get_attribute_taxonomies')?wc_get_attribute_taxonomies():[];
  echo '<div class="dw-panel dw-print-builder" style="max-width:1200px;margin:12px 0"><h2>Skapa flexibel inventeringslista</h2><p>Du kan kombinera filtren fritt, välja flera kategorier/taggar, bestämma primär och sekundär sortering, gruppera listan och själv välja vilka kolumner som ska skrivas ut.</p><form method="get" target="_blank" action="'.esc_url(admin_url('admin-post.php')).'">';
  echo '<input type="hidden" name="action" value="pb_wms_print">'; wp_nonce_field('pb_wms_print');
  echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:14px;align-items:start">';echo '<label><strong>Shop</strong><br><select name="pb_print_shop" style="width:100%"><option value="local">Huvudshop</option>';if(class_exists('Dennis_WMS_Multi_Shop'))foreach(Dennis_WMS_Multi_Shop::shops() as $ms)echo '<option value="remote:'.esc_attr((string)$ms->id).'">'.esc_html($ms->name).' (extern)</option>';echo '</select><small>Externa shoppar använder senast synkade produkt- och saldodata.</small></label>';
  echo '<label><strong>Kategorier</strong><br><select name="pb_print_categories[]" multiple size="5" style="width:100%"><option value="">Alla kategorier</option>';foreach($cats as $cat)echo '<option value="'.esc_attr($cat->slug).'">'.esc_html($cat->name).'</option>';echo '</select><small>Ctrl/Cmd för flera.</small></label>';
  echo '<label><strong>Produkttaggar</strong><br><select name="pb_print_tags[]" multiple size="5" style="width:100%"><option value="">Alla taggar</option>';foreach($tags as $tag)echo '<option value="'.esc_attr($tag->slug).'">'.esc_html($tag->name).'</option>';echo '</select></label>';
  echo '<label><strong>Produkt / SKU-sökning</strong><br><input type="text" name="pb_print_search" style="width:100%" placeholder="Namn eller SKU"><br><input type="text" name="pb_print_sku" style="width:100%;margin-top:6px" placeholder="SKU innehåller..."></label>';
  echo '<label><strong>Lagerplats</strong><br><select name="pb_print_location_mode" style="width:100%"><option value="contains">Innehåller</option><option value="exact">Exakt</option><option value="starts">Börjar med</option><option value="missing">Saknas</option></select><input type="text" name="pb_print_location" style="width:100%;margin-top:6px" placeholder="t.ex. A3 eller A-"></label>';
  echo '<label><strong>Lagerstatus</strong><br><select name="pb_print_stock" style="width:100%"><option value="all">Alla</option><option value="in_stock">I lager</option><option value="out">Slut i lager</option><option value="low">Lågt saldo</option><option value="backorder">Restorder tillåten</option><option value="no_location">Saknar lagerplats</option></select><select name="pb_print_managed" style="width:100%;margin-top:6px"><option value="all">Lagerstyrd: alla</option><option value="yes">Endast lagerstyrda</option><option value="no">Endast ej lagerstyrda</option></select></label>';
  echo '<label><strong>Saldo-intervall</strong><br><input type="number" name="pb_print_qty_min" style="width:48%" placeholder="Min"><input type="number" name="pb_print_qty_max" style="width:48%;float:right" placeholder="Max"><br><select name="pb_print_type" style="width:100%;margin-top:6px"><option value="all">Alla produkttyper</option><option value="simple">Enkla produkter</option><option value="variation">Variationer</option></select></label>';
  echo '<label><strong>Batch / utgångsdatum</strong><br><select name="pb_print_batch" style="width:100%"><option value="all">Batch: alla</option><option value="has">Har batch</option><option value="missing">Saknar batch</option></select><select name="pb_print_expiry" style="width:100%;margin-top:6px"><option value="all">Utgångsdatum: alla</option><option value="has">Har datum</option><option value="missing">Saknar datum</option><option value="expired">Utgånget</option><option value="30">Inom 30 dagar</option><option value="60">Inom 60 dagar</option><option value="90">Inom 90 dagar</option></select></label>';
  echo '<label><strong>WooCommerce-attribut</strong><br><select name="pb_print_attribute" style="width:100%"><option value="">Alla attribut</option>';foreach($attrs as $a){$tax=wc_attribute_taxonomy_name($a->attribute_name);echo '<option value="'.esc_attr($tax).'">'.esc_html($a->attribute_label?:$a->attribute_name).'</option>';}echo '</select><input type="text" name="pb_print_attribute_value" style="width:100%;margin-top:6px" placeholder="Värde innehåller... (tomt = attribut finns)"></label>';
  $sortopts=['name'=>'Produktnamn','sku'=>'SKU','category'=>'Kategori','location'=>'Lagerplats','stock'=>'Saldo','batch'=>'Batch','expiry'=>'Utgångsdatum','last_order_date'=>'Last order date','type'=>'Produkttyp','status'=>'Lagerstatus','id'=>'Produkt-ID'];
  echo '<label><strong>Primär sortering</strong><br><select name="pb_print_sort" style="width:68%">';foreach($sortopts as $k=>$v)echo '<option value="'.esc_attr($k).'">'.esc_html($v).'</option>';echo '</select><select name="pb_print_dir" style="width:30%;float:right"><option value="ASC">A–Ö / stigande</option><option value="DESC">Ö–A / fallande</option></select></label>';
  echo '<label><strong>Sekundär sortering</strong><br><select name="pb_print_sort2" style="width:68%"><option value="none">Ingen</option>';foreach($sortopts as $k=>$v)echo '<option value="'.esc_attr($k).'">'.esc_html($v).'</option>';echo '</select><select name="pb_print_dir2" style="width:30%;float:right"><option value="ASC">Stigande</option><option value="DESC">Fallande</option></select></label>';
  echo '<label><strong>Gruppera utskriften</strong><br><select name="pb_print_group" style="width:100%"><option value="none">Ingen gruppering</option><option value="category">Kategori</option><option value="location">Lagerplats</option><option value="type">Produkttyp</option><option value="status">Lagerstatus</option></select></label>';
  echo '</div><hr><strong>Kolumner på utskriften</strong><div style="display:flex;flex-wrap:wrap;gap:10px 18px;margin:8px 0 16px">';
  $cols=['name'=>'Produkt','sku'=>'SKU','category'=>'Kategori','location'=>'Lagerplats','stock'=>'Systemsaldo','batch'=>'Batch','expiry'=>'Utgångsdatum','last_order_date'=>'Last order date','type'=>'Produkttyp','status'=>'Lagerstatus','id'=>'Produkt-ID'];foreach($cols as $k=>$v){$checked=in_array($k,['name','sku','location','batch','expiry','last_order_date','stock'],true)?' checked':'';echo '<label><input type="checkbox" name="pb_print_columns[]" value="'.esc_attr($k).'"'.$checked.'> '.esc_html($v).'</label>';}
  echo '</div><p><button class="button button-primary button-hero">Skapa / skriv ut inventeringslista</button> <span class="description">Systemsaldo, räknat antal, differens och kommentar finns alltid med.</span></p></form></div>';
  echo '<p><strong>Inventering:</strong> Sparad räkning uppdaterar WooCommerce standardsaldo direkt. ATUM avancerade lagerfunktioner (t.ex. Multi-Inventory) ingår inte. Testa på en kopia av butiken först.</p>';
  self::stats();
  $status=isset($_GET['pb_status']) ? sanitize_key(wp_unslash($_GET['pb_status'])) : '';
  if (in_array($status,['count','location','batch'],true)) echo '<div class="notice notice-success is-dismissible"><p>Uppgifterna har sparats.</p></div>';
  $search=isset($_GET['pb_search']) ? sanitize_text_field(wp_unslash($_GET['pb_search'])) : '';
  $page=isset($_GET['pb_page']) ? max(1,absint($_GET['pb_page'])) : 1;
  echo '<form method="get"><input type="hidden" name="page" value="pb-wms"><label for="pb-search">Sök produkt eller SKU: </label><input id="pb-search" type="search" name="pb_search" value="'.esc_attr($search).'"> <button class="button">Sök</button></form><br>';
  $args=['limit'=>25,'page'=>$page,'paginate'=>true,'orderby'=>'title','order'=>'ASC','status'=>['publish','private'],'type'=>['simple','variation']];
  if ($search!=='') $args['search']=$search;
  $result=wc_get_products($args);
  $followup_products=$result->products; $followup_dates=Dennis_WMS_Inventory_Followup::dates(array_map(static function($x){return $x->get_id();},$followup_products));
  echo '<p class="description">Inventeringsstatus baseras på slutförda inventeringar. Produktdatakontroll är en separat kontroll av produktuppgifter.</p>';
  echo '<table class="widefat striped"><thead><tr><th>Produkt</th><th>SKU</th><th>WooCommerce-saldo</th><th>Lagerplats</th><th>Batch / utgångsdatum</th><th>Produktdata</th><th>Inventeringsstatus</th><th>Inventera och uppdatera saldo</th></tr></thead><tbody>';
  foreach($result->products as $p) {
   $id=$p->get_id(); $loc=(string)$p->get_meta('_pb_wms_location',true);
   $stock=$p->managing_stock() ? $p->get_stock_quantity() : null;
   echo '<tr><td>'.esc_html($p->get_name()).' <small>#'.esc_html((string)$id).'</small></td><td>'.esc_html($p->get_sku()).'</td><td>'.esc_html($stock===null?'Ej lagerstyrd':(string)$stock).'</td><td>';
   if(current_user_can(self::MANAGE)) {
    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'; wp_nonce_field('pb_wms_location_'.$id);
    echo '<input type="hidden" name="action" value="pb_wms_location"><input type="hidden" name="product_id" value="'.esc_attr((string)$id).'"><input type="text" maxlength="80" name="location" value="'.esc_attr($loc).'" aria-label="Lagerplats" placeholder="A-01-02"> <button class="button">Spara plats</button></form>';
   } else echo esc_html($loc);
   echo '</td><td>';
   if(current_user_can(self::MANAGE)) {
    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'; wp_nonce_field('pb_wms_batch_'.$id);
    echo '<input type="hidden" name="action" value="pb_wms_batch"><input type="hidden" name="product_id" value="'.esc_attr((string)$id).'"><input name="batch" maxlength="80" style="width:110px" placeholder="Batch" value="'.esc_attr((string)$p->get_meta('_pb_wms_batch',true)).'"><input type="date" name="expiry" value="'.esc_attr((string)$p->get_meta('_pb_wms_expiry',true)).'"> <button class="button">Spara</button></form>';
   } else echo esc_html((string)$p->get_meta('_pb_wms_batch',true)).' '.esc_html((string)$p->get_meta('_pb_wms_expiry',true));
   echo '</td><td>';
   if (class_exists('Dennis_WMS_Product_Rules')) echo Dennis_WMS_Product_Rules::badge_html($p); else echo '–';
   echo '</td><td>';
   echo $p->managing_stock() ? Dennis_WMS_Inventory_Followup::badge($followup_dates[$id]??'') : 'Ej lagerstyrd';
   echo '</td><td>';
   if(current_user_can(self::COUNT) && current_user_can('manage_woocommerce') && $p->managing_stock() && $stock!==null) {
    if(!Dennis_WMS_Inventory_Slots::form($p)){
    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'; wp_nonce_field('pb_wms_count_'.$id);
    echo '<input type="hidden" name="action" value="pb_wms_count"><input type="hidden" name="product_id" value="'.esc_attr((string)$id).'"><input type="hidden" name="expected_stock" value="'.esc_attr((string)$stock).'"><input type="number" name="count" min="0" max="999999999" step="1" required style="width:100px" aria-label="Räknat antal"><input name="reason" required minlength="3" maxlength="500" placeholder="Orsak / kommentar"> <button class="button" onclick="return confirm(\'Uppdatera WooCommerce-saldot direkt?\')">Spara och uppdatera</button></form>';
    }
   } else echo 'Kräver lagerstyrd produkt och behörighet';
   echo '</td></tr>';
  }
  echo '</tbody></table>';
  $total=(int)$result->max_num_pages;
  if($total>1) {
   echo '<p>Sida '.esc_html((string)$page).' av '.esc_html((string)$total).' &nbsp;';
   if($page>1) echo '<a class="button" href="'.esc_url(add_query_arg(['page'=>'pb-wms','pb_page'=>$page-1,'pb_search'=>$search],admin_url('admin.php'))).'">Föregående</a> ';
   if($page<$total) echo '<a class="button" href="'.esc_url(add_query_arg(['page'=>'pb-wms','pb_page'=>$page+1,'pb_search'=>$search],admin_url('admin.php'))).'">Nästa</a>';
   echo '</p>';
  }
  global $wpdb; $table=$wpdb->prefix.'pb_wms_counts';
  $events=$wpdb->get_results("SELECT id,product_id,counted_qty,reference_qty,location,user_id,counted_at,applied_qty,update_status FROM $table ORDER BY id DESC LIMIT 30");
  echo '<h2>Senaste inventeringar</h2><table class="widefat striped"><thead><tr><th>Tid</th><th>Artikel</th><th>Räknat</th><th>Saldo vid räkning</th><th>Differens</th><th>Lagerplats</th><th>Användare</th><th>Orsak / ändringshistorik</th><th>Status / åtgärder</th></tr></thead><tbody>';
  foreach($events as $e) {
   $p=wc_get_product((int)$e->product_id); $ref=$e->reference_qty;
   $diff=$ref===null?'–':(string)((int)$e->counted_qty-(int)$ref);
   $u=get_userdata((int)$e->user_id);
   $revision=Dennis_WMS_Revisions::latest((int)$e->id);
   $display_qty=$revision && $revision->kind==='correct' ? (int)$revision->corrected_qty : (int)$e->counted_qty;
   $display_loc=$revision && $revision->kind==='correct' ? $revision->corrected_location : $e->location;
   $display_diff=$ref===null?'–':(string)($display_qty-(int)$ref);
   $void=$revision && $revision->kind==='void';
   $history=$wpdb->get_results($wpdb->prepare('SELECT * FROM '.$wpdb->prefix.'dennis_wms_revisions WHERE count_id=%d ORDER BY id DESC',(int)$e->id));
   $slot_detail=in_array($e->update_status,['applied_slots','applied_details'],true)?Dennis_WMS_Inventory_Slots::detail((int)$e->id):null;
   $reason_cell=$slot_detail?Dennis_WMS_Inventory_Slots::history_html($slot_detail):'–';
   if($history) {
    $reason_cell='';
    foreach($history as $h) {
     $editor=get_userdata((int)$h->user_id);
     $reason_cell.='<div style="margin-bottom:7px"><strong>'.esc_html($h->kind==='void'?'Ogiltigförklarad':'Korrigerad').'</strong> '.esc_html(substr((string)$h->created_at,0,16)).' – '.esc_html($editor?$editor->display_name:'#'.$h->user_id).'<br>'.esc_html($h->reason).'<br><small>Saldo: '.esc_html($h->stock_status==='applied'?'uppdaterat till '.$h->stock_after.' st':($h->stock_status==='failed'?'uppdatering misslyckades':($h->stock_status==='pending'?'kontrollera uppdatering':'inte ändrat'))).'</small></div>';
    }
   }
   echo '<tr'.($void?' style="opacity:.65"':'').'><td>'.esc_html(substr((string)$e->counted_at,0,16)).'</td><td>'.esc_html($p?$p->get_name():'#'.$e->product_id).'</td><td>'.esc_html((string)$display_qty).'</td><td>'.esc_html($ref===null?'–':(string)$ref).'</td><td>'.esc_html($display_diff).'</td><td>'.esc_html($display_loc).'</td><td>'.esc_html($u?$u->display_name:'#'.$e->user_id).'</td><td>'.wp_kses_post($reason_cell).'</td><td>'.($void?'Ogiltigförklarad':($revision?'Korrigerad':'Aktiv'));
   if(current_user_can(self::MANAGE) && !$void && $e->update_status!=='applied_slots') {
    echo '<details><summary>Redigera / ogiltigförklara</summary><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
    wp_nonce_field('dennis_wms_revision_'.(int)$e->id);
    echo '<input type="hidden" name="action" value="dennis_wms_revision"><input type="hidden" name="event_id" value="'.esc_attr((string)$e->id).'">';
    echo '<p><label>Räknat antal <input type="number" min="0" max="999999999" name="corrected_qty" value="'.esc_attr((string)$display_qty).'" required></label></p>';
    echo '<p><label>Lagerplats <input name="corrected_location" maxlength="80" value="'.esc_attr($display_loc).'"></label></p>';
    echo '<p><label>Orsak (obligatorisk) <input name="reason" maxlength="500" required></label></p>';
    echo '<p><label><input type="checkbox" name="update_stock" value="1"> <strong>Uppdatera även WooCommerce-saldot</strong> (kräver oförändrat saldo och ingen senare inventering)</label></p>';
    echo '<p><label>Aktuellt saldo (bekräfta) <input type="number" name="expected_stock" min="0" step="1" value="'.esc_attr($p && $p->get_stock_quantity()!==null?(string)$p->get_stock_quantity():'').'"></label> <small>Kontrollera saldot i WooCommerce innan du markerar rutan ovan.</small></p>';
    echo '<button class="button button-primary" name="revision_kind" value="correct">Spara korrigering</button> ';
    echo '<button class="button" name="revision_kind" value="void" formnovalidate onclick="return confirm(&quot;Ogiltigförklara denna inventering? WooCommerce-saldot ändras INTE.&quot;)">Ogiltigförklara</button></form></details>';
   }
   echo '</td></tr>';
  }
  if(!$events) echo '<tr><td colspan="9">Inga inventeringar ännu.</td></tr>';
  echo '</tbody></table><p><em>Ogiltigförklarade räkningar ligger kvar i revisionsloggen och ändrar inte WooCommerce-saldot. Korrigeringar av historiken ändrar inte heller saldot om du inte uttryckligen väljer det. Statistik från äldre moduler kan fortfarande visa ursprungliga inventeringar tills de har anpassats till revisionsloggen.</em></p><p><em>ATUM-specifika lager och flera lagerplatser per artikel stöds inte. Batch och utgångsdatum ovan är WMS-anteckningar per produkt, inte ATUM-batcher.</em></p></div>';
 }
}

/** Separate picking workflow: no WooCommerce stock or order-status mutations. */
final class Dennis_WMS_Orders {
 const CAP='pb_wms_view';
 static function menu() {
  add_submenu_page('pb-wms','Orders in Progress','Orders in Progress',self::CAP,'dennis-wms-orders',[__CLASS__,'page']);
 }
 static function order($id) {
  if (!function_exists('wc_get_order')) wp_die('WooCommerce måste vara aktivt.',400);
  $order=wc_get_order($id);
  if (!$order || !is_a($order,'WC_Order')) wp_die('Ordern finns inte.',404);
  return $order;
 }
 static function location($product_id) {
  $p=wc_get_product($product_id);
  if (!$p) return '';
  $location=(string)$p->get_meta('_pb_wms_location',true);
  // A variation can inherit the location of its parent product.
  if ($location==='' && $p->is_type('variation')) {
   $parent=wc_get_product($p->get_parent_id());
   if ($parent) $location=(string)$parent->get_meta('_pb_wms_location',true);
  }
  return $location;
 }
 static function items($order,&$packed_budget=[]) {
  $rows=[];
  foreach ($order->get_items('line_item') as $item) {
   $p=$item->get_product();
   $pid=$item->get_variation_id() ?: $item->get_product_id();
   $row=['name'=>$item->get_name(),'sku'=>$p?$p->get_sku():'','qty'=>$item->get_quantity(),
    'location'=>self::location($pid),'item_id'=>$item->get_id(),'product_id'=>$pid,'image'=>self::product_image_url(wc_get_product($pid) ?: $p),'purchase_note'=>self::purchase_note($p)];
   $rows=array_merge($rows,class_exists('Dennis_WMS_Kits')?Dennis_WMS_Kits::pick_rows($order,$item,$row,$packed_budget):[$row]);
  }
  return class_exists('Dennis_WMS_Product_Packing')?array_values(Dennis_WMS_Product_Packing::prioritize($rows)):$rows;
 }
 static function group_items($orders) {
  $agg=[];$packed_budget=[];
  foreach($orders as $order)foreach(self::items($order,$packed_budget) as $row){
   $key=(string)$row['product_id'].(!empty($row['accompanying_group'])?':'.$row['accompanying_group']:'');
   if(!isset($agg[$key])){$agg[$key]=array_merge($row,['qty'=>0,'packed_qty'=>0,'unpacked_qty'=>0,'orders'=>[],'purchase_note'=>'','packing_instruction'=>'','kit_instruction'=>'','kit_allocation'=>['rows'=>[],'missing'=>0]]);$agg[$key]['name']=$row['base_name']??$row['name'];}
   $agg[$key]['qty']+=(float)$row['qty'];$agg[$key]['packed_qty']+=(int)($row['packed_qty']??0);$agg[$key]['unpacked_qty']+=(int)($row['unpacked_qty']??0);
   $agg[$key]['orders'][]=['label'=>'#'.$order->get_order_number(),'qty'=>(float)$row['qty']];
   if(!empty($row['purchase_note'])&&strpos($agg[$key]['purchase_note'],$row['purchase_note'])===false)$agg[$key]['purchase_note'].=($agg[$key]['purchase_note']?' ':'').$row['purchase_note'];
   if(!empty($row['kit_instruction'])){$kit_note='#'.$order->get_order_number().': '.$row['kit_instruction'];if(strpos($agg[$key]['kit_instruction'],$kit_note)===false)$agg[$key]['kit_instruction'].=($agg[$key]['kit_instruction']?' ':'').$kit_note;}
   $agg[$key]['packing_component_only']=!empty($agg[$key]['packing_component_only'])&&!empty($row['packing_component_only']);
   $alloc=$row['kit_allocation']??self::pick_allocation($row['product_id'],$row['qty']);
   $agg[$key]['kit_allocation']['rows']=array_merge($agg[$key]['kit_allocation']['rows'],$alloc['rows']);
   $agg[$key]['kit_allocation']['missing']+=(float)$alloc['missing'];
  }foreach($agg as &$entry)if(class_exists('Dennis_WMS_Product_Packing'))$entry['packing_instruction']=!empty($entry['accompanying_group'])?($entry['packed_qty']>0?'Plocka '.$entry['packed_qty'].' för-packade'.($entry['unpacked_qty']>0?' och '.$entry['unpacked_qty'].' oförpackade':'').' st.':''):Dennis_WMS_Product_Packing::pick_instruction($entry['packed_qty'],$entry['unpacked_qty'],!empty($entry['packing_component_only']));unset($entry);return class_exists('Dennis_WMS_Product_Packing')?Dennis_WMS_Product_Packing::prioritize($agg):$agg;
 }
 static function purchase_note($product) {
  if(!$product || !is_a($product,'WC_Product')) return '';
  $note=method_exists($product,'get_purchase_note')?(string)$product->get_purchase_note():'';
  if(trim(wp_strip_all_tags($note))==='' && $product->is_type('variation')){
   $parent=wc_get_product($product->get_parent_id());
   if($parent && method_exists($parent,'get_purchase_note'))$note=(string)$parent->get_purchase_note();
  }
  return trim($note);
 }
 static function purchase_note_html($note,$print=false) {
  if(trim(wp_strip_all_tags((string)$note))==='')return '';
  $style=$print
   ?'margin:7px 0 2px;padding:9px 11px;border:1px solid #d7b55b;border-left:5px solid #d7b55b;border-radius:5px;background:#fff9e8;line-height:1.45'
   :'margin:8px 0 2px;padding:10px 12px;border:1px solid #ead9a2;border-left:5px solid #dba617;border-radius:8px;background:#fff8e5;line-height:1.45';
  return '<div style="'.$style.'"><strong>📝 Purchase note</strong><div style="margin-top:4px">'.wp_kses_post(wpautop((string)$note)).'</div></div>';
 }
 static function packing_html($row,$print=false){
  $instruction=(string)($row['packing_instruction']??'');$kit=(string)($row['kit_instruction']??'');if($instruction===''&&$kit==='')return '';
  $style='margin:8px 0 2px;padding:10px 12px;border:1px solid #bfdcde;border-left:4px solid #1D949C;border-radius:8px;background:#f1f9f9;line-height:1.45';
  return '<div class="dw-packing-info" style="'.$style.'"><strong>Plock &amp; pack</strong>'.($instruction!==''?'<div>'.esc_html($instruction).'</div>':'').($kit!==''?'<div>'.nl2br(esc_html($kit)).'</div>':'').'</div>';
 }
 static function product_image_url($product) {
  if (!$product || !is_a($product,'WC_Product')) return function_exists('wc_placeholder_img_src') ? wc_placeholder_img_src('thumbnail') : '';
  $image_id=(int)$product->get_image_id();
  if (!$image_id && $product->is_type('variation')) {
   $parent=wc_get_product($product->get_parent_id());
   if ($parent) $image_id=(int)$parent->get_image_id();
  }
  if ($image_id) {
   // A thumbnail derivative may not exist in Playground or after a recent upload.
   // Fall back to the original attachment rather than showing the placeholder.
   foreach (['thumbnail','medium','full'] as $size) {
    $url=wp_get_attachment_image_url($image_id,$size);
    if ($url) return $url;
   }
   $url=wp_get_attachment_url($image_id);
   if ($url) return $url;
  }
  return function_exists('wc_placeholder_img_src') ? wc_placeholder_img_src('thumbnail') : '';
 }
 /** Resolve the image for the actual pick row, including kits and stale order product references. */
 static function pick_row_image($row) {
  $pid=absint($row['product_id']??0);
  $sku=trim((string)($row['sku']??''));
  $product=$pid?wc_get_product($pid):false;
  // Deleted/recreated products and migrated order lines can retain an old product ID.
  if ((!$product || !(int)$product->get_image_id()) && $sku!=='' && function_exists('wc_get_product_id_by_sku')) {
   $sku_id=wc_get_product_id_by_sku($sku);
   if ($sku_id) {
    $by_sku=wc_get_product($sku_id);
    if ($by_sku && (!$product || (int)$by_sku->get_image_id())) $product=$by_sku;
   }
  }
  if ($product) return self::product_image_url($product);
  return (string)($row['image']??'');
 }
 /** A scannable Code 128 barcode beneath the SKU, only on the first row of each item. */
 static function pick_barcode_html($row,$print=false) {
  if (!class_exists('Dennis_WMS_Barcodes') || !function_exists('wc_get_product')) return '';
  $pid=absint($row['product_id']??0);
  $sku=(string)($row['sku']??'');
  $product=$pid?wc_get_product($pid):false;
  if ((!$product || ($sku!=='' && $product->get_sku()!==$sku)) && $sku!=='' && function_exists('wc_get_product_id_by_sku')) {
   $found=wc_get_product_id_by_sku($sku);
   if ($found) $product=wc_get_product($found);
  }
  if (!$product) return '';
  $code=(string)$product->get_meta(Dennis_WMS_Barcodes::META,true);
  if ($code==='') $code=(string)Dennis_WMS_Barcodes::ensure($product->get_id());
  $svg=Dennis_WMS_Barcodes::svg($code,35);
  if ($svg==='') return '';
  $width=$print?'150px':'165px';
  return '<div class="dw-pick-barcode" style="margin-top:7px;max-width:'.$width.';break-inside:avoid;page-break-inside:avoid">'
   .'<div style="background:#fff;padding:3px 5px;border:1px solid #e1e5e9;border-radius:4px">'.$svg.'</div>'
   .'<small style="display:block;overflow-wrap:anywhere;font:9px/1.4 monospace;color:#333;margin-top:2px">'.esc_html($code).'</small></div>';
 }
 static function image_html($url,$name,$print=false) {
  if (!$url) return '<span class="dw-no-product-image">Ingen bild</span>';
  $style=$print?'width:56px;height:56px;object-fit:contain;border:1px solid #ddd;border-radius:6px;background:#fff':'width:58px;height:58px;object-fit:contain;border:1px solid #dfe7ef;border-radius:8px;background:#fff';
  return '<img src="'.esc_url($url).'" alt="'.esc_attr($name).'" style="'.$style.'" loading="eager" decoding="async">';
 }
 static function url($id=0) {
  $args=['page'=>'dennis-wms-orders']; if ($id) $args['order_id']=$id;
  return add_query_arg($args,admin_url('admin.php'));
 }
 static function wc_edit_url($order) {
  // WooCommerce supplies the correct URL for both HPOS and legacy order storage.
  if(method_exists($order,'get_edit_order_url')) return $order->get_edit_order_url();
  return admin_url('post.php?post='.$order->get_id().'&action=edit');
 }
 static function depot_label($order) {
  if(!class_exists('Dennis_WMS_Depot') || Dennis_WMS_Depot::state($order)!=='waiting')return '';
  $place=(string)$order->get_meta('_dennis_wms_depot_place',true);
  return 'I depån'.($place!==''?' – '.$place:'');
 }
 static function reopen() {
  if(!current_user_can(self::CAP)||!current_user_can('edit_shop_orders'))wp_die('Åtkomst nekad.',403);
  $id=isset($_POST['order_id'])?absint(wp_unslash($_POST['order_id'])):0;
  check_admin_referer('dennis_wms_reopen_'.$id);
  $order=self::order($id);
  if(class_exists('Dennis_WMS_Depot') && Dennis_WMS_Depot::state($order)==='waiting')wp_die('Ta först ut ordern ur depån innan arbetet återöppnas.',409);
  if(class_exists('Dennis_WMS_Depot') && Dennis_WMS_Depot::state($order)==='ready')wp_die('Ordern är markerad redo för leverans. Ändra detta arbetsflöde innan återöppning.',409);
  $mode=isset($_POST['reopen_mode'])?sanitize_key(wp_unslash($_POST['reopen_mode'])):'';
  if(!in_array($mode,['pick','pack','both'],true))wp_die('Välj arbetsmoment.',400);
  $pick=self::phase_status($order,'pick');$pack=self::phase_status($order,'pack');
  if($mode==='pick' && $pick!=='done' || $mode==='pack' && ($pack!=='done'||$pick!=='done') || $mode==='both' && ($pick!=='done'||$pack!=='done'))wp_die('Endast avslutade arbetsmoment kan återöppnas.',409);
  $reason=isset($_POST['reopen_reason'])?sanitize_textarea_field(wp_unslash($_POST['reopen_reason'])):'';
  if(trim($reason)===''||mb_strlen($reason)>500)wp_die('Ange en orsak (högst 500 tecken).',400);
  $now=current_time('mysql');$phases=$mode==='both'?['pick','pack']:[$mode];
  $history=$order->get_meta('_dennis_wms_reopen_history',true);if(!is_array($history))$history=[];
  $history[]=['time'=>$now,'user'=>get_current_user_id(),'mode'=>$mode,'reason'=>$reason,'items'=>array_map(function($item){return ['item_id'=>$item->get_id(),'product_id'=>$item->get_product_id(),'variation_id'=>$item->get_variation_id(),'qty'=>$item->get_quantity()];},array_values($order->get_items('line_item'))),'previous'=>['pick'=>['active'=>self::seconds($order,'pick'),'pause'=>self::seconds($order,'pick','pause')],'pack'=>['active'=>self::seconds($order,'pack'),'pause'=>self::seconds($order,'pack','pause')]]];
  $order->update_meta_data('_dennis_wms_reopen_history',$history);
  foreach($phases as $phase){$prefix='_dennis_wms_'.$phase.'_';$order->update_meta_data($prefix.'status','waiting');$order->update_meta_data($prefix.'since',0);$order->update_meta_data($prefix.'finished','');}
  // The prior active/pause totals are deliberately retained; resumed work adds to them.
  // No WooCommerce stock, line item, or order status is changed here.
  $order->save();wp_safe_redirect(self::url($id));exit;
 }
 static function reopen_panel($order) {
  if(!current_user_can('edit_shop_orders'))return;
  $pick=self::phase_status($order,'pick');$pack=self::phase_status($order,'pack');
  if($pick!=='done'&&$pack!=='done')return;
  echo '<div style="background:#fff;border:1px solid #ccd0d4;padding:16px;margin:12px 0;max-width:680px"><h3>Återöppna för komplettering</h3><p>Behåll tidigare plock- och packtid och fortsätt arbetet. Kontrollera orderraderna så att redan plockade varor inte plockas igen. Ingen lagerjustering görs.</p>';
  if(class_exists('Dennis_WMS_Depot') && in_array(Dennis_WMS_Depot::state($order),['waiting','ready'],true)){echo '<p>Ta först ut ordern ur depån (eller hantera statusen Redo för leverans).</p></div>';return;}
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_reopen_'.$order->get_id());
  echo '<input type="hidden" name="action" value="dennis_wms_reopen"><input type="hidden" name="order_id" value="'.esc_attr($order->get_id()).'"><p><label>Återöppna <select name="reopen_mode">';
  if($pick==='done')echo '<option value="pick">Endast plockning</option>';
  if($pack==='done'&&$pick==='done')echo '<option value="pack">Endast packning</option><option value="both">Plockning och packning</option>';
  echo '</select></label></p><p><label>Orsak till komplettering<br><textarea name="reopen_reason" required maxlength="500" rows="2" cols="55"></textarea></label></p><button type="submit" class="button button-primary">Återöppna order</button></form></div>';
  $history=$order->get_meta('_dennis_wms_reopen_history',true);if(is_array($history)&&$history){echo '<h3>Kompletteringshistorik</h3><table class="widefat striped"><thead><tr><th>Tid</th><th>Användare</th><th>Moment</th><th>Orsak</th><th>Tid före återöppning</th></tr></thead><tbody>';foreach(array_reverse($history) as $event){$u=get_userdata((int)($event['user']??0));$previous=$event['previous']??[];echo '<tr><td>'.esc_html($event['time']??'').'</td><td>'.esc_html($u?$u->display_name:'Okänd').'</td><td>'.esc_html($event['mode']??'').'</td><td>'.esc_html($event['reason']??'').'</td><td>'.esc_html('Plock '.self::duration((int)($previous['pick']['active']??0)).' / Pack '.self::duration((int)($previous['pack']['active']??0))).'</td></tr>';}echo '</tbody></table>';}
 }
 static function phase_label($s){return ['waiting'=>'Ej påbörjad','active'=>'Pågår','paused'=>'Pausad','done'=>'Färdig'][$s]??$s;}
 static function pick_status($order) {return self::phase_status($order,'pick');}
 static function phase_status($order,$phase) {
  $v=(string)$order->get_meta('_dennis_wms_'.$phase.'_status',true);
  if($phase==='pick' && $v==='in_progress')return 'active';
  if($phase==='pick' && $v==='picked')return 'done';
  return in_array($v,['active','paused','done'],true)?$v:'waiting';
 }
 static function seconds($order,$phase,$kind='active') {
  $n=max(0,(int)$order->get_meta('_dennis_wms_'.$phase.'_'.$kind.'_seconds',true));
  $status=self::phase_status($order,$phase);
  $since=(int)$order->get_meta('_dennis_wms_'.$phase.'_since',true);
  if($since>0 && (($kind==='active'&&$status==='active')||($kind==='pause'&&$status==='paused'))) $n+=max(0,time()-$since);
  return $n;
 }
 static function duration($n) {return sprintf('%02d:%02d:%02d',floor($n/3600),floor(($n%3600)/60),$n%60);}
 static function save_pick() {
  if(!current_user_can(self::CAP)||!current_user_can('edit_shop_orders'))wp_die('Åtkomst nekad.',403);
  $id=isset($_POST['order_id'])?absint(wp_unslash($_POST['order_id'])):0;
  check_admin_referer('dennis_wms_pick_'.$id);
  $order=self::order($id);
  if(class_exists('Dennis_WMS_Kits')&&($kit_error=Dennis_WMS_Kits::pick_error($order)))wp_die(esc_html($kit_error),409);
  $phase=isset($_POST['phase'])?sanitize_key(wp_unslash($_POST['phase'])):'pick';
  $action=isset($_POST['pick_action'])?sanitize_key(wp_unslash($_POST['pick_action'])):'';
  if(!in_array($phase,['pick','pack'],true))wp_die('Ogiltigt arbetsmoment.',400);
  $status=self::phase_status($order,$phase);
  if(class_exists('Dennis_WMS_Depot') && Dennis_WMS_Depot::state($order)==='waiting')wp_die('Ordern står i depån. Ta ut den innan arbetet fortsätter.',409);
  if($phase==='pack'&&self::phase_status($order,'pick')!=='done')wp_die('Avsluta plockningen först.',409);
  $allowed=['waiting'=>['start'],'active'=>['pause','finish'],'paused'=>['resume','finish'],'done'=>[]];
  if(!in_array($action,$allowed[$status],true))wp_die('Arbetsmomentet har ändrats. Ladda om sidan.',409);
  if($phase==='pick'&&in_array($action,['start','resume','finish'],true)&&class_exists('Dennis_WMS_Product_Packing')){try{Dennis_WMS_Product_Packing::reserve_for_pick($order);}catch(Throwable $e){wp_die(esc_html($e->getMessage()),409);}}
  $now=time();$prefix='_dennis_wms_'.$phase.'_';$since=(int)$order->get_meta($prefix.'since',true);
  if(in_array($status,['active','paused'],true)&&$since>0){$kind=$status==='active'?'active':'pause';$order->update_meta_data($prefix.$kind.'_seconds',max(0,(int)$order->get_meta($prefix.$kind.'_seconds',true))+max(0,$now-$since));}
  $next=['start'=>'active','resume'=>'active','pause'=>'paused','finish'=>'done'][$action];
  $order->update_meta_data($prefix.'status',$next);
  $order->update_meta_data($prefix.'since',$next==='done'?0:$now);
  if($action==='start'){$order->update_meta_data($prefix.'started',current_time('mysql'));$order->update_meta_data($prefix.'user',get_current_user_id());}
  if($action==='finish')$order->update_meta_data($prefix.'finished',current_time('mysql'));
  $order->save();wp_safe_redirect(self::url($id));exit;
 }
 static function form($order,$phase,$action,$label) {
  if(!current_user_can('edit_shop_orders'))return;
  echo '<form style="display:inline-block;margin:4px" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
  wp_nonce_field('dennis_wms_pick_'.$order->get_id());
  echo '<input type="hidden" name="action" value="dennis_wms_pick"><input type="hidden" name="order_id" value="'.esc_attr((string)$order->get_id()).'"><input type="hidden" name="phase" value="'.esc_attr($phase).'"><input type="hidden" name="pick_action" value="'.esc_attr($action).'">';
  echo '<button class="button '.($action==='finish'?'button-primary':'').'" type="submit">'.esc_html($label).'</button></form>';
 }
 static function phase_panel($order,$phase) {
  if(class_exists('Dennis_WMS_Kits')&&($error=Dennis_WMS_Kits::pick_error($order))){echo '<p class="notice notice-error inline">'.esc_html($error).'</p>';return;}
  $status=self::phase_status($order,$phase);$labels=['waiting'=>'Ej påbörjad','active'=>'Pågår','paused'=>'Pausad','done'=>'Färdig'];
  echo '<div style="background:#fff;border:1px solid #ccd0d4;padding:16px;margin:12px 0;max-width:680px"><h3>'.($phase==='pick'?'Plockning':'Packning').' – '.esc_html($labels[$status]).'</h3>';
  echo '<p>Aktiv tid: <strong class="dw-live-time" data-base="'.esc_attr(self::seconds($order,$phase)).'" data-running="'.($status==='active'?'1':'0').'">'.esc_html(self::duration(self::seconds($order,$phase))).'</strong> · Paustid: <strong class="dw-live-time" data-base="'.esc_attr(self::seconds($order,$phase,'pause')).'" data-running="'.($status==='paused'?'1':'0').'">'.esc_html(self::duration(self::seconds($order,$phase,'pause'))).'</strong></p>';
  if(class_exists('Dennis_WMS_Depot') && Dennis_WMS_Depot::state($order)==='waiting'){echo '<p>Ordern står i depån. Arbetsmomentet kan inte ändras förrän den tas ut.</p>';echo '</div>';return;}
  if($status==='waiting')self::form($order,$phase,'start','Starta '.($phase==='pick'?'plock':'pack'));
  if($status==='active'){self::form($order,$phase,'pause','Pausa');self::form($order,$phase,'finish','Avsluta '.($phase==='pick'?'plock':'pack'));}
  if($status==='paused'){self::form($order,$phase,'resume','Återuppta');self::form($order,$phase,'finish','Avsluta '.($phase==='pick'?'plock':'pack'));}
  echo '<p class="description">Start: '.esc_html((string)$order->get_meta('_dennis_wms_'.$phase.'_started',true)).' · Slut: '.esc_html((string)$order->get_meta('_dennis_wms_'.$phase.'_finished',true)).'</p></div>';
 }
 static function pick_allocation($pid,$qty){if(!class_exists('Dennis_WMS_Batches'))return ['rows'=>[['batch'=>'','expiry'=>'','location'=>self::location($pid),'qty'=>$qty]],'missing'=>0];global $wpdb;$table=Dennis_WMS_Batches::table('balances');$registered=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE product_id=%d",$pid));if(!$registered)return ['rows'=>[['batch'=>'','expiry'=>'','location'=>self::location($pid),'qty'=>$qty]],'missing'=>0];return Dennis_WMS_Batches::allocate($pid,$qty);}
 static function sku_separator($sku,&$previous,$columns){if($previous!==null&&$previous!==$sku)echo '<tr class="dw-sku-divider" aria-hidden="true"><td colspan="'.(int)$columns.'" style="padding:0;height:12px;border:0;border-bottom:3px solid #1D949C;background:#fff"></td></tr>';$previous=$sku;}
 static function product_label_html($row){
  if(!empty($row['accompanying_group'])){
   $kit=(string)($row['kit_parent_name']??'Kit');$component=(string)($row['name']??'');
   return '<strong>'.esc_html($kit).'</strong><br><span>'.esc_html($component).' · medföljande</span>'.(isset($row['kit_component_per'])?'<br><small>'.esc_html((string)$row['kit_component_per']).' st per kit</small>':'');
  }
  return '<strong>'.esc_html((string)($row['name']??'')).'</strong>';
 }
 static function kit_header_html($row,$print=false){
  if(empty($row['accompanying_group']))return '';
  $name=(string)($row['kit_parent_name']??'Kit');$sku=(string)($row['kit_parent_sku']??'');$qty=(float)($row['kit_order_qty']??0);
  $qty_text=((float)(int)$qty===$qty)?(string)(int)$qty:(string)$qty;
  $style=$print?'padding:12px 14px;background:#eaf7f7;border:1px solid #9fcfd2;border-left:6px solid #1D949C;border-radius:8px':'padding:14px 16px;background:#eaf7f7;border:1px solid #b7dcde;border-left:6px solid #1D949C;border-radius:10px';
  return '<div class="dw-kit-pick-header" style="'.$style.'"><strong style="font-size:16px">▦ KIT · '.esc_html($name).'</strong>'.($sku!==''?' <span style="color:#53646f">('.esc_html($sku).')</span>':'').'<div style="margin-top:4px"><strong>'.$qty_text.' kit beställda</strong> · Plocka komponenterna nedan.</div></div>';
 }
 static function rows($order) {
  echo '<table class="widefat striped"><thead><tr><th>Bild</th><th>Produkt</th><th>SKU</th><th>Antal</th><th>Batch</th><th>Expire date</th><th>Lagerplats</th><th>Plockordning</th></tr></thead><tbody>';
  $previous_sku=null;$current_kit=null;foreach(self::items($order) as $row) {
   $kit_group=!empty($row['accompanying_group'])?(string)$row['accompanying_group']:'';if($kit_group!==''&&$kit_group!==$current_kit){echo '<tr class="dw-kit-header-row"><td colspan="8">'.self::kit_header_html($row).'</td></tr>';$current_kit=$kit_group;}elseif($kit_group===''){$current_kit=null;}
   self::sku_separator(!empty($row['accompanying_group'])?'kit:'.$row['accompanying_group']:'sku:'.$row['sku'],$previous_sku,8);
   $alloc=$row['kit_allocation']??self::pick_allocation($row['product_id'],$row['qty']);
   if(!empty($alloc['rows'])){foreach($alloc['rows'] as $i=>$a){echo '<tr><td>'.($i===0?self::image_html(self::pick_row_image($row),$row['name']):'').'</td><td>'.($i===0?self::product_label_html($row):'↳ samma SKU').'</td><td>'.($i===0?esc_html($row['sku']).self::pick_barcode_html($row):'').'</td><td><strong style="font-size:20px">PLOCKA '.esc_html((string)$a['qty']).' ST</strong></td><td>'.esc_html($a['batch']?:'–').'</td><td>'.esc_html($a['expiry']?:'–').'</td><td>'.esc_html($a['location']?:($row['location']?:'Ej angiven')).'</td><td>'.($i===0?'<span class="dw-status dw-status-blue">Plockordning</span>':'').'</td></tr>';}}
   if((float)$alloc['missing']>0)echo '<tr style="background:#fff5f7"><td>'.(empty($alloc['rows'])?self::image_html(self::pick_row_image($row),$row['name']):'').'</td><td>'.(empty($alloc['rows'])?esc_html($row['name']):'↳ återstående').'</td><td>'.(empty($alloc['rows'])?esc_html($row['sku']).self::pick_barcode_html($row):'').'</td><td><strong>'.esc_html((string)$alloc['missing']).'</strong></td><td colspan="3">Saknas i Dennis WMS batchsaldo – kontrollera batch/expire date</td><td>⚠</td></tr>';
   if(empty($row['accompanying_group'])&&(!empty($row['packing_instruction'])||!empty($row['kit_instruction'])))echo '<tr class="dw-packing-info-row"><td></td><td colspan="7">'.self::packing_html($row).'</td></tr>';
   if(!empty($row['purchase_note']))echo '<tr class="dw-purchase-note-row"><td></td><td colspan="7">'.self::purchase_note_html($row['purchase_note']).'</td></tr>';
  }
  echo '</tbody></table>';
 }
 static function shipping_key($order) {
  // Normalise the delivery address so harmless differences in case/spacing do not prevent a match.
  $parts=[
   $order->get_shipping_address_1() ?: $order->get_billing_address_1(),
   $order->get_shipping_address_2() ?: $order->get_billing_address_2(),
   $order->get_shipping_postcode() ?: $order->get_billing_postcode(),
   $order->get_shipping_city() ?: $order->get_billing_city(),
   $order->get_shipping_country() ?: $order->get_billing_country(),
  ];
  $parts=array_map(function($v){$v=remove_accents(wp_strip_all_tags((string)$v));$v=strtolower(trim(preg_replace('/\\s+/u',' ',$v)));return $v;},$parts);
  return implode('|',$parts);
 }
 static function shipping_label($order) {
  $a=$order->get_shipping_address_1() ?: $order->get_billing_address_1();
  $p=$order->get_shipping_postcode() ?: $order->get_billing_postcode();
  $c=$order->get_shipping_city() ?: $order->get_billing_city();
  return trim($a.', '.trim($p.' '.$c),' ,');
 }
 static function group_ids_from_request() {
  $raw=isset($_GET['pack_group'])?sanitize_text_field(wp_unslash($_GET['pack_group'])):'';
  $ids=array_values(array_unique(array_filter(array_map('absint',explode(',',$raw)))));
  return array_slice($ids,0,20);
 }
 static function group_url($ids) {return add_query_arg(['page'=>'dennis-wms-orders','pack_group'=>implode(',',array_map('absint',$ids))],admin_url('admin.php'));}
 static function group_order_splits($order_rows,$chunks) {
  $queue=[];foreach($order_rows as $r){$q=(float)($r['qty']??0);if($q>0)$queue[]=['label'=>(string)($r['label']??''),'qty'=>$q];}
  $out=[];$idx=0;$left=$queue?($queue[0]['qty']??0):0;
  foreach($chunks as $chunk){$need=(float)$chunk;$parts=[];while($need>0.00001&&$idx<count($queue)){$take=min($need,$left);if($take>0){$shown=(abs($take-round($take))<0.00001)?(string)(int)round($take):wc_format_localized_decimal($take);$parts[]=$queue[$idx]['label'].' × '.$shown;$need-=$take;$left-=$take;}if($left<=0.00001){$idx++;$left=$idx<count($queue)?(float)$queue[$idx]['qty']:0;}}$out[]=implode(' · ',$parts);}
  return $out;
 }
 static function render_group($ids) {
  $orders=[];foreach($ids as $id){$o=wc_get_order($id);if($o&&is_a($o,'WC_Order'))$orders[]=$o;}
  if(count($orders)<2){echo '<div class="notice notice-warning"><p>Sampackningsgruppen kunde inte öppnas.</p></div>';return;}
  $key=self::shipping_key($orders[0]);foreach($orders as $o){if(self::shipping_key($o)!==$key){echo '<div class="notice notice-error"><p>Orderna har inte längre samma leveransadress och kan därför inte visas som en sampackningsgrupp.</p></div>';return;}}
  $nums=array_map(fn($o)=>'#'.$o->get_order_number(),$orders);$address=self::shipping_label($orders[0]);
  echo '<div class="dw-pack-group"><div style="background:#fff;border:1px solid #e2e8f0;border-left:5px solid #1D949C;border-radius:12px;padding:18px;margin:16px 0"><h2 style="margin-top:0">📦 Sampackning – '.esc_html(implode(' + ',$nums)).'</h2><p><strong>Leveransadress:</strong> '.esc_html($address).'</p><p>Orderna är fortfarande separata i WooCommerce. Den här vyn kombinerar bara plock och packning.</p><a class="button button-primary" target="_blank" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=dennis_wms_group_print&ids='.implode(',',$ids)),'dennis_wms_group_print_'.implode('_',$ids))).'">Skriv ut gemensam plocklista</a></div>';
  $agg=self::group_items($orders);
  echo '<table class="widefat striped"><thead><tr><th>Bild</th><th>Produkt</th><th>SKU</th><th>Antal</th><th>Batch</th><th>Expire date</th><th>Lagerplats</th><th>Orderfördelning</th></tr></thead><tbody>';
  $previous_sku=null;foreach($agg as $r){self::sku_separator(!empty($r['accompanying_group'])?'kit:'.$r['accompanying_group']:'sku:'.$r['sku'],$previous_sku,8);
   $alloc=$r['kit_allocation']??self::pick_allocation($r['product_id'],$r['qty']);
   $chunks=array_map(fn($a)=>(float)$a['qty'],$alloc['rows']);if((float)$alloc['missing']>0)$chunks[]=(float)$alloc['missing'];$splits=self::group_order_splits($r['orders'],$chunks);$si=0;$first=true;
   foreach($alloc['rows'] as $a){$dist=$splits[$si++]??'';echo '<tr><td>'.($first?self::image_html(self::pick_row_image($r),$r['name']):'').'</td><td>'.($first?esc_html($r['name']):'↳ samma SKU').'</td><td>'.($first?'<strong>'.esc_html($r['sku']).'</strong>'.self::pick_barcode_html($r):'').'</td><td><strong>'.esc_html((string)$a['qty']).'</strong></td><td>'.esc_html($a['batch']?:'–').'</td><td>'.esc_html($a['expiry']?:'–').'</td><td>'.esc_html($a['location']?:($r['location']?:'Ej angiven')).'</td><td>'.esc_html($dist).'</td></tr>';$first=false;}
   if($alloc['missing']>0){$dist=$splits[$si]??'';echo '<tr style="background:#fff5f7"><td>'.($first?self::image_html(self::pick_row_image($r),$r['name']):'').'</td><td>'.($first?esc_html($r['name']):'↳ återstående').'</td><td>'.($first?esc_html($r['sku']).self::pick_barcode_html($r,true):'').'</td><td><strong>'.esc_html((string)$alloc['missing']).'</strong></td><td colspan="3">Saknas i batchsaldo</td><td>'.esc_html($dist).' ⚠</td></tr>';}
   if(!empty($r['packing_instruction'])||!empty($r['kit_instruction']))echo '<tr class="dw-packing-info-row"><td></td><td colspan="7">'.self::packing_html($r).'</td></tr>';
   if(!empty($r['purchase_note']))echo '<tr><td></td><td colspan="7">'.self::purchase_note_html($r['purchase_note']).'</td></tr>';
  }
  echo '</tbody></table><h3>Order i gruppen</h3><p>';foreach($orders as $o)echo '<a class="button" style="margin:0 6px 6px 0" href="'.esc_url(self::url($o->get_id())).'">Öppna #'.esc_html($o->get_order_number()).'</a>';echo '</p></div>';
 }
 static function print_group() {
  if(!current_user_can(self::CAP))wp_die('Åtkomst nekad.',403);
  $raw=isset($_GET['ids'])?sanitize_text_field(wp_unslash($_GET['ids'])):'';$ids=array_values(array_unique(array_filter(array_map('absint',explode(',',$raw)))));$ids=array_slice($ids,0,20);
  check_admin_referer('dennis_wms_group_print_'.implode('_',$ids));if(count($ids)<2)wp_die('Minst två order krävs.',400);
  $orders=[];foreach($ids as $id){$o=wc_get_order($id);if($o)$orders[]=$o;}if(count($orders)<2)wp_die('Order saknas.',404);
  $key=self::shipping_key($orders[0]);foreach($orders as $o)if(self::shipping_key($o)!==$key)wp_die('Orderna har inte samma leveransadress.',409);
  $agg=self::group_items($orders);
  nocache_headers();header('Content-Type:text/html; charset='.get_option('blog_charset'));$nums=array_map(fn($o)=>'#'.$o->get_order_number(),$orders);
  echo '<!doctype html><html lang="sv"><head><meta charset="utf-8"><title>Sampackning '.esc_html(implode(' + ',$nums)).'</title><style>body{font:14px Arial;margin:24px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #777;padding:9px;text-align:left}th{background:#eee}@media print{button{display:none}}</style></head><body><button onclick="window.print()">Skriv ut</button><h1>Dennis WMS – Sampackning</h1><p><strong>Order:</strong> '.esc_html(implode(' + ',$nums)).'<br><strong>Adress:</strong> '.esc_html(self::shipping_label($orders[0])).'</p><table><thead><tr><th>Bild</th><th>Produkt</th><th>SKU</th><th>Antal</th><th>Batch</th><th>Expire date</th><th>Lagerplats</th><th>Orderfördelning</th><th>✓</th></tr></thead><tbody>';
  $previous_sku=null;foreach($agg as $r){self::sku_separator(!empty($r['accompanying_group'])?'kit:'.$r['accompanying_group']:'sku:'.$r['sku'],$previous_sku,9);
   $alloc=$r['kit_allocation']??self::pick_allocation($r['product_id'],$r['qty']);
   $chunks=array_map(fn($a)=>(float)$a['qty'],$alloc['rows']);if((float)$alloc['missing']>0)$chunks[]=(float)$alloc['missing'];$splits=self::group_order_splits($r['orders'],$chunks);$si=0;$first=true;
   foreach($alloc['rows'] as $a){$dist=$splits[$si++]??'';echo '<tr><td>'.($first?self::image_html(self::pick_row_image($r),$r['name'],true):'').'</td><td>'.($first?esc_html($r['name']):'↳ samma SKU').'</td><td>'.($first?esc_html($r['sku']).self::pick_barcode_html($r,true):'').'</td><td>'.esc_html((string)$a['qty']).'</td><td>'.esc_html($a['batch']?:'–').'</td><td>'.esc_html($a['expiry']?:'–').'</td><td>'.esc_html($a['location']?:($r['location']?:'Ej angiven')).'</td><td>'.esc_html($dist).'</td><td>□</td></tr>';$first=false;}
   if($alloc['missing']>0){$dist=$splits[$si]??'';echo '<tr><td>'.($first?self::image_html(self::pick_row_image($r),$r['name'],true):'').'</td><td>'.($first?esc_html($r['name']):'↳ återstående').'</td><td>'.($first?esc_html($r['sku']).self::pick_barcode_html($r,true):'').'</td><td>'.esc_html((string)$alloc['missing']).'</td><td colspan="3">Saknas i batchsaldo</td><td>'.esc_html($dist).'</td><td>⚠</td></tr>';}
   if(!empty($r['packing_instruction'])||!empty($r['kit_instruction']))echo '<tr class="dw-packing-info-row"><td></td><td colspan="8">'.self::packing_html($r,true).'</td></tr>';
   if(!empty($r['purchase_note']))echo '<tr><td></td><td colspan="8">'.self::purchase_note_html($r['purchase_note'],true).'</td></tr>';
  }
  echo '</tbody></table>';self::print_packaging_suggestions($orders);echo '<p>Packad/kontrollerad av: __________________</p></body></html>';exit;
 }
 static function completed_orders(){
  $page=max(1,absint($_GET['orders_page']??1));$result=wc_get_orders(['status'=>['completed'],'limit'=>25,'page'=>$page,'paginate'=>true,'orderby'=>'date','order'=>'DESC','return'=>'objects']);
  echo '<p>Order med WooCommerce-status Slutförd (completed). Senaste order visas först.</p><table class="widefat striped"><thead><tr><th>Order</th><th>Kund / beställare</th><th>Leveransadress</th><th>Slutförd</th><th>Artiklar</th><th></th></tr></thead><tbody>';
  foreach($result->orders as $order){$date=$order->get_date_completed();echo '<tr><td><strong>#'.esc_html($order->get_order_number()).'</strong></td><td>'.esc_html($order->get_formatted_billing_full_name()).'</td><td>'.esc_html(self::shipping_label($order)).'</td><td>'.esc_html($date?$date->date_i18n('Y-m-d H:i'):'–').'</td><td>'.esc_html(count($order->get_items('line_item'))).'</td><td><a class="button" href="'.esc_url(add_query_arg('orders_tab','completed',self::url($order->get_id()))).'">Visa order / plocklista</a></td></tr>';}
  if(!$result->orders)echo '<tr><td colspan="6">Inga slutförda order.</td></tr>';echo '</tbody></table><p>';
  if($page>1)echo '<a class="button" href="'.esc_url(add_query_arg(['orders_tab'=>'completed','orders_page'=>$page-1,'dw_shop'=>$dw_shop_choice],self::url())).'">Föregående</a> ';
  if($page<(int)$result->max_num_pages)echo '<a class="button" href="'.esc_url(add_query_arg(['orders_tab'=>'completed','orders_page'=>$page+1,'dw_shop'=>$dw_shop_choice],self::url())).'">Nästa</a>';echo '</p>';
 }
 static function page() {
  if (!current_user_can(self::CAP)) wp_die('Åtkomst nekad.',403);
  echo '<div class="wrap"><h1>Dennis WMS – Ordrar</h1>';
  $completed=($_GET['orders_tab']??'')==='completed';echo '<nav class="nav-tab-wrapper"><a class="nav-tab '.(!$completed?'nav-tab-active':'').'" href="'.esc_url(self::url()).'">Pågående order</a><a class="nav-tab '.($completed?'nav-tab-active':'').'" href="'.esc_url(add_query_arg('orders_tab','completed',self::url())).'">Slutförda order</a></nav>';
  if (!function_exists('wc_get_orders')) {echo '<p>WooCommerce måste vara aktivt.</p></div>';return;}
  $dw_shop_choice=sanitize_text_field(wp_unslash($_GET['dw_shop']??'all'));
  $dw_remote_shop=ctype_digit($dw_shop_choice)?absint($dw_shop_choice):0;
  $dw_local_only=$dw_shop_choice==='central';
  $dw_hide_local=$dw_remote_shop>0;
  if(empty($_GET['order_id'])&&empty($_GET['pack_group'])){
   echo '<form method="get" style="margin:14px 0"><input type="hidden" name="page" value="dennis-wms-orders"><input type="hidden" name="orders_tab" value="'.($completed?'completed':'').'"><label><strong>Filtrera per shop </strong><select name="dw_shop"><option value="all" '.selected($dw_shop_choice,'all',false).'>Alla shoppar</option><option value="central" '.selected($dw_shop_choice,'central',false).'>Huvudshop (lokal)</option>';
   if(class_exists('Dennis_WMS_Multi_Shop'))foreach(Dennis_WMS_Multi_Shop::shops() as $dw_shop)echo '<option value="'.esc_attr($dw_shop->id).'" '.selected($dw_shop_choice,(string)$dw_shop->id,false).'>'.esc_html($dw_shop->name).'</option>';
   echo '</select></label> <button class="button button-primary">Visa order</button></form>';
  }
  if($completed&&empty($_GET['order_id'])){if(!$dw_hide_local)self::completed_orders();else echo '<p>Slutförda order från anslutna shoppar visas ännu inte i detta filter. Ingen orderdata har ändrats.</p>';echo '</div>';return;}
  $group_ids=self::group_ids_from_request(); if(count($group_ids)>1){self::render_group($group_ids);echo '</div>';return;}
  echo '<p>Order hämtas från WooCommerce. Lagerplatser hämtas från Dennis WMS när ordern öppnas eller skrivs ut. Plockstatus sparas separat och ändrar varken WooCommerce-orderstatus eller lagersaldo.</p>';
  $id=isset($_GET['order_id'])?absint(wp_unslash($_GET['order_id'])):0;
  if ($id) {
   // v1.5.7: opening an order is deliberately read-only. Record raw WooCommerce/DB snapshots
   // before and after rendering so we can prove whether the order still exists.
   Dennis_WMS_Order_Debug::open_begin($id);
   Dennis_WMS_Order_Debug::watch_shutdown($id);
   $order=self::order($id);
   Dennis_WMS_Order_UI::render($order);
   Dennis_WMS_Order_Debug::open_after_render($id);
   echo '<div class="notice notice-info inline"><p><strong>Order Debug aktiv:</strong> öppningen har loggats före och efter plocklistan. Se <a href="'.esc_url(admin_url('admin.php?page=dennis-wms-order-debug')).'">Dennis WMS → Order Debug</a>.</p></div>';
   echo '<script>document.addEventListener("DOMContentLoaded",function(){var nodes=document.querySelectorAll(".dw-live-time");var origin=Date.now();function fmt(n){return [Math.floor(n/3600),Math.floor(n%3600/60),n%60].map(x=>String(x).padStart(2,"0")).join(":")}function tick(){nodes.forEach(function(el){var n=Number(el.dataset.base)+(el.dataset.running==="1"?Math.floor((Date.now()-origin)/1000):0);el.textContent=fmt(n)})}tick();setInterval(tick,1000)});</script>';
  } else {
   $page=isset($_GET['orders_page'])?max(1,absint($_GET['orders_page'])):1;
   $all_orders=$dw_hide_local?[]:wc_get_orders(['status'=>['processing','on-hold'],'limit'=>-1,'orderby'=>'date','order'=>'ASC','return'=>'objects']);if(class_exists('Dennis_WMS_Preorders'))$all_orders=Dennis_WMS_Preorders::filter_pickable_orders($all_orders);if(class_exists('Dennis_WMS_Deadline'))usort($all_orders,function($a,$b){$av=Dennis_WMS_Deadline::sort_value($a);$bv=Dennis_WMS_Deadline::sort_value($b);if($av===$bv){$ad=$a->get_date_created();$bd=$b->get_date_created();return ($ad?$ad->getTimestamp():0)<=>($bd?$bd->getTimestamp():0);}return $av<=>$bv;});$per_page=25;$total_orders=count($all_orders);$max_pages=max(1,(int)ceil($total_orders/$per_page));$page=min($page,$max_pages);$page_orders=array_slice($all_orders,($page-1)*$per_page,$per_page);$result=(object)['orders'=>$page_orders,'max_num_pages'=>$max_pages];
   if(class_exists('Dennis_WMS_Deadline')){$dc=Dennis_WMS_Deadline::dashboard_counts();echo '<div class="notice notice-info inline dw-deadline-legend" style="padding:12px 14px">'
    .'<div class="dw-deadline-summary"><strong>⏱ Deadlinebevakning</strong><span>🟡 '.absint($dc['today']).' Skickas idag</span><span>🔴 '.absint($dc['urgent']).' Brådskande</span><span>🚨 '.absint($dc['overdue']).' Försenade</span><small>Närmast deadline visas först</small></div>'
    .'<div class="dw-deadline-title"><strong>Förklaring</strong></div>'
    .'<div class="dw-deadline-grid">'
      .'<div>🟢 <strong>I tid</strong><small>Före kl. 12:00: försök skicka senast kl. 12:00 samma dag. Från kl. 12:00: deadline nästa dag kl. 12:00.</small></div>'
      .'<div>🟡 <strong>Skickas idag</strong><small>Deadline är idag kl. 12:00.</small></div>'
      .'<div>🔴 <strong>Brådskande</strong><small>Deadline närmar sig.</small></div>'
      .'<div>🚨 <strong>Försenad</strong><small>Deadline har passerat.</small></div>'
      .'<div>🟣 <strong>Undantag</strong><small>Ordern har fått ett annat skickdatum.</small></div>'
      .'<div>✅ <strong>Skickad i tid</strong><small>Skickad före deadline.</small></div>'
      .'<div>⚠️ <strong>Skickad för sent</strong><small>Skickad efter deadline.</small></div>'
    .'</div>'
    .'<div class="dw-deadline-rule"><strong>Standardregel:</strong> Order som kommer in <strong>före kl. 12:00</strong> försöker vi skicka senast kl. <strong>12:00 samma dag</strong>. Order som kommer in <strong>från kl. 12:00</strong> ska skickas senast kl. <strong>12:00 nästa dag</strong>. Ett annat datum kan anges via <strong>Undantag</strong>.</div>'
    .'</div>';}
   echo '<p>Order med samma normaliserade leveransadress grupperas automatiskt på samma rad som en <strong>möjlig sampackning</strong>. Inga WooCommerce-order slås ihop eller ändras.</p>';
   $groups=[];foreach($result->orders as $order){$k=self::shipping_key($order);if($k==='||||')$k='order-'.$order->get_id();$groups[$k][]=$order;}
   echo '<table class="widefat striped"><thead><tr><th>Order</th><th>Leveransadress</th><th>Datum</th><th>Deadline</th><th>Status</th><th>Plock / Pack</th><th>Artiklar</th><th></th></tr></thead><tbody>';
   foreach($groups as $orders){$first=$orders[0];$is_group=count($orders)>1;$ids=array_map(fn($o)=>$o->get_id(),$orders);$nums=array_map(fn($o)=>'#'.$o->get_order_number(),$orders);$items=0;foreach($orders as $o)$items+=count($o->get_items('line_item'));
    echo '<tr'.($is_group?' class="dw-sampack-row" style="background:#f0fffd"':'').'>';
    echo '<td>'.($is_group?'<span style="display:inline-block;background:#ff4fa3;color:#fff;border-radius:999px;padding:3px 8px;font-weight:700;margin-right:6px">SAMPACKA</span>':'').'<strong>'.esc_html(implode(' + ',$nums)).'</strong></td>';
    echo '<td>'.esc_html(self::shipping_label($first)?:'Adress saknas').'</td><td>'.esc_html($first->get_date_created()?$first->get_date_created()->date_i18n('Y-m-d H:i'):'–').'</td><td>';if(class_exists('Dennis_WMS_Deadline')){if($is_group){foreach($orders as $o)echo '<div style="margin-bottom:4px"><strong>#'.esc_html($o->get_order_number()).'</strong> '.Dennis_WMS_Deadline::badge('local',$o->get_id(),$o).'</div>';}else echo Dennis_WMS_Deadline::badge('local',$first->get_id(),$first);}else echo '–';echo '</td><td>';if($is_group){foreach($orders as $o){$ws=class_exists('Dennis_WMS_Delivery')?Dennis_WMS_Delivery::workflow_label('local',$o->get_id(),$o):wc_get_order_status_name($o->get_status());echo '<div><strong>#'.esc_html($o->get_order_number()).':</strong> '.esc_html($ws).'</div>';}}else{$ws=class_exists('Dennis_WMS_Delivery')?Dennis_WMS_Delivery::workflow_label('local',$first->get_id(),$first):wc_get_order_status_name($first->get_status());echo '<strong>'.esc_html($ws).'</strong>';if(class_exists('Dennis_WMS_Delivery')){$dr=Dennis_WMS_Delivery::record('local',$first->get_id());if($dr&&$dr->method)echo '<br><small>Leverans: '.esc_html(Dennis_WMS_Delivery::label_method($dr->method)).' · '.esc_html(Dennis_WMS_Delivery::label_status($dr->status)).'</small>';}echo '<br><small>WooCommerce: '.esc_html(wc_get_order_status_name($first->get_status())).'</small>';}echo '</td><td>';
    if($is_group){foreach($orders as $o)echo '<div>'.esc_html('#'.$o->get_order_number().': '.(self::depot_label($o)?:'Plock: '.self::phase_label(self::pick_status($o)).' · Pack: '.self::phase_label(self::phase_status($o,'pack')))).'</div>';}else echo esc_html(self::depot_label($first)?:'Plock: '.self::phase_label(self::pick_status($first)).' · Pack: '.self::phase_label(self::phase_status($first,'pack')));
    echo '</td><td>'.esc_html((string)$items).'</td><td>';
    if($is_group)echo '<a class="button button-primary" href="'.esc_url(self::group_url($ids)).'">Öppna sampackning</a>';
    else echo '<a class="button" href="'.esc_url(self::url($first->get_id())).'">Öppna / plocklista</a>';
    echo '</td></tr>';
   }
   if (!$result->orders) echo '<tr><td colspan="8">Inga order med status Behandlas eller Väntande.</td></tr>';
   echo '</tbody></table><p>';
   if($page>1) echo '<a class="button" href="'.esc_url(add_query_arg(['page'=>'dennis-wms-orders','orders_page'=>$page-1,'dw_shop'=>$dw_shop_choice],admin_url('admin.php'))).'">Föregående</a> ';
   if($page<(int)$result->max_num_pages) echo '<a class="button" href="'.esc_url(add_query_arg(['page'=>'dennis-wms-orders','orders_page'=>$page+1,'dw_shop'=>$dw_shop_choice],admin_url('admin.php'))).'">Nästa</a>';
   echo '</p>';
   if(class_exists('Dennis_WMS_Multi_Shop')) if(!$dw_local_only)Dennis_WMS_Multi_Shop::render_remote_orders($dw_remote_shop);
  }
  echo '</div>';
 }
 static function print_packaging_suggestions($orders) {
  if (!class_exists('Dennis_WMS_Packaging_Materials')) return;
  $materials=Dennis_WMS_Packaging_Materials::all();
  if (!$materials) return;
  echo '<style>
  .dw-print-packaging{margin:22px 0 16px;padding:16px;border:1px solid #dbe4eb;border-radius:12px;background:#fff;color:#243347;break-inside:avoid}
  .dw-print-packaging *{box-sizing:border-box}
  .dw-print-packaging .dw-pm-head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px}
  .dw-print-packaging .dw-pm-head h2{font-size:17px!important;line-height:1.25;margin:0!important;color:#14283e}
  .dw-print-packaging .dw-pm-tag{font-size:11px;font-weight:700;color:#245c8e;background:#edf5fd;border-radius:999px;padding:5px 9px;white-space:nowrap}
  .dw-print-packaging .dw-pm-guide{background:#f2f6f9;border-left:3px solid #4a83ad;border-radius:7px;padding:10px 12px;margin:0 0 12px;font-size:12px;line-height:1.55}
  .dw-print-packaging .dw-pm-guide p{margin:0 0 6px!important;color:#364c62}
  .dw-print-packaging .dw-pm-guide ol{margin:0 0 5px 18px;padding:0;display:grid;gap:2px}
  .dw-print-packaging .dw-pm-guide li{padding-left:2px}
  .dw-print-packaging .dw-pm-guide small{display:block;color:#5b6e80;font-size:11px}
  .dw-print-packaging table{width:100%;border-collapse:collapse;font-size:12px;table-layout:auto}
  .dw-print-packaging th{background:#eaf0f4!important;color:#364b60;font-size:10px;text-transform:uppercase;letter-spacing:.04em;padding:9px 8px!important;text-align:left;border-bottom:1px solid #d9e2e9}
  .dw-print-packaging td{padding:10px 8px!important;border-bottom:1px solid #e5ebf0;vertical-align:middle}
  .dw-print-packaging tr:last-child td{border-bottom:0}
  .dw-print-packaging .dw-pm-qty{font-weight:700;white-space:nowrap}
  .dw-print-packaging .dw-pm-status{font-size:11px;font-weight:700;white-space:nowrap}
  .dw-print-packaging .dw-pm-status.is-saved{color:#157451}
  .dw-print-packaging .dw-pm-status.is-suggested{color:#7b5c1b}
  .dw-print-packaging .dw-pm-check{font-size:19px;text-align:center;line-height:1}
  .dw-print-packaging .dw-pm-order{font-size:13px;margin:13px 0 7px;color:#14283e}
  @media print{.dw-print-packaging{padding:10px;border-radius:0;margin:14px 0;break-inside:auto}.dw-print-packaging .dw-pm-guide{padding:7px 10px}.dw-print-packaging th,.dw-print-packaging td{padding:6px!important}.dw-print-packaging tr{break-inside:avoid}.dw-print-packaging .dw-pm-tag{border:1px solid #d6e2ed}}
  </style>';
  echo '<section class="dw-print-packaging"><div class="dw-pm-head"><h2>Föreslaget packmaterial</h2><span class="dw-pm-tag">Endast rekommendation</span></div>';
  echo '<div class="dw-pm-guide"><p>Förslag utifrån liknande tidigare order. <strong>Den som packar ansvarar för att kontrollera och registrera rätt material.</strong></p><ol><li><strong>Kontrollera</strong> vilket packmaterial som behövs.</li><li><strong>Lägg till, ta bort eller ändra antal</strong> i WMS så att det motsvarar det som faktiskt används.</li><li><strong>Spara användningen</strong> i WMS – då förbättras framtida förslag.</li></ol><small>Utskriften ändrar inget lagersaldo. Saldot uppdateras först när användningen registreras och sparas.</small></div>';
  $found=false;
  foreach ($orders as $order) {
   $suggestions=Dennis_WMS_Packaging_Materials::suggestions($order,$materials);
   $usage=Dennis_WMS_Packaging_Materials::usage($order);
   $used=[];foreach ($usage as $u) { if (!empty($u['id']) && (int)($u['qty']??0)>0) $used[(string)$u['id']]=(int)$u['qty']; }
   $rows=[];
   foreach ($materials as $material) {
    $id=(string)($material['id']??'');
    $is_used=isset($used[$id]);
    $qty=$is_used?$used[$id]:(int)($suggestions[$id]['qty']??0);
    if ($qty<=0) continue;
    $rows[]=[$material,$qty,$is_used];
   }
   if (!$rows) continue;
   $found=true;
   if (count($orders)>1) echo '<h3 class="dw-pm-order">Order #'.esc_html($order->get_order_number()).'</h3>';
   echo '<table><thead><tr><th>Material</th><th>Typ</th><th>Antal (förslag)</th><th>Lagerplats</th><th>Status</th><th>✓</th></tr></thead><tbody>';
   foreach ($rows as $row) { [$material,$qty,$is_used]=$row;
    echo '<tr><td><strong>'.esc_html($material['name']??'–').'</strong></td><td>'.esc_html($material['type']??'–').'</td><td><strong>'.esc_html((string)$qty).' st</strong></td><td>'.esc_html(($material['location']??'')?:'Ej angiven').'</td><td>'.($is_used?'Registrerat':'Förslag').'</td><td>□</td></tr>';
   }
   echo '</tbody></table>';
  }
  if (!$found) echo '<p>Inget packmaterial kan föreslås ännu utifrån tidigare order.</p>';
  echo '</section>';
 }
 static function print_pick() {
  if (!current_user_can(self::CAP)) wp_die('Åtkomst nekad.',403);
  $id=isset($_GET['order_id'])?absint(wp_unslash($_GET['order_id'])):0;
  check_admin_referer('dennis_wms_print_'.$id);
  $order=self::order($id);
  $customer=trim($order->get_shipping_first_name().' '.$order->get_shipping_last_name());
  if($customer==='')$customer=trim($order->get_billing_first_name().' '.$order->get_billing_last_name());
  $address=self::shipping_label($order);
  $method=$order->get_shipping_method();
  nocache_headers(); header('Content-Type: text/html; charset='.get_option('blog_charset'));
  echo '<!doctype html><html lang="sv"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dennis WMS – Plocklista #'.esc_html($order->get_order_number()).'</title><style>
  *{box-sizing:border-box}body{font:14px -apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;margin:0;background:#f4f7f9;color:#17212b}.page{max-width:1180px;margin:24px auto;background:#fff;border-radius:16px;box-shadow:0 8px 30px rgba(0,0,0,.08);overflow:hidden}.head{padding:24px 28px;background:linear-gradient(135deg,#17212b,#263746);color:#fff;display:flex;justify-content:space-between;gap:24px}.brand{font-size:24px;font-weight:800}.brand span{color:#f05a9d}.brand b{color:#28d0c7}.order{font-size:30px;font-weight:800;text-align:right}.meta{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;padding:18px 28px;background:#f8fafb;border-bottom:1px solid #e6ebef}.meta div{background:#fff;border:1px solid #e4e9ed;border-radius:10px;padding:10px 12px}.meta small{display:block;color:#667786;margin-bottom:3px}.content{padding:22px 28px}table{border-collapse:separate;border-spacing:0;width:100%;border:1px solid #dfe5e9;border-radius:12px;overflow:hidden}th{background:#eef3f5;color:#40515f;font-size:12px;text-transform:uppercase;letter-spacing:.04em}th,td{padding:11px 9px;text-align:left;border-bottom:1px solid #e8edef;vertical-align:middle}tr:last-child td{border-bottom:0}.qty{font-size:18px;font-weight:800}.check{width:34px;height:34px;border:2px solid #71808c;border-radius:7px;display:inline-block}.footer{display:flex;justify-content:space-between;gap:20px;margin-top:24px;padding-top:16px;border-top:1px solid #dfe5e9}.sign{min-width:260px;border-bottom:1px solid #6b7780;padding-top:25px}.printbar{max-width:1180px;margin:18px auto}.printbar button{background:#17212b;color:#fff;border:0;border-radius:8px;padding:10px 18px;font-weight:700;cursor:pointer}
  @media(max-width:800px){.page{margin:0;border-radius:0}.head{display:block}.order{text-align:left;margin-top:10px}.meta{grid-template-columns:1fr 1fr}.content{padding:14px;overflow:auto}th,td{white-space:nowrap}}
  @media print{body{background:#fff}.printbar{display:none}.page{max-width:none;margin:0;box-shadow:none;border-radius:0}.head{-webkit-print-color-adjust:exact;print-color-adjust:exact}.meta{padding:12px 0}.content{padding:14px 0}tr{break-inside:avoid}.dw-purchase-note{break-inside:avoid}}
  </style></head><body><div class="printbar"><button onclick="window.print()">🖨 Skriv ut plocklista</button></div><div class="page"><div class="head"><div><div class="brand"><span>DENNIS</span> <b>WMS</b></div><div>Plocklista · Warehouse Management System</div></div><div class="order">ORDER #'.esc_html($order->get_order_number()).'</div></div>';
  echo '<div class="meta"><div><small>Skapad</small><strong>'.esc_html(current_time('Y-m-d H:i')).'</strong></div><div><small>Kund</small><strong>'.esc_html($customer?:'–').'</strong></div><div><small>Leverans</small><strong>'.esc_html($method?:'–').'</strong></div><div><small>Adress</small><strong>'.esc_html($address?:'–').'</strong></div></div><div class="content">';
  echo '<table><thead><tr><th>Bild</th><th>Produkt</th><th>SKU</th><th>Antal</th><th>Batch</th><th>Expire</th><th>Lagerplats</th><th>✓</th></tr></thead><tbody>';
  $previous_sku=null;$current_kit=null;foreach(self::items($order) as $row){$kit_group=!empty($row['accompanying_group'])?(string)$row['accompanying_group']:'';if($kit_group!==''&&$kit_group!==$current_kit){echo '<tr class="dw-kit-header-row"><td colspan="8">'.self::kit_header_html($row,true).'</td></tr>';$current_kit=$kit_group;}elseif($kit_group===''){$current_kit=null;}self::sku_separator(!empty($row['accompanying_group'])?'kit:'.$row['accompanying_group']:'sku:'.$row['sku'],$previous_sku,8);
   $alloc=$row['kit_allocation']??self::pick_allocation($row['product_id'],$row['qty']);$first=true;
   foreach($alloc['rows'] as $a){echo '<tr><td>'.($first?self::image_html(self::pick_row_image($row),$row['name'],true):'').'</td><td>'.($first?self::product_label_html($row):'↳ samma SKU').'</td><td>'.($first?'<strong>'.esc_html($row['sku']).'</strong>'.self::pick_barcode_html($row,true):'').'</td><td class="qty">PLOCKA '.esc_html((string)$a['qty']).' ST</td><td>'.esc_html($a['batch']?:'–').'</td><td>'.esc_html($a['expiry']?:'–').'</td><td><strong>'.esc_html($a['location']?:($row['location']?:'Ej angiven')).'</strong></td><td><span class="check"></span></td></tr>';$first=false;}
   if($alloc['missing']>0)echo '<tr style="background:#fff3f4"><td>'.($first?self::image_html(self::pick_row_image($row),$row['name'],true):'').'</td><td>'.($first?'<strong>'.esc_html($row['name']).'</strong>':'↳ återstående').'</td><td>'.($first?esc_html($row['sku']).self::pick_barcode_html($row,true):'').'</td><td class="qty">'.esc_html((string)$alloc['missing']).'</td><td colspan="3"><strong>⚠ Saknas i batchsaldo</strong></td><td><span class="check"></span></td></tr>';
   if(empty($row['accompanying_group'])&&(!empty($row['packing_instruction'])||!empty($row['kit_instruction'])))echo '<tr class="dw-packing-info-row"><td></td><td colspan="7">'.self::packing_html($row,true).'</td></tr>';
   if(!empty($row['purchase_note']))echo '<tr class="dw-purchase-note"><td></td><td colspan="7">'.self::purchase_note_html($row['purchase_note'],true).'</td></tr>';
  }
  echo '</tbody></table>';
  self::print_packaging_suggestions([$order]);
  echo '<div class="footer"><div><strong>Plockad av</strong><div class="sign"></div></div><div><strong>Kontrollerad av</strong><div class="sign"></div></div></div></div></div></body></html>'; exit;
 }

}

/**
 * v1.7.1: WMS plockinformation visas endast inne i Dennis WMS.
 * Inga plocklistor eller lagerplatser läggs till i WooCommerce ordermejl.
 */

require_once __DIR__.'/activity-log.php';
require_once __DIR__.'/security.php';
require_once __DIR__.'/order-debug.php';
require_once __DIR__.'/analytics.php';
require_once __DIR__.'/inventory-followup.php';
require_once __DIR__.'/dashboard.php';
require_once __DIR__.'/revisions.php';
require_once __DIR__.'/depot.php';
require_once __DIR__.'/receiving.php';
require_once __DIR__.'/order-images.php';
require_once __DIR__.'/material-usage.php';
require_once __DIR__.'/packaging-materials.php';
require_once __DIR__.'/warnings.php';
require_once __DIR__.'/order-ui.php';
require_once __DIR__.'/product-rules.php';
require_once __DIR__.'/flow-stats.php';
require_once __DIR__.'/report-builder.php';
require_once __DIR__.'/batch-ledger.php';
require_once __DIR__.'/multi-shop.php';
require_once __DIR__.'/multi-shop-stats.php';
require_once __DIR__.'/remote-workflow.php';
require_once __DIR__.'/customer-stats.php';
require_once __DIR__.'/delivery.php';
require_once __DIR__.'/deadline.php';
require_once __DIR__.'/preorders.php';
require_once __DIR__.'/calendar.php';
register_activation_hook(__FILE__,['PB_WMS_V03','activate']);
register_activation_hook(__FILE__,['Dennis_WMS_Multi_Shop','install']);
register_activation_hook(__FILE__,['Dennis_WMS_Batches','install']);
register_activation_hook(__FILE__,['Dennis_WMS_Batches','backfill_receipts']);
register_activation_hook(__FILE__,['Dennis_WMS_Delivery','install']);
register_activation_hook(__FILE__,['Dennis_WMS_Deadline','install']);
Dennis_WMS_Order_Debug::boot();
Dennis_WMS_Warnings::boot();
Dennis_WMS_Preorders::boot();
PB_WMS_V03::boot();
Dennis_WMS_Remote_Workflow::boot();

require_once __DIR__.'/locations-v14.php';
require_once __DIR__.'/inventory-slots.php';
require_once __DIR__.'/product-view.php';
require_once __DIR__.'/barcodes.php';

require_once __DIR__.'/kits.php';
require_once __DIR__.'/product-packing.php';
register_activation_hook(__FILE__,['Dennis_WMS_Kits','install']);

require_once __DIR__.'/temporary-storage.php';

require_once __DIR__.'/playground-compat.php';

require_once __DIR__.'/order-status.php';

require_once __DIR__.'/accompanying-products.php';

require_once __DIR__.'/scanner.php';
require_once __DIR__.'/pwa.php';

require_once __DIR__.'/remote-inventory.php';
Dennis_WMS_Remote_Inventory::boot();

require_once __DIR__.'/remote-stock-details.php';
Dennis_WMS_Remote_Stock_Details::boot();
