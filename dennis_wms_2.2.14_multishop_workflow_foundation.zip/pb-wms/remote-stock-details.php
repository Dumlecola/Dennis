<?php
if(!defined('ABSPATH'))exit;
/** External shop stock annotations. No automatic stock changes. */
final class Dennis_WMS_Remote_Stock_Details {
 static function boot(){add_action('admin_post_dw_remote_stock_detail',[__CLASS__,'save']);}
 static function records(){ $v=get_option('dw_remote_stock_details',[]);return is_array($v)?$v:[]; }
 static function save(){
  if(!current_user_can('manage_woocommerce')||!current_user_can('pb_wms_manage'))wp_die('Åtkomst nekad',403);
  check_admin_referer('dw_remote_stock_detail');global $wpdb;
  $id=absint($_POST['product_id']??0);$t=Dennis_WMS_Multi_Shop::table('products');
  $product=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id));if(!$product)wp_die('Produkten saknas',404);
  $location=trim(sanitize_text_field(wp_unslash($_POST['location']??'')));
  $batch=trim(sanitize_text_field(wp_unslash($_POST['batch']??'')));
  $expires=trim(sanitize_text_field(wp_unslash($_POST['expires']??'')));
  $lod=trim(sanitize_text_field(wp_unslash($_POST['last_order_date']??'')));
  $quantity=trim((string)wp_unslash($_POST['quantity']??''));
  if($location===''||strlen($location)>100||strlen($batch)>100)wp_die('Ange giltig lagerplats och batch',400);
  if(!preg_match('/^\d+(?:[.,]\d{1,4})?$/D',$quantity))wp_die('Ogiltigt antal',400);
  foreach([$expires,$lod] as $date){if($date!==''&&(!preg_match('/^\d{4}-\d{2}-\d{2}$/D',$date)||!checkdate((int)substr($date,5,2),(int)substr($date,8,2),(int)substr($date,0,4))))wp_die('Ogiltigt datum',400);}
  $key=absint($product->shop_id).':'.absint($product->remote_product_id);
  $records=self::records();$items=isset($records[$key])&&is_array($records[$key])?$records[$key]:[];
  $itemid=absint($_POST['item_id']??0);
  if($itemid&& !isset($items[$itemid]))wp_die('Lagerposten finns inte',404);
  $entry=['location'=>$location,'batch'=>$batch,'expires'=>$expires,'last_order_date'=>$lod,'quantity'=>(float)str_replace(',','.',$quantity),'updated'=>current_time('mysql'),'user'=>get_current_user_id()];
  if(!$itemid)$itemid=time()*1000+wp_rand(1,999);
  $old=$items[$itemid]??null;$items[$itemid]=$entry;$records[$key]=$items;
  update_option('dw_remote_stock_details',$records,false);
  $log=(array)get_option('dw_remote_stock_details_log',[]);
  array_unshift($log,['key'=>$key,'item'=>$itemid,'before'=>$old,'after'=>$entry,'time'=>current_time('mysql'),'user'=>get_current_user_id()]);
  update_option('dw_remote_stock_details_log',array_slice($log,0,1000),false);
  wp_safe_redirect(add_query_arg(['page'=>'pb-wms','dw_inventory_shop'=>absint($product->shop_id),'dw_stock_saved'=>1],admin_url('admin.php')));exit;
 }
 static function render($selected=0,$mode="all"){
  global $wpdb;$pt=Dennis_WMS_Multi_Shop::table('products');$st=Dennis_WMS_Multi_Shop::table('shops');
  $where=$selected?$wpdb->prepare('WHERE p.shop_id=%d',$selected):'';
  $products=$wpdb->get_results("SELECT p.id,p.shop_id,p.remote_product_id,p.sku,p.name,s.name shop_name FROM $pt p JOIN $st s ON s.id=p.shop_id $where ORDER BY s.name,p.name LIMIT 500");
  $records=self::records();$counts=[];$totals=[];
  foreach($products as $p){$key=$p->shop_id.':'.$p->remote_product_id;$counts[$key]=$p;}
  echo '<h2>Batcher och lagerplatser – anslutna shoppar</h2><p>Registrera och justera batch, lagerplats, utgångsdatum och Last order date. Dessa poster lagras i WMS och ändrar inte WooCommerce-saldot. Produktens lagersaldo uppdateras separat via inventeringen.</p>';
  if(isset($_GET['dw_stock_saved']))echo '<p><strong>Lagerpost sparad.</strong></p>';
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:flex;flex-wrap:wrap;gap:8px;align-items:end">';wp_nonce_field('dw_remote_stock_detail');
  echo '<input type="hidden" name="action" value="dw_remote_stock_detail"><label>Produkt <select name="product_id" required>';
  foreach($products as $p)echo '<option value="'.absint($p->id).'">'.esc_html($p->shop_name.' / '.$p->name.' ('.$p->sku.')').'</option>';
  echo '</select></label><label>Lagerplats <input name="location" required maxlength="100" placeholder="A-01"></label><label>Batch <input name="batch" maxlength="100"></label><label>Antal <input type="number" name="quantity" min="0" step="0.0001" required></label><label>Utgångsdatum <input type="date" name="expires"></label><label>Last order date <input type="date" name="last_order_date"></label><button class="button button-primary">Spara lagerpost</button></form>';
  echo '<h3>Registrerade lagerposter</h3><div style="overflow-x:auto"><table class="widefat striped"><thead><tr><th>Shop</th><th>SKU</th><th>Lagerplats</th><th>Batch</th><th>Antal</th><th>Utgångsdatum</th><th>Last order date</th><th>Ändra</th></tr></thead><tbody>';
  $n=0;$byshop=[];
  foreach($records as $key=>$items){if(!isset($counts[$key]))continue;$p=$counts[$key];foreach((array)$items as $itemid=>$v){if($mode==='batches'&&empty($v['batch']))continue;$n++;$byshop[$p->shop_name]=($byshop[$p->shop_name]??0)+(float)$v['quantity'];$form='dw-stock-'.absint($itemid);
   echo '<tr><td>'.esc_html($p->shop_name).'</td><td>'.esc_html($p->sku).'</td>';
   foreach(['location','batch','quantity','expires','last_order_date'] as $field){$type=in_array($field,['expires','last_order_date'],true)?'date':($field==='quantity'?'number':'text');echo '<td><input form="'.esc_attr($form).'" name="'.esc_attr($field).'" type="'.$type.'" '.($field==='quantity'?'min="0" step="0.0001"':'').' value="'.esc_attr($v[$field]??'').'" style="max-width:130px" '.(in_array($field,['location','quantity'],true)?'required':'').'></td>';}
   echo '<td><form id="'.esc_attr($form).'" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dw_remote_stock_detail');echo '<input type="hidden" name="action" value="dw_remote_stock_detail"><input type="hidden" name="product_id" value="'.absint($p->id).'"><input type="hidden" name="item_id" value="'.absint($itemid).'"><button class="button">Spara</button></form></td></tr>';
  }}
  if(!$n)echo '<tr><td colspan="8">Inga lagerposter registrerade ännu.</td></tr>';
  echo '</tbody></table></div><h3>Statistik – registrerade lagerposter</h3><p>Antal poster: '.absint($n).'. Summerade registrerade antal per shop (inte verifierat fysiskt saldo):</p><ul>';
  foreach($byshop as $name=>$qty)echo '<li>'.esc_html($name).': '.esc_html(wc_format_decimal($qty,4)).'</li>';
  echo '</ul>';
 }
}
