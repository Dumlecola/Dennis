<?php
if(!defined('ABSPATH'))exit;
final class Dennis_WMS_Inventory_Slots {
 static function table(){global $wpdb;return $wpdb->prefix.'dennis_wms_count_details';}
 static function boot(){add_action('admin_init',[__CLASS__,'install']);add_action('admin_post_dennis_wms_count_slots',[__CLASS__,'save']);}
 static function install(){
  if(!current_user_can('manage_options')||get_option('dennis_wms_count_details_schema')==='1')return;
  global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::table();dbDelta("CREATE TABLE $t (
 count_id bigint(20) unsigned NOT NULL,
 reason text NOT NULL,
 snapshot longtext NOT NULL,
 PRIMARY KEY  (count_id)
 ) ".$wpdb->get_charset_collate().';');
  if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$t))===$t)update_option('dennis_wms_count_details_schema','1');
 }
 static function rows($pid,$lock=false){
  global $wpdb;$suffix=$lock?' FOR UPDATE':'';
  $b=Dennis_WMS_Batches::table('balances');$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $b WHERE product_id=%d ORDER BY id".$suffix,$pid));$mode='batch';
  if(!$rows){$mode='location';$t=Dennis_WMS_Locations_V14::table('balances');$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE product_id=%d ORDER BY id".$suffix,$pid));}
  $out=[];foreach($rows as $r)$out[]=['id'=>(int)$r->id,'location'=>(string)$r->location,'batch'=>$r->batch??'','expiry'=>$r->expiry??'','last_order_date'=>$r->last_order_date??'','quantity'=>(float)$r->quantity];
  return ['mode'=>$mode,'rows'=>$out];
 }
 static function token($data){return hash('sha256',wp_json_encode($data));}
 static function detail($id){global $wpdb;return $wpdb->get_row($wpdb->prepare('SELECT * FROM '.self::table().' WHERE count_id=%d',$id));}
 static function form($p){
  $data=self::rows($p->get_id());if(!$data['rows'])return false;
  echo '<details><summary><strong>Inventera alla lagerplatser / batcher</strong></summary><p>Räkna alla rader, även utgångna och tomma batcher. Summan blir produktens nya WooCommerce-saldo. Datum ändras via batchregistret.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_count_slots_'.$p->get_id());
  echo '<input type="hidden" name="action" value="dennis_wms_count_slots"><input type="hidden" name="product_id" value="'.esc_attr($p->get_id()).'"><input type="hidden" name="expected_stock" value="'.esc_attr($p->get_stock_quantity()).'"><input type="hidden" name="snapshot" value="'.esc_attr(self::token($data)).'"><table class="widefat"><thead><tr><th>Plats</th><th>Batch</th><th>Expire</th><th>Last order date</th><th>System</th><th>Räknat</th></tr></thead><tbody>';
  $sum=0;foreach($data['rows'] as $r){$sum+=$r['quantity'];echo '<tr><td>'.esc_html($r['location']?:'Ej angiven').'</td><td>'.esc_html($r['batch']?:'–').'</td><td>'.esc_html($r['expiry']?:'–').'</td><td>'.esc_html($r['last_order_date']?:'–').'</td><td>'.esc_html($r['quantity']).'</td><td><input name="slot_count['.esc_attr($r['id']).']" type="number" min="0" max="999999999" step="1" required aria-label="Räknat antal" style="width:90px"></td></tr>';}
  $unassigned=max(0,(float)$p->get_stock_quantity()-$sum);
  echo '<tr><td colspan="4">Ytterligare ofördelat / utan lagerplats</td><td>'.esc_html($unassigned).'</td><td><input type="number" name="unassigned" min="0" max="999999999" step="1" value="0" required style="width:90px"></td></tr></tbody></table><p>WooCommerce: '.esc_html($p->get_stock_quantity()).' · Fördelat: '.esc_html($sum).'. Ange även fysiskt antal utan plats i raden Ofördelat.</p><p><label>Orsak / kommentar <input name="reason" required minlength="3" maxlength="500" placeholder="T.ex. ordinarie inventering"></label></p><button class="button button-primary" onclick="return confirm(\'Spara alla räknade rader och uppdatera WooCommerce-saldot?\')">Spara hela inventeringen</button></form></details>';return true;
 }
 static function count_value($v){if(!is_string($v)||!preg_match('/^(0|[1-9][0-9]{0,8})$/',$v))throw new Exception('Ange ett heltal 0–999999999 på varje rad.');return (int)$v;}
 static function save(){
  $pid=absint($_POST['product_id']??0);if(!current_user_can('pb_wms_count')||!current_user_can('manage_woocommerce')||!current_user_can('edit_product',$pid))wp_die('Åtkomst nekad.',403);check_admin_referer('dennis_wms_count_slots_'.$pid);Dennis_WMS_Batches::require_schema();
  $p=wc_get_product($pid);if(!$p||!$p->managing_stock()||$p->get_stock_quantity()===null)wp_die('Produkten saknar lagerhantering.',400);
  if(get_post_meta($pid,'_atum_multi_inventory',true)||get_post_meta($pid,'_multi_inventory',true))wp_die('ATUM Multi-Inventory stöds inte för automatisk inventering.',400);
  $reason=sanitize_textarea_field(wp_unslash($_POST['reason']??''));if(strlen(trim($reason))<3||strlen($reason)>500)wp_die('Ange en orsak på 3–500 tecken.',400);
  global $wpdb;$counts=$wpdb->prefix.'pb_wms_counts';$before=$p->get_stock_quantity();Dennis_WMS_Audit::query('START TRANSACTION');$stock_changed=false;
  try{
   $data=self::rows($pid,true);$p->get_data_store()->read($p);$before=$p->get_stock_quantity();if(!$data['rows'])throw new Exception('Lagerplatser saknas. Ladda om inventeringen.');
   if(!hash_equals(self::token($data),(string)($_POST['snapshot']??''))||(float)($_POST['expected_stock']??-1)!==(float)$before)throw new Exception('Saldo eller batchuppgifter har ändrats. Ladda om och räkna igen.');
   $posted=(array)wp_unslash($_POST['slot_count']??[]);if(count($posted)!==count($data['rows']))throw new Exception('Alla lagerplatser måste räknas.');$total=0;$snapshot=[];
   foreach($data['rows'] as $r){$q=self::count_value($posted[$r['id']]??null);$total+=$q;$r['counted']=$q;$r['difference']=$q-$r['quantity'];$snapshot[]=$r;}
   $extra=self::count_value(wp_unslash($_POST['unassigned']??'0'));$total+=$extra;if($total>999999999)throw new Exception('Totalsaldot är för stort.');
   if(!Dennis_WMS_Audit::insert($counts,['product_id'=>$pid,'counted_qty'=>$total,'reference_qty'=>$before,'location'=>'Flera platser','user_id'=>get_current_user_id(),'counted_at'=>current_time('mysql'),'update_status'=>'pending']))throw new Exception('Kunde inte spara inventeringshistoriken.');$event=(int)$wpdb->insert_id;
   $sum=array_sum(array_column($data['rows'],'quantity'));$snapshot[]=['id'=>0,'location'=>'Ofördelat','batch'=>'','expiry'=>'','last_order_date'=>'','quantity'=>max(0,(float)$before-$sum),'counted'=>$extra,'difference'=>$extra-max(0,(float)$before-$sum)];
   if(!Dennis_WMS_Audit::insert(self::table(),['count_id'=>$event,'reason'=>$reason,'snapshot'=>wp_json_encode($snapshot,JSON_UNESCAPED_UNICODE)]))throw new Exception('Kunde inte spara inventeringsraderna.');
   $t=$data['mode']==='batch'?Dennis_WMS_Batches::table('balances'):Dennis_WMS_Locations_V14::table('balances');
   foreach($snapshot as $r){if(!$r['id'])continue;if(Dennis_WMS_Audit::update($t,array_merge(['quantity'=>$r['counted']],$data['mode']==='batch'?['updated_at'=>current_time('mysql')]:[]),['id'=>$r['id']])===false)throw new Exception('Kunde inte spara radsaldo.');
    if($data['mode']==='batch'&&$r['difference']!=0){if(!Dennis_WMS_Audit::insert(Dennis_WMS_Batches::table('movements'),['product_id'=>$pid,'batch'=>$r['batch'],'expiry'=>$r['expiry']?:null,'last_order_date'=>$r['last_order_date']?:null,'location'=>$r['location'],'quantity'=>$r['difference'],'action'=>'inventory','source_type'=>'count','source_id'=>$event,'source_key'=>'count-'.$event.'-'.$r['id'],'note'=>$reason,'user_id'=>get_current_user_id(),'created_at'=>current_time('mysql')]))throw new Exception('Kunde inte logga batchdifferensen.');}}
   if($extra>0){$empty=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE product_id=%d AND location=''".($data['mode']==='batch'?" AND batch='' AND expiry IS NULL":'')." LIMIT 1",$pid));if($empty){$ok=Dennis_WMS_Audit::update($t,['quantity'=>(float)$empty->quantity+$extra],['id'=>$empty->id]);}else{$row=['product_id'=>$pid,'location'=>'','quantity'=>$extra];if($data['mode']==='batch')$row+=['batch'=>'','expiry'=>null,'last_order_date'=>null,'created_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')];$ok=Dennis_WMS_Audit::insert($t,$row);}if($ok===false)throw new Exception('Kunde inte spara ofördelat saldo.');if($data['mode']==='batch'&&!Dennis_WMS_Audit::insert(Dennis_WMS_Batches::table('movements'),['product_id'=>$pid,'batch'=>'','expiry'=>null,'last_order_date'=>null,'location'=>'','quantity'=>$extra,'action'=>'inventory','source_type'=>'count','source_id'=>$event,'source_key'=>'count-'.$event.'-unassigned','note'=>$reason,'user_id'=>get_current_user_id(),'created_at'=>current_time('mysql')]))throw new Exception('Kunde inte logga ofördelat saldo.');}
   $stock_changed=true;$actual=wc_update_product_stock($p,$total,'set');if($actual===false||(float)$actual!==(float)$total)throw new Exception('WooCommerce-saldot kunde inte verifieras.');
   if(Dennis_WMS_Audit::update($counts,['applied_qty'=>$total,'update_status'=>'applied_slots'],['id'=>$event])===false)throw new Exception('Kunde inte slutföra inventeringshistoriken.');
   if(Dennis_WMS_Audit::query('COMMIT')===false)throw new Exception('Kunde inte slutföra inventeringen.');
  }catch(Throwable $e){Dennis_WMS_Audit::query('ROLLBACK');if($stock_changed){wc_delete_product_transients($pid);clean_post_cache($pid);}wp_die(esc_html($e->getMessage()).' Ingen inventering slutfördes. Ladda om sidan och kontrollera saldot.',409);}
  PB_WMS_V03::redirect('count');
 }
 static function history_html($detail){
  if(!$detail)return '';$rows=json_decode($detail->snapshot,true);$html='<strong>'.esc_html($detail->reason).'</strong><details><summary>Rader / differenser / datum</summary><table><thead><tr><th>Plats</th><th>Batch</th><th>Expire</th><th>Last order date</th><th>Före</th><th>Räknat</th><th>Diff</th></tr></thead><tbody>';
  foreach((array)$rows as $r)$html.='<tr><td>'.esc_html($r['location']?:'–').'</td><td>'.esc_html($r['batch']?:'–').'</td><td>'.esc_html($r['expiry']?:'–').'</td><td>'.esc_html($r['last_order_date']?:'–').'</td><td>'.esc_html($r['quantity']).'</td><td>'.esc_html($r['counted']).'</td><td>'.esc_html($r['difference']).'</td></tr>';
  return $html.'</tbody></table></details>';
 }
}
Dennis_WMS_Inventory_Slots::boot();
