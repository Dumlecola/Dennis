<?php
if (!defined('ABSPATH')) exit;
final class Dennis_WMS_Scanner {
 const CAP='pb_wms_view';
 static function boot(){add_action('admin_menu',[__CLASS__,'menu'],98);add_action('wp_ajax_dw_scanner_find',[__CLASS__,'find']);}
 static function menu(){add_submenu_page('pb-wms','Scanning','Scanning',self::CAP,'dennis-wms-scanner',[__CLASS__,'page']);}
 static function product($code){
  $ids=wc_get_products(['limit'=>3,'return'=>'ids','status'=>['publish','private','draft','pending','future'],'meta_key'=>'_dennis_wms_barcode','meta_value'=>$code]);
  if(count($ids)>1)return new WP_Error('duplicate','Flera produkter har samma streckkod.');
  if(count($ids)===1)return wc_get_product($ids[0]);
  $id=wc_get_product_id_by_sku($code);return $id?wc_get_product($id):false;
 }
 static function find(){
  if(!current_user_can(self::CAP))wp_send_json_error(['message'=>'Åtkomst nekad'],403);
  check_ajax_referer('dw_scanner','nonce');
  if(!function_exists('wc_get_product'))wp_send_json_error(['message'=>'WooCommerce saknas'],503);
  $code=trim(sanitize_text_field(wp_unslash($_POST['code']??'')));
  if($code===''||strlen($code)>100)wp_send_json_error(['message'=>'Ogiltig kod'],400);
  $p=self::product($code);if(is_wp_error($p))wp_send_json_error(['message'=>$p->get_error_message()],409);
  if(!$p && class_exists('Dennis_WMS_Multi_Shop')){
   global $wpdb;$t=Dennis_WMS_Multi_Shop::table('products');$shops=Dennis_WMS_Multi_Shop::table('shops');
   $matches=[];
   if(class_exists('Dennis_WMS_Product_View')){
    $codes=Dennis_WMS_Product_View::remote_codes();
    foreach($codes as $key=>$barcode)if(hash_equals((string)$barcode,$code)){
     $parts=explode(':',(string)$key,2);
     if(count($parts)===2){$row=$wpdb->get_row($wpdb->prepare("SELECT p.*,s.name shop_name FROM $t p INNER JOIN $shops s ON s.id=p.shop_id WHERE p.shop_id=%d AND p.remote_product_id=%d",absint($parts[0]),absint($parts[1])));if($row)$matches[(int)$row->id]=$row;}
    }
   }
   $rows=$wpdb->get_results($wpdb->prepare("SELECT p.*,s.name shop_name FROM $t p INNER JOIN $shops s ON s.id=p.shop_id WHERE p.sku=%s LIMIT 20",$code));
   foreach($rows as $row)$matches[(int)$row->id]=$row;
   $rows=array_values($matches);
   if(count($rows)>1)wp_send_json_error(['message'=>'SKU finns i flera anslutna shoppar. Öppna Produktvy och välj rätt shop.'],409);
   if(count($rows)===1){
    $r=$rows[0];$order_id=absint($_POST['order_id']??0);
    if($order_id)wp_send_json_error(['message'=>'Orderkontroll mot ansluten shop kräver att rätt shop och order väljs. Ingen status ändrades.'],409);
    wp_send_json_success(['id'=>0,'name'=>$r->name,'sku'=>$r->sku,'stock'=>$r->stock_quantity,'shop'=>$r->shop_name,
     'url'=>Dennis_WMS_Product_View::remote_url($r->id),'expected'=>0,'matched'=>false,'order'=>'','locations'=>[]]);
   }
  }
  if(!$p)wp_send_json_error(['message'=>'Ingen produkt hittades för streckkoden eller SKU. Kontrollera att anslutna shoppar är synkroniserade.'],404);
  $order_id=absint($_POST['order_id']??0);$expected=0;$order_name='';$matched=false;
  if($order_id){
   if(!current_user_can('manage_woocommerce')&&!current_user_can('pb_wms_manage'))wp_send_json_error(['message'=>'Du saknar behörighet att kontrollera ordrar'],403);
   $o=wc_get_order($order_id);if(!$o)wp_send_json_error(['message'=>'Ordern hittades inte'],404);
   foreach($o->get_items('line_item') as $item){
    $item_pid=(int)$item->get_product_id();$item_vid=(int)$item->get_variation_id();
    if(($item_vid && $item_vid===(int)$p->get_id())||(!$item_vid && $item_pid===(int)$p->get_id())){$matched=true;$expected+=(float)$item->get_quantity();}
   }
   $order_name='#'.$o->get_order_number();
  }
  $locations=[];
  if(class_exists('Dennis_WMS_Product_View')&&method_exists('Dennis_WMS_Product_View','locations')){
   $locations=Dennis_WMS_Product_View::locations([$p]);
   $locations=array_keys($locations[$p->get_id()]??[]);
  }
  if(!$locations&&class_exists('Dennis_WMS_Orders')){$base=Dennis_WMS_Orders::location($p->get_id());if($base)$locations[]=$base;}
  $stock=$p->get_stock_quantity();
  wp_send_json_success(['id'=>$p->get_id(),'name'=>$p->get_name(),'sku'=>$p->get_sku(),'stock'=>$stock,
   'url'=>add_query_arg(['page'=>'dennis-wms-products','dw_product_id'=>$p->get_id()],admin_url('admin.php')),
   'expected'=>$expected,'matched'=>$matched,'order'=>$order_name,'locations'=>$locations]);
 }
 static function page(){
  if(!current_user_can(self::CAP))wp_die('Åtkomst nekad');
  $nonce=wp_create_nonce('dw_scanner');$ajax=admin_url('admin-ajax.php');
  $initial_mode=sanitize_key(wp_unslash($_GET['scan_mode']??'search'));if(!in_array($initial_mode,['pick','search'],true))$initial_mode='search';
  $initial_order=absint($_GET['scan_order']??0);
  echo '<div class="wrap dw-scanner-page"><h1>Scanning – Dennis WMS</h1><p>Scanna med USB/Bluetooth-läsare eller mobilkamera. Scanning söker produkter eller kontrollerar om artikeln ingår i en order. Ingen lager- eller orderdata ändras.</p><div style="max-width:680px;background:#fff;padding:22px;border:1px solid #ddd;border-radius:10px">';
  echo '<p><label><strong>Arbetsläge</strong><br><select id="dws-mode"><option value="search">Sök produkt</option><option value="pick">Kontrollera mot order</option></select></label></p>';
  echo '<p id="dws-order-row"><label>WooCommerce order-ID för kontroll<br><input id="dws-order" type="number" min="1" placeholder="WooCommerce order-ID"></label> <small>Ange orderns interna ID (kan skilja sig från visat ordernummer).</small></p>';
  echo '<p><button type="button" class="button" id="dws-camera">Starta mobilkamera</button> <button type="button" class="button" id="dws-stop" disabled>Stoppa kamera</button></p><video id="dws-video" playsinline muted style="display:none;width:100%;max-height:280px;background:#111"></video>';
  echo '<p><label>Streckkod eller SKU<br><input id="dws-code" type="text" autocomplete="off" style="width:75%" placeholder="Scanna eller skriv kod och tryck Enter"></label> <button type="button" class="button button-primary" id="dws-find">Sök</button></p>';
  echo '<div id="dws-result" aria-live="polite" role="status" style="padding:14px;background:#f6f7f7;min-height:40px;border-radius:8px">Väntar på scanning…</div>';
  echo '<p><small>Produktsökning visar artikelns uppgifter. Orderkontroll visar RÄTT PRODUKT eller FEL PRODUKT och beställt antal. Scanning ändrar aldrig lagersaldo, plockstatus eller orderstatus.</small></p></div></div>';
  echo '<script>window.DWScannerConfig='.wp_json_encode(['ajax'=>$ajax,'nonce'=>$nonce,'mode'=>$initial_mode,'order'=>$initial_order]).';</script><script src="'.esc_url(plugins_url('scanner.js',__FILE__)).'?v='.rawurlencode(PB_WMS_VERSION).'" defer></script>';
 }
}
Dennis_WMS_Scanner::boot();
