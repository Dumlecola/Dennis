<?php
if (!defined('ABSPATH')) exit;
/** Receiving ledger: posted quantities are immutable; stock is changed only on explicit posting. */
final class Dennis_WMS_Receiving {
 const CAP='pb_wms_manage';
 static function table($suffix){global $wpdb;return $wpdb->prefix.'dennis_wms_'.$suffix;}
 static function install(){global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$c=$wpdb->get_charset_collate();$h=self::table('receipts');$l=self::table('receipt_lines');$e=self::table('receipt_events');
 dbDelta("CREATE TABLE $h (id bigint(20) unsigned NOT NULL AUTO_INCREMENT, reference varchar(120) NOT NULL DEFAULT '', title varchar(190) NOT NULL DEFAULT '', supplier varchar(190) NOT NULL DEFAULT '', expected_date date NULL, arrived_at datetime NULL, package_count bigint(20) unsigned NULL, pallet_count bigint(20) unsigned NULL, status varchar(30) NOT NULL DEFAULT 'draft', notes text NULL, created_by bigint(20) unsigned NOT NULL, created_at datetime NOT NULL, PRIMARY KEY  (id), KEY status (status)) $c;");
 dbDelta("CREATE TABLE $l (id bigint(20) unsigned NOT NULL AUTO_INCREMENT, receipt_id bigint(20) unsigned NOT NULL, product_id bigint(20) unsigned NOT NULL, no_stock tinyint(1) NOT NULL DEFAULT 0, product_name varchar(190) NOT NULL DEFAULT '', expected_qty bigint(20) unsigned NOT NULL DEFAULT 0, received_qty bigint(20) unsigned NOT NULL DEFAULT 0, approved_qty bigint(20) unsigned NOT NULL DEFAULT 0, posted_qty bigint(20) unsigned NOT NULL DEFAULT 0, rejected_qty bigint(20) unsigned NOT NULL DEFAULT 0, batch varchar(120) NOT NULL DEFAULT '', expiry date NULL, last_order_date date NULL, location varchar(120) NOT NULL DEFAULT '', note text NULL, PRIMARY KEY  (id), KEY receipt_id (receipt_id), KEY product_id (product_id)) $c;");
 dbDelta("CREATE TABLE $e (id bigint(20) unsigned NOT NULL AUTO_INCREMENT, receipt_id bigint(20) unsigned NOT NULL, line_id bigint(20) unsigned NOT NULL DEFAULT 0, product_id bigint(20) unsigned NOT NULL DEFAULT 0, sku varchar(190) NOT NULL DEFAULT '', action varchar(40) NOT NULL, quantity bigint(20) NOT NULL DEFAULT 0, user_id bigint(20) unsigned NOT NULL, created_at datetime NOT NULL, detail text NULL, PRIMARY KEY  (id), KEY receipt_id (receipt_id), KEY created_at (created_at), KEY product_id (product_id)) $c;");$i=self::table('receipt_images');dbDelta("CREATE TABLE $i (id bigint(20) unsigned NOT NULL AUTO_INCREMENT, receipt_id bigint(20) unsigned NOT NULL, line_id bigint(20) unsigned NOT NULL DEFAULT 0, product_id bigint(20) unsigned NOT NULL DEFAULT 0, attachment_id bigint(20) unsigned NOT NULL, category varchar(30) NOT NULL DEFAULT 'delivery', comment text NULL, created_by bigint(20) unsigned NOT NULL, created_at datetime NOT NULL, PRIMARY KEY (id), KEY receipt_id (receipt_id), KEY line_id (line_id), KEY category (category)) $c;");if(!$wpdb->get_var("SHOW COLUMNS FROM $h LIKE 'title'"))Dennis_WMS_Audit::query("ALTER TABLE $h ADD title varchar(190) NOT NULL DEFAULT ''");foreach(['no_stock'=>'tinyint(1) NOT NULL DEFAULT 0','product_name'=>"varchar(190) NOT NULL DEFAULT ''",'approved_qty'=>'bigint(20) unsigned NOT NULL DEFAULT 0','posted_qty'=>'bigint(20) unsigned NOT NULL DEFAULT 0','rejected_qty'=>'bigint(20) unsigned NOT NULL DEFAULT 0'] as $column=>$definition){if(!$wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM $l LIKE %s",$column)))Dennis_WMS_Audit::query("ALTER TABLE $l ADD $column $definition");}if(!$wpdb->get_var("SHOW COLUMNS FROM $l LIKE 'last_order_date'"))Dennis_WMS_Audit::query("ALTER TABLE $l ADD last_order_date date NULL");$ready=true;foreach([$h=>['title'=>"varchar(190) NOT NULL DEFAULT ''",'arrived_at'=>'datetime NULL','package_count'=>'bigint(20) unsigned NULL','pallet_count'=>'bigint(20) unsigned NULL'],$e=>['sku'=>"varchar(190) NOT NULL DEFAULT ''"],$l=>['last_order_date'=>'date NULL']] as $table=>$columns){foreach($columns as $column=>$definition){if(!$wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM $table LIKE %s",$column)))Dennis_WMS_Audit::query("ALTER TABLE $table ADD $column $definition");if(!$wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM $table LIKE %s",$column)))$ready=false;}}if($ready)update_option('dennis_wms_receiving_schema','1.2.5');}
 static function boot(){add_action('wp_ajax_dennis_wms_receiving_sku',[__CLASS__,'lookup_sku']);add_action('admin_menu',[__CLASS__,'menu'],103);add_action('admin_post_dennis_wms_receiving',[__CLASS__,'submit']);add_action('admin_init',[__CLASS__,'upgrade']);}
 static function upgrade(){if(current_user_can('manage_options') && get_option('dennis_wms_receiving_schema')!=='1.2.5')self::install();}
 static function menu(){add_submenu_page('pb-wms','Inleveranser','Inleveranser','pb_wms_view','dennis-wms-receiving',[__CLASS__,'page']);add_submenu_page('pb-wms','Inleveransstatistik','Inleveransstatistik','pb_wms_view','dennis-wms-receiving-stats',[__CLASS__,'stats']);add_submenu_page('pb-wms','SKU-analys','SKU-analys','pb_wms_view','dennis-wms-sku-stats',[__CLASS__,'sku_stats']);}
 static function url($id=0){return add_query_arg(['page'=>'dennis-wms-receiving']+($id?['receipt_id'=>$id]:[]),admin_url('admin.php'));}

 static function event($rid,$lid,$pid,$action,$qty,$detail=''){global $wpdb;$product=$pid?wc_get_product($pid):false;$sku=$product?(string)$product->get_sku():'';Dennis_WMS_Audit::insert(self::table('receipt_events'),['receipt_id'=>$rid,'line_id'=>$lid,'product_id'=>$pid,'sku'=>$sku,'action'=>$action,'quantity'=>$qty,'user_id'=>get_current_user_id(),'created_at'=>current_time('mysql'),'detail'=>$detail],['%d','%d','%d','%s','%s','%d','%d','%s','%s']);}
 static function redirect($id,$msg){wp_safe_redirect(add_query_arg('dw_notice',$msg,self::url($id)));exit;}
 static function submit(){if(!current_user_can(self::CAP)||!current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad',403);check_admin_referer('dennis_wms_receiving');global $wpdb;$h=self::table('receipts');$l=self::table('receipt_lines');$mode=sanitize_key(wp_unslash($_POST['mode']??''));$id=absint($_POST['receipt_id']??0);$receipt=$id?$wpdb->get_row($wpdb->prepare("SELECT * FROM $h WHERE id=%d",$id)):null;
 if($mode==='create'){$reference=sanitize_text_field(wp_unslash($_POST['reference']??''));$supplier=sanitize_text_field(wp_unslash($_POST['supplier']??''));$date=sanitize_text_field(wp_unslash($_POST['expected_date']??''));if($date && !self::date_valid($date))wp_die('Ogiltigt datum',400);Dennis_WMS_Audit::insert($h,self::arrival_input()+['title'=>self::title_input(),'reference'=>$reference,'supplier'=>$supplier,'expected_date'=>$date?:null,'status'=>'draft','notes'=>sanitize_textarea_field(wp_unslash($_POST['notes']??'')),'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')]);$id=(int)$wpdb->insert_id;if(!$id)wp_die('Kunde inte skapa inleveransen. Ladda om WMS så att databasen uppdateras och försök igen.',500);self::event($id,0,0,'created',0);self::redirect($id,'created');}
 if(!$receipt)wp_die('Inleveransen hittades inte',404);
 if($mode==='save_title'){
  $data=[];if(array_key_exists('receipt_title',$_POST))$data['title']=self::title_input();
  foreach(['reference'=>120,'supplier'=>190] as $key=>$limit){if(array_key_exists($key,$_POST)){$value=sanitize_text_field(wp_unslash($_POST[$key]));if(preg_match_all('/./us',$value)>$limit)wp_die('Projektnr eller leverantör är för långt.',400);$data[$key]=$value;}}
  if(array_key_exists('notes',$_POST))$data['notes']=sanitize_textarea_field(wp_unslash($_POST['notes']));
  if(array_key_exists('expected_date',$_POST)){$date=sanitize_text_field(wp_unslash($_POST['expected_date']));if($date&&!self::date_valid($date))wp_die('Ogiltigt förväntat datum.',400);$data['expected_date']=$date?:null;}
  if(Dennis_WMS_Audit::update($h,$data,['id'=>$id])===false)wp_die('Kunde inte spara inleveransuppgifterna.',500);
  self::event($id,0,0,'title_updated',0,'Inleveransuppgifter ändrade.');self::redirect($id,'title_saved');
 }
 if($mode==='save_arrival'){
  $data=self::arrival_input();if(Dennis_WMS_Audit::update($h,$data,['id'=>$id])===false)wp_die('Kunde inte spara ankomstuppgifterna.',500);
  self::event($id,0,0,'arrival_updated',0,'Ankom: '.($data['arrived_at']??'Ej angivet').'; paket: '.($data['package_count']??'Ej angivet').'; pallar: '.($data['pallet_count']??'Ej angivet'));
  self::redirect($id,'arrival_saved');
 }
 if($mode==='upload_image'){
  $lid=absint($_POST['line_id']??0);$line=null;$pid=0;if($lid){$line=$wpdb->get_row($wpdb->prepare("SELECT * FROM $l WHERE id=%d AND receipt_id=%d",$lid,$id));if(!$line)wp_die('Inleveransraden hittades inte.',404);$pid=(int)$line->product_id;}
  $category=sanitize_key(wp_unslash($_POST['image_category']??'delivery'));$allowed=['delivery_note','outer_packages','inner_packages','delivery','damage','packaging','product','other'];if(!in_array($category,$allowed,true))$category='other';$comment=sanitize_textarea_field(wp_unslash($_POST['image_comment']??''));if($category==='damage'&&$comment==='')wp_die('Skriv en kort kommentar till skadebilden.',400);
  if(empty($_FILES['receipt_image']['name'])||!is_uploaded_file($_FILES['receipt_image']['tmp_name']))wp_die('Välj en bild att ladda upp.',400);if((int)$_FILES['receipt_image']['size']>12*1024*1024)wp_die('Bilden är för stor. Max 12 MB.',400);
  $att=Dennis_WMS_Security::upload_image('receipt_image',trim('IN-'.$id.' '.self::image_label($category).' '.$comment));if(is_wp_error($att))wp_die('Bilden kunde inte laddas upp: '.esc_html($att->get_error_message()),400);$mime=(string)get_post_mime_type($att);if(strpos($mime,'image/')!==0){wp_delete_attachment($att,true);wp_die('Filen måste vara en bild.',400);}
  $it=self::table('receipt_images');$ok=Dennis_WMS_Audit::insert($it,['receipt_id'=>$id,'line_id'=>$lid,'product_id'=>$pid,'attachment_id'=>$att,'category'=>$category,'comment'=>$comment,'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')]);if(!$ok){wp_delete_attachment($att,true);wp_die('Bilden kunde inte kopplas till inleveransen.',500);}self::event($id,$lid,$pid,$category==='damage'?'damage_image_added':'image_added',0,self::image_label($category).($comment?': '.$comment:''));self::redirect($id,$category==='damage'?'damage_image_added':'image_added');
 }
 if($mode==='delete_image'){$iid=absint($_POST['image_id']??0);$it=self::table('receipt_images');$img=$wpdb->get_row($wpdb->prepare("SELECT * FROM $it WHERE id=%d AND receipt_id=%d",$iid,$id));if(!$img)wp_die('Bilden hittades inte.',404);Dennis_WMS_Audit::delete($it,['id'=>$iid,'receipt_id'=>$id],['%d','%d']);wp_delete_attachment((int)$img->attachment_id,true);self::event($id,(int)$img->line_id,(int)$img->product_id,'image_deleted',0,'Bild borttagen: '.$img->category);self::redirect($id,'image_deleted');}
 if($mode==='sku_bulk'){
  $raw=trim((string)wp_unslash($_POST['sku_rows']??''));
  $rows=preg_split('/\r\n|\n|\r/',$raw);if(!$raw||count($rows)>250)wp_die('Ange 1–250 rader.',400);
  $parsed=[];$errors=[];
  foreach($rows as $index=>$row){if(!trim($row))continue;
   $cells=str_getcsv($row,"\t");if(count($cells)<2)$cells=str_getcsv($row,';');
   if(count($cells)<2||count($cells)>6){$errors[]='Rad '.($index+1).': ange SKU och antal.';continue;}
   $sku=trim($cells[0]);$qty=filter_var(trim($cells[1]),FILTER_VALIDATE_INT,['options'=>['min_range'=>1,'max_range'=>999999999]]);
   $pid=$sku!==''?wc_get_product_id_by_sku($sku):0;$product=$pid?wc_get_product($pid):false;
   if(!$product||!in_array($product->get_type(),['simple','variation'],true)||$qty===false){$errors[]='Rad '.($index+1).': okänd SKU eller ogiltigt antal ('.sanitize_text_field($sku).').';continue;}
   $loc=sanitize_text_field($cells[2]??'');$batch=sanitize_text_field($cells[3]??'');$expiry=trim($cells[4]??'');
   if($expiry&&!self::date_valid($expiry)){$errors[]='Rad '.($index+1).': ogiltigt utgångsdatum.';continue;}
   $last=self::last_order_input($cells[5]??'');
   $parsed[]=['last_order_date'=>$last,'pid'=>(int)$pid,'sku'=>$sku,'qty'=>$qty,'location'=>$loc,'batch'=>$batch,'expiry'=>$expiry];
  }
  if($errors||!$parsed)wp_die(esc_html(implode(' | ',$errors?:['Inga giltiga rader. Inget har sparats.'])),400);
  $received_bulk=($_POST['receipt_kind']??'')==='received';
  foreach($parsed as $row){$ok=Dennis_WMS_Audit::insert($l,['receipt_id'=>$id,'product_id'=>$row['pid'],'expected_qty'=>$received_bulk?0:$row['qty'],'received_qty'=>$received_bulk?$row['qty']:0,'location'=>$row['location'],'batch'=>$row['batch'],'expiry'=>$row['expiry']?:null,'last_order_date'=>$row['last_order_date']]);if(!$ok)wp_die('Databasfel: kontrollera inleveransen innan du försöker igen.',500);$new_id=(int)$wpdb->insert_id;if($temporary)Dennis_WMS_Temporary_Storage::complete($temporary,$id,$new_id,$sku);self::event($id,$new_id,$row['pid'],'line_added',$received_bulk?0:$row['qty'],'SKU: '.$row['sku']);if($received_bulk)self::event($id,$new_id,$row['pid'],'received',$row['qty'],'Räknat och mottaget. Inväntar godkännande.');}
  if($received_bulk)Dennis_WMS_Audit::update($h,['status'=>'pending_approval'],['id'=>$id]);
  self::redirect($id,$received_bulk?'received_pending':'sku_rows_added');
 }
 if($mode==='add_line'&&!empty($_POST['no_stock']))self::registration_error($id,'Inleveranser kräver en produkt med SKU. Lägg till SKU i WooCommerce först och ange sedan SKU.');
 if($mode==='add_line'){
  $temporary=absint($_POST['temporary_storage']??0);if($temporary&&(!Dennis_WMS_Temporary_Storage::active($temporary)||(int)get_post_meta($temporary,'_dw_draft_receipt',true)!==$id))self::registration_error($id,'Förvaringen är redan behandlad eller tillhör en annan inleverans.');
  $sku=trim(sanitize_text_field(wp_unslash($_POST['sku']??'')));$selected=absint($_POST['product_id']??0);$sku_pid=$sku!==''?(int)wc_get_product_id_by_sku($sku):0;
  if($sku===''||!$sku_pid)self::registration_error($id,'Ange ett befintligt SKU. Produktnamnet hämtas automatiskt från SKU.');
  if($selected&&$sku_pid&&$selected!==$sku_pid)self::registration_error($id,'SKU och produkt är olika. Ladda om sidan och ange rätt SKU.');
  $pid=$sku_pid;$p=$pid?wc_get_product($pid):false;
  $expected_raw=trim((string)($_POST['expected_qty']??''));$expected=$expected_raw===''?0:filter_var($expected_raw,FILTER_VALIDATE_INT,['options'=>['min_range'=>0,'max_range'=>999999999]]);
  $received_raw=trim((string)($_POST['received_qty']??''));$received=$received_raw===''?0:filter_var($received_raw,FILTER_VALIDATE_INT,['options'=>['min_range'=>1,'max_range'=>999999999]]);
  if(!$p)self::registration_error($id,'Produkten för detta SKU hittades inte. Kontrollera SKU.');
  if($p->get_sku()==='')self::registration_error($id,'Produkten saknar SKU. Lägg till SKU i WooCommerce först och ange sedan SKU.');
  if(!in_array($p->get_type(),['simple','variation'],true))self::registration_error($id,'Välj en enkel produkt eller en specifik produktvariant.');
  if($expected===false)self::registration_error($id,'Förväntat antal ska vara ett heltal, eller lämnas tomt.');
  if($received===false||$received<1)self::registration_error($id,'Ange mottaget antal som ett heltal större än noll, till exempel 10.');
  if(($_POST['receipt_kind']??'')==='received'&&$received<1)wp_die('Ange det antal ni räknat och tagit emot.',400);
  $last_raw=trim((string)wp_unslash($_POST['last_order_date']??''));if($last_raw!==''&&!self::date_valid($last_raw))self::registration_error($id,'Kontrollera Last order date.');$last=$last_raw?:null;
  $batch=sanitize_text_field(wp_unslash($_POST['batch']??''));$expiry=sanitize_text_field(wp_unslash($_POST['expiry']??''));$location=sanitize_text_field(wp_unslash($_POST['location']??''));
  if($expiry&&!self::date_valid($expiry))self::registration_error($id,'Kontrollera utgångsdatum.');
  if(!Dennis_WMS_Audit::insert($l,['receipt_id'=>$id,'product_id'=>$pid,'expected_qty'=>$expected,'received_qty'=>$received,'batch'=>$batch,'expiry'=>$expiry?:null,'last_order_date'=>$last,'location'=>$location,'note'=>sanitize_textarea_field(wp_unslash($_POST['note']??''))]))self::registration_error($id,'Inleveransraden kunde inte sparas. Ladda om WMS som administratör för att uppdatera databasen.');
  $new_id=(int)$wpdb->insert_id;self::event($id,$new_id,$pid,'line_added',$expected);
  if($received>0){self::event($id,$new_id,$pid,'received',$received,'Räknat och mottaget. Inväntar godkännande. '.sanitize_textarea_field(wp_unslash($_POST['note']??'')));Dennis_WMS_Audit::update($h,['status'=>'pending_approval'],['id'=>$id]);}
  self::redirect($id,$received>0?'received_pending':'line_added');
 }

 $lid=absint($_POST['line_id']??0);$line=$wpdb->get_row($wpdb->prepare("SELECT * FROM $l WHERE id=%d AND receipt_id=%d",$lid,$id));if(!$line)wp_die('Raden hittades inte',404);
 if($mode==='connect_sku'){
  if(empty($line->no_stock)&&(int)$line->product_id>0)wp_die('Raden är redan kopplad till en produkt.',409);
  $sku=trim(sanitize_text_field(wp_unslash($_POST['connect_sku']??'')));$pid=$sku?(int)wc_get_product_id_by_sku($sku):0;$p=$pid?wc_get_product($pid):false;
  $qty=filter_var($_POST['received_qty']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1,'max_range'=>999999999]]);
  if(!$p||!in_array($p->get_type(),['simple','variation'],true)||$qty===false)wp_die('Ange ett befintligt SKU och mottaget antal större än noll.',400);
  $ok=Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $l SET product_id=%d,no_stock=0,received_qty=%d WHERE id=%d AND receipt_id=%d AND (no_stock=1 OR product_id=0) AND posted_qty=0 AND approved_qty=0",$pid,$qty,$lid,$id));
  if($ok!==1)self::redirect($id,'concurrent');
  self::event($id,$lid,$pid,'received',$qty,'Tidigare inleverans utan SKU kopplad till SKU '.$sku.'. Väntar på godkännande.');
  Dennis_WMS_Audit::update($h,['status'=>'pending_approval'],['id'=>$id]);self::redirect($id,'received_pending');
 }
 if($mode==='assign_sku')wp_die('Lägg till SKU på produkten i WooCommerce innan inleverans.',400);
 if($mode==='receive'&&!empty($line->no_stock))wp_die('Koppla raden till SKU och ange mottaget antal först.',400);
 if($mode==='receive'){
  $p=wc_get_product((int)$line->product_id);if(!$p||trim((string)$p->get_sku())==='')wp_die('Produkten behöver SKU i WooCommerce innan mottagningen kan registreras.',400);
  $qty=filter_var($_POST['received_qty']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1,'max_range'=>999999999]]);
  if($qty===false)wp_die('Ogiltigt mottaget antal',400);
  $last=self::last_order_input($_POST['last_order_date']??'');
  $batch=sanitize_text_field(wp_unslash($_POST['batch']??''));$expiry=sanitize_text_field(wp_unslash($_POST['expiry']??''));
  if($expiry&&!self::date_valid($expiry))wp_die('Ogiltigt utgångsdatum',400);
  $location=sanitize_text_field(wp_unslash($_POST['location']??''));$note=sanitize_textarea_field(wp_unslash($_POST['note']??''));
  if((int)$line->received_qty>0&&($batch!==(string)$line->batch||$expiry!==(string)$line->expiry||$location!==(string)$line->location||($last?:'')!==(string)($line->last_order_date??'')))wp_die('Raden har redan mottagna varor. Lägg till en ny rad för en annan batch, annat datum eller annan lagerplats.',409);
  $ok=Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $l SET received_qty=received_qty+%d,batch=%s,expiry=%s,last_order_date=%s,location=%s,note=%s WHERE id=%d AND receipt_id=%d",$qty,$batch,$expiry?:null,$last?:null,$location,$note,$lid,$id));
  if($ok===false)wp_die('Kunde inte registrera mottagningen.',500);
  self::event($id,$lid,(int)$line->product_id,'received',$qty,'Väntar på godkännande; batch: '.$batch.'; plats: '.$location.'; '.$note);
  Dennis_WMS_Audit::update($h,['status'=>'pending_approval'],['id'=>$id]);self::redirect($id,'received_pending');
 }
 if(($mode==='approve'||$mode==='post')&&(!empty($line->no_stock)||(int)$line->product_id===0))wp_die('Inleveransen är utan SKU. Koppla SKU och mottaget antal innan godkännande.',400);
 if($mode==='approve'){
  $line=$wpdb->get_row($wpdb->prepare("SELECT * FROM $l WHERE id=%d AND receipt_id=%d",$lid,$id));
  if(!$line)wp_die('Inleveransraden finns inte.',404);
  $available=max(0,(int)$line->received_qty-(int)$line->approved_qty-(int)$line->rejected_qty);
  $qty=filter_var($_POST['approve_qty']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1,'max_range'=>999999999]]);
  if($qty===false||$qty>$available)wp_die('Godkänt antal måste vara mellan 1 och mottaget antal som väntar på kontroll.',400);
  $p=wc_get_product((int)$line->product_id);
  if(!$p)wp_die('Produkten finns inte längre. Välj en befintlig produkt.',404);
  if(class_exists('Dennis_WMS_Kits')&&Dennis_WMS_Kits::on_demand($p))wp_die('Detta förpackning packas vid plockning och har inget eget inleveranssaldo. Registrera inleverans på komponenternas SKU.',409);
  $enable_stock=!$p->managing_stock()||$p->get_stock_quantity()===null;
  if($enable_stock&&empty($_POST['enable_stock']))wp_die('Markera Aktivera lagerhantering för att lagersätta denna produkt.',400);
  if($enable_stock&&!current_user_can('edit_post',$p->get_id()))wp_die('Du får inte ändra produktens lagerhantering.',403);
  $new_sku='';if($p->get_sku()==='')wp_die('Produkten behöver SKU innan denna rad kan lagersättas.',400);
  // Claim first so a double-click cannot approve/post the same received units twice.
  $claimed=Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $l SET approved_qty=approved_qty+%d,posted_qty=posted_qty+%d WHERE id=%d AND receipt_id=%d AND received_qty-approved_qty-rejected_qty>=%d",$qty,$qty,$lid,$id,$qty));
  if($claimed!==1)self::redirect($id,'concurrent');
  if($new_sku!==''){
   try{$p->set_sku($new_sku);if(!$p->save())throw new Exception('Kunde inte spara SKU.');}
   catch(Exception $ex){Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $l SET approved_qty=GREATEST(0,approved_qty-%d),posted_qty=GREATEST(0,posted_qty-%d) WHERE id=%d",$qty,$qty,$lid));wp_die(esc_html($ex->getMessage()),400);}
  }
  if($enable_stock){
   try{$p->set_manage_stock(true);if($p->get_stock_quantity()===null)$p->set_stock_quantity(0);if(!$p->save())throw new Exception('Kunde inte aktivera lagerhantering.');}
   catch(Exception $ex){Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $l SET approved_qty=GREATEST(0,approved_qty-%d),posted_qty=GREATEST(0,posted_qty-%d) WHERE id=%d",$qty,$qty,$lid));if($new_sku!=='')self::undo_new_sku($p,$new_sku,$id,$lid);wp_die(esc_html($ex->getMessage()),400);}
  }
  // Save the exact stock state before converting preorder quota into physical stock.
  $preorder_allocation=null;
  $was_preorder=class_exists('Dennis_WMS_Preorders')&&Dennis_WMS_Preorders::is_product($p);
  $stock_before=$p->get_stock_quantity('edit');
  $status_before=$p->get_stock_status('edit');
  $started_before=$was_preorder?$p->get_meta(Dennis_WMS_Preorders::RECEIVING_STARTED,true):null;
  try{
   if($was_preorder){
    $preorder_allocation=Dennis_WMS_Preorders::allocate_receipt((int)$p->get_id(),$qty,$id,$lid);
    $free=(int)$preorder_allocation['free'];
    if($started_before!=='yes'){
     $p->set_stock_quantity($free);$p->set_stock_status($free>0?'instock':'outofstock');
     $p->update_meta_data(Dennis_WMS_Preorders::RECEIVING_STARTED,'yes');$result=$p->save();
    }else{$result=$free>0?wc_update_product_stock($p,$free,'increase'):$p->get_stock_quantity();}
   }else{$result=wc_update_product_stock($p,$qty,'increase');}
   if($result===false||is_wp_error($result))throw new RuntimeException('WooCommerce kunde inte uppdatera saldot.');
   if(class_exists('Dennis_WMS_Batches')&&!Dennis_WMS_Batches::record_receipt($line,$qty))throw new RuntimeException('Batch-/lagerplatsregistrering misslyckades.');
  }catch(Throwable $ex){
   // Restore the original exact value, not a subtraction of the entire receipt.
   // The first preorder receipt converts a sales quota and cannot be undone by -qty.
   $restored=false;
   try{
    $fresh=wc_get_product((int)$p->get_id());
    if($fresh){
     $fresh->set_stock_quantity($stock_before);
     $fresh->set_stock_status($status_before);
     if($was_preorder){
      if($started_before==='yes')$fresh->update_meta_data(Dennis_WMS_Preorders::RECEIVING_STARTED,'yes');
      else $fresh->delete_meta_data(Dennis_WMS_Preorders::RECEIVING_STARTED);
     }
     $restored=$fresh->save()!==false;
    }
   }catch(Throwable $restore_error){$restored=false;}
   if($was_preorder)Dennis_WMS_Preorders::rollback_allocation($preorder_allocation,'Inleverans IN-'.$id);
   Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $l SET approved_qty=GREATEST(0,approved_qty-%d),posted_qty=GREATEST(0,posted_qty-%d) WHERE id=%d AND receipt_id=%d",$qty,$qty,$lid,$id));
   self::event($id,$lid,(int)$line->product_id,'approval_failed',$qty,'Godkännande avbrutet: '.$ex->getMessage().'; ursprungligt saldo återställt: '.($restored?'ja':'NEJ – MANUELL KONTROLL KRÄVS'));
   self::redirect($id,'failed');
  }
  if($new_sku!=='')self::event($id,$lid,(int)$line->product_id,'sku_assigned',0,'SKU tilldelat av kontrollant vid godkännande: '.$new_sku);
  self::event($id,$lid,(int)$line->product_id,'approved_posted',$qty,'Godkänd och lagersaldo uppdaterat. '.($preorder_allocation!==null?('Pre-order reserverat: '.(int)$preorder_allocation['allocated'].'; fritt lager: '.(int)$preorder_allocation['free'].'. '):'').'WooCommerce stock after: '.$result);
  $remaining=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(GREATEST(0,received_qty-approved_qty-rejected_qty)),0) FROM $l WHERE receipt_id=%d",$id));
  Dennis_WMS_Audit::update($h,['status'=>$remaining>0?'pending_approval':'approved'],['id'=>$id]);
  self::redirect($id,'approved_posted');
 }
 if($mode==='reject'){
  $line=$wpdb->get_row($wpdb->prepare("SELECT * FROM $l WHERE id=%d AND receipt_id=%d",$lid,$id));
  $available=max(0,(int)$line->received_qty-(int)$line->approved_qty-(int)$line->rejected_qty);
  $qty=filter_var($_POST['reject_qty']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1,'max_range'=>999999999]]);
  $reason=sanitize_textarea_field(wp_unslash($_POST['reject_reason']??''));
  if($qty===false||$qty>$available||$reason==='')wp_die('Ange ett giltigt antal och orsak för underkännandet.',400);
  $claimed=Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $l SET rejected_qty=rejected_qty+%d WHERE id=%d AND receipt_id=%d AND received_qty-approved_qty-rejected_qty>=%d",$qty,$lid,$id,$qty));
  if($claimed!==1)self::redirect($id,'concurrent');
  self::event($id,$lid,(int)$line->product_id,'rejected',$qty,$reason);
  $remaining=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(GREATEST(0,received_qty-approved_qty-rejected_qty)),0) FROM $l WHERE receipt_id=%d",$id));
  Dennis_WMS_Audit::update($h,['status'=>$remaining>0?'pending_approval':'reviewed'],['id'=>$id]);self::redirect($id,'rejected');
 }
 // Backwards compatibility for rows approved in older Dennis WMS versions but not yet posted:
 if($mode==='post'){
  $pending=(int)$line->approved_qty-(int)$line->posted_qty;if($pending<=0)self::redirect($id,'nothing_to_post');
  $p=wc_get_product((int)$line->product_id);if(!$p||!$p->managing_stock()||$p->get_stock_quantity()===null)wp_die('Aktivera WooCommerce lagerhantering för produkten innan bokföring.',400);
  if(trim((string)$p->get_sku())==='')wp_die('Produkten behöver SKU i WooCommerce innan lagersättning.',400);
  $claimed=Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $l SET posted_qty=posted_qty+%d WHERE id=%d AND receipt_id=%d AND approved_qty-posted_qty=%d",$pending,$lid,$id,$pending));if($claimed!==1)self::redirect($id,'concurrent');
  $result=wc_update_product_stock($p,$pending,'increase');if($result===false||is_wp_error($result)){Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $l SET posted_qty=posted_qty-%d WHERE id=%d",$pending,$lid));self::event($id,$lid,(int)$line->product_id,'post_failed',$pending,'WooCommerce stock API failed');self::redirect($id,'failed');}
  if(class_exists('Dennis_WMS_Batches')&&!Dennis_WMS_Batches::record_receipt($line,$pending)){wc_update_product_stock($p,$pending,'decrease');Dennis_WMS_Audit::query($wpdb->prepare("UPDATE $l SET posted_qty=posted_qty-%d WHERE id=%d",$pending,$lid));self::event($id,$lid,(int)$line->product_id,'post_failed',$pending,'Batch/location ledger failed; Woo rollback attempted');self::redirect($id,'failed');}
  self::event($id,$lid,(int)$line->product_id,'posted_legacy',$pending,'Äldre redan godkänd rad bokförd. WooCommerce stock after: '.$result);self::redirect($id,'posted');
 }
 wp_die('Okänd åtgärd',400);}
 /** Approval timestamps come from the immutable receiving event log, not print time. */
 static function approval_history($rid){
  global $wpdb;
  $events=self::table('receipt_events');
  $rows=$wpdb->get_results($wpdb->prepare("SELECT created_at,user_id,quantity FROM $events WHERE receipt_id=%d AND action IN ('approved_posted','approved') ORDER BY created_at ASC,id ASC",(int)$rid));
  return is_array($rows)?$rows:[];
 }
 static function approval_summary($rid){
  $rows=self::approval_history($rid);
  if(!$rows)return 'Ej godkänd';
  $first=reset($rows);$last=end($rows);
  $user=get_userdata((int)$last->user_id);
  $who=$user?$user->display_name:'Användare #'.(int)$last->user_id;
  $time=self::display_datetime($last->created_at);
  return $time.' · '.$who.(count($rows)>1?' (senaste av '.count($rows).' godkännanden)':'');
 }
 static function display_datetime($value){$value=trim((string)$value);return $value!==''?substr($value,0,16):'Ej angivet';}
 static function date_valid($s){$d=DateTimeImmutable::createFromFormat('!Y-m-d',$s);return $d&&$d->format('Y-m-d')===$s;}
 static function form($mode,$rid=0,$lid=0){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_receiving');echo '<input type="hidden" name="action" value="dennis_wms_receiving"><input type="hidden" name="mode" value="'.esc_attr($mode).'"><input type="hidden" name="receipt_id" value="'.esc_attr($rid).'"><input type="hidden" name="line_id" value="'.esc_attr($lid).'">';}
 static function image_label($c){return ['delivery_note'=>'Följesedel','outer_packages'=>'Ytterförpackning (outer packages)','inner_packages'=>'Innerförpackning (inner packages)','delivery'=>'Inleverans','damage'=>'Skada','packaging'=>'Emballage','product'=>'Produkt','other'=>'Övrigt'][$c]??'Övrigt';}
 static function images($rid,$lid=null){global $wpdb;$t=self::table('receipt_images');if($lid===null)return $wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE receipt_id=%d ORDER BY id DESC",$rid));return $wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE receipt_id=%d AND line_id=%d ORDER BY id DESC",$rid,$lid));}
 static function image_gallery($rid,$images,$can){if(!$images)return;$damage=false;foreach($images as $im)if($im->category==='damage')$damage=true;if($damage)echo '<div style="background:#fff1f1;border-left:5px solid #b32d2e;padding:10px 12px;margin:10px 0"><strong>⚠️ Skada registrerad på inleveransen</strong></div>';echo '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:12px;margin:12px 0">';foreach($images as $im){$url=wp_get_attachment_image_url((int)$im->attachment_id,'medium');$full=wp_get_attachment_url((int)$im->attachment_id);$u=get_userdata((int)$im->created_by);echo '<div style="border:'.($im->category==='damage'?'2px solid #b32d2e':'1px solid #ccd0d4').';border-radius:9px;background:#fff;padding:8px"><a href="'.esc_url($full).'" target="_blank" rel="noopener"><img src="'.esc_url($url?:$full).'" alt="" style="width:100%;height:130px;object-fit:cover;border-radius:6px"></a><div style="margin-top:6px"><strong>'.($im->category==='damage'?'⚠️ ':'').esc_html(self::image_label($im->category)).'</strong></div>'.($im->comment?'<div style="font-size:12px">'.esc_html($im->comment).'</div>':'').'<small>'.esc_html($u?$u->display_name:'').' · '.esc_html(self::display_datetime($im->created_at)).'</small>';if($can){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:6px">';wp_nonce_field('dennis_wms_receiving');echo '<input type="hidden" name="action" value="dennis_wms_receiving"><input type="hidden" name="mode" value="delete_image"><input type="hidden" name="receipt_id" value="'.esc_attr($rid).'"><input type="hidden" name="image_id" value="'.esc_attr($im->id).'"><button class="button button-small" onclick="return confirm(\'Ta bort bilden?\')">Ta bort</button></form>';}echo '</div>';}echo '</div>';}
 static function upload_form($rid,$lines,$default_lid=0){echo '<form method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'" style="background:#f6fbfb;border:1px solid #1D949C;border-radius:9px;padding:12px;margin:10px 0">';wp_nonce_field('dennis_wms_receiving');echo '<input type="hidden" name="action" value="dennis_wms_receiving"><input type="hidden" name="mode" value="upload_image"><input type="hidden" name="receipt_id" value="'.esc_attr($rid).'"><div style="display:flex;gap:10px;flex-wrap:wrap;align-items:end"><label><strong>📷 Bild</strong><br><input type="file" name="receipt_image" accept="image/*" capture="environment" required></label><label>Typ<br><select name="image_category"><option value="delivery_note">Följesedel</option><option value="outer_packages">Ytterförpackning (outer packages)</option><option value="inner_packages">Innerförpackning (inner packages)</option><option value="product">Produkten</option><option value="damage">⚠️ Skada</option><option value="other">Övrigt</option></select></label><label>Koppla till SKU<br><select name="line_id"><option value="0">Hela inleveransen</option>';foreach($lines as $ln){$p=wc_get_product((int)$ln->product_id);echo '<option value="'.esc_attr($ln->id).'" '.selected($default_lid,$ln->id,false).'>'.esc_html($p?($p->get_sku()?:$p->get_name()):'#'.$ln->product_id).'</option>';}echo '</select></label><label style="flex:1;min-width:220px">Kommentar<br><input name="image_comment" style="width:100%" placeholder="T.ex. kartong intryckt på vänster sida"></label><button class="button button-primary">Ladda upp bild</button></div><p class="description">På mobil kan kameran öppnas direkt. För skadebilder krävs en kommentar. Max 12 MB.</p></form>';}
 static function undo_new_sku($p,$sku,$rid,$lid){
  try{$fresh=wc_get_product($p->get_id());if($fresh&&$fresh->get_sku()===$sku){$fresh->set_sku('');$fresh->save();}}
  catch(Exception $ex){self::event($rid,$lid,$p->get_id(),'approval_failed',0,'SKU kunde inte återställas efter fel. Kontrollera produkten: '.$ex->getMessage());}
 }
 static function registration_error($id,$message){
  $fields=[];foreach(['temporary_storage','no_stock','product_name','sku','product_id','expected_qty','received_qty','batch','expiry','last_order_date','location','note'] as $key)$fields[$key]=sanitize_textarea_field(wp_unslash($_POST[$key]??''));
  set_transient('dw_receipt_form_'.get_current_user_id().'_'.$id,['message'=>$message,'fields'=>$fields],900);
  self::redirect($id,'registration_error');
 }
 static function restore_registration($id){
  $key='dw_receipt_form_'.get_current_user_id().'_'.$id;$saved=get_transient($key);if(!$saved||!is_array($saved))return;
  delete_transient($key);
  echo '<div class="notice notice-error"><p><strong>Inget sparades.</strong> '.esc_html($saved['message']).' Dina uppgifter finns kvar i formuläret.</p></div>';
  $json=wp_json_encode($saved['fields'],JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
  echo '<script>document.addEventListener("DOMContentLoaded",function(){const values='.$json.',form=document.getElementById("dw-receive-stock");if(!form)return;Object.keys(values).forEach(key=>{const field=form.elements.namedItem(key);if(field)field.value=values[key]});form.querySelectorAll("details").forEach(d=>d.open=true);});</script>';
 }
 static function last_order_input($value){$value=trim((string)wp_unslash($value));if($value!==''&&!self::date_valid($value))wp_die('Last order date måste vara ett giltigt datum.',400);return $value?:null;}
 static function lookup_sku(){
  if(!current_user_can(self::CAP)||!current_user_can('manage_woocommerce'))wp_send_json_error(['message'=>'Åtkomst nekad.'],403);
  check_ajax_referer('dennis_wms_receiving_sku','nonce');
  $sku=trim(sanitize_text_field(wp_unslash($_POST['sku']??'')));$id=$sku!==''?wc_get_product_id_by_sku($sku):0;$product=$id?wc_get_product($id):false;
  if(!$product||!in_array($product->get_type(),['simple','variation'],true))wp_send_json_error(['message'=>'SKU hittades inte. Kontrollera SKU.'],404);
  wp_send_json_success(['name'=>$product->get_name(),'sku'=>$product->get_sku()]);
 }
 static function sku_preview(){
  echo '<p><output id="dw-receipt-product-name" aria-live="polite"></output></p>';
  $config=wp_json_encode(['url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('dennis_wms_receiving_sku')],JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
  echo '<script>(function(){const config='.$config.',form=document.getElementById("dw-receive-stock"),input=form.elements.sku,output=document.getElementById("dw-receipt-product-name");let timer,request;async function lookup(){if(request)request.abort();const sku=input.value.trim();if(!sku){output.textContent="";return}request=new AbortController();output.textContent="Hämtar produktnamn…";try{const response=await fetch(config.url,{method:"POST",credentials:"same-origin",signal:request.signal,body:new URLSearchParams({action:"dennis_wms_receiving_sku",nonce:config.nonce,sku:sku})});const result=await response.json();if(input.value.trim()!==sku)return;output.textContent=result.success?result.data.name:(result.data.message||"SKU hittades inte.");}catch(error){if(error.name!=="AbortError"&&input.value.trim()===sku)output.textContent="Kunde inte hämta produktnamnet. Försök igen.";}}input.addEventListener("input",function(){clearTimeout(timer);if(request)request.abort();output.textContent="";timer=setTimeout(lookup,250)});input.addEventListener("change",function(){clearTimeout(timer);lookup()});document.addEventListener("DOMContentLoaded",function(){if(input.value.trim())lookup()});})();</script>';
 }
 static function arrival_input(){
  $raw=trim(sanitize_text_field(wp_unslash($_POST['arrived_at']??'')));$arrival=null;
  if($raw!==''){$date=DateTimeImmutable::createFromFormat('!Y-m-d\TH:i',$raw);if(!$date||$date->format('Y-m-d\TH:i')!==$raw)wp_die('Ange ett giltigt ankomstdatum och klockslag.',400);$arrival=$date->format('Y-m-d H:i:s');}
  $data=['arrived_at'=>$arrival];
  foreach(['package_count'=>'Antal paket','pallet_count'=>'Antal pallar'] as $key=>$label){$value=trim((string)wp_unslash($_POST[$key]??''));$number=$value===''?null:filter_var($value,FILTER_VALIDATE_INT,['options'=>['min_range'=>0,'max_range'=>999999999]]);if($number===false)wp_die($label.' ska vara ett heltal från 0.',400);$data[$key]=$number;}
  return $data;
 }
 static function arrival_fields($r=null){
  $arrival=$r?str_replace(' ','T',substr((string)($r->arrived_at??''),0,16)):current_time('Y-m-d\TH:i');
  echo '<div class="dw-arrival-fields"><p><label>Ankom – datum &amp; tid <input type="datetime-local" name="arrived_at" value="'.esc_attr($arrival).'"></label></p><p><label>Antal paket <input type="number" name="package_count" min="0" step="1" value="'.esc_attr($r->package_count??'').'" placeholder="Ej angivet"></label> <label>Antal pallar <input type="number" name="pallet_count" min="0" step="1" value="'.esc_attr($r->pallet_count??'').'" placeholder="Ej angivet"></label></p></div>';
 }
 static function title_input(){
  $title=sanitize_text_field(wp_unslash($_POST['receipt_title']??''));
  if(preg_match_all('/./us',$title)>190)wp_die('Titeln får vara högst 190 tecken.',400);return $title;
 }
 static function receipt_title($r){global $wpdb;$table=self::table('receipt_lines');$rows=$wpdb->get_results($wpdb->prepare("SELECT DISTINCT product_id FROM $table WHERE receipt_id=%d AND product_id>0 ORDER BY product_id",$r->id));$names=[];foreach($rows as $row){$product=wc_get_product((int)$row->product_id);if($product)$names[]=$product->get_name();}if($names)return implode(' · ',$names);return trim((string)($r->title??''))!==''?$r->title:'Inleverans IN-'.$r->id;}
 static function status_label($status){return ['draft'=>'Registrerad / förväntad','pending_approval'=>'Inväntar godkännande','approved'=>'Godkänd och lagersatt','reviewed'=>'Kontrollerad','posted'=>'Lagersatt'][$status]??$status;}
 static function notice_label($notice){return ['arrival_saved'=>'Ankomstuppgifterna är sparade. Lagersaldot är oförändrat.','saved_no_stock'=>'Inleveransen utan SKU är sparad. Antalet finns i kommentaren och inget lager har ändrats.','registration_error'=>'Kontrollera uppgifterna nedan.','title_saved'=>'Inleveransuppgifterna är sparade.','sku_assigned'=>'SKU är sparat på produkten. Inleveransen och saldot är oförändrade.','received_pending'=>'Mottagningen är sparad och inväntar godkännande. Inget lagersaldo har ändrats. Du kan stänga sidan och godkänna senare.','approved_posted'=>'Antalet är godkänt. Eventuella Pre-orders med samma SKU har reserverats först och resterande antal har lagts som fritt lager.','rejected'=>'Antalet är underkänt. Lagersaldot är oförändrat.','concurrent'=>'Raden har redan behandlats eller ändrats. Kontrollera aktuella antal innan du fortsätter.','failed'=>'Lagersättningen misslyckades. Kontrollera raden och historiken.','created'=>'Inleveransen är skapad.','sku_rows_added'=>'SKU-raderna är sparade. Registrera mottagningen när varorna har kommit.','line_added'=>'Produkten är tillagd.'][$notice]??$notice;}

  /** Read-only receipt report; browser print dialog also supports Save as PDF. */
  static function print_receipt($id){
   if(!current_user_can('pb_wms_view'))wp_die('Åtkomst nekad',403);
   global $wpdb;
   $h=self::table('receipts');$l=self::table('receipt_lines');
   $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM $h WHERE id=%d",$id));
   if(!$r)wp_die('Inleveransen hittades inte',404);
   $lines=$wpdb->get_results($wpdb->prepare("SELECT * FROM $l WHERE receipt_id=%d ORDER BY id",$id));
   $back=self::url($id);
   echo '<div class="dw-receipt-print-actions"><a class="button" href="'.esc_url($back).'">← Till inleveransen</a> <button type="button" class="button button-primary" onclick="window.print()">Skriv ut / Spara som PDF</button></div>';
   echo '<section class="dw-receipt-print"><header><h1>Inleveransrapport · IN-'.esc_html($id).'</h1><p>Utskriven: '.esc_html(wp_date('Y-m-d H:i')).'</p></header>';
   echo '<div class="dw-print-meta"><p><strong>Titel:</strong> '.esc_html($r->title?:self::receipt_title($r)).'</p><p><strong>Status:</strong> '.esc_html(self::status_label($r->status)).'</p><p><strong>Leverantör:</strong> '.esc_html($r->supplier?:'–').'</p><p><strong>Projektnr:</strong> '.esc_html($r->reference?:'–').'</p><p><strong>Förväntad dag:</strong> '.esc_html($r->expected_date?:'–').'</p><p><strong>Ankomst:</strong> '.esc_html($r->arrived_at?:'–').'</p><p><strong>Paket:</strong> '.esc_html($r->package_count===null?'–':$r->package_count).'</p><p><strong>Pallar:</strong> '.esc_html($r->pallet_count===null?'–':$r->pallet_count).'<p><strong>Godkänd datum och tid:</strong> '.esc_html(self::approval_summary($id)).'</p></div>';
   $approvals=self::approval_history($id);if(count($approvals)>1){echo '<h2>Godkännandehistorik</h2><table><thead><tr><th>Datum och tid</th><th>Godkänd av</th><th>Antal</th></tr></thead><tbody>';foreach($approvals as $a){$u=get_userdata((int)$a->user_id);echo '<tr><td>'.esc_html(self::display_datetime($a->created_at)).'</td><td>'.esc_html($u?$u->display_name:'Användare #'.(int)$a->user_id).'</td><td>'.esc_html((int)$a->quantity).'</td></tr>';}echo '</tbody></table>';}
   echo '<h2>Produktrader</h2><table><thead><tr><th>Produkt / SKU</th><th>Förväntat</th><th>Mottaget</th><th>Godkänt</th><th>Lagersatt</th><th>Underkänt</th><th>Batch / datum / plats</th></tr></thead><tbody>';
   $totals=['expected_qty'=>0,'received_qty'=>0,'approved_qty'=>0,'posted_qty'=>0,'rejected_qty'=>0];
   foreach($lines as $line){
    $product=$line->product_id?wc_get_product((int)$line->product_id):false;
    $name=$product?$product->get_name():($line->product_name?:'Okänd produkt');
    $sku=$product?$product->get_sku():'';
    foreach($totals as $key=>$_)$totals[$key]+=(int)$line->$key;
    echo '<tr><td><strong>'.esc_html($name).'</strong><br>'.esc_html($sku?:'SKU saknas').'</td>';
    foreach($totals as $key=>$_)echo '<td>'.esc_html((int)$line->$key).'</td>';
    echo '<td>Batch: '.esc_html($line->batch?:'–').'<br>Expire: '.esc_html($line->expiry?:'–').'<br>Last order date: '.esc_html($line->last_order_date?:'–').'<br>Plats: '.esc_html($line->location?:'–').'</td></tr>';
    if(!empty($line->note))echo '<tr class="dw-print-note"><td colspan="7"><strong>Kommentar:</strong> '.nl2br(esc_html($line->note)).'</td></tr>';
   }
   if(!$lines)echo '<tr><td colspan="7">Inga produktrader registrerade.</td></tr>';
   echo '</tbody><tfoot><tr><th>Totalt</th>';
   foreach($totals as $total)echo '<th>'.esc_html($total).'</th>';
   echo '<th></th></tr></tfoot></table>';
   if(!empty($r->notes))echo '<h2>Kommentar till inleveransen</h2><p>'.nl2br(esc_html($r->notes)).'</p>';
   echo '<p class="dw-print-footer">Rapporten är en ögonblicksbild och påverkar inte lagersaldon eller godkännanden.</p></section>';
   echo '<style>
   .dw-receipt-print{background:white;color:#202a35;padding:28px;max-width:1100px;margin:20px auto;font:14px/1.5 Arial,sans-serif}
   .dw-receipt-print header{display:flex;justify-content:space-between;gap:20px;border-bottom:3px solid #1d949c;margin-bottom:18px}
   .dw-receipt-print h1{font-size:24px}.dw-receipt-print h2{font-size:17px;margin-top:25px}
   .dw-print-meta{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 24px}
   .dw-print-meta p{margin:5px 0}
   .dw-receipt-print table{width:100%;border-collapse:collapse;font-size:12px}
   .dw-receipt-print th,.dw-receipt-print td{border:1px solid #ccd3da;padding:8px;text-align:left;vertical-align:top;overflow-wrap:anywhere}
   .dw-receipt-print th{background:#eaf3f4}
   .dw-receipt-print tr{break-inside:avoid}
   .dw-print-note td{background:#f7f8fa}
   .dw-print-footer{font-size:11px;color:#666;margin-top:25px}
   .dw-receipt-print-actions{margin:15px 20px}
   @media print{
    @page{size:A4 landscape;margin:12mm}
    #adminmenumain,#wpadminbar,#wpfooter,.dw-receipt-print-actions,.notice{display:none!important}
    html,body,#wpwrap,#wpcontent,#wpbody,#wpbody-content{margin:0!important;padding:0!important;background:#fff!important}
    .dw-receipt-print{padding:0;margin:0;max-width:none}
    .dw-receipt-print th{print-color-adjust:exact;-webkit-print-color-adjust:exact}
   }</style>';
  }
 static function page(){if(($_GET['storage_tab']??'')==='temporary'){Dennis_WMS_Temporary_Storage::page();return;}if(!current_user_can('pb_wms_view'))wp_die('Åtkomst nekad',403);global $wpdb;$h=self::table('receipts');$l=self::table('receipt_lines');$e=self::table('receipt_events');$id=absint($_GET['receipt_id']??0);if($id && isset($_GET['dw_print_receipt']) && $_GET['dw_print_receipt']==='1'){self::print_receipt($id);return;}$can=current_user_can(self::CAP)&&current_user_can('manage_woocommerce');echo '<div class="wrap"><h1>Inleveranser</h1>';Dennis_WMS_Temporary_Storage::tabs();echo '<p class="dw-receipt-intro">Inleveranser kräver SKU. Registrera mottaget antal och godkänn efter kontroll; först då ökar saldot.</p><style>.dw-receiving-steps{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin:16px 0}.dw-receiving-steps>div{background:#fff;border:1px solid #ddd;border-top:4px solid #1D949C;border-radius:10px;padding:14px}.dw-receiving-steps>div:last-child{border-top-color:#ED6B7C}.dw-receiving-steps span{display:block;margin-top:5px}.dw-receiving-counts{display:flex;gap:12px;flex-wrap:wrap;margin:12px 0}.dw-receiving-counts>span{background:#f6f7f7;padding:9px 12px;border-radius:7px}.dw-receiving-counts strong{display:block;font-size:20px}@media(max-width:782px){.dw-receiving-steps{grid-template-columns:1fr}}</style>';if(isset($_GET['dw_notice']))echo '<div class="notice notice-info"><p>'.esc_html(self::notice_label(sanitize_key(wp_unslash($_GET['dw_notice'])))).'</p></div>';
 if(!$id){if($can){echo '<div class="dw-receipt-new">';self::form('create');echo '<button class="button button-primary">Skapa inleverans</button></form></div>';}echo '<h2>Inleveranser</h2><form method="get"><input type="hidden" name="page" value="dennis-wms-receiving">'.(in_array($_GET['review']??'',['pending','approved'],true)?'<input type="hidden" name="review" value="'.esc_attr($_GET['review']).'">':'').'<label>Sök SKU, produktnamn, projektnr eller leverantör <input type="search" name="receipt_search" value="'.esc_attr(sanitize_text_field(wp_unslash($_GET['receipt_search']??''))).'"></label> <button class="button">Sök</button></form><p><a class="button" href="'.esc_url(self::url()).'">Pågående inleveranser</a> <a class="button" href="'.esc_url(add_query_arg('review','pending',self::url())).'">Inväntar godkännande</a></p><table class="widefat striped"><thead><tr><th>Inleverans / titel</th><th>Projektnr</th><th>Leverantör</th><th>Ankom – datum &amp; tid</th><th>Status / godkännande</th><th>Dokumentation</th></tr></thead><tbody>';$pending_only=($_GET['review']??'')==='pending';$approved_only=($_GET['review']??'')==='approved';$where=$pending_only?" WHERE EXISTS (SELECT 1 FROM $l rl WHERE rl.receipt_id=r.id AND rl.received_qty>rl.approved_qty+rl.rejected_qty)":($approved_only?" WHERE r.status IN ('approved','posted') AND NOT EXISTS (SELECT 1 FROM $l rl WHERE rl.receipt_id=r.id AND rl.received_qty>rl.approved_qty+rl.rejected_qty)":" WHERE (r.status NOT IN ('approved','posted') OR EXISTS (SELECT 1 FROM $l rl WHERE rl.receipt_id=r.id AND rl.received_qty>rl.approved_qty+rl.rejected_qty))");$search=sanitize_text_field(wp_unslash($_GET['receipt_search']??''));if($search!==''){$like='%'.$wpdb->esc_like($search).'%';$where.=($where?' AND ':' WHERE ').$wpdb->prepare('(r.title LIKE %s OR r.reference LIKE %s OR r.supplier LIKE %s OR EXISTS (SELECT 1 FROM '.$l.' search_line JOIN '.$wpdb->posts.' search_product ON search_product.ID=search_line.product_id LEFT JOIN '.$wpdb->postmeta." search_sku ON search_sku.post_id=search_line.product_id AND search_sku.meta_key='_sku' WHERE search_line.receipt_id=r.id AND (search_product.post_title LIKE %s OR search_sku.meta_value LIKE %s)))",$like,$like,$like,$like,$like);}$rows=$wpdb->get_results("SELECT r.* FROM $h r $where ORDER BY r.id DESC LIMIT 200");foreach($rows as $r){$no_stock_count=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $l WHERE receipt_id=%d AND no_stock=1",$r->id));$waiting=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(GREATEST(0,received_qty-approved_qty-rejected_qty)),0) FROM $l WHERE receipt_id=%d",$r->id));$imgs=self::images((int)$r->id);$dc=0;foreach($imgs as $im)if($im->category==='damage')$dc++;echo '<tr><td><a href="'.esc_url(($approved_only?add_query_arg('review','approved',self::url($r->id)):self::url($r->id))).'">'.esc_html(self::receipt_title($r)).'</a><br><small>IN-'.esc_html($r->id).'</small></td><td>'.esc_html($r->reference).'</td><td>'.esc_html($r->supplier).'</td><td>'.esc_html(self::display_datetime($r->arrived_at??'Ej angivet')).'</td><td>'.esc_html($waiting>0?'Inväntar godkännande':($no_stock_count>0?'Äldre rad saknar SKU':self::status_label($r->status))).($waiting>0?'<br><strong>'.esc_html($waiting).' st väntar</strong><br><a href="'.esc_url(self::url($r->id)).'">Öppna för godkännande →</a>':'').'</td><td>'.($dc?'<strong style="color:#b32d2e">⚠️ '.$dc.' skada'.($dc===1?'':'or').'</strong>':(count($imgs)?'📷 '.count($imgs).' bild'.(count($imgs)===1?'':'er'):'–')).'</td></tr>'; }echo '</tbody></table><p>Visar högst 200 inleveranser.</p></div>';return;}
 $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM $h WHERE id=%d",$id));if(!$r)wp_die('Inleveransen hittades inte',404);echo '<p><a href="'.esc_url((($_GET['review']??'')==='approved'?add_query_arg('review','approved',self::url()):self::url())).'">← Till inleveranser</a> <a class="button button-primary" href="'.esc_url(add_query_arg('dw_print_receipt','1',self::url($id))).'">Skriv ut / Spara som PDF</a></p><h2>IN-'.esc_html($id).' – '.esc_html(self::receipt_title($r)).'</h2><p>Leverantör: '.esc_html($r->supplier).' · Projektnr: '.esc_html($r->reference).' | Förväntat: '.esc_html($r->expected_date).'</p>';

 echo '<p><strong>Godkännande:</strong> '.esc_html(self::approval_summary($id)).'</p>';echo '<section class="dw-receipt-entry"><h3>Ankomst och kollin</h3>';if($can){self::form('save_arrival',$id);self::arrival_fields($r);echo '<p><button class="button">Spara ankomstuppgifter</button></p></form>';}else echo '<p>Ankom: '.esc_html(self::display_datetime($r->arrived_at??'Ej angivet')).' · Paket: '.esc_html($r->package_count??'Ej angivet').' · Pallar: '.esc_html($r->pallet_count??'Ej angivet').'</p>';echo '<p>Antal paket/pallar avser hela inleveransen. Antal räknat anges per SKU nedan.</p></section>';
 if($can){echo '<details><summary>Projektnr, leverantör och kommentar</summary>';self::form('save_title',$id);echo '<p><label>Projektnr <input name="reference" maxlength="120" value="'.esc_attr($r->reference).'"></label> <label>Leverantör <input name="supplier" maxlength="190" value="'.esc_attr($r->supplier).'"></label> <label>Förväntad dag <input type="date" name="expected_date" value="'.esc_attr($r->expected_date).'"></label></p><p><label>Kommentar om inleveransen<br><textarea name="notes" rows="2">'.esc_html($r->notes??'').'</textarea></label></p><p><button class="button">Spara inleveransuppgifter</button></p></form></details>';}

 if($can){self::restore_registration($id);echo '<section class="dw-receipt-entry"><h3>Registrera mottagna varor</h3>';self::form('add_line',$id);echo '<script>document.currentScript.parentElement.id="dw-receive-stock";</script>';echo '<input type="hidden" name="receipt_kind" value="received"><p><label>SKU <input name="sku" required placeholder="Scanna eller ange SKU"></label> <label>Antal räknat <input type="number" name="received_qty" min="1" required placeholder="Antalet ni räknat"></label></p>';self::sku_preview();Dennis_WMS_Temporary_Storage::prefill($id);echo '<fieldset class="dw-receipt-dates"><legend>Batch, lagerplats och datum (valfritt)</legend><p><label>Lagerplats <input name="location" placeholder="T.ex. A3"></label> <label>Batch <input name="batch" placeholder="Valfritt"></label> <label>Utgångsdatum <input type="date" name="expiry"></label> <label>Last order date <input type="date" name="last_order_date"></label></p></fieldset><p><label>Kommentar<br><textarea name="note" rows="2" style="width:100%;max-width:700px" placeholder="T.ex. skick, avvikelser eller information till kontrollanten"></textarea></label></p><details><summary>Förväntat antal (valfritt)</summary><p><label>Förväntat antal <input type="number" name="expected_qty" min="0" placeholder="Lämna tomt om okänt"></label></p></details><p><button class="button button-primary">Spara mottagning – godkänn senare</button></p></form></section>';}

 if($can){echo '<details><summary>Registrera många SKU från Excel</summary><h3>Snabbregistrera många SKU</h3><p>Klistra in rader från Excel: SKU [tabb] mottaget antal [tabb] lagerplats [tabb] batch [tabb] utgångsdatum [tabb] Last order date (ÅÅÅÅ-MM-DD). De fyra sista kolumnerna är valfria. Även semikolon fungerar. En rad per SKU/batch/plats. Alla rader kontrolleras innan de sparas. Inget lagersaldo ändras förrän mottagna enheter har godkänts.</p>';self::form('sku_bulk',$id);echo '<input type="hidden" name="receipt_kind" value="received"><textarea name="sku_rows" rows="7" style="width:100%;max-width:900px" required placeholder="SKU-001&#9;50&#9;A3&#9;B123&#9;2027-12-31"></textarea><p><button class="button button-primary">Spara mottagna SKU-rader – godkänn senare</button></p></form></details>';}
 $lines=$wpdb->get_results($wpdb->prepare("SELECT * FROM $l WHERE receipt_id=%d ORDER BY id",$id));
 // Snabbkontroll: återanvänder exakt samma godkännande som detaljvyn, inklusive lagerbokföring.
 $pending_lines=array_values(array_filter($lines,static function($item){return max(0,(int)$item->received_qty-(int)$item->approved_qty-(int)$item->rejected_qty)>0;}));
 if($pending_lines){
  echo '<section class="dw-quick-approval" style="margin:20px 0;padding:20px;background:#fff;border:1px solid #d8e1eb;border-radius:14px;box-shadow:0 5px 18px rgba(20,40,70,.07)"><h2 style="margin-top:0">✓ Snabbgodkännande</h2><p>Kontrollera mottaget antal och godkänn varje rad. Lagersaldot ändras först när du godkänner. Rader med avvikelser eller saknade uppgifter granskas i detaljvyn.</p><div style="display:grid;gap:12px">';
  foreach($pending_lines as $quick){
   $qty=max(0,(int)$quick->received_qty-(int)$quick->approved_qty-(int)$quick->rejected_qty);
   $product=empty($quick->no_stock)?wc_get_product((int)$quick->product_id):false;
   $sku=$product?(string)$product->get_sku():'';
   $ready=$can&&$product&&$sku!==''&&$product->managing_stock()&&$product->get_stock_quantity()!==null;
   echo '<div style="border:1px solid #e4e8ee;border-radius:10px;padding:14px;background:#fafbfd"><div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap"><div><strong>'.esc_html($product?$product->get_name():($quick->product_name?:'Produkt utan SKU')).'</strong><div style="color:#576577">SKU: '.esc_html($sku?:'Saknas').' · Förväntat: '.esc_html((int)$quick->expected_qty).' · Mottaget: '.esc_html((int)$quick->received_qty).'</div><div style="color:#576577">Batch: '.esc_html($quick->batch?:'–').' · Plats: '.esc_html($quick->location?:'–').' · Utgång: '.esc_html($quick->expiry?:'–').'</div></div><strong>'.esc_html($qty).' st att kontrollera</strong></div>';
   if($ready){self::form('approve',$id,$quick->id);echo '<p style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:0"><label>Godkänn antal <input type="number" name="approve_qty" min="1" max="'.esc_attr((string)$qty).'" value="'.esc_attr((string)$qty).'" required style="width:95px"></label> <button class="button button-primary" onclick="return confirm(\'Godkänn detta antal och uppdatera lagersaldot?\')">✓ Godkänn och lagersätt</button></p></form>';}
   else echo '<p style="color:#995c00;margin-bottom:0">⚠ Kräver kontroll av SKU eller lagerhantering i detaljvyn nedan.</p>';
   echo '</div>';
  }
  echo '</div><p style="color:#576577;margin-bottom:0">Varje godkännande sparas och loggas separat. Underkännande och komplettering görs i respektive detaljrad nedan.</p></section>';
 }
 $all_images=self::images($id);echo '<details class="dw-receipt-documentation"><summary>Bilder: följesedel, förpackningar och produkt</summary><h3>📷 Bilder och dokumentation</h3><p>Ladda upp bilder av följesedel, ytterförpackning, innerförpackning och produkten. Välj bildkategori för varje bild. Bilder kan kopplas till en specifik SKU.</p>';self::image_gallery($id,$all_images,$can);if($can)self::upload_form($id,$lines);echo '</details><h2>Sparade rader</h2>'; $shown=0;foreach($lines as $line){$shown++;$p=wc_get_product((int)$line->product_id);echo '<div class="dw-receipt-line"><h3>'.esc_html($p?$p->get_name():($line->product_name??'Produkt borttagen')).' – '.esc_html($p?$p->get_sku():'#'.$line->product_id).'</h3><div class="dw-receiving-counts" style="'.(!empty($line->no_stock)?'display:none':'').'"><span>Antal räknat<strong>'.esc_html($line->received_qty).' st</strong></span><span>Väntar på godkännande<strong>'.esc_html(max(0,(int)$line->received_qty-(int)$line->approved_qty-(int)$line->rejected_qty)).' st</strong></span><span>Godkänt / tillagt i lager<strong>'.esc_html($line->posted_qty).' st</strong></span></div><p>Förväntat: '.esc_html((int)$line->expected_qty>0?$line->expected_qty.' st':'Ej angivet').' · Underkänt: '.esc_html($line->rejected_qty).' st</p><p>Batch: '.esc_html($line->batch).' | Utgångsdatum: '.esc_html($line->expiry).' | Last order date: '.esc_html($line->last_order_date??'').' | Plats: '.esc_html($line->location).'</p><p><strong>Kommentar:</strong> '.nl2br(esc_html($line->note?:'Ingen kommentar')).'</p>';if(!empty($line->no_stock)){echo '<p><strong>Äldre rad utan SKU</strong> – antalet finns i kommentaren. Inget lagersaldo har ändrats.</p>';if($can){echo '<details><summary>Komplettera äldre rad med befintligt SKU</summary>';self::form('connect_sku',$id,$line->id);echo '<p><label>Befintligt SKU <input name="connect_sku" required></label> <label>Antal räknat <input type="number" name="received_qty" min="1" required></label> <button class="button">Koppla SKU – godkänn senare</button></p></form></details>';}echo '</div>';continue;}$lineimgs=self::images($id,(int)$line->id);if($lineimgs){$ld=0;foreach($lineimgs as $li)if($li->category==='damage')$ld++;echo '<p><strong>'.($ld?'⚠️ '.$ld.' skadebild'.($ld===1?'':'er'):'📷 '.count($lineimgs).' kopplad'.(count($lineimgs)===1?' bild':'e bilder')).'</strong></p>';}if($can){echo '<details><summary>Registrera fler varor på samma rad</summary>';self::form('receive',$id,$line->id);echo '<div style="background:#f6f7f7;padding:10px;border-radius:7px"><strong>Registrera ytterligare mottagning på samma rad</strong><p>Efter registrering kan du lämna sidan. Öppna inleveransen senare via Inväntar godkännande för att kontrollera och godkänna varorna.</p><p><label>Antal räknat (ytterligare) <input type="number" name="received_qty" min="1" required></label> <label>Batch <input name="batch" value="'.esc_attr($line->batch).'"></label> <label>Utgångsdatum <input type="date" name="expiry" value="'.esc_attr($line->expiry).'"></label> <label>Last order date <input type="date" name="last_order_date" value="'.esc_attr($line->last_order_date??'').'"></label> <label>Lagerplats <input name="location" value="'.esc_attr($line->location).'"></label></p><p><input name="note" placeholder="Kommentar vid mottagning" style="width:70%"></p><button class="button">Spara mottagning – godkänn senare</button></div></form></details>';
 $review=max(0,(int)$line->received_qty-(int)$line->approved_qty-(int)$line->rejected_qty);
 if($review>0){echo '<div style="background:#fff8e5;border-left:4px solid #dba617;padding:10px;margin-top:10px"><strong>⚠️ '.$review.' st väntar på godkännande – ännu inte i lagersaldot</strong>';self::form('approve',$id,$line->id);if($p&&(!$p->managing_stock()||$p->get_stock_quantity()===null))echo '<p><label><input type="checkbox" name="enable_stock" value="1" required> Aktivera lagerhantering på produkten vid godkännande</label></p>';if($p&&$p->get_sku()==='')echo '<p><strong>SKU saknas.</strong> Lägg till SKU på produkten i WooCommerce innan lagersättning.</p>';else echo '<p><strong>Påfyllning</strong> – befintligt SKU: '.esc_html($p?$p->get_sku():'–').'</p>';echo '<p><label>Godkänn antal <input type="number" name="approve_qty" min="1" max="'.esc_attr((string)$review).'" value="'.esc_attr((string)$review).'" required></label> <button class="button button-primary" onclick="return confirm(\'Lägg till det godkända antalet i lagret?\')">✓ Godkänn och lägg till i lager</button></p></form>';echo '<details><summary>Underkänn varor, till exempel vid skada</summary>';self::form('reject',$id,$line->id);echo '<p><label>Underkänn antal <input type="number" name="reject_qty" min="1" max="'.esc_attr((string)$review).'" required></label> <label>Orsak <input name="reject_reason" required placeholder="T.ex. skadad vara"></label> <button class="button">Underkänn</button></p></form></details></div>';}
 if((int)$line->approved_qty>(int)$line->posted_qty){self::form('post',$id,$line->id);echo '<div class="notice notice-warning inline"><p>Den här raden godkändes i en äldre WMS-version men har inte lagersatts ännu. <button class="button button-primary">Lagersätt tidigare godkänt antal</button></p></div></form>';}}echo '</div>';}
 if(!$shown)echo '<p class="dw-receipt-empty">Inga varor registrerade ännu.</p>';echo '<details class="dw-receipt-history"><summary>Händelselogg</summary><table class="widefat striped"><thead><tr><th>Tid</th><th>Åtgärd</th><th>SKU</th><th>Produkt</th><th>Antal</th><th>Användare</th><th>Detaljer</th></tr></thead><tbody>';$events=$wpdb->get_results($wpdb->prepare("SELECT * FROM $e WHERE receipt_id=%d ORDER BY id DESC LIMIT 200",$id));foreach($events as $ev){$u=get_userdata($ev->user_id);$product=$ev->product_id?wc_get_product((int)$ev->product_id):false;$sku=trim((string)($ev->sku??''));if($sku===''&&$product)$sku=$product->get_sku();echo '<tr><td>'.esc_html(self::display_datetime($ev->created_at)).'</td><td>'.esc_html(Dennis_WMS_Batches::action_label($ev->action)).'</td><td><strong>'.esc_html($sku?:'–').'</strong></td><td>'.esc_html($product?$product->get_name():($ev->product_id?'#'.$ev->product_id:'Hela inleveransen')).'</td><td>'.esc_html($ev->quantity).'</td><td>'.esc_html($u?$u->display_name:$ev->user_id).'</td><td>'.esc_html($ev->detail).'</td></tr>';}echo '</tbody></table></details></div>';}
 static function stats(){if(!current_user_can('pb_wms_view'))wp_die('Åtkomst nekad',403);global $wpdb;$h=self::table('receipts');$l=self::table('receipt_lines');$e=self::table('receipt_events');$days=absint($_GET['days']??30);if(!in_array($days,[7,30,90,365],true))$days=30;$since=gmdate('Y-m-d H:i:s',time()-$days*DAY_IN_SECONDS);$sum=$wpdb->get_row($wpdb->prepare("SELECT COUNT(DISTINCT receipt_id) receipts,COALESCE(SUM(CASE WHEN action='received' THEN quantity ELSE 0 END),0) received,COALESCE(SUM(CASE WHEN action IN ('posted','approved_posted','posted_legacy') THEN quantity ELSE 0 END),0) posted,COALESCE(SUM(CASE WHEN action IN ('post_failed','approval_failed') THEN 1 ELSE 0 END),0) failures FROM $e WHERE created_at >= %s",$since));$daily=$wpdb->get_results($wpdb->prepare("SELECT DATE(created_at) day,SUM(CASE WHEN action='received' THEN quantity ELSE 0 END) received,SUM(CASE WHEN action IN ('posted','approved_posted','posted_legacy') THEN quantity ELSE 0 END) posted FROM $e WHERE created_at >= %s GROUP BY DATE(created_at) ORDER BY day",$since));$products=$wpdb->get_results($wpdb->prepare("SELECT product_id,SUM(quantity) units FROM $e WHERE action IN ('posted','approved_posted','posted_legacy') AND created_at >= %s GROUP BY product_id ORDER BY units DESC LIMIT 20",$since));$suppliers=$wpdb->get_results($wpdb->prepare("SELECT h.supplier,SUM(CASE WHEN e.action='received' THEN e.quantity ELSE 0 END) received,SUM(CASE WHEN e.action IN ('posted','approved_posted','posted_legacy') THEN e.quantity ELSE 0 END) posted FROM $e e JOIN $h h ON h.id=e.receipt_id WHERE e.created_at >= %s GROUP BY h.supplier ORDER BY received DESC LIMIT 20",$since));$outstanding=$wpdb->get_row("SELECT COALESCE(SUM(GREATEST(0,expected_qty-received_qty)),0) remaining,COALESCE(SUM(GREATEST(0,approved_qty-posted_qty)),0) pending,COALESCE(SUM(rejected_qty),0) rejected,COALESCE(SUM(GREATEST(0,received_qty-approved_qty-rejected_qty)),0) waiting FROM $l");echo '<div class="wrap"><h1>Inleveransstatistik</h1><p>Antal och enheter, inga priser. Perioden avser händelsedatum; öppna restantal avser samtliga registrerade inleveranser.</p><form><input type="hidden" name="page" value="dennis-wms-receiving-stats"><select name="days">';foreach([7,30,90,365] as $d)echo '<option value="'.$d.'" '.selected($d,$days,false).'>'.$d.' dagar</option>';echo '</select> <button class="button">Visa</button></form><div style="display:flex;flex-wrap:wrap;gap:12px;margin:20px 0">';foreach(['Inleveranser med händelser'=>$sum->receipts,'Mottagna enheter'=>$sum->received,'Bokförda enheter'=>$sum->posted,'Misslyckade bokföringar'=>$sum->failures,'Förväntade enheter kvar'=>$outstanding->remaining,'Inväntar godkännande'=>$outstanding->waiting,'Äldre godkända ej lagersatta'=>$outstanding->pending,'Ej godkända totalt'=>$outstanding->rejected] as $name=>$value)echo '<div style="background:white;border:1px solid #ddd;padding:16px;min-width:155px"><div>'.esc_html($name).'</div><strong style="font-size:26px">'.esc_html(number_format_i18n($value)).'</strong></div>';echo '</div><h2>Mottagna och bokförda enheter per dag</h2>';self::bars($daily,'day',['received'=>'Mottaget','posted'=>'Bokfört']);echo '<h2>Mest inlevererade produkter (bokförda enheter)</h2>';$pRows=[];foreach($products as $p){$product=wc_get_product((int)$p->product_id);$pRows[]=(object)['name'=>$product?($product->get_sku()?:$product->get_name()):'#'.$p->product_id,'units'=>$p->units];}self::bars($pRows,'name',['units'=>'Enheter']);echo '<h2>Leverantörer – mottagna och bokförda enheter</h2>';self::bars($suppliers,'supplier',['received'=>'Mottaget','posted'=>'Bokfört']);echo '<p><small>Mottagna enheter påverkar inte lagret. Först vid godkännande uppdateras WooCommerce och Dennis WMS batch-/lagerplatssaldo. Underkända enheter påverkar aldrig lagersaldot. Plocklistan använder Plockordning-förslag. Historik börjar när modulen används.</small></p></div>';}
 static function sku_stats(){if(!current_user_can('pb_wms_view'))wp_die('Åtkomst nekad',403);global $wpdb;$e=self::table('receipt_events');$l=self::table('receipt_lines');$sku=sanitize_text_field(wp_unslash($_GET['sku']??''));echo '<div class="wrap"><h1>SKU – inleveransanalys</h1><form method="get"><input type="hidden" name="page" value="dennis-wms-sku-stats"><label>SKU <input name="sku" value="'.esc_attr($sku).'" required></label> <button class="button button-primary">Visa produkt</button></form>';
 if($sku!==''){$pid=wc_get_product_id_by_sku($sku);$p=$pid?wc_get_product($pid):false;if(!$p){echo '<p>Ingen produkt hittades för SKU.</p></div>';return;}
 $totals=$wpdb->get_row($wpdb->prepare("SELECT COALESCE(SUM(CASE WHEN action='received' THEN quantity ELSE 0 END),0) received,COALESCE(SUM(CASE WHEN action IN ('posted','approved_posted','posted_legacy') THEN quantity ELSE 0 END),0) posted,COUNT(DISTINCT CASE WHEN action='received' THEN receipt_id END) receipts FROM $e WHERE product_id=%d",$pid));
 echo '<h2>'.esc_html($p->get_name()).' – '.esc_html($p->get_sku()).'</h2><p>WooCommerce aktuellt saldo: '.esc_html($p->get_stock_quantity()===null?'Ej lagerstyrd':$p->get_stock_quantity()).' | Mottaget: '.esc_html($totals->received).' | Bokfört: '.esc_html($totals->posted).' | Inleveranser: '.esc_html($totals->receipts).'</p>';
 $daily=$wpdb->get_results($wpdb->prepare("SELECT DATE(created_at) day,SUM(CASE WHEN action='received' THEN quantity ELSE 0 END) received,SUM(CASE WHEN action IN ('posted','approved_posted','posted_legacy') THEN quantity ELSE 0 END) posted FROM $e WHERE product_id=%d GROUP BY DATE(created_at) ORDER BY day DESC LIMIT 60",$pid));$daily=array_reverse($daily);echo '<h2>Inleverans och bokföring per dag (senaste 60 registrerade dagar)</h2>';self::bars($daily,'day',['received'=>'Mottaget','posted'=>'Bokfört']);
 $lines=$wpdb->get_results($wpdb->prepare("SELECT r.id receipt_id,r.supplier,l.expected_qty,l.received_qty,l.approved_qty,l.posted_qty,l.rejected_qty,l.location,l.batch,l.expiry,l.last_order_date FROM $l l JOIN ".self::table('receipts')." r ON r.id=l.receipt_id WHERE l.product_id=%d ORDER BY l.id DESC LIMIT 100",$pid));echo '<h2>Senaste 100 inleveransraderna</h2><table class="widefat striped"><thead><tr><th>Inleverans</th><th>Leverantör</th><th>Förväntat</th><th>Mottaget</th><th>Godkänt</th><th>Bokfört</th><th>Ej godkänt</th><th>Lagerplats</th><th>Batch</th><th>Utgång</th><th>Last order date</th></tr></thead><tbody>';foreach($lines as $r){echo '<tr><td><a href="'.esc_url(self::url($r->receipt_id)).'">IN-'.esc_html($r->receipt_id).'</a></td>';foreach(['supplier','expected_qty','received_qty','approved_qty','posted_qty','rejected_qty','location','batch','expiry','last_order_date'] as $key)echo '<td>'.esc_html($r->$key).'</td>';echo '</tr>';}echo '</tbody></table><p>Batch, expire date och plats registreras per inleveransrad och bokförda rader förs över till batchsaldot. Historik börjar när WMS registrerar händelser.</p>';}
 echo '</div>';}
 static function bars($rows,$label,$fields){$max=1;foreach($rows as $r)foreach($fields as $key=>$title)$max=max($max,(int)$r->$key);if(!$rows){echo '<p>Ingen data för perioden.</p>';return;}echo '<div style="background:white;border:1px solid #ddd;padding:15px;max-width:950px">';foreach($rows as $r){echo '<div style="margin:12px 0"><strong>'.esc_html($r->$label?:'Ej angiven').'</strong>';foreach($fields as $key=>$title){$value=(int)$r->$key;echo '<div style="display:flex;gap:10px;align-items:center;margin:5px 0"><span style="min-width:90px">'.esc_html($title).'</span><div style="flex:1;background:#e8edf3;border-radius:4px;height:14px"><div style="background:#2271b1;width:'.esc_attr(round(100*$value/$max,2)).'%;height:14px;border-radius:4px"></div></div><b>'.esc_html(number_format_i18n($value)).'</b></div>';}echo '</div>';}echo '</div>';}
}
Dennis_WMS_Receiving::boot();
