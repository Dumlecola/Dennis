<?php
if (!defined('ABSPATH')) exit;
/** Local WMS workflow for remote WooCommerce orders. No stock or remote order status writes. */
final class Dennis_WMS_Remote_Workflow {
 const OPT='dw_remote_order_workflow_v1';
 static function boot(){ add_action('admin_post_dw_remote_order_workflow',[__CLASS__,'save']); }
 static function order_key($row){ return absint($row->shop_id).':'.absint($row->remote_order_id); }
 static function all(){ $v=get_option(self::OPT,[]);return is_array($v)?$v:[]; }
 static function state($row){ $all=self::all();$v=$all[self::order_key($row)]??[];return is_array($v)?$v:[]; }
 static function save(){
  if(!current_user_can('pb_wms_manage')||!current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad',403);
  $id=absint($_POST['remote_order_id']??0);
  check_admin_referer('dw_remote_order_workflow_'.$id);
  $row=Dennis_WMS_Multi_Shop::get_cached_order($id);
  if(!$row)wp_die('Order saknas',404);
  if(!in_array((string)$row->status,['processing','on-hold'],true))wp_die('Endast aktiva ordrar kan plockas och packas.',409);
  $items=Dennis_WMS_Order_UI::remote_items($row);
  $valid=[];
  foreach($items as $item){$line=absint($item['item_id']??0);if($line>0)$valid[(string)$line]=true;}
  if(!$valid)wp_die('Ordern har inga identifierbara orderrader. Synkronisera igen.',409);
  $event=sanitize_key(wp_unslash($_POST['workflow_event']??''));
  $all=self::all();$key=self::order_key($row);$state=isset($all[$key])&&is_array($all[$key])?$all[$key]:[];
  $picked=isset($state['picked'])&&is_array($state['picked'])?$state['picked']:[];
  $before=['picked'=>$picked,'packed'=>!empty($state['packed'])];
  if($event==='save_pick'){
   $submitted=isset($_POST['picked'])&&is_array($_POST['picked'])?wp_unslash($_POST['picked']):[];
   $next=[];
   foreach($submitted as $line){$line=(string)absint($line);if(isset($valid[$line]))$next[$line]=true;}
   $state['picked']=$next;
   $state['packed']=false; // Packing is invalidated if picking changes.
  }elseif($event==='finish_pack'){
   foreach($valid as $line=>$_){if(empty($picked[$line]))wp_die('Alla orderrader måste markeras som plockade innan packning kan slutföras.',409);}
   $state['packed']=true;
  }elseif($event==='reopen_pack'){
   $state['packed']=false;
  }else wp_die('Okänd åtgärd',400);
  $state['updated_at']=current_time('mysql');$state['updated_by']=get_current_user_id();
  $state['history']=isset($state['history'])&&is_array($state['history'])?$state['history']:[];
  array_unshift($state['history'],['time'=>current_time('mysql'),'user'=>get_current_user_id(),'event'=>$event,'before'=>$before,'after'=>['picked'=>$state['picked']??[],'packed'=>!empty($state['packed'])]]);
  $state['history']=array_slice($state['history'],0,100);
  $all[$key]=$state;
  if(!update_option(self::OPT,$all,false)){
   // WordPress returns false for an unchanged option: still allow a harmless repeat submission.
   if(self::state($row)!==$state)wp_die('Arbetsflödet kunde inte sparas. Försök igen.',500);
  }
  wp_safe_redirect(add_query_arg(['page'=>'dennis-wms-shops','view'=>'order','remote_order_id'=>$id,'workflow_saved'=>1],admin_url('admin.php')));exit;
 }
 static function panel($row){
  $id=absint($row->id);$state=self::state($row);$picked=isset($state['picked'])&&is_array($state['picked'])?$state['picked']:[];
  $items=Dennis_WMS_Order_UI::remote_items($row);$valid=[];
  foreach($items as $item){$line=absint($item['item_id']??0);if($line)$valid[(string)$line]=true;}
  $count=0;foreach($valid as $key=>$unused)if(!empty($picked[$key]))$count++;
  $total=count($valid);$complete=$total>0&&$count===$total;$packed=!empty($state['packed']);
  echo '<div id="dw-pick" class="dw-order-section"><h3>Plockning – ansluten shop</h3>';
  echo '<p>'.absint($count).' av '.absint($total).' orderrader plockade. Registreringen sparas centralt i WMS.</p>';
  if(isset($_GET['workflow_saved']))echo '<p><strong>Arbetsflödet sparat.</strong></p>';
  if(!current_user_can('pb_wms_manage')||!current_user_can('manage_woocommerce')){
   echo '<p>Du behöver behörighet för att ändra plockning.</p>';
  }else{
   echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dw_remote_order_workflow_'.$id);
   echo '<input type="hidden" name="action" value="dw_remote_order_workflow"><input type="hidden" name="workflow_event" value="save_pick"><input type="hidden" name="remote_order_id" value="'.absint($id).'">';
   foreach($items as $item){$line=(string)absint($item['item_id']??0);if(!isset($valid[$line]))continue;
    echo '<label style="display:block;margin:12px 0"><input type="checkbox" name="picked[]" value="'.esc_attr($line).'" '.checked(!empty($picked[$line]),true,false).'> '.esc_html((string)($item['name']??'Produkt')).' — '.esc_html((string)($item['sku']??'')).' × '.esc_html((string)($item['qty']??0)).'</label>';
   }
   echo '<button class="button button-primary" '.($total?'':'disabled').'>Spara plockning</button></form>';
  }
  echo '<p><small>Denna registrering drar inte lagersaldo och ändrar inte orderstatus i WooCommerce.</small></p></div>';
  echo '<div id="dw-pack" class="dw-order-section"><h3>Packning – ansluten shop</h3>';
  echo '<p>'.($packed?'Färdigpackad i Dennis WMS':($complete?'Redo att färdigpacka':'Plockningen måste slutföras först')).'</p>';
  if(current_user_can('pb_wms_manage')&&current_user_can('manage_woocommerce')&&($complete||$packed)){
   echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dw_remote_order_workflow_'.$id);
   echo '<input type="hidden" name="action" value="dw_remote_order_workflow"><input type="hidden" name="remote_order_id" value="'.absint($id).'">';
   echo '<button class="button" name="workflow_event" value="'.($packed?'reopen_pack':'finish_pack').'">'.($packed?'Återöppna packning':'Markera färdigpackad').'</button></form>';
  }
  echo '</div>';
 }
 static function history($row){
  $s=self::state($row);$hist=$s['history']??[];
  echo '<section id="dw-history" class="dw-order-section"><h2>Plock- och packhistorik</h2>';
  if(!$hist){echo '<p>Ingen registrerad aktivitet.</p></section>';return;}
  echo '<table class="widefat striped"><thead><tr><th>Tid</th><th>Användar-ID</th><th>Händelse</th></tr></thead><tbody>';
  foreach($hist as $h){echo '<tr><td>'.esc_html((string)($h['time']??'')).'</td><td>'.absint($h['user']??0).'</td><td>'.esc_html((string)($h['event']??'')).'</td></tr>';}
  echo '</tbody></table></section>';
 }
}
