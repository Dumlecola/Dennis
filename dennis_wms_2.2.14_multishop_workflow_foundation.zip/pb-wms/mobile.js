/* Accessible mobile layouts; data and submit controls stay in their original forms. */
(function () {
  'use strict';
  function scannerLinks() {
    var page=new URLSearchParams(location.search).get('page');
    if(!page || !document.body.classList.contains('dennis-wms-modern'))return;
    var modes={'dennis-wms-orders':'pick','dennis-wms-products':'search'};
    var mode=modes[page];if(!mode)return;
    var wrap=document.querySelector('#wpbody-content .wrap');if(!wrap||wrap.querySelector('.dw-inline-scanner-link'))return;
    var orderId=new URLSearchParams(location.search).get('order_id');
    var link=document.createElement('a');link.className='button button-primary dw-inline-scanner-link';
    var params=new URLSearchParams({page:'dennis-wms-scanner',scan_mode:mode});
    if(mode==='pick'&&orderId&&/^\d+$/.test(orderId))params.set('scan_order',orderId);
    link.href='admin.php?'+params.toString();link.textContent=mode==='pick'?'📷 Scanna för plockning':'📷 Scanna och sök produkt';
    link.setAttribute('aria-label',link.textContent+' – öppnar scanningvyn');
    var h=wrap.querySelector('h1');if(h)h.insertAdjacentElement('afterend',link);else wrap.prepend(link);
  }
  function adapt() {
    if (!document.body.classList.contains('dennis-wms-modern')) return;
    scannerLinks();
    document.querySelectorAll('#wpbody-content .wrap table').forEach(function (table) {
      if (table.dataset.dwMobileReady) {
        if (table.classList.contains('dw-mobile-cards') && table.tHead) {
          var labels = Array.from(table.tHead.rows[0].cells).map(function (cell) { return cell.textContent.trim(); });
          Array.from(table.tBodies).forEach(function (body) { Array.from(body.rows).forEach(function (row) {
            if (row.cells.length !== labels.length) return;
            Array.from(row.cells).forEach(function (cell, index) { if (!cell.hasAttribute('data-label')) cell.dataset.label = labels[index]; });
          }); });
        }
        return;
      }
      table.dataset.dwMobileReady = '1';
      var head = table.tHead;
      var headers = head && head.rows.length === 1 ? Array.from(head.rows[0].cells) : [];
      var rows = Array.from(table.tBodies).flatMap(function (body) { return Array.from(body.rows); });
      var simple = headers.length > 0 && headers.every(function (cell) { return cell.colSpan === 1 && cell.rowSpan === 1; }) && rows.every(function (row) {
        return row.cells.length === headers.length && Array.from(row.cells).every(function (cell) { return cell.colSpan === 1 && cell.rowSpan === 1; });
      });
      // Tracking already has its own mobile layout. Matrix/merged-cell tables scroll as a whole.
      if (simple && !table.matches('.dw-track-table,.dw-delivery-queue,#dw-dist-table,.dw-product-list')) {
        table.classList.add('dw-mobile-cards');
        table.setAttribute('role', 'table');
        Array.from(table.rows).forEach(function (row) { row.setAttribute('role', 'row'); });
        headers.forEach(function (cell) { cell.setAttribute('role', 'columnheader'); });
        rows.forEach(function (row) {
          Array.from(row.cells).forEach(function (cell, index) {
            if (!cell.hasAttribute('data-label')) cell.dataset.label = headers[index].textContent.trim();
            cell.setAttribute('role', cell.tagName === 'TH' ? 'rowheader' : 'cell');
          });
        });
      } else if (!table.matches('.dw-track-table,.dw-delivery-queue')) {
        var wrapper = document.createElement('div');
        wrapper.className = 'dw-mobile-table-scroll';
        wrapper.tabIndex = 0;
        wrapper.setAttribute('role', 'region');
        wrapper.setAttribute('aria-label', 'Tabell – svep i sidled för att se alla kolumner');
        table.parentNode.insertBefore(wrapper, table);
        wrapper.appendChild(table);
      }
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', adapt); else adapt();
  // SKU searches and dynamic inventory/order rows may add new tables.
  var queued = false;
  new MutationObserver(function (changes) {
    if (queued || !changes.some(function (change) { return change.addedNodes.length > 0; })) return;
    queued = true;
    requestAnimationFrame(function () { queued = false; adapt(); });
  }).observe(document.documentElement, { childList: true, subtree: true });
})();
