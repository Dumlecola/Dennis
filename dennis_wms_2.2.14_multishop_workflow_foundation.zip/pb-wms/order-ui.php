<?php
if (!defined('ABSPATH')) exit;
final class Dennis_WMS_Order_UI {
 static function status_badge($label,$kind='blue'){return '<span class="dw-status dw-status-'.esc_attr($kind).'">'.esc_html($label).'</span>';}
 static function card($icon,$title,$html){echo '<div class="dw-info-card"><span class="dashicons '.esc_attr($icon).'"></span><div><h3>'.esc_html($title).'</h3>'.$html.'</div></div>';}
 static function render($order){
  $id=$order->get_id();$pick=Dennis_WMS_Orders::phase_status($order,'pick');$pack=Dennis_WMS_Orders::phase_status($order,'pack');$depot=class_exists('Dennis_WMS_Depot')?Dennis_WMS_Depot::state($order):'';
  $wms=class_exists('Dennis_WMS_Delivery')?Dennis_WMS_Delivery::workflow_status('local',$id,$order):['label'=>wc_get_order_status_name($order->get_status()),'kind'=>'blue'];
  $created=$order->get_date_created()?$order->get_date_created()->date_i18n('Y-m-d H:i'):'–';$name=trim($order->get_formatted_billing_full_name());if($name==='')$name='Ingen kund angiven';$email=$order->get_billing_email();$phone=$order->get_billing_phone();
  $shipname=trim($order->get_formatted_shipping_full_name());$addr1=$order->get_shipping_address_1();$addr2=$order->get_shipping_address_2();$city=trim($order->get_shipping_postcode().' '.$order->get_shipping_city());$country=$order->get_shipping_country();$country=$country&&function_exists('WC')&&WC()->countries?WC()->countries->countries[$country]??$country:$country;
  echo '<div class="dw-order-app"><div class="dw-order-title"><div><a class="dw-back" href="'.esc_url(Dennis_WMS_Orders::url()).'">‹ Tillbaka till order</a><p><span class="dw-shop-badge">🏬 '.esc_html(class_exists('Dennis_WMS_Product_View')?Dennis_WMS_Product_View::central_name():(get_bloginfo('name')?:'Huvudshop')).'</span></p><h1>Order #<a href="'.esc_url(Dennis_WMS_Orders::wc_edit_url($order)).'">'.esc_html($order->get_order_number()).'</a></h1><p>'.esc_html($created).' <span>•</span> '.esc_html($name).($email?' <span>•</span> '.esc_html($email):'').'</p></div><div class="dw-title-actions">'.self::status_badge($wms['label'],$wms['kind']).'<a class="button" target="_blank" rel="noopener" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=dennis_wms_pick_print&order_id='.$id),'dennis_wms_print_'.$id)).'">Skriv ut plocklista</a></div></div>';
  if(class_exists('Dennis_WMS_Kits'))Dennis_WMS_Kits::error_panel($order);
  if(class_exists('Dennis_WMS_Warnings'))Dennis_WMS_Warnings::render_order($order);
  echo '<div class="dw-info-grid">';
  self::card('dashicons-admin-users','Kund','<strong>'.esc_html($name).'</strong>'.($phone?'<span>'.esc_html($phone).'</span>':'').($email?'<span>'.esc_html($email).'</span>':''));
  self::card('dashicons-admin-home','Leveransadress','<strong>'.esc_html($shipname?:$name).'</strong>'.($addr1?'<span>'.esc_html($addr1).'</span>':'').($addr2?'<span>'.esc_html($addr2).'</span>':'').($city?'<span>'.esc_html($city).'</span>':'').($country?'<span>'.esc_html($country).'</span>':''));
  self::card('dashicons-car','Fraktsätt','<strong>'.esc_html($order->get_shipping_method()?:'Ej angivet').'</strong><span>Order #'.esc_html($order->get_order_number()).'</span>');
  $work='Plock: '.self::status_text($pick).' · Pack: '.self::status_text($pack);if($depot==='waiting')$work='I depån'.(($p=(string)$order->get_meta('_dennis_wms_depot_place',true))?' – '.$p:'');
  self::card('dashicons-clipboard','WMS-status',self::status_badge($wms['label'],$wms['kind']).'<span>'.esc_html($work).'</span><span>WooCommerce: '.esc_html(wc_get_order_status_name($order->get_status())).'</span>');
  echo '</div>';
  $imgCount=count(Dennis_WMS_Order_Images::rows($order));
  echo '<nav class="dw-order-tabs"><a href="#dw-order-lines">Orderrader</a><a href="#dw-pick">Plockning</a><a href="#dw-pack">Packning</a><a href="#dw-depot">Depå</a><a href="#dw-packmaterial">Packmaterial</a><a href="#dw-material">Materialretur</a><a href="#dw-deadline">Deadline</a><a href="#dw-delivery">Leverans</a><a href="#dw-order-images">Bilder <b>'.esc_html((string)$imgCount).'</b></a><a href="#dw-history">Historik</a></nav>';
  echo '<div class="dw-order-layout"><main><section id="dw-order-lines" class="dw-order-section"><div class="dw-section-head"><div><span class="dashicons dashicons-products"></span><div><h2>Orderrader</h2><p>Produkter, SKU, antal, batch, expire date och lagerplats enligt Plockordning.</p></div></div></div>';Dennis_WMS_Orders::rows($order);echo '</section>';
  echo '<section class="dw-phase-grid"><div id="dw-pick">';Dennis_WMS_Orders::phase_panel($order,'pick');echo '</div><div id="dw-pack">';if($pick==='done')Dennis_WMS_Orders::phase_panel($order,'pack');else echo '<div class="dw-phase-placeholder"><span class="dashicons dashicons-archive"></span><h3>Packning</h3><p>Avsluta plockningen innan packningen kan startas.</p></div>';echo '</div></section>';
  if(class_exists('Dennis_WMS_Packaging_Materials'))Dennis_WMS_Packaging_Materials::render_order($order);
  Dennis_WMS_Material_Usage::render($order);
  if(class_exists('Dennis_WMS_Deadline')) Dennis_WMS_Deadline::render_order_section('local',$id,'local',$order);
  if(class_exists('Dennis_WMS_Delivery')) Dennis_WMS_Delivery::render_order_section('local',$id,'local');
  Dennis_WMS_Order_Images::render($order);
  echo '<section id="dw-history" class="dw-order-section"><div class="dw-section-head"><div><span class="dashicons dashicons-backup"></span><div><h2>Komplettering och historik</h2><p>Återöppna färdiga arbetsmoment utan att förlora tidigare tid.</p></div></div></div>';Dennis_WMS_Orders::reopen_panel($order);echo '</section></main>';
  echo '<aside><section class="dw-side-card"><h3>Orderinformation</h3><dl><dt>Ordernr</dt><dd>#'.esc_html($order->get_order_number()).'</dd><dt>Datum</dt><dd>'.esc_html($created).'</dd><dt>WMS-status</dt><dd>'.self::status_badge($wms['label'],$wms['kind']).'</dd><dt>WooCommerce</dt><dd><span class="dw-wc-status">'.esc_html(wc_get_order_status_name($order->get_status())).'</span></dd></dl>';Dennis_WMS_Order_Status::form($order);echo '<dl><dt>Kund</dt><dd>'.esc_html($name).'</dd></dl></section>';
  echo '<section id="dw-depot" class="dw-side-card"><h3>Depå</h3><p>'.esc_html(Dennis_WMS_Orders::depot_label($order)?:($depot?:'Ej i depå')).'</p><a class="button" href="'.esc_url(Dennis_WMS_Depot::url($id)).'">Öppna depåhantering</a></section>';
  echo '<section class="dw-side-card"><h3>Snabblänkar</h3><a class="dw-quick" href="'.esc_url(Dennis_WMS_Orders::wc_edit_url($order)).'"><span class="dashicons dashicons-external"></span> Visa i WooCommerce</a><a class="dw-quick" target="_blank" rel="noopener" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=dennis_wms_pick_print&order_id='.$id),'dennis_wms_print_'.$id)).'"><span class="dashicons dashicons-printer"></span> Skriv ut plocklista</a><a class="dw-quick" href="#dw-order-images"><span class="dashicons dashicons-format-image"></span> Orderbilder ('.esc_html((string)$imgCount).')</a></section></aside></div></div>';
 }
 static function remote_items($row){
  $items=json_decode((string)$row->items_json,true);return is_array($items)?$items:[];
 }
 static function remote_barcode($item){
  // Match by SKU only: remote product IDs belong to another WooCommerce site.
  $sku=trim((string)($item['sku']??''));if($sku==='')return '';
  if(function_exists('wc_get_product_id_by_sku') && function_exists('wc_get_product')){
   $id=wc_get_product_id_by_sku($sku);if($id){$p=wc_get_product($id);if($p && class_exists('Dennis_WMS_Barcodes')){ $value=trim((string)$p->get_meta(Dennis_WMS_Barcodes::META,true));if($value!=='')return $value; }}
  }
  // SKU itself is scannable when a separate barcode has not been synced.
  return $sku;
 }
 static function remote_rows($row,$print=false){
  $items=self::remote_items($row);
  echo '<table class="widefat striped dw-remote-lines"><thead><tr><th>Bild</th><th>Produkt / SKU</th><th>Streckkod</th><th>Antal</th><th>Batch / Expire</th><th>Lagerplats</th><th>✓</th></tr></thead><tbody>';
  foreach($items as $item){
   $sku=trim((string)($item['sku']??''));$code=self::remote_barcode($item);
   $img=!empty($item['image'])?'<img src="'.esc_url($item['image']).'" alt="" style="width:58px;height:58px;object-fit:contain">':'–';
   $barcode=($code!=='' && class_exists('Dennis_WMS_Barcodes'))?Dennis_WMS_Barcodes::svg($code,35):'';
   echo '<tr><td>'.$img.'</td><td><strong>'.esc_html($item['name']??'').'</strong><br><small>SKU: '.esc_html($sku?:'–').'</small></td><td>'.$barcode.($code!==''?'<div><small>'.esc_html($code).'</small></div>':'–').'</td><td>'.esc_html((string)($item['qty']??0)).'</td><td>Ej synkroniserad</td><td>Ej synkroniserad</td><td>□</td></tr>';
  }
  if(!$items)echo '<tr><td colspan="7">Inga orderrader i synkroniserad order.</td></tr>';
  echo '</tbody></table>';
 }
 static function render_remote($row){
  $id=(int)$row->id;$shopkey='remote:'.(int)$row->shop_id;
  $name=$row->customer_name?:'Ingen kund angiven';$shipping=json_decode((string)$row->shipping_json,true);if(!is_array($shipping))$shipping=[];
  $shipname=trim(($shipping['first_name']??'').' '.($shipping['last_name']??''));
  $created=$row->date_created?:'–';$status=$row->status==='processing'?'Behandlas':($row->status==='on-hold'?'Väntande':ucfirst((string)$row->status));
  $wms=class_exists('Dennis_WMS_Delivery')?Dennis_WMS_Delivery::workflow_status($shopkey,$id,$row):['label'=>$status,'kind'=>'blue'];
  $print=wp_nonce_url(admin_url('admin-post.php?action=dennis_wms_remote_pick_print&remote_order_id='.$id),'dennis_wms_remote_pick_print_'.$id);
  echo '<div class="wrap"><div class="dw-order-app"><div class="dw-order-title"><div><a class="dw-back" href="'.esc_url(admin_url('admin.php?page=dennis-wms-orders')).'">‹ Tillbaka till order</a><p><span class="dw-shop-badge">🏬 '.esc_html($row->shop_name).'</span></p><h1>Order #'.esc_html($row->order_number).'</h1><p>'.esc_html($created).' <span>•</span> '.esc_html($name).'</p></div><div class="dw-title-actions">'.self::status_badge($wms['label'],$wms['kind']).'<a class="button" target="_blank" rel="noopener" href="'.esc_url($print).'">Skriv ut plocklista</a></div></div>';
  echo '<div class="dw-info-grid">';
  self::card('dashicons-admin-users','Kund','<strong>'.esc_html($name).'</strong>');
  $addr=implode('</span><span>',array_map('esc_html',array_filter([$shipping['address_1']??'',$shipping['address_2']??'',trim(($shipping['postcode']??'').' '.($shipping['city']??'')),$shipping['country']??''])));
  self::card('dashicons-admin-home','Leveransadress','<strong>'.esc_html($shipname?:$name).'</strong>'.($addr?'<span>'.$addr.'</span>':''));
  self::card('dashicons-car','Fraktsätt','<strong>Ej synkroniserat</strong><span>Order #'.esc_html($row->order_number).'</span>');
  self::card('dashicons-clipboard','WMS-status',self::status_badge($wms['label'],$wms['kind']).'<span>WooCommerce: '.esc_html($status).'</span><span>Extern order · läsläge</span>');
  echo '</div><nav class="dw-order-tabs"><a href="#dw-order-lines">Orderrader</a><a href="#dw-pick">Plockning</a><a href="#dw-pack">Packning</a><a href="#dw-depot">Depå</a><a href="#dw-packmaterial">Packmaterial</a><a href="#dw-material">Materialretur</a><a href="#dw-deadline">Deadline</a><a href="#dw-delivery">Leverans</a><a href="#dw-order-images">Bilder <b>0</b></a><a href="#dw-history">Historik</a></nav>';
  echo '<div class="dw-order-layout"><main><section id="dw-order-lines" class="dw-order-section"><div class="dw-section-head"><div><span class="dashicons dashicons-products"></span><div><h2>Orderrader</h2><p>Produkter, SKU, antal, streckkod, batch och lagerplats.</p></div></div></div>';self::remote_rows($row);echo '</section>';
  echo '<section class="dw-phase-grid">';Dennis_WMS_Remote_Workflow::panel($row);echo '</section>';
  foreach([['dw-packmaterial','Packmaterial'],['dw-material','Materialretur']] as $section)echo '<section id="'.esc_attr($section[0]).'" class="dw-order-section"><h2>'.esc_html($section[1]).'</h2><p>Inte tillgängligt för externa ordrar i denna version.</p></section>';
  if(class_exists('Dennis_WMS_Deadline'))Dennis_WMS_Deadline::render_order_section($shopkey,$id,'remote',$row);
  if(class_exists('Dennis_WMS_Delivery'))Dennis_WMS_Delivery::render_order_section($shopkey,$id,'remote');
  echo '<section id="dw-order-images" class="dw-order-section"><h2>Bilder</h2><p>Orderbilder synkroniseras inte från anslutna shoppar.</p></section>';Dennis_WMS_Remote_Workflow::history($row);echo '</main><aside>';
  echo '<section class="dw-side-card"><h3>Orderinformation</h3><dl><dt>Ordernr</dt><dd>#'.esc_html($row->order_number).'</dd><dt>Datum</dt><dd>'.esc_html($created).'</dd><dt>WMS-status</dt><dd>'.self::status_badge($wms['label'],$wms['kind']).'</dd><dt>WooCommerce</dt><dd><span class="dw-wc-status">'.esc_html($status).'</span></dd><dt>Kund</dt><dd>'.esc_html($name).'</dd><dt>Shop</dt><dd>'.esc_html($row->shop_name).'</dd></dl></section>';
  echo '<section id="dw-depot" class="dw-side-card"><h3>Depå</h3><p>Extern order i läsläge.</p></section><section class="dw-side-card"><h3>Snabblänkar</h3><a class="dw-quick" target="_blank" rel="noopener" href="'.esc_url($print).'"><span class="dashicons dashicons-printer"></span> Skriv ut plocklista</a></section></aside></div></div></div>';
 }
 static function status_text($s){return ['waiting'=>'Ej påbörjad','active'=>'Pågår','paused'=>'Pausad','done'=>'Färdig'][$s]??$s;}
}
