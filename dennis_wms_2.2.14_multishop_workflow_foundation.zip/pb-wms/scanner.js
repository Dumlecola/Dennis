(function(){'use strict';
const $=id=>document.getElementById(id),cfg=window.DWScannerConfig;
const mode=$('dws-mode'),order=$('dws-order'),code=$('dws-code'),result=$('dws-result'),video=$('dws-video');
let running=false,last='',lastTime=0;
function message(s,err){result.textContent=s;result.style.color=err?'#a00':'#202b35';}
function request(action,data){return fetch(cfg.ajax,{method:'POST',credentials:'same-origin',body:new URLSearchParams({action,nonce:cfg.nonce,...data})}).then(r=>r.json()).then(r=>{if(!r.success)throw Error(r.data?.message||'Något gick fel');return r.data;});}
async function find(){
 const value=code.value.trim();if(!value)return;
 if(mode.value==='pick'&&!order.value.trim()){message('Ange orderns interna WooCommerce-ID först.',true);return;}
 message('Kontrollerar produkt…');
 try{
  const d=await request('dw_scanner_find',{code:value,order_id:mode.value==='pick'?order.value:''});
  if(mode.value==='search'){
   await stop();
   window.location.assign(d.url);
   return;
  }
  result.replaceChildren();
  const heading=document.createElement('strong');heading.style.fontSize='20px';
  if(mode.value==='pick'){heading.textContent=d.matched?'✓ RÄTT PRODUKT':'✕ FEL PRODUKT';heading.style.color=d.matched?'#137333':'#b42318';}
  else heading.textContent='✓ Produkt hittad';
  result.appendChild(heading);
  const details=document.createElement('p');details.textContent=d.name+' | SKU: '+(d.sku||'saknas')+' | Saldo: '+(d.stock??'ej angivet');result.appendChild(details);
  if(mode.value==='pick'){
   const o=document.createElement('p');o.textContent=d.order+' | '+(d.matched?'Beställt antal: '+d.expected:'Den här artikeln ingår inte i ordern.');result.appendChild(o);
  }
  if(d.locations?.length){const l=document.createElement('p');l.textContent='Lagerplats: '+d.locations.join(', ');result.appendChild(l);}
  const link=document.createElement('a');link.href=d.url;link.textContent='Visa produktinformation';result.appendChild(link);
  result.style.background=mode.value==='pick'?(d.matched?'#e8f5e9':'#fff0ed'):'#f0f7ff';
  code.value='';code.focus();
 }catch(e){message(e.message,true);code.focus();}
}
$('dws-find').onclick=find;code.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();find();}});
mode.onchange=()=>{$('dws-order-row').style.display=mode.value==='pick'?'block':'none';message('Väntar på scanning…');code.focus();};
let zxingReader=null, loadingLibrary=null, scanBusy=false;
function loadZXing(){
 if(window.ZXing?.BrowserMultiFormatReader)return Promise.resolve(window.ZXing);
 if(loadingLibrary)return loadingLibrary;
 loadingLibrary=new Promise((resolve,reject)=>{
  const script=document.createElement('script');
  script.src='https://cdn.jsdelivr.net/npm/@zxing/library@0.21.3/umd/index.min.js';
  script.async=true;
  script.onload=()=>window.ZXing?.BrowserMultiFormatReader?resolve(window.ZXing):reject(new Error('Streckkodsbiblioteket kunde inte startas.'));
  script.onerror=()=>reject(new Error('Streckkodsbiblioteket kunde inte hämtas. Kontrollera internetanslutningen eller webbplatsens säkerhetsregler.'));
  document.head.appendChild(script);
 }).catch(e=>{loadingLibrary=null;throw e;});
 return loadingLibrary;
}
function onScan(value){
 if(!running||!value)return;
 const now=Date.now();
 if(scanBusy || (value===last&&now-lastTime<1800))return;
 scanBusy=true;last=value;lastTime=now;code.value=value;
 Promise.resolve(find()).finally(()=>{scanBusy=false;});
}
async function stop(){
 running=false;
 if(zxingReader){try{zxingReader.reset();}catch(e){} zxingReader=null;}
 if(video.srcObject){try{video.srcObject.getTracks().forEach(t=>t.stop());}catch(e){}}
 video.pause();video.srcObject=null;video.style.display='none';
 $('dws-stop').disabled=true;
 $('dws-camera').disabled=false;
}
$('dws-stop').onclick=stop;
$('dws-camera').onclick=async()=>{
 if(!navigator.mediaDevices?.getUserMedia){
  message('Kameran kräver HTTPS och kamerabehörighet. Öppna WMS direkt via https:// i Safari eller Chrome.',true);return;
 }
 $('dws-camera').disabled=true;
 message('Startar kameran…');
 try{
  // ZXing runs in Safari on iPhone, even when BarcodeDetector is missing.
  const ZXing=await loadZXing();
  zxingReader=new ZXing.BrowserMultiFormatReader();
  video.style.display='block';
  video.setAttribute('playsinline','');
  running=true;$('dws-stop').disabled=false;
  // @zxing/library's BrowserCodeReader has no static listVideoInputDevices().
  // Prefer the rear-facing camera on mobile without enumerating devices.
  const callback=(res,err)=>{if(res?.getText)onScan(res.getText());};
  if(typeof zxingReader.decodeFromConstraints==='function'){
   await zxingReader.decodeFromConstraints(
    {audio:false,video:{facingMode:{ideal:'environment'}}},video,callback
   );
  }else{
   await zxingReader.decodeFromVideoDevice(undefined,video,callback);
  }
 }catch(e){
  message('Kameran kunde inte startas: '+(e?.message||String(e)),true);
  await stop();
 }
};
if(['pick','search'].includes(cfg.mode))mode.value=cfg.mode;
if(cfg.order)order.value=String(cfg.order);
mode.dispatchEvent(new Event('change'));
window.addEventListener('pagehide',stop);code.focus();
})();
