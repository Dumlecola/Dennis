<?php
if (!defined('ABSPATH')) exit;
final class Dennis_WMS_Preorders {
 const META='_dennis_wms_preorder';
 const RESERVED_META='_dennis_wms_preorder_reserved';
 const RECEIVING_STARTED='_dennis_wms_preorder_receiving_started';
 static function boot(){
  add_action('woocommerce_product_options_inventory_product_data',[__CLASS__,'field']);
  add_action('woocommerce_process_product_meta',[__CLASS__,'save']);
  add_action('woocommerce_variation_options_inventory',[__CLASS__,'variation_field'],20,3);
  add_action('woocommerce_save_product_variation',[__CLASS__,'save_variation'],20,2);
  add_action('admin_menu',[__CLASS__,'menu'],96);
  add_action('wp_ajax_dennis_wms_preorder_alert',[__CLASS__,'ajax_alert']);
 }
 static function field(){
  woocommerce_wp_checkbox([
   'id'=>self::META,
   'label'=>'Pre-order-produkt',
   'description'=>'Produktens WooCommerce-lagersaldo anger hur många som kan förbeställas. Pre-order-order hålls utanför vanlig plockning i Dennis WMS.',
   'desc_tip'=>true,
  ]);
  echo '<p class="form-field"><span style="display:inline-block;margin-left:162px;color:#646970"><strong>Dennis WMS:</strong> Saldo = antal kvar att förbeställa, inte fysiskt lagersaldo.</span></p>';
 }
 static function save($id){
  $enabled=isset($_POST[self::META]); update_post_meta($id,self::META,$enabled?'yes':'no');
  if($enabled){$p=wc_get_product($id);if($p){$raw=$p->get_stock_quantity('edit');$p->set_manage_stock(true);if($raw!==null)$p->set_stock_status((float)$raw>0?'instock':'outofstock');$p->save();wc_delete_product_transients($id);}}
 }
 static function variation_field($loop,$data,$variation){
  $checked=get_post_meta($variation->ID,self::META,true)==='yes';
  echo '<p class="form-row form-row-full"><label><input type="checkbox" name="dennis_wms_preorder_var['.esc_attr($loop).']" value="yes" '.checked($checked,true,false).'> <strong>Pre-order-produkt</strong></label><span class="description">Variantens lagersaldo anger hur många som kan förbeställas.</span></p>';
 }
 static function save_variation($id,$loop){$all=(array)($_POST['dennis_wms_preorder_var']??[]);$enabled=isset($all[$loop]);update_post_meta($id,self::META,$enabled?'yes':'no');if($enabled){$p=wc_get_product($id);if($p){$raw=$p->get_stock_quantity('edit');$p->set_manage_stock(true);if($raw!==null)$p->set_stock_status((float)$raw>0?'instock':'outofstock');$p->save();wc_delete_product_transients($id);}}}
 static function is_product($product){
  if(!$product)return false;
  if($product->get_meta(self::META,true)==='yes')return true;
  if($product->is_type('variation')){$parent=wc_get_product($product->get_parent_id());return $parent&&$parent->get_meta(self::META,true)==='yes';}
  return false;
 }
 static function order_has_preorder($order){
  if(!$order)return false;
  foreach($order->get_items('line_item') as $item){$p=$item->get_product();if(self::is_product($p))return true;}
  return false;
 }
 static function preorder_items($order){$out=[];foreach($order->get_items('line_item') as $item){$p=$item->get_product();if(self::is_product($p))$out[]=['product'=>$p,'item'=>$item];}return $out;}
 static function item_reserved($item){return max(0,(int)$item->get_meta(self::RESERVED_META,true));}
 static function item_waiting($item){return max(0,(int)$item->get_quantity()-self::item_reserved($item));}
 static function order_waiting($order){foreach(self::preorder_items($order) as $r)if(self::item_waiting($r['item'])>0)return true;return false;}
 static function filter_pickable_orders($orders){return array_values(array_filter((array)$orders,function($o){return !self::order_has_preorder($o)||!self::order_waiting($o);}));}
 static function waiting_for_product($product_id){
  $product=wc_get_product($product_id);if(!$product)return 0;$sku=(string)$product->get_sku();if($sku==='')return 0;$total=0;
  $orders=wc_get_orders(['status'=>['processing','on-hold'],'limit'=>-1,'orderby'=>'date','order'=>'ASC','return'=>'objects']);
  foreach($orders as $o)foreach($o->get_items('line_item') as $item){$p=$item->get_product();if(!$p||!self::is_product($p)||(string)$p->get_sku()!==$sku)continue;$total+=self::item_waiting($item);}
  return $total;
 }
 static function allocate_receipt($product_id,$qty,$receipt_id=0,$line_id=0){
  $qty=max(0,(int)$qty);$product=wc_get_product($product_id);if(!$product||$qty<1||!self::is_product($product))return ['allocated'=>0,'free'=>$qty,'orders'=>[]];
  $sku=(string)$product->get_sku();if($sku==='')return ['allocated'=>0,'free'=>$qty,'orders'=>[]];$left=$qty;$allocated=0;$touched=[];$changes=[];
  $orders=wc_get_orders(['status'=>['processing','on-hold'],'limit'=>-1,'orderby'=>'date','order'=>'ASC','return'=>'objects']);
  try{foreach($orders as $o){if($left<=0)break;foreach($o->get_items('line_item') as $item){if($left<=0)break;$p=$item->get_product();if(!$p||!self::is_product($p)||(string)$p->get_sku()!==$sku)continue;$waiting=self::item_waiting($item);if($waiting<1)continue;$take=min($left,$waiting);$previous=self::item_reserved($item);$changes[]=['order_id'=>(int)$o->get_id(),'item_id'=>(int)$item->get_id(),'previous'=>$previous];$item->update_meta_data(self::RESERVED_META,$previous+$take);$item->save();$left-=$take;$allocated+=$take;$touched[$o->get_id()]=($touched[$o->get_id()]??0)+$take;}
   if(isset($touched[$o->get_id()])){$o->add_order_note('Dennis WMS: '.$touched[$o->get_id()].' st Pre-order '.$sku.' reserverade från inleverans'.($receipt_id?' IN-'.$receipt_id:'').'.'.(self::order_waiting($o)?' Väntar fortfarande på resterande antal.':' Ordern är nu redo för plock.'));$o->save();}
  }
  }catch(Throwable $e){self::rollback_allocation(['changes'=>$changes],'Reservation avbröts');throw $e;}
  return ['allocated'=>$allocated,'free'=>$left,'orders'=>$touched,'changes'=>$changes];
 }
 static function rollback_allocation($allocation,$reason=''){
  if(!is_array($allocation)||empty($allocation['changes']))return;
  foreach(array_reverse($allocation['changes']) as $change){
   $order=wc_get_order((int)$change['order_id']);if(!$order)continue;
   $item=$order->get_item((int)$change['item_id']);if(!$item)continue;
   $item->update_meta_data(self::RESERVED_META,(int)$change['previous']);$item->save();
   $order->add_order_note('Dennis WMS: reservation från misslyckad inleverans återställd. '.$reason);
  }
 }
 // A per-user acknowledgement timestamp keeps old, already reviewed orders quiet.
 static function new_order_count(){
  if(!function_exists('wc_get_orders'))return 0;
  $seen=(int)get_user_meta(get_current_user_id(),'dennis_wms_preorder_seen_at',true);
  $orders=wc_get_orders(['status'=>['processing','on-hold'],'limit'=>-1,'orderby'=>'date','order'=>'DESC','return'=>'objects']);
  $count=0;
  foreach($orders as $order){
   $created=$order->get_date_created();
   if(!$created||$created->getTimestamp()<=$seen)continue;
   if(self::order_has_preorder($order))$count++;
  }
  return $count;
 }
 // Active, still-waiting Pre-orders drive the persistent pulse independently of the new-order badge.
 static function active_waiting_count(){
  if(!function_exists('wc_get_orders'))return 0;
  $orders=wc_get_orders(['status'=>['processing','on-hold'],'limit'=>-1,'return'=>'objects']);
  $count=0;
  foreach($orders as $order){
   if(self::order_has_preorder($order)&&self::order_waiting($order))$count++;
  }
  return $count;
 }
 static function ajax_alert(){
  check_ajax_referer('dennis_wms_preorder_alert','nonce');
  if(!current_user_can('pb_wms_view'))wp_send_json_error('Åtkomst nekad',403);
  wp_send_json_success(['count'=>self::new_order_count(),'active'=>self::active_waiting_count()]);
 }
 static function alert_assets(){
  if(!current_user_can('pb_wms_view'))return;
  $nonce=wp_create_nonce('dennis_wms_preorder_alert');
  echo '<script>window.dennisPreorderAlert='.wp_json_encode(['url'=>admin_url('admin-ajax.php'),'nonce'=>$nonce]).';</script>';
 }
 static function menu(){add_submenu_page('pb-wms','Pre-orders','Pre-orders','pb_wms_view','dennis-wms-preorders',[__CLASS__,'page']);}
 static function page(){
  if(!current_user_can('pb_wms_view'))wp_die('Åtkomst nekad.',403);
  update_user_meta(get_current_user_id(),'dennis_wms_preorder_seen_at',time());
  echo '<div class="wrap"><h1>Dennis WMS – Pre-orders</h1><p>Här visas pågående order som innehåller minst en produkt markerad som <strong>Pre-order-produkt</strong>. De hålls utanför vanlig plockkö tills inlevererat antal med samma SKU har reserverats. Äldsta order får varor först.</p>';
  if(!function_exists('wc_get_orders')){echo '<p>WooCommerce måste vara aktivt.</p></div>';return;}
  $orders=wc_get_orders(['status'=>['processing','on-hold'],'limit'=>-1,'orderby'=>'date','order'=>'ASC','return'=>'objects']);$orders=array_values(array_filter($orders,[__CLASS__,'order_has_preorder']));
  echo '<table class="widefat striped"><thead><tr><th>Order</th><th>Datum</th><th>Pre-order SKU</th><th>Beställt</th><th>Reserverat</th><th>Väntar</th><th>Status</th><th></th></tr></thead><tbody>';
  foreach($orders as $o){$rows=self::preorder_items($o);$skus=[];$qty=[];$reserved=[];$waiting=[];foreach($rows as $r){$p=$r['product'];$skus[]=$p->get_sku()?:'#'.$p->get_id();$qty[]=(string)$r['item']->get_quantity();$reserved[]=(string)self::item_reserved($r['item']);$waiting[]=(string)self::item_waiting($r['item']);}$ready=!self::order_waiting($o);echo '<tr><td><strong>#'.esc_html($o->get_order_number()).'</strong></td><td>'.esc_html($o->get_date_created()?$o->get_date_created()->date_i18n('Y-m-d H:i'):'–').'</td><td>'.esc_html(implode(', ',$skus)).'</td><td>'.esc_html(implode(', ',$qty)).'</td><td>'.esc_html(implode(', ',$reserved)).'</td><td>'.esc_html(implode(', ',$waiting)).'</td><td><strong>'.($ready?'Redo att plocka':'Väntar på inleverans').'</strong></td><td><a class="button" href="'.esc_url(admin_url('admin.php?page=dennis-wms-orders&order_id='.$o->get_id())).'">Öppna order</a></td></tr>';}
  if(!$orders)echo '<tr><td colspan="8">Inga Pre-orders.</td></tr>';
  echo '</tbody></table></div>';
 }
}
