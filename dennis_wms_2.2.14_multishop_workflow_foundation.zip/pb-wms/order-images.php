<?php
if (!defined('ABSPATH')) exit;

/** Order image evidence for Dennis WMS. Images live in WordPress Media Library; order metadata stores the association. */
final class Dennis_WMS_Order_Images {
 const META = '_dennis_wms_order_images';
 const CAP = 'edit_shop_orders';

 static function boot() {
  add_action('admin_post_dennis_wms_order_images_add', [__CLASS__, 'add']);
  add_action('admin_post_dennis_wms_order_image_update', [__CLASS__, 'update']);
  add_action('admin_post_dennis_wms_order_image_delete', [__CLASS__, 'delete']);
 }
 static function categories() {
  return ['pick'=>'Plockning','pack'=>'Packning','depot'=>'Depå','deviation'=>'Avvikelse','other'=>'Övrigt'];
 }
 static function rows($order) {
  $rows=$order->get_meta(self::META,true);
  return is_array($rows)?array_values(array_filter($rows,'is_array')):[];
 }
 static function save($order,$rows) {
  $order->update_meta_data(self::META,array_values($rows));
  $order->save();
 }
 static function guard($id,$nonce) {
  if(!current_user_can('pb_wms_view')||!current_user_can(self::CAP))wp_die('Åtkomst nekad.',403);
  check_admin_referer($nonce.'_'.$id);
  return Dennis_WMS_Orders::order($id);
 }
 static function add() {
  $id=isset($_POST['order_id'])?absint(wp_unslash($_POST['order_id'])):0;
  $order=self::guard($id,'dennis_wms_order_images_add');
  $category=isset($_POST['image_category'])?sanitize_key(wp_unslash($_POST['image_category'])):'other';
  if(!array_key_exists($category,self::categories()))$category='other';
  $aid=Dennis_WMS_Security::upload_image('order_image','Order #'.$order->get_order_number().' – '.self::categories()[$category]);if(is_wp_error($aid))wp_die(esc_html($aid->get_error_message()),400);
  $rows=self::rows($order);$rows[]=['attachment_id'=>$aid,'category'=>$category,'note'=>'','user_id'=>get_current_user_id(),'created_at'=>current_time('mysql')];
  self::save($order,$rows);wp_safe_redirect(Dennis_WMS_Orders::url($id).'#dw-order-images');exit;
 }
 static function update() {
  $id=isset($_POST['order_id'])?absint(wp_unslash($_POST['order_id'])):0;
  $order=self::guard($id,'dennis_wms_order_image_update');
  $aid=isset($_POST['attachment_id'])?absint(wp_unslash($_POST['attachment_id'])):0;
  $category=isset($_POST['image_category'])?sanitize_key(wp_unslash($_POST['image_category'])):'other';
  $note=isset($_POST['image_note'])?sanitize_textarea_field(wp_unslash($_POST['image_note'])):'';
  if(!array_key_exists($category,self::categories()))$category='other';
  if(mb_strlen($note)>500)wp_die('Kommentaren får vara högst 500 tecken.',400);
  $rows=self::rows($order);$found=false;
  foreach($rows as &$r){if((int)($r['attachment_id']??0)===$aid){$r['category']=$category;$r['note']=$note;$r['updated_at']=current_time('mysql');$r['updated_by']=get_current_user_id();$found=true;break;}}unset($r);
  if(!$found)wp_die('Bilden är inte kopplad till ordern.',404);
  self::save($order,$rows);wp_safe_redirect(Dennis_WMS_Orders::url($id).'#dw-order-images');exit;
 }
 static function delete() {
  $id=isset($_POST['order_id'])?absint(wp_unslash($_POST['order_id'])):0;
  $order=self::guard($id,'dennis_wms_order_image_delete');
  $aid=isset($_POST['attachment_id'])?absint(wp_unslash($_POST['attachment_id'])):0;
  $rows=array_values(array_filter(self::rows($order),fn($r)=>(int)($r['attachment_id']??0)!==$aid));
  self::save($order,$rows);wp_safe_redirect(Dennis_WMS_Orders::url($id).'#dw-order-images');exit;
 }
 static function render($order) {
  $rows=self::rows($order);$cats=self::categories();$can=current_user_can(self::CAP);
  echo '<section id="dw-order-images" class="dw-order-section dw-image-section"><div class="dw-section-head"><div><span class="dashicons dashicons-format-image"></span><div><h2>Orderbilder <span class="dw-count">'.esc_html((string)count($rows)).'</span></h2><p>Ladda upp och hantera bilder som är kopplade till denna order.</p></div></div>';
  if($can){echo '<form id="dw-image-add-form" class="dw-image-add" method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_order_images_add_'.$order->get_id());echo '<input type="hidden" name="action" value="dennis_wms_order_images_add"><input type="hidden" name="order_id" value="'.esc_attr((string)$order->get_id()).'"><input id="dw-order-image-file" type="file" name="order_image" accept="image/jpeg,image/png,image/webp,image/gif" required><select name="image_category" aria-label="Bildkategori">';foreach($cats as $k=>$label)echo '<option value="'.esc_attr($k).'">'.esc_html($label).'</option>';echo '</select><button id="dw-add-images" type="submit" class="button button-primary"><span class="dashicons dashicons-plus-alt2"></span> Ladda upp privat bild</button></form>';}
  echo '</div>';
  if($can)echo '<p class="description">Bilden sparas privat och visas endast för inloggade användare med WMS-behörighet. JPG, PNG, WebP eller GIF, högst 12 MB.</p>';
  if(!$rows){echo '<div class="dw-empty"><span class="dashicons dashicons-format-image"></span><p>Inga bilder har lagts till på ordern ännu.</p></div></section>';return;}
  echo '<div class="dw-image-filters"><button type="button" class="dw-filter active" data-filter="all">Alla ('.esc_html((string)count($rows)).')</button>';foreach($cats as $k=>$label){$n=0;foreach($rows as $r)if(($r['category']??'other')===$k)$n++;if($n)echo '<button type="button" class="dw-filter" data-filter="'.esc_attr($k).'">'.esc_html($label).' ('.esc_html((string)$n).')</button>';}echo '</div><div class="dw-image-grid">';
  foreach(array_reverse($rows) as $r){$aid=(int)($r['attachment_id']??0);if(!$aid||!wp_attachment_is_image($aid))continue;$cat=array_key_exists(($r['category']??''),$cats)?$r['category']:'other';$user=get_userdata((int)($r['user_id']??0));$full=wp_get_attachment_image_url($aid,'large');
   echo '<article class="dw-image-card" data-category="'.esc_attr($cat).'"><a class="dw-image-preview" href="'.esc_url($full?:wp_get_attachment_url($aid)).'" target="_blank" rel="noopener">'.wp_get_attachment_image($aid,'medium_large',false,['loading'=>'lazy']).'<span class="dw-badge dw-badge-'.esc_attr($cat).'">'.esc_html($cats[$cat]).'</span></a><div class="dw-image-meta"><strong>'.esc_html(get_the_title($aid)?:('Bild #'.$aid)).'</strong><small>'.esc_html((string)($r['created_at']??'')).' · '.esc_html($user?$user->display_name:'Okänd användare').'</small>';
   if(!empty($r['note']))echo '<p>'.esc_html($r['note']).'</p>';
   if($can){echo '<details><summary>Redigera</summary><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_order_image_update_'.$order->get_id());echo '<input type="hidden" name="action" value="dennis_wms_order_image_update"><input type="hidden" name="order_id" value="'.esc_attr((string)$order->get_id()).'"><input type="hidden" name="attachment_id" value="'.esc_attr((string)$aid).'"><select name="image_category">';foreach($cats as $k=>$label)echo '<option value="'.esc_attr($k).'" '.selected($cat,$k,false).'>'.esc_html($label).'</option>';echo '</select><textarea name="image_note" maxlength="500" rows="2" placeholder="Kommentar">'.esc_textarea((string)($r['note']??'')).'</textarea><button class="button" type="submit">Spara</button></form><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" onsubmit="return confirm(\'Ta bort kopplingen till bilden? Själva filen ligger kvar i Media Library.\')">';wp_nonce_field('dennis_wms_order_image_delete_'.$order->get_id());echo '<input type="hidden" name="action" value="dennis_wms_order_image_delete"><input type="hidden" name="order_id" value="'.esc_attr((string)$order->get_id()).'"><input type="hidden" name="attachment_id" value="'.esc_attr((string)$aid).'"><button class="button-link-delete" type="submit">Ta bort från order</button></form></details>';}
   echo '</div></article>';
  }
  echo '</div></section>';
 }
}
Dennis_WMS_Order_Images::boot();
