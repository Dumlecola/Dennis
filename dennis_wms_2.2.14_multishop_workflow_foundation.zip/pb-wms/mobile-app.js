/* Dennis WMS mobile app shell: progressive enhancement, no inventory writes. */
(function () {
 'use strict';
 function init() {
  if (!document.body.classList.contains('dennis-wms-modern') || document.getElementById('dw-mobile-shell')) return;
  var shell=document.createElement('div');shell.id='dw-mobile-shell';
  shell.innerHTML='<header class="dw-mobile-header"><a class="dw-mobile-logo" href="admin.php?page=dennis-wms-dashboard"><span class="dashicons dashicons-archive"></span> DENNIS <b>WMS</b></a><button type="button" class="dw-mobile-menu-button" aria-label="Öppna alla WMS-funktioner" aria-controls="dw-mobile-drawer" aria-expanded="false"><span class="dashicons dashicons-menu"></span> Meny</button></header><div class="dw-mobile-overlay" hidden></div><nav id="dw-mobile-drawer" class="dw-mobile-drawer" aria-label="Alla Dennis WMS-funktioner" inert><div class="dw-mobile-drawer-title"><strong>Alla funktioner</strong><button type="button" class="dw-mobile-close" aria-label="Stäng menyn">✕</button></div><div class="dw-mobile-drawer-links"></div></nav><nav class="dw-mobile-bottom" aria-label="Snabbnavigering"></nav>';
  document.body.appendChild(shell);
  var drawer=shell.querySelector('.dw-mobile-drawer'), overlay=shell.querySelector('.dw-mobile-overlay'), opener=shell.querySelector('.dw-mobile-menu-button'), close=shell.querySelector('.dw-mobile-close');
  function toggle(open){drawer.classList.toggle('is-open',open);overlay.hidden=!open;drawer.inert=!open;opener.setAttribute('aria-expanded',String(open));document.body.classList.toggle('dw-mobile-menu-open',open);if(open)close.focus();else opener.focus();}
  opener.addEventListener('click',function(){toggle(true)});close.addEventListener('click',function(){toggle(false)});overlay.addEventListener('click',function(){toggle(false)});
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&drawer.classList.contains('is-open'))toggle(false)});
  var links=shell.querySelector('.dw-mobile-drawer-links');
  var seen={};
  // The native WordPress menu includes secondary screens not present in the top nav.
  Array.from(document.querySelectorAll('#toplevel_page_pb-wms .wp-submenu a[href*="page="],.dw-appnav a[href*="page="]')).forEach(function(a){
   var url;try{url=new URL(a.href,location.href)}catch(e){return}
   var slug=url.searchParams.get('page');if(!slug||seen[slug]||url.origin!==location.origin)return;seen[slug]=true;
   var item=document.createElement('a');item.href=url.href;item.textContent=a.textContent.trim().replace(/\s+/g,' ')||slug;
   if(slug===new URLSearchParams(location.search).get('page'))item.className='is-current';
   links.appendChild(item);
  });
  var quick=[['dennis-wms-dashboard','dashicons-dashboard','Översikt'],['dennis-wms-orders','dashicons-cart','Ordrar'],['dennis-wms-products','dashicons-products','Produkter'],['dennis-wms-scanner','dashicons-camera','Scanna']];
  var bottom=shell.querySelector('.dw-mobile-bottom');var current=new URLSearchParams(location.search).get('page');
  quick.forEach(function(entry){var a=document.createElement('a');a.href='admin.php?page='+encodeURIComponent(entry[0]);if(current===entry[0]){a.className='is-current';a.setAttribute('aria-current','page')}var icon=document.createElement('span');icon.className='dashicons '+entry[1];a.appendChild(icon);var label=document.createElement('span');label.textContent=entry[2];a.appendChild(label);bottom.appendChild(a)});
  var more=document.createElement('button');more.type='button';more.innerHTML='<span class="dashicons dashicons-menu"></span><span>Mer</span>';more.addEventListener('click',function(){toggle(true)});bottom.appendChild(more);
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
