<?php
if (!defined('ABSPATH')) exit;
/** Accompanying SKUs use the existing atomic order allocation and restoration ledger. */
final class Dennis_WMS_Accompanying {
 static function boot(){add_action('admin_menu',[__CLASS__,'menu'],108);add_action('admin_post_dennis_wms_accompanying_save',[__CLASS__,'save']);add_action('admin_post_dennis_wms_accompanying_delete',[__CLASS__,'delete']);}
 static function menu(){add_submenu_page('pb-wms','Kit','Kit','pb_wms_view','dennis-wms-accompanying',[__CLASS__,'page']);}
 static function url($sku=''){return add_query_arg(['page'=>'dennis-wms-accompanying','sku'=>$sku],admin_url('admin.php'));}
 static function configure($main,$rows){
  Dennis_WMS_Kits::ready();
  if(!$main)throw new Exception('Huvudproduktens SKU hittades inte.');
  $old=Dennis_WMS_Kits::recipe($main->get_id());if($old&&empty($old['accompanying']))throw new Exception('Produkten har en äldre förpackningskoppling. Återställ den först under För-packade produkter.');
  if(get_post_meta($main->get_id(),'_manage_stock',true)!=='yes'&&!$main->managing_stock())throw new Exception('Huvudprodukten behöver eget lagerstyrt saldo.');
  $recipe=Dennis_WMS_Kits::validate($main,'pick',$rows,true,true);$recipe['accompanying']=true;
  return Dennis_WMS_Kits::transaction(array_column($recipe['components'],'product_id'),function()use($main,$recipe){
   $before=Dennis_WMS_Kits::recipe($main->get_id());update_post_meta($main->get_id(),Dennis_WMS_Kits::META,$recipe);
   if(get_post_meta($main->get_id(),Dennis_WMS_Kits::META,true)!==$recipe)throw new Exception('Kopplingen kunde inte sparas.');
   foreach($recipe['components'] as $c)if(empty($c['base_product']))update_post_meta($c['product_id'],'_dennis_wms_kit_component_used','yes');
   Dennis_WMS_Audit::record('Medföljande artiklar ändrade','product',$main->get_id(),$before,$recipe,'WMS','success',$main->get_sku());wc_delete_product_transients($main->get_id());return $recipe;
  });
 }
 static function save(){Dennis_WMS_Kits::guard('dennis_wms_accompanying_save');$main=wc_get_product(wc_get_product_id_by_sku(sanitize_text_field(wp_unslash($_POST['main_sku']??''))));$skus=(array)wp_unslash($_POST['component_sku']??[]);$qty=(array)wp_unslash($_POST['component_qty']??[]);$rows=[];foreach($skus as $i=>$sku)$rows[]=['sku'=>sanitize_text_field($sku),'qty'=>$qty[$i]??''];
  try{self::configure($main,$rows);}catch(Throwable $e){wp_die(esc_html($e->getMessage()),'Medföljande artiklar',['response'=>409,'back_link'=>true]);}wp_safe_redirect(add_query_arg('saved','1',self::url($main->get_sku())));exit;
 }
 static function delete(){
  Dennis_WMS_Kits::guard('dennis_wms_accompanying_delete');
  $id=absint($_POST['product_id']??0);$product=wc_get_product($id);$recipe=$product?Dennis_WMS_Kits::recipe($id):[];
  if(!$product||empty($recipe['accompanying']))wp_die('Kitet hittades inte.',404);
  $before=$recipe;delete_post_meta($id,Dennis_WMS_Kits::META);wc_delete_product_transients($id);
  Dennis_WMS_Audit::record('Kit borttaget','product',$id,$before,[],'WMS','success',$product->get_sku());
  wp_safe_redirect(add_query_arg('deleted','1',self::url()));exit;
 }
 static function page(){if(!current_user_can('pb_wms_view'))wp_die('Åtkomst nekad.',403);$sku=sanitize_text_field(wp_unslash($_GET['sku']??''));$p=$sku!==''?wc_get_product(wc_get_product_id_by_sku($sku)):false;$r=$p?Dennis_WMS_Kits::recipe($p->get_id()):[];
  echo '<div class="wrap"><h1>Kit</h1><p>Kunden beställer huvudproduktens SKU. Huvudprodukten är Kitets sälj-SKU och har inget eget fysiskt saldo. Vid order dras endast angivet antal av de ingående artiklarna. Beställningsbart antal räknas automatiskt från de ingående SKU:ernas aktuella tillgängliga saldo. Inget saldo ändras när kopplingen sparas.</p>';
  if(isset($_GET['saved']))echo '<div class="notice notice-success"><p>Medföljande artiklar sparade.</p></div>';if(isset($_GET['deleted']))echo '<div class="notice notice-success"><p>Kitet är borttaget. Produkter och lagersaldon är oförändrade.</p></div>';
  echo '<form method="get"><input type="hidden" name="page" value="dennis-wms-accompanying"><label>Huvudproduktens SKU <input name="sku" value="'.esc_attr($sku).'"></label> <button class="button">Visa produkt</button></form>';
  if($p)echo '<h2>'.esc_html($p->get_name()).' · '.esc_html($p->get_sku()).'</h2><p>'.(!empty($r['accompanying'])?'Automatiskt Kit-saldo: <strong>'.esc_html(Dennis_WMS_Kits::capacity($r)).' st</strong> · styrs av ingående artiklar':'Fysiskt saldo: '.esc_html($p->get_stock_quantity('edit')).' st').'</p>';
  if(current_user_can('pb_wms_manage')&&current_user_can('manage_woocommerce')){
   echo '<form class="dw-kit-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="max-width:850px;background:#fff;padding:20px;margin-top:16px;border-top:4px solid #1D949C;border-radius:10px">';wp_nonce_field('dennis_wms_accompanying_save');echo '<input type="hidden" name="action" value="dennis_wms_accompanying_save"><label>Huvudproduktens SKU<input name="main_sku" class="dw-kit-sku" value="'.esc_attr($p?$p->get_sku():'').'" required '.($p?'readonly':'').'><small class="dw-kit-result">'.esc_html($p?$p->get_name():'Sök SKU med minst 3 tecken.').'</small></label><h3>Medföljande SKU</h3><p>Antal gäller per beställd huvudprodukt. Huvudprodukten ingår automatiskt med 1 st. Samma SKU kan användas i flera listor med olika antal. Endast angivna SKU ingår; deras egna medföljande artiklar läggs inte till automatiskt.</p><div class="dw-kit-components">';$components=!empty($r['accompanying'])?array_values(array_filter($r['components'],fn($c)=>empty($c['base_product']))):[['sku'=>'','qty'=>1]];foreach($components as $c){ob_start();Dennis_WMS_Kits::component_field($c);echo str_replace('Antal per förpackning','Antal per huvudprodukt',ob_get_clean());}echo '</div><button type="button" class="button dw-kit-add">＋ Lägg till artikel</button><p><button class="button button-primary">Spara medföljande artiklar</button></p><p>Gäller kommande lageruttag. Registrerade order behåller sitt sparade innehåll. Avbokning och återbetalning med återlagring använder registrerade uttag.</p></form>';
  }
  global $wpdb;$ids=$wpdb->get_col($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key=%s ORDER BY post_id DESC",Dennis_WMS_Kits::META));echo '<h2>Sparade kopplingar</h2><table class="widefat striped"><thead><tr><th>Huvudprodukt</th><th>Medföljande artiklar per st</th><th>Beställningsbart</th><th>Åtgärder</th></tr></thead><tbody>';foreach($ids as $id){$recipe=Dennis_WMS_Kits::recipe($id);if(empty($recipe['accompanying']))continue;$product=wc_get_product($id);if(!$product)continue;$contents=[];foreach($recipe['components'] as $c)if(empty($c['base_product']))$contents[]=$c['sku'].' × '.$c['qty'];echo '<tr><td><a href="'.esc_url(self::url($product->get_sku())).'">'.esc_html($product->get_sku().' · '.$product->get_name()).'</a></td><td>'.esc_html(implode(' · ',$contents)).'</td><td>'.esc_html(Dennis_WMS_Kits::capacity($recipe)).' st</td><td><a class="button button-small" href="'.esc_url(self::url($product->get_sku())).'">Redigera</a> ';if(current_user_can('pb_wms_manage')&&current_user_can('manage_woocommerce')){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:inline" onsubmit="return confirm(\'Ta bort detta Kit? Produkter och lagersaldon påverkas inte.\');">';wp_nonce_field('dennis_wms_accompanying_delete');echo '<input type="hidden" name="action" value="dennis_wms_accompanying_delete"><input type="hidden" name="product_id" value="'.(int)$id.'"><button class="button button-small" type="submit">Ta bort</button></form>';}echo '</td></tr>';}echo '</tbody></table></div>';
 }
}
Dennis_WMS_Accompanying::boot();
