Dennis WMS 2.1.89 PWA
Installera plugin på en HTTPS WordPress-webbplats. Logga in, öppna Dennis WMS -> Översikt och lägg till på hemskärmen via Safari (iOS) eller Chrome (Android).
Använder WordPress befintliga användarkonton. Inget order- eller lagerinnehåll cachelagras offline.
Obs: Appen återanvänder befintligt WP-admin-gränssnitt. En helt fristående mobilvy och fullständig enhetstestning återstår.
