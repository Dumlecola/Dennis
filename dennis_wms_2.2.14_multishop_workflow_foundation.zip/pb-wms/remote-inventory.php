<?php
if(!defined('ABSPATH'))exit;
final class Dennis_WMS_Remote_Inventory {
 /** Read persisted remote counts safely for product view and inventory. */
 static function history(){
  $entries=get_option('dw_remote_inventory_history',[]);
  return is_array($entries)?array_values(array_filter($entries,'is_array')):[];
 }
 static function boot(){add_action('admin_post_dw_remote_inventory',[__CLASS__,'save']);}
 static function save(){
  if(!current_user_can('pb_wms_count')||!current_user_can('manage_woocommerce'))wp_die('Åtkomst nekad',403);
  check_admin_referer('dw_remote_inventory');
  global $wpdb;$id=absint($_POST['product_id']??0);$t=Dennis_WMS_Multi_Shop::table('products');
  $p=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id));
  if(!$p||!in_array($p->type,['simple','variation'],true))wp_die('Ogiltig produkt',400);
  $raw=trim((string)wp_unslash($_POST['quantity']??''));
  if(!preg_match('/^\d+(?:[.,]\d{1,4})?$/D',$raw))wp_die('Ogiltigt antal',400);
  $qty=(float)str_replace(',','.',$raw);if($qty>100000000)wp_die('Antalet är för stort',400);
  $reason=trim(sanitize_textarea_field(wp_unslash($_POST['reason']??'')));if($reason==='')wp_die('Orsak krävs',400);
  $mode=sanitize_key($_POST['mode']??'record');$status='Registrerad';$old=$p->stock_quantity;
  if($mode==='write'||$mode==='enable_write'){
   $enable=($mode==='enable_write');
   $shop=Dennis_WMS_Multi_Shop::get_shop((int)$p->shop_id);if(!$shop)wp_die('Shop saknas',404);
   $endpoint=$p->type==='variation'?'products/'.absint($p->remote_parent_id).'/variations/'.absint($p->remote_product_id):'products/'.absint($p->remote_product_id);
   $live=Dennis_WMS_Multi_Shop::api($shop,$endpoint);
   if(is_wp_error($live))wp_die('Kunde inte läsa aktuellt saldo: '.esc_html($live->get_error_message()),502);
   $data=$live['data'];
   // WooCommerce returns the product object at the JSON root. Some API gateways
   // wrap it in `data`; unwrap only when it contains an identifiable product.
   if(is_array($data)&&isset($data['data'])&&is_array($data['data'])&&isset($data['data']['id'])&&!isset($data['id']))$data=$data['data'];
   // Do not trust a successful HTTP status alone: some hosts return a login page or a product list.
   $received_id=(is_array($data)&&isset($data['id'])&&is_scalar($data['id']))?absint($data['id']):0;
   $expected_id=absint($p->remote_product_id);
   if(!$received_id||$received_id!==$expected_id){
    $kind=!is_array($data)?'ogiltig JSON':(isset($data[0])?'produktlista':(isset($data['code'])?'API-felobjekt':'saknar korrekt produkt-ID'));
    $http=(int)($live['code']??0);
    $keys=is_array($data)?implode(', ',array_slice(array_map('strval',array_keys($data)),0,12)):'inga';
    $api_code=is_array($data)&&isset($data['code'])&&is_scalar($data['code'])?sanitize_text_field((string)$data['code']):'saknas';
    wp_die(esc_html(sprintf('API-kontroll stoppade ändringen. Shop: %s (ID %d). WMS-produkt: %d. WooCommerce-produkt förväntad: %d, API-svar: %d (%s). Endpoint: %s. HTTP: %d. Svarsfält: %s. API-felkod: %s. Kontrollera ansluten shops URL och synkronisera produkterna. Ingen skrivning utfördes.',(string)$shop->name,(int)$shop->id,(int)$p->id,$expected_id,$received_id,$kind,$endpoint,$http,$keys,$api_code)),409);
   }
   // Product variations must also match their expected parent; do not mix stock records.
   if($p->type==='variation'&&(!isset($data['parent_id'])||absint($data['parent_id'])!==absint($p->remote_parent_id)))wp_die('API svarade med fel överordnad produkt för variationen. Ingen ändring gjord.',409);
   $managed=!empty($data['manage_stock']);
   if($enable&&$managed)wp_die('Lagerstyrning är redan aktiverad. Synkronisera och använd Uppdatera via API.',409);
   if(!$enable&&!$managed)wp_die('Lagerstyrning är inte aktiv. Använd Aktivera lagerstyrning + uppdatera efter att ha kontrollerat produkten.',409);
   if(!$enable&&($old===null||!isset($data['stock_quantity'])||abs((float)$data['stock_quantity']-(float)$old)>0.0001))wp_die('Saldot har ändrats sedan synkronisering. Synkronisera först.',409);
   // Explicitly opted-in enablement; never silently change manage_stock.
   $payload=$enable?['manage_stock'=>true,'stock_quantity'=>$qty]:['stock_quantity'=>$qty];
   $url=trailingslashit($shop->url).'wp-json/wc/v3/'.$endpoint;
   $res=wp_safe_remote_request($url,['method'=>'PUT','timeout'=>20,'redirection'=>0,'headers'=>array_merge(Dennis_WMS_Multi_Shop::auth_headers($shop),['Content-Type'=>'application/json']),'body'=>wp_json_encode($payload)]);
   if(is_wp_error($res))wp_die('Skrivning misslyckades: '.esc_html($res->get_error_message()),502);
   $body=json_decode(wp_remote_retrieve_body($res),true);$http=(int)wp_remote_retrieve_response_code($res);
   if($http<200||$http>=300||!is_array($body)||!isset($body['id'])||absint($body['id'])!==$expected_id||empty($body['manage_stock'])||!isset($body['stock_quantity'])||abs((float)$body['stock_quantity']-$qty)>0.0001)wp_die('API-uppdateringen kunde inte bekräftas. Kontrollera produktens lagerstyrning och saldo manuellt innan du försöker igen.',502);
   Dennis_WMS_Audit::update($t,['stock_quantity'=>$qty,'updated_at'=>current_time('mysql')],['id'=>$p->id]);
   $status=$enable?'Lagerstyrning aktiverad och saldo uppdaterat via API':'Uppdaterad via API';
  }elseif($mode!=='record')wp_die('Ogiltigt läge',400);
  $history=self::history();
  array_unshift($history,['shop_id'=>(int)$p->shop_id,'product_id'=>(int)$p->remote_product_id,'sku'=>$p->sku,'before'=>$old,'count'=>$qty,'reason'=>$reason,'status'=>$status,'user'=>get_current_user_id(),'time'=>current_time('mysql')]);
  update_option('dw_remote_inventory_history',array_slice($history,0,1000),false);
  wp_safe_redirect(add_query_arg(['page'=>'pb-wms','remote_inventory_saved'=>1],admin_url('admin.php')));exit;
 }
 static function render(){
  if(!class_exists('Dennis_WMS_Multi_Shop'))return;
  global $wpdb;$selected=absint($_GET['dw_inventory_shop']??0);$focus=absint($_GET['dw_inventory_product']??0);$shops=Dennis_WMS_Multi_Shop::shops();
  echo '<section class="dw-panel" style="background:white;padding:16px;margin:14px 0;border:1px solid #ddd"><h2>Inventering – anslutna shoppar</h2><p><strong>Så inventerar du:</strong> Ange räknat antal och orsak på produktraden. Välj <em>Registrera</em> för att spara utan saldoändring. Välj <em>Uppdatera via API</em> när lagerstyrning redan är aktiv. Om lagerstyrning är avstängd kan du uttryckligen välja <em>Aktivera lagerstyrning + uppdatera</em>. Det ändrar inställning och saldo i WooCommerce.</p><p>Produkter hålls åtskilda per shop. Identiska SKU innebär inte automatiskt gemensamt saldo. Synkronisera före API-uppdatering.</p>';
  if(isset($_GET['remote_inventory_saved']))echo '<div class="notice notice-success inline"><p>Inventeringen sparades.</p></div>';
  echo '<form method="get"><input type="hidden" name="page" value="pb-wms"><label>Shop <select name="dw_inventory_shop"><option value="0">Alla anslutna shoppar</option>';
  foreach($shops as $shop)echo '<option value="'.absint($shop->id).'" '.selected($selected,(int)$shop->id,false).'>'.esc_html($shop->name).'</option>';
  echo '</select></label> <button class="button">Visa</button></form>';
  $pt=Dennis_WMS_Multi_Shop::table('products');$st=Dennis_WMS_Multi_Shop::table('shops');
  $where="WHERE p.status IN ('publish','private') AND p.type IN ('simple','variation')";
  if($selected)$where.=$wpdb->prepare(' AND p.shop_id=%d',$selected);
  if($focus)$where.=$wpdb->prepare(' AND p.id=%d',$focus);
  $rows=$wpdb->get_results("SELECT p.*,s.name shop_name FROM $pt p JOIN $st s ON s.id=p.shop_id $where ORDER BY s.name,p.name LIMIT 300");
  $last=[];foreach(self::history() as $h){$k=(int)$h['shop_id'].':'.(int)$h['product_id'];if(!isset($last[$k]))$last[$k]=$h;}
  echo '<p><small>Visar upp till 300 synkroniserade produkter. Systemsaldo är senast synkroniserat.</small></p><div style="overflow-x:auto"><table class="widefat striped"><thead><tr><th>Shop</th><th>Produkt</th><th>SKU</th><th>Systemsaldo</th><th>Senast räknat</th><th>Räknat antal</th><th>Orsak</th><th>Åtgärd</th></tr></thead><tbody>';
  foreach($rows as $r){$form='dw-ri-'.absint($r->id);
   echo '<tr><td>'.esc_html($r->shop_name).'</td><td>'.esc_html($r->name).'</td><td>'.esc_html($r->sku).'</td><td>'.($r->stock_quantity===null?'Ej lagerstyrd':esc_html($r->stock_quantity)).'</td>';
    $previous=$last[(int)$r->shop_id.':'.(int)$r->remote_product_id]??null;
   echo '<td>'.($previous?esc_html((string)$previous['count']).' <small>('.esc_html($previous['time']).')</small>':'Ej inventerad').'</td>';
   echo '<td><input form="'.esc_attr($form).'" name="quantity" type="number" min="0" step="0.0001" required style="width:100px"></td><td><input form="'.esc_attr($form).'" name="reason" required placeholder="Orsak"></td><td>';
   echo '<form id="'.esc_attr($form).'" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dw_remote_inventory');
   echo '<input type="hidden" name="action" value="dw_remote_inventory"><input type="hidden" name="product_id" value="'.absint($r->id).'">';
   echo '<button class="button" name="mode" value="record">Registrera</button> ';
   if($r->stock_quantity!==null)echo '<button class="button button-primary" name="mode" value="write" onclick="return confirm(\'Detta ändrar saldot i den anslutna shoppen till angivet räknat antal. Fortsätta?\')">Uppdatera via API</button> ';
   echo '<button class="button" name="mode" value="enable_write" onclick="return confirm(\'OBS! Detta AKTIVERAR lagerstyrning i den anslutna WooCommerce-shoppen och sätter lagersaldot till det räknade antalet. Detta kan påverka köpbarhet och befintliga ordrar. Har du kontrollerat produkten och vill fortsätta?\')">Aktivera lagerstyrning + uppdatera</button>';
   echo '</form></td></tr>';
  }
  if(!$rows)echo '<tr><td colspan="8">Inga synkroniserade produkter.</td></tr>';
  echo '</tbody></table></div>';
  $history=array_slice(self::history(),0,15);
  if($history){echo '<h3>Senaste inventeringar</h3><table class="widefat striped"><tr><th>Tid</th><th>Shop-ID</th><th>SKU</th><th>Före</th><th>Räknat</th><th>Status</th><th>Orsak</th></tr>';
   foreach($history as $h)echo '<tr><td>'.esc_html($h['time']).'</td><td>'.absint($h['shop_id']).'</td><td>'.esc_html($h['sku']).'</td><td>'.esc_html((string)$h['before']).'</td><td>'.esc_html((string)$h['count']).'</td><td>'.esc_html($h['status']).'</td><td>'.esc_html($h['reason']).'</td></tr>';
   echo '</table>';
  }
  if(class_exists('Dennis_WMS_Remote_Stock_Details'))Dennis_WMS_Remote_Stock_Details::render($selected);
  echo '</section>';
 }
}
