<?php
if (!defined('ABSPATH')) exit;
final class Dennis_WMS_Packaging_Materials {
 const OPT='dennis_wms_packaging_materials';
 const META='_dennis_wms_packaging_usage';
 static function boot(){
  add_action('admin_menu',[__CLASS__,'menu'],98);
  add_action('admin_post_dennis_wms_packmat_save',[__CLASS__,'save_material']);
  add_action('admin_post_dennis_wms_packmat_delete',[__CLASS__,'delete_material']);
  add_action('admin_post_dennis_wms_packmat_use',[__CLASS__,'save_usage']);
  add_action('admin_post_dennis_wms_packmat_count',[__CLASS__,'save_count']);
  add_action('admin_menu',[__CLASS__,'log_menu'],99);
 }
 static function menu(){add_submenu_page('pb-wms','Packmaterial','Packmaterial',PB_WMS_V03::MANAGE,'dennis-wms-packaging-materials',[__CLASS__,'page']);}
 static function all(){ $v=get_option(self::OPT,[]); return is_array($v)?$v:[]; }
 static function money($v){return function_exists('wc_price')?wc_price((float)$v):number_format_i18n((float)$v,2).' kr';}
 static function save_all($v){update_option(self::OPT,array_values($v),false);}
 static function log_menu(){add_submenu_page('pb-wms','Packmateriallogg','Packmateriallogg',PB_WMS_V03::MANAGE,'dennis-wms-packmat-log',[__CLASS__,'log_page']);}
 static function log_change($event,$material,$before,$after,$reason='',$order_id=0){
  $changes=[];foreach(array_unique(array_merge(array_keys((array)$before),array_keys((array)$after))) as $key){
   if(in_array($key,['created'],true))continue;
   $old=$before[$key]??null;$new=$after[$key]??null;
   if($old!==$new){$changes[$key]=['before'=>$old,'after'=>$new];if($key==='stock')$changes[$key]['difference']=(int)$new-(int)$old;}
  }
  if(!$changes)return;
  $entry=['time'=>current_time('mysql'),'event'=>$event,'id'=>$material['id']??'','name'=>$material['name']??'','changes'=>$changes,'reason'=>$reason,'order_id'=>(int)$order_id,'user_id'=>get_current_user_id()];
  $log=get_option('dennis_wms_packmat_change_log',[]);if(!is_array($log))$log=[];
  array_unshift($log,$entry);update_option('dennis_wms_packmat_change_log',array_slice($log,0,5000),false);
 }
 static function log_page(){
  if(!current_user_can(PB_WMS_V03::MANAGE))wp_die('Åtkomst nekad.',403);
  $log=get_option('dennis_wms_packmat_change_log',[]);if(!is_array($log))$log=[];
  echo '<div class="wrap"><h1>Packmaterial – ändringslogg</h1><p>Visar ändringar som registrerats efter installation av denna version. Äldre händelser kan inte återskapas automatiskt.</p><table class="widefat striped"><thead><tr><th>Datum</th><th>Material</th><th>Händelse</th><th>Fält</th><th>Före</th><th>Efter</th><th>Skillnad</th><th>Order</th><th>Orsak</th><th>Användare</th></tr></thead><tbody>';
  foreach(array_slice($log,0,500) as $e){$u=get_userdata($e['user_id']??0);foreach(($e['changes']??[]) as $field=>$v){
   $format=static function($value){return is_scalar($value)?(string)$value:($value===null?'–':wp_json_encode($value));};
   echo '<tr><td>'.esc_html($e['time']).'</td><td>'.esc_html($e['name']).'</td><td>'.esc_html($e['event']).'</td><td>'.esc_html($field).'</td><td>'.esc_html($format($v['before']??null)).'</td><td>'.esc_html($format($v['after']??null)).'</td><td>'.esc_html(isset($v['difference'])?sprintf('%+d',$v['difference']):'–').'</td><td>'.esc_html($e['order_id']?:'–').'</td><td>'.esc_html($e['reason']).'</td><td>'.esc_html($u?$u->display_name:'–').'</td></tr>';
  }}echo '</tbody></table></div>';
 }
 static function find($id){foreach(self::all() as $m)if(($m['id']??'')===$id)return $m;return null;}
 static function save_material(){
  if(!current_user_can(PB_WMS_V03::MANAGE))wp_die('Åtkomst nekad.',403);check_admin_referer('dennis_wms_packmat_save');
  $id=sanitize_key(wp_unslash($_POST['id']??''));$name=sanitize_text_field(wp_unslash($_POST['name']??''));if($name==='')wp_die('Ange namn.',400);
  $type=sanitize_text_field(wp_unslash($_POST['type']??''));$stock=max(0,(int)($_POST['stock']??0));$minimum=max(0,(int)($_POST['minimum']??0));$cost=max(0,(float)str_replace(',','.',(string)($_POST['cost']??0)));$location=sanitize_text_field(wp_unslash($_POST['location']??''));$barcode=trim(sanitize_text_field(wp_unslash($_POST['barcode']??'')));
  if($barcode!==''){foreach(self::all() as $existing){if(($existing['id']??'')!==$id && ($existing['barcode']??'')===$barcode)wp_die('Streckkoden används redan av annat packmaterial.',409);}}
  $before=self::find($id);$all=self::all();$found=false;if($id!==''){foreach($all as &$m)if(($m['id']??'')===$id){$m=array_merge($m,compact('name','type','stock','minimum','cost','location','barcode'));$found=true;break;}unset($m);}if(!$found){$id='pm_'.strtolower(wp_generate_password(10,false,false));$all[]=['id'=>$id,'name'=>$name,'type'=>$type,'stock'=>$stock,'minimum'=>$minimum,'cost'=>$cost,'location'=>$location,'barcode'=>$barcode,'created'=>current_time('mysql')];}
  self::save_all($all);$after=self::find($id);self::log_change($before?'Redigering':'Skapad',$after,$before?:[],$after,'Manuell ändring');wp_safe_redirect(admin_url('admin.php?page=dennis-wms-packaging-materials&saved=1'));exit;
 }
 static function delete_material(){if(!current_user_can(PB_WMS_V03::MANAGE))wp_die('Åtkomst nekad.',403);$id=sanitize_key(wp_unslash($_GET['id']??''));check_admin_referer('dennis_wms_packmat_delete_'.$id);$before=self::find($id);self::save_all(array_values(array_filter(self::all(),fn($m)=>($m['id']??'')!==$id)));if($before)self::log_change('Borttagen',$before,$before,[],'Manuell borttagning');wp_safe_redirect(admin_url('admin.php?page=dennis-wms-packaging-materials&deleted=1'));exit;}
 static function usage($order){$v=$order->get_meta(self::META,true);return is_array($v)?$v:[];}
 static function save_usage(){
  if(!current_user_can(PB_WMS_V03::MANAGE))wp_die('Åtkomst nekad.',403);$oid=absint($_POST['order_id']??0);check_admin_referer('dennis_wms_packmat_use_'.$oid);$order=wc_get_order($oid);if(!$order)wp_die('Ordern finns inte.',404);
  $posted=is_array($_POST['qty']??null)?wp_unslash($_POST['qty']):[];$all=self::all();$before_all=array_column($all,null,'id');$old=self::usage($order);$oldmap=[];foreach($old as $u)$oldmap[$u['id']] = (int)$u['qty'];$new=[];
  foreach($all as &$m){$id=$m['id'];$qty=max(0,(int)($posted[$id]??0));$prev=$oldmap[$id]??0;$delta=$qty-$prev;if($delta>0 && $delta>(int)$m['stock'])wp_die('Inte tillräckligt saldo av '.$m['name'].'.',409);$m['stock']=max(0,(int)$m['stock']-$delta);if($qty>0)$new[]=['id'=>$id,'name'=>$m['name'],'type'=>$m['type']??'','qty'=>$qty,'unit_cost'=>(float)($m['cost']??0),'time'=>current_time('mysql'),'user_id'=>get_current_user_id()];}unset($m);
  self::save_all($all);foreach($all as $m){$prev=$before_all[$m['id']]??[];self::log_change('Orderpackning',$m,$prev,$m,'Registrerat emballage på order', $oid);}$order->update_meta_data(self::META,$new);$order->save();
  wp_safe_redirect(admin_url('admin.php?page=dennis-wms-orders&order_id='.$oid.'&packmat_saved=1#dw-packmaterial'));exit;
 }
 static function counts(){ $v=get_option('dennis_wms_packmat_counts',[]);return is_array($v)?$v:[]; }
 static function save_count(){
  if(!current_user_can(PB_WMS_V03::MANAGE))wp_die('Åtkomst nekad.',403);
  check_admin_referer('dennis_wms_packmat_count');
  $id=sanitize_key(wp_unslash($_POST['material_id']??''));
  $raw=wp_unslash($_POST['counted']??'');
  if(!is_scalar($raw)||!preg_match('/^\d+$/',(string)$raw))wp_die('Ange ett giltigt heltal.',400);
  $counted=(int)$raw;
  $reason=sanitize_text_field(wp_unslash($_POST['reason']??''));
  if($reason==='')wp_die('Ange orsak till inventeringen.',400);
  $all=self::all();$found=false;$counted_material=null;
  foreach($all as &$m){if(($m['id']??'')!==$id)continue;
   $before=(int)$m['stock'];$m['stock']=$counted;$found=true;$counted_material=$m;
   $entry=['time'=>current_time('mysql'),'id'=>$id,'name'=>$m['name'],'before'=>$before,'counted'=>$counted,'difference'=>$counted-$before,'reason'=>$reason,'user_id'=>get_current_user_id()];break;
  }unset($m);
  if(!$found)wp_die('Packmaterialet finns inte.',404);
  self::save_all($all);self::log_change('Inventering',$counted_material,['stock'=>$before],['stock'=>$counted],$reason);$history=self::counts();array_unshift($history,$entry);update_option('dennis_wms_packmat_counts',array_slice($history,0,1000),false);
  wp_safe_redirect(admin_url('admin.php?page=pb-wms&packmat_counted=1#dw-packmat-inventory'));exit;
 }
 static function render_inventory(){
  if(!current_user_can(PB_WMS_V03::MANAGE))return;
  $all=self::all();echo '<div id="dw-packmat-inventory" class="dw-panel" style="max-width:1200px;margin:18px 0;padding:18px"><h2>Inventering av packmaterial</h2><p>Inventera lådor, halvpallar, helpallar och annat emballage utan SKU. Räknat antal ersätter packmaterialets saldo, utan att påverka WooCommerce.</p>';
  if(isset($_GET['packmat_counted']))echo '<div class="notice notice-success inline"><p>Inventeringen har sparats.</p></div>';
  if(!$all){echo '<p>Inget packmaterial finns ännu. <a href="'.esc_url(admin_url('admin.php?page=dennis-wms-packaging-materials')).'">Lägg till packmaterial</a>.</p></div>';return;}
  echo '<table class="widefat striped"><thead><tr><th>Material</th><th>Typ</th><th>Lagerplats</th><th>Saldo</th><th>Räknat antal / Orsak</th></tr></thead><tbody>';
  foreach($all as $m){echo '<tr><td><strong>'.esc_html($m['name']).'</strong></td><td>'.esc_html($m['type']??'').'</td><td>'.esc_html($m['location']??'').'</td><td>'.esc_html((string)$m['stock']).'</td><td><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dennis_wms_packmat_count"><input type="hidden" name="material_id" value="'.esc_attr($m['id']).'">';wp_nonce_field('dennis_wms_packmat_count');echo '<input aria-label="Räknat antal" type="number" name="counted" min="0" step="1" required value="'.esc_attr((string)$m['stock']).'" style="width:95px"> <input aria-label="Orsak" type="text" name="reason" required placeholder="Orsak / kommentar" style="max-width:220px"> <button class="button button-primary" onclick="return confirm(\'Spara inventering och uppdatera saldot?\')">Spara inventering</button></form></td></tr>';}
  echo '</tbody></table><h3>Senaste inventeringar av packmaterial</h3><table class="widefat striped"><thead><tr><th>Datum</th><th>Material</th><th>Före</th><th>Räknat</th><th>Differens</th><th>Orsak</th><th>Användare</th></tr></thead><tbody>';
  foreach(array_slice(self::counts(),0,30) as $e){$user=get_userdata($e['user_id']??0);echo '<tr><td>'.esc_html($e['time']).'</td><td>'.esc_html($e['name']).'</td><td>'.esc_html((string)$e['before']).'</td><td>'.esc_html((string)$e['counted']).'</td><td>'.esc_html((string)$e['difference']).'</td><td>'.esc_html($e['reason']).'</td><td>'.esc_html($user?$user->display_name:'–').'</td></tr>';}
  echo '</tbody></table></div>';
 }
 static function signature($order){
  $items=[];
  foreach($order->get_items('line_item') as $item){
   $product=$item->get_product();$key=$product?$product->get_sku():'';
   if($key==='')$key='product:'.$item->get_product_id().':'.$item->get_variation_id();
   $items[$key]=($items[$key]??0)+max(0,(int)$item->get_quantity());
  }
  ksort($items);return $items;
 }
 static function suggestions($order,$all){
  $target=self::signature($order);if(!$target)return [];
  $orders=wc_get_orders(['limit'=>200,'orderby'=>'date','order'=>'DESC','exclude'=>[$order->get_id()]]);
  $votes=[];$counts=[];
  foreach($orders as $previous){
   $usage=self::usage($previous);if(!$usage)continue;
   $items=self::signature($previous);if(!$items)continue;
   $common=array_intersect(array_keys($target),array_keys($items));
   if(!$common)continue;
   $union=array_unique(array_merge(array_keys($target),array_keys($items)));
   $similarity=count($common)/max(1,count($union));
   $distance=0;foreach($union as $sku)$distance+=abs(($target[$sku]??0)-($items[$sku]??0));
   $weight=$similarity/(1+$distance/max(1,array_sum($target)));
   if($weight<0.3)continue;
   foreach($usage as $u){$id=$u['id']??'';if(!$id||empty($u['qty']))continue;
    $votes[$id][$u['qty']]=($votes[$id][$u['qty']]??0)+$weight;
    $counts[$id]=($counts[$id]??0)+1;
   }
  }
  $out=[];foreach($all as $m){$id=$m['id'];if(empty($votes[$id]))continue;arsort($votes[$id],SORT_NUMERIC);$qty=(int)array_key_first($votes[$id]);$out[$id]=['qty'=>$qty,'examples'=>$counts[$id]];}
  return $out;
 }
 static function render_order($order){
  $all=self::all();$used=self::usage($order);$map=[];foreach($used as $u)$map[$u['id']]=(int)$u['qty'];$suggestions=self::suggestions($order,$all);
  echo '<section id="dw-packmaterial" class="dw-order-section"><div class="dw-section-head"><div><span class="dashicons dashicons-archive"></span><div><h2>Packmaterial</h2><p>Ange vilka lådor och annat packmaterial som används för ordern. Ingen SKU krävs.</p></div></div></div>';
  if(!$all){echo '<p>Inget packmaterial upplagt ännu. <a class="button" href="'.esc_url(admin_url('admin.php?page=dennis-wms-packaging-materials')).'">Lägg upp packmaterial</a></p></section>';return;}
  echo '<p><strong>Emballageförslag:</strong> '.($suggestions?'Baserat på tidigare order med liknande artiklar och antal.':'Ingen tillräckligt liknande packhistorik ännu.').' Förslagen är inte sparade förrän du bekräftar dem.</p>';
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dennis_wms_packmat_use"><input type="hidden" name="order_id" value="'.esc_attr($order->get_id()).'">';wp_nonce_field('dennis_wms_packmat_use_'.$order->get_id());echo '<table class="widefat striped"><thead><tr><th>Material</th><th>Typ</th><th>Lagerplats</th><th>Tillgängligt</th><th>Förslag från historik</th><th>Använt på ordern</th></tr></thead><tbody>';
  foreach($all as $m){$id=$m['id'];$q=$map[$id]??0;$suggest=$suggestions[$id]??null;
   $hint=$suggest?($suggest['qty'].' st · '.$suggest['examples'].' liknande order'):'–';
   echo '<tr><td><strong>'.esc_html($m['name']).'</strong></td><td>'.esc_html($m['type']?:'–').'</td><td>'.esc_html($m['location']?:'–').'</td><td>'.esc_html((string)$m['stock']).' st</td><td>'.esc_html($hint).'</td><td><input type="number" min="0" step="1" name="qty['.esc_attr($id).']" value="'.esc_attr((string)$q).'" style="width:90px"> st';
   if($suggest && !$used)echo ' <button type="button" class="button dw-use-suggestion" data-target="qty['.esc_attr($id).']" data-qty="'.esc_attr((string)$suggest['qty']).'">Använd förslag</button>';
   echo '</td></tr>';
  }
  echo '</tbody></table><p><button class="button button-primary">Spara packmaterial</button> <small>Saldot justeras endast med skillnaden mot tidigare sparat antal, så samma order dras inte dubbelt.</small></p></form><script>document.querySelectorAll(".dw-use-suggestion").forEach(function(b){b.addEventListener("click",function(){var f=b.closest("form");var input=f&&Array.from(f.querySelectorAll("input[type=number]")).find(function(i){return i.name===b.dataset.target});if(input)input.value=b.dataset.qty;});});</script></section>';
 }
 static function page(){
  if(!current_user_can(PB_WMS_V03::MANAGE))wp_die('Åtkomst nekad.',403);$all=self::all();$edit=sanitize_key(wp_unslash($_GET['edit']??''));$e=$edit?self::find($edit):null;
  $orders=wc_get_orders(['limit'=>200,'orderby'=>'date','order'=>'DESC']);$stats=[];$totalCost=0;foreach($orders as $o)foreach(self::usage($o) as $u){$id=$u['id'];if(!isset($stats[$id]))$stats[$id]=['name'=>$u['name'],'qty'=>0,'cost'=>0];$stats[$id]['qty']+=(int)$u['qty'];$stats[$id]['cost']+=(int)$u['qty']*(float)$u['unit_cost'];$totalCost+=(int)$u['qty']*(float)$u['unit_cost'];}
  echo '<div class="wrap"><h1>Packmaterial</h1><p>Skapa exempelvis Låda S, Låda M, Halvpall och Helpall som separata material med egna saldon. För Typ kan du skriva Låda, Halvpall eller Helpall.</p><p>Separat lager för lådor och annat packmaterial. Ingen SKU eller WooCommerce-produkt behövs.</p><div style="display:grid;grid-template-columns:minmax(300px,420px) 1fr;gap:20px;align-items:start"><div class="postbox" style="padding:18px"><h2>'.($e?'Redigera':'Lägg till').' packmaterial</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dennis_wms_packmat_save"><input type="hidden" name="id" value="'.esc_attr($e['id']??'').'">';wp_nonce_field('dennis_wms_packmat_save');
  foreach([['name','Namn','text'],['barcode','Streckkod (manuell)','text'],['type','Typ','text'],['stock','Saldo','number'],['minimum','Miniminivå','number'],['cost','Kostnad/st','number'],['location','Lagerplats','text']] as $f){[$k,$lab,$type]=$f;$val=$e[$k]??($type==='number'?0:'');echo '<p><label><strong>'.esc_html($lab).'</strong><br><input class="regular-text" type="'.esc_attr($type).'" '.($k==='cost'?'step="0.01"':'').' min="0" name="'.esc_attr($k).'" value="'.esc_attr((string)$val).'" '.($k==='name'?'required':'').'></label></p>';}
  echo '<button class="button button-primary">'.($e?'Spara ändringar':'Lägg till').'</button></form></div><div><table class="widefat striped"><thead><tr><th>Namn</th><th>Streckkod</th><th>Typ</th><th>Saldo</th><th>Min</th><th>Kostnad/st</th><th>Lagerplats</th><th></th></tr></thead><tbody>';
  foreach($all as $m){$low=(int)$m['stock']<=(int)$m['minimum'];echo '<tr'.($low?' style="background:#fff3cd"':'').'><td><strong>'.esc_html($m['name']).'</strong>'.($low?' <span title="Under miniminivå">⚠️</span>':'').'</td><td>'.esc_html($m['barcode']??'–').'</td><td>'.esc_html($m['type']?:'–').'</td><td><strong>'.esc_html((string)$m['stock']).'</strong> st</td><td>'.esc_html((string)$m['minimum']).'</td><td>'.wp_kses_post(self::money($m['cost'])).'</td><td>'.esc_html($m['location']?:'–').'</td><td><a class="button" href="'.esc_url(admin_url('admin.php?page=dennis-wms-packaging-materials&edit='.$m['id'])).'">Redigera</a> <a class="button" onclick="return confirm(\'Ta bort packmaterialet? Historik på gamla order påverkas inte.\')" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=dennis_wms_packmat_delete&id='.$m['id']),'dennis_wms_packmat_delete_'.$m['id'])).'">Ta bort</a></td></tr>';}
  if(!$all)echo '<tr><td colspan="8">Inget packmaterial upplagt.</td></tr>';echo '</tbody></table><h2 style="margin-top:28px">Förbrukningsstatistik <small>(senaste 200 order)</small></h2><table class="widefat striped"><thead><tr><th>Material</th><th>Använt</th><th>Kostnad</th></tr></thead><tbody>';foreach($stats as $s)echo '<tr><td>'.esc_html($s['name']).'</td><td><strong>'.esc_html((string)$s['qty']).' st</strong></td><td>'.wp_kses_post(self::money($s['cost'])).'</td></tr>';if(!$stats)echo '<tr><td colspan="3">Ingen förbrukning registrerad ännu.</td></tr>';echo '<tr><th colspan="2">Total kostnad</th><th>'.wp_kses_post(self::money($totalCost)).'</th></tr></tbody></table></div></div></div>';
 }
}
Dennis_WMS_Packaging_Materials::boot();
