<?php
if (!defined('ABSPATH')) exit;
/** Read-only follow-up of completed stock counts; never changes stock. */
final class Dennis_WMS_Inventory_Followup {
 const DAYS=183;
 static function dates($ids) {
  global $wpdb; $out=[]; $ids=array_values(array_unique(array_filter(array_map('absint',(array)$ids))));
  if (!$ids) return $out;
  $table=$wpdb->prefix.'pb_wms_counts';
  if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$table))!==$table) return $out;
  foreach(array_chunk($ids,300) as $chunk){
   $marks=implode(',',array_fill(0,count($chunk),'%d'));
   $sql=$wpdb->prepare("SELECT product_id,MAX(counted_at) last_count FROM `$table` WHERE product_id IN ($marks) AND update_status NOT IN ('void','invalid','failed','pending') GROUP BY product_id",$chunk);
   foreach((array)$wpdb->get_results($sql) as $r) $out[(int)$r->product_id]=(string)$r->last_count;
  }
  return $out;
 }
 static function status($date){
  if (!$date || !($ts=strtotime($date)))return ['none','Ej inventerad','–'];
  $tz=wp_timezone(); $last=new DateTimeImmutable($date,$tz);
  $due=$last->modify('+6 months'); $now=new DateTimeImmutable('now',$tz);
  $days=(int)$now->diff($due)->format('%r%a');
  return [$days<0?'late':($days<=30?'soon':'ok'),$days<0?'Försenad':($days<=30?'Snart dags':'Inventerad'),$due->format('Y-m-d')];
 }
 static function badge($date){[$key,$label,$due]=self::status($date);$colors=['none'=>'#64748b','late'=>'#b91c1c','soon'=>'#a16207','ok'=>'#15803d'];$last=$date?substr($date,0,16):'Ingen registrerad inventering';return '<span style="display:inline-block;padding:4px 9px;border-radius:7px;background:'.esc_attr($colors[$key]).';color:#fff;font-weight:600">'.esc_html($label).'</span><br><small>Senast: '.esc_html($last).'<br>Nästa senast: '.esc_html($due).'</small>';
 }
 static function latest_details($ids){
  global $wpdb; $out=[];
  $ids=array_values(array_unique(array_filter(array_map('absint',(array)$ids))));
  if(!$ids)return $out;
  $table=$wpdb->prefix.'pb_wms_counts';
  if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$table))!==$table)return $out;
  foreach(array_chunk($ids,300) as $chunk){
   $marks=implode(',',array_fill(0,count($chunk),'%d'));
   $sql=$wpdb->prepare("SELECT id,product_id,counted_at,counted_qty,user_id FROM `$table` WHERE product_id IN ($marks) AND update_status NOT IN ('void','invalid','failed','pending') ORDER BY counted_at DESC,id DESC",$chunk);
   foreach((array)$wpdb->get_results($sql) as $row){$id=(int)$row->product_id;if(!isset($out[$id]))$out[$id]=$row;}
  }
  return $out;
 }
 static function product_status_html($event){
  $date=$event?(string)$event->counted_at:'';
  [$key,$label,$due]=self::status($date);
  $colors=['none'=>'#64748b','late'=>'#b91c1c','soon'=>'#a16207','ok'=>'#15803d'];
  $html='<div class="dw-inventory-status"><span class="dw-inventory-badge" style="background:'.esc_attr($colors[$key]).'">'.esc_html($label).'</span>';
  if($event){
   $user=get_userdata((int)$event->user_id);
   $html.='<small><strong>Senast:</strong> '.esc_html(substr($date,0,16)).'</small>';
   $html.='<small><strong>Nästa senast:</strong> '.esc_html($due).'</small>';
   $html.='<small><strong>Inventerad av:</strong> '.esc_html($user?$user->display_name:'Användare #'.(int)$event->user_id).'</small>';
   $html.='<small><strong>Räknat antal:</strong> '.esc_html((string)$event->counted_qty).' st</small>';
  }else $html.='<small>Ingen slutförd inventering registrerad.</small>';
  return $html.'</div>';
 }
 static function summary($products){
  $ids=[];foreach($products as $p)if($p->managing_stock() && (int)$p->get_stock_managed_by_id()===(int)$p->get_id())$ids[]=$p->get_id();
  $dates=self::dates($ids);$counts=['ok'=>0,'soon'=>0,'late'=>0,'none'=>0];foreach($ids as $id){[$status]=self::status($dates[$id]??'');$counts[$status]++;}
  echo '<section style="margin:16px 0;padding:14px;background:#fff;border:1px solid #dcdcde;border-radius:10px"><h2 style="margin-top:0">Inventeringsuppföljning – två gånger per år</h2><p>Varje lagerstyrd artikel ska inventeras minst var sjätte månad. Varning visas 30 dagar innan nästa inventering. Endast slutförda inventeringar räknas.</p><div style="display:flex;gap:10px;flex-wrap:wrap">';
  foreach(['ok'=>'Inventerade','soon'=>'Snart dags','late'=>'Försenade','none'=>'Ej inventerade'] as $k=>$label)echo '<span style="padding:9px 12px;border-radius:7px;background:#f1f5f9"><strong>'.esc_html($counts[$k]).'</strong> '.esc_html($label).'</span>';
  echo '</div><p><a href="'.esc_url(admin_url('admin.php?page=pb-wms')).'">Visa inventeringsstatus per produkt →</a></p></section>';
 }
}
