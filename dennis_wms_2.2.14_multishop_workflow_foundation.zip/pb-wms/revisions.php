<?php
if (!defined('ABSPATH')) exit;
final class Dennis_WMS_Revisions {
 static function table() {
  global $wpdb;
  $t=$wpdb->prefix.'dennis_wms_revisions';
  require_once ABSPATH.'wp-admin/includes/upgrade.php';
  dbDelta("CREATE TABLE $t (
   id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
   count_id bigint(20) unsigned NOT NULL,
   kind varchar(12) NOT NULL,
   corrected_qty bigint(20) unsigned NULL,
   corrected_location varchar(80) NOT NULL DEFAULT '',
   reason varchar(500) NOT NULL,
   user_id bigint(20) unsigned NOT NULL,
   created_at datetime NOT NULL,
   stock_before bigint(20) NULL,
   stock_after bigint(20) NULL,
   stock_status varchar(20) NOT NULL DEFAULT 'unchanged',
   PRIMARY KEY  (id),
   KEY count_id (count_id)
  ) ".$wpdb->get_charset_collate().';');
 }
 static function latest($id) {
  global $wpdb; $t=$wpdb->prefix.'dennis_wms_revisions';
  return $wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE count_id=%d ORDER BY id DESC LIMIT 1",$id));
 }
 static function save() {
  if (!current_user_can(PB_WMS_V03::MANAGE) || !current_user_can('manage_woocommerce')) wp_die('Behörighet saknas.',403);
  $id=isset($_POST['event_id']) ? absint(wp_unslash($_POST['event_id'])) : 0;
  check_admin_referer('dennis_wms_revision_'.$id);
  global $wpdb; $counts=$wpdb->prefix.'pb_wms_counts'; $revs=$wpdb->prefix.'dennis_wms_revisions';
  $e=$wpdb->get_row($wpdb->prepare("SELECT * FROM $counts WHERE id=%d",$id));
  if (!$e) wp_die('Inventeringen hittades inte.',404);
  if($e->update_status==='applied_slots')wp_die('Denna inventering har rader per batch/lagerplats. Gör en ny fullständig inventering för att korrigera delsaldo och totalsaldo tillsammans.',409);
  if(Dennis_WMS_Inventory_Slots::rows((int)$e->product_id)['rows'])wp_die('Produkten har nu delsaldo per batch eller lagerplats. Gör en ny fullständig inventering för att korrigera saldot.',409);
  $last=self::latest($id);
  if ($last && $last->kind==='void') wp_die('Denna inventering är redan ogiltigförklarad.',409);
  $kind=isset($_POST['revision_kind']) ? sanitize_key(wp_unslash($_POST['revision_kind'])) : '';
  if (!in_array($kind,['correct','void'],true)) wp_die('Ogiltig åtgärd.',400);
  $reason=isset($_POST['reason']) ? sanitize_text_field(wp_unslash($_POST['reason'])) : '';
  if (!is_string($reason) || mb_strlen(trim($reason))<3 || mb_strlen($reason)>500) wp_die('Ange en orsak (3–500 tecken).',400);
  $qty=null; $loc=(string)$e->location;
  if ($kind==='correct') {
   $raw=isset($_POST['corrected_qty']) ? wp_unslash($_POST['corrected_qty']) : '';
   if (!is_string($raw) || !preg_match('/^(0|[1-9][0-9]{0,8})$/',$raw)) wp_die('Ogiltigt antal.',400);
   $qty=(int)$raw;
   $loc=isset($_POST['corrected_location']) ? sanitize_text_field(wp_unslash($_POST['corrected_location'])) : '';
   if (!is_string($loc) || mb_strlen($loc)>80) wp_die('Ogiltig lagerplats.',400);
  }
  $update=$kind==='correct' && isset($_POST['update_stock']) && $_POST['update_stock']==='1';
  $p=null; $before=null; $status='unchanged';
  if ($update) {
   $p=PB_WMS_V03::allowed_product((int)$e->product_id);
   if (!$p || !current_user_can('edit_product',$p->get_id()) || !$p->managing_stock() || $p->get_stock_quantity()===null) wp_die('Produkten saknar stöd för saldouppdatering.',400);
   if (get_post_meta($p->get_id(),'_atum_multi_inventory',true) || get_post_meta($p->get_id(),'_multi_inventory',true)) wp_die('ATUM Multi-Inventory stöds inte.',400);
   if (!in_array($e->update_status,['applied','applied_details'],true) || $e->applied_qty===null) wp_die('Den ursprungliga inventeringen uppdaterade inte saldot korrekt. Korrigera WooCommerce manuellt.',409);
   // A newer inventory count makes retrospective stock overwrites unsafe.
   $newer=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $counts WHERE product_id=%d AND id>%d AND update_status IN ('applied','applied_details','applied_slots')",$e->product_id,$id));
   if ((int)$newer>0) wp_die('En senare inventering finns. Gör en ny inventering i stället.',409);
   $before=(int)$p->get_stock_quantity();
   if($last && $last->kind==='correct' && $last->stock_status!=='applied') wp_die('Senaste korrigeringen uppdaterade inte saldot. Gör en ny inventering för att korrigera aktuellt saldo.',409);
   $expected=isset($_POST['expected_stock']) ? wp_unslash($_POST['expected_stock']) : '';
   if (!is_string($expected) || !preg_match('/^(0|[1-9][0-9]{0,8})$/',$expected) || (int)$expected!==$before || $before!==(int)($last && $last->stock_status==='applied' ? $last->stock_after : $e->applied_qty)) wp_die('Aktuellt saldo skiljer sig från inventeringens sparade saldo. Inget saldo ändrat. Gör en ny inventering i stället.',409);
   $status='pending';
  }
  $ok=Dennis_WMS_Audit::insert($revs,['count_id'=>$id,'kind'=>$kind,'corrected_qty'=>$qty,'corrected_location'=>$loc,'reason'=>$reason,'user_id'=>get_current_user_id(),'created_at'=>current_time('mysql'),'stock_before'=>$before,'stock_status'=>$status],['%d','%s','%d','%s','%s','%d','%s','%d','%s']);
  if (!$ok) wp_die('Revisionsloggen kunde inte sparas. Inget saldo ändrades.',500);
  $revision_id=(int)$wpdb->insert_id;
  if ($update) {
   try {
    $result=wc_update_product_stock($p,$qty,'set');
    if ($result===false) throw new Exception('WooCommerce kunde inte ändra saldot.');
    $fresh=wc_get_product($p->get_id());
    if (!$fresh || (int)$fresh->get_stock_quantity()!==$qty) throw new Exception('Det nya saldot kunde inte verifieras.');
    Dennis_WMS_Audit::update($revs,['stock_after'=>$qty,'stock_status'=>'applied'],['id'=>$revision_id],['%d','%s'],['%d']);
   } catch(Throwable $ex) {
    Dennis_WMS_Audit::update($revs,['stock_status'=>'failed'],['id'=>$revision_id],['%s'],['%d']);
    wp_die(esc_html($ex->getMessage()).' Kontrollera produktens saldo innan du försöker igen.',500);
   }
  }
  wp_safe_redirect(add_query_arg(['page'=>'pb-wms','pb_status'=>'revision'],admin_url('admin.php'))); exit;
 }
}
