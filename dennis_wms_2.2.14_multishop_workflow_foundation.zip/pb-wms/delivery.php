<?php
if (!defined('ABSPATH')) exit;
/** Optional delivery/transport workflow with DHL/DSV tracking. Bookings are performed outside WMS; only DHL/DSV tracking APIs are available. */
final class Dennis_WMS_Delivery {
 const SCHEMA='1.9.2'; const CAP='pb_wms_manage';
 static function table(){global $wpdb;return $wpdb->prefix.'dennis_wms_delivery';}
 static function boot(){
  add_action('admin_menu',[__CLASS__,'menu'],109);
  add_action('admin_init',[__CLASS__,'upgrade']);
  add_action('admin_init',[__CLASS__,'remove_booking_settings']);
  add_action('admin_post_dennis_wms_delivery_save',[__CLASS__,'save_order']);
  add_action('admin_post_dennis_wms_delivery_settings',[__CLASS__,'save_settings']);
  add_action('admin_post_dennis_wms_sender_save',[__CLASS__,'save_sender']);
  add_action('admin_post_dennis_wms_sender_delete',[__CLASS__,'delete_sender']);
  add_action('admin_post_dennis_wms_tracking_test',[__CLASS__,'tracking_test']);
  add_action('admin_post_dennis_wms_tracking_refresh',[__CLASS__,'tracking_refresh']);
  add_action('admin_post_dennis_wms_tracking_refresh_all',[__CLASS__,'tracking_refresh_all']);
  add_action('admin_post_dennis_wms_dsv_api_test',[__CLASS__,'dsv_api_test']);
  add_action('admin_post_dennis_wms_freight_doc',[__CLASS__,'serve_freight_doc']);
  add_action('admin_post_nopriv_dennis_wms_freight_doc',['Dennis_WMS_Security','deny']);
  add_action('admin_post_dennis_wms_freight_doc_upload',[__CLASS__,'upload_freight_doc']);
  add_action('dennis_wms_tracking_cron',[__CLASS__,'tracking_cron']);
  add_action('init',[__CLASS__,'ensure_tracking_cron']);
  // Keep WMS delivery/tracking in sync when a local WooCommerce order is trashed or permanently deleted.
  add_action('wp_trash_post',[__CLASS__,'maybe_cleanup_deleted_order'],10,1);
  add_action('before_delete_post',[__CLASS__,'maybe_cleanup_deleted_order'],10,1);
  add_action('woocommerce_before_delete_order',[__CLASS__,'cleanup_local_order'],10,1);
 }
 static function local_order_exists($order_id){
  $order_id=absint($order_id);if(!$order_id||!function_exists('wc_get_order'))return false;
  $o=wc_get_order($order_id);if(!$o)return false;
  $status=method_exists($o,'get_status')?(string)$o->get_status():'';
  return $status!==''&&$status!=='trash';
 }
 static function maybe_cleanup_deleted_order($post_id){
  $post_id=absint($post_id);if(!$post_id)return;
  $type=get_post_type($post_id);if($type!=='shop_order')return;
  self::cleanup_local_order($post_id);
 }
 static function cleanup_local_order($order_id){
  $order_id=is_object($order_id)&&method_exists($order_id,'get_id')?$order_id->get_id():absint($order_id);if(!$order_id)return;
  global $wpdb;Dennis_WMS_Audit::delete(self::table(),['shop_key'=>'local','order_ref'=>$order_id],['%s','%d']);
  // Freight documents are retained on disk for audit, but detached from active order views.
  Dennis_WMS_Audit::delete(self::docs_table(),['shop_key'=>'local','order_ref'=>$order_id],['%s','%d']);
 }
 static function purge_missing_local_records(){
  global $wpdb;$t=self::table();$ids=$wpdb->get_col("SELECT order_ref FROM $t WHERE shop_key='local' ORDER BY id DESC LIMIT 1000");$removed=0;
  foreach(array_unique(array_map('absint',$ids)) as $id){if($id&&!self::local_order_exists($id)){self::cleanup_local_order($id);$removed++;}}
  return $removed;
 }
 static function menu(){
  add_submenu_page('pb-wms','Transport & Tracking','Transport & Tracking','pb_wms_view','dennis-wms-tracking',[__CLASS__,'tracking_center']);
  add_submenu_page('pb-wms','Leverans & transport','Leverans & transport','pb_wms_view','dennis-wms-delivery',[__CLASS__,'page']);
 }
 static function install(){global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$c=$wpdb->get_charset_collate();$t=self::table();dbDelta("CREATE TABLE $t (id bigint(20) unsigned NOT NULL AUTO_INCREMENT,shop_key varchar(80) NOT NULL,order_ref bigint(20) unsigned NOT NULL,method varchar(30) NOT NULL DEFAULT '',status varchar(40) NOT NULL DEFAULT '',carrier varchar(30) NOT NULL DEFAULT '',sender_id varchar(80) NOT NULL DEFAULT '',packages int unsigned NOT NULL DEFAULT 1,weight decimal(12,3) NULL,length decimal(12,2) NULL,width decimal(12,2) NULL,height decimal(12,2) NULL,tracking varchar(190) NOT NULL DEFAULT '',tracking_status varchar(40) NOT NULL DEFAULT '',tracking_updated_at datetime NULL,tracking_history longtext NULL,project varchar(190) NOT NULL DEFAULT '',note text NULL,completed_at datetime NULL,completion_estimated tinyint NOT NULL DEFAULT 0,updated_at datetime NOT NULL,updated_by bigint(20) unsigned NOT NULL DEFAULT 0,PRIMARY KEY (id),UNIQUE KEY order_key (shop_key,order_ref),KEY method_status (method,status),KEY updated_at (updated_at)) $c;");
 $d=$wpdb->prefix.'dennis_wms_freight_docs';dbDelta("CREATE TABLE $d (id bigint(20) unsigned NOT NULL AUTO_INCREMENT,shop_key varchar(80) NOT NULL DEFAULT 'local',order_ref bigint(20) unsigned NOT NULL DEFAULT 0,booking_id varchar(190) NOT NULL DEFAULT '',doc_type varchar(40) NOT NULL DEFAULT 'other',filename varchar(190) NOT NULL,path text NOT NULL,created_at datetime NOT NULL,created_by bigint(20) unsigned NOT NULL DEFAULT 0,PRIMARY KEY (id),KEY order_key (shop_key,order_ref),KEY booking_id (booking_id)) $c;");
 foreach(['completed_at'=>'datetime NULL','completion_estimated'=>'tinyint NOT NULL DEFAULT 0'] as $column=>$definition){if(!$wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$t` LIKE %s",$column)))Dennis_WMS_Audit::query("ALTER TABLE `$t` ADD COLUMN $column $definition");}
 if(!$wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$t` LIKE %s",'completed_at'))||!$wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$t` LIKE %s",'completion_estimated')))return;
 Dennis_WMS_Audit::query("UPDATE `$t` SET completed_at=updated_at,completion_estimated=1 WHERE completed_at IS NULL AND ((method='ship' AND status='dispatched') OR (method='pickup' AND status='picked_up') OR (method='internal' AND status='internal_done'))");
 update_option('dennis_wms_delivery_schema',self::SCHEMA);}
 static function upgrade(){if(current_user_can('manage_options')&&get_option('dennis_wms_delivery_schema')!==self::SCHEMA)self::install();}
 static function settings(){return wp_parse_args((array)get_option('dennis_wms_delivery_settings',[]),['enabled'=>1,'wc_complete'=>0,'carrier_mode'=>'test','auto_tracking'=>1,'tracking_interval'=>1,'attention_hours'=>48,'dhl_enabled'=>0,'dsv_enabled'=>0,'dhl_key'=>'','dsv_tracking_key'=>'','dsv_tracking_secondary_key'=>'','dsv_connect_access_key'=>'']);}
 static function remove_booking_settings(){
  if(!current_user_can('manage_options'))return;$settings=(array)get_option('dennis_wms_delivery_settings',[]);$changed=false;
  foreach(['dsv_key','dsv_secondary_key','dsv_token_key','dsv_booking_key','dsv_label_key','dsv_secret','dsv_username','dsv_mdm','dsv_pkg_full','dsv_pkg_half','dsv_pkg_parcel','dhl_secret'] as $key){if(array_key_exists($key,$settings)){unset($settings[$key]);$changed=true;}}
  if($changed)update_option('dennis_wms_delivery_settings',$settings,false);
 }

 static function docs_table(){global $wpdb;return $wpdb->prefix.'dennis_wms_freight_docs';}
 static function product_shipping_fields(){
  echo '<div class="options_group"><p style="padding:0 12px"><strong>Dennis WMS – automatisk fraktberäkning</strong><br><small>Ange hur många av artikeln som ryms per emballage. WMS använder helpall först, sedan halvpall och sist kolli.</small></p>';
  woocommerce_wp_text_input(['id'=>'_dennis_wms_full_pallet_qty','label'=>'Antal / helpall','type'=>'number','custom_attributes'=>['min'=>'0','step'=>'1'],'desc_tip'=>true,'description'=>'0 = använd inte helpall för artikeln.']);
  woocommerce_wp_text_input(['id'=>'_dennis_wms_half_pallet_qty','label'=>'Antal / halvpall','type'=>'number','custom_attributes'=>['min'=>'0','step'=>'1'],'desc_tip'=>true,'description'=>'0 = använd inte halvpall för artikeln.']);
  woocommerce_wp_text_input(['id'=>'_dennis_wms_parcel_qty','label'=>'Antal / kolli','type'=>'number','custom_attributes'=>['min'=>'1','step'=>'1'],'desc_tip'=>true,'description'=>'Resterande antal delas upp i kolli.']);
  echo '</div>';
 }
 static function save_product_shipping_fields($product_id){if(!current_user_can('edit_post',$product_id))return;foreach(['_dennis_wms_full_pallet_qty','_dennis_wms_half_pallet_qty','_dennis_wms_parcel_qty'] as $k){if(isset($_POST[$k]))update_post_meta($product_id,$k,max(0,absint(wp_unslash($_POST[$k]))));}}
 static function packaging_for_order($order){
  if(is_numeric($order))$order=wc_get_order($order);if(!$order)return [];
  $out=['full'=>0,'half'=>0,'parcel'=>0,'unconfigured'=>[],'weight'=>0.0,'volume'=>0.0];
  foreach($order->get_items('line_item') as $item){$pr=$item->get_product();if(!$pr)continue;$pid=$pr->is_type('variation')&&$pr->get_parent_id()?$pr->get_parent_id():$pr->get_id();$q=max(0,(int)$item->get_quantity());$full=max(0,(int)get_post_meta($pid,'_dennis_wms_full_pallet_qty',true));$half=max(0,(int)get_post_meta($pid,'_dennis_wms_half_pallet_qty',true));$parcel=max(0,(int)get_post_meta($pid,'_dennis_wms_parcel_qty',true));
   if($parcel<1){$out['unconfigured'][]=$pr->get_sku()?:$pr->get_name();$parcel=max(1,$q);}
   if($full>0){$n=intdiv($q,$full);$out['full']+=$n;$q-=$n*$full;}
   if($half>0){$n=intdiv($q,$half);$out['half']+=$n;$q-=$n*$half;}
   if($q>0)$out['parcel']+=(int)ceil($q/$parcel);
   $w=(float)$pr->get_weight();if($w>0)$out['weight']+=$w*(float)$item->get_quantity();
   $l=(float)$pr->get_length();$wi=(float)$pr->get_width();$h=(float)$pr->get_height();if($l>0&&$wi>0&&$h>0)$out['volume']+=(($l*$wi*$h)/1000000)*(float)$item->get_quantity();
  }
  return $out;
 }
 static function packaging_summary($pack){$x=[];if(!empty($pack['full']))$x[]=$pack['full'].' helpall';if(!empty($pack['half']))$x[]=$pack['half'].' halvpall';if(!empty($pack['parcel']))$x[]=$pack['parcel'].' kolli';return $x?implode(' + ',$x):'Ingen fraktenhet beräknad';}

 static function freight_docs($shop='local',$order_ref=0,$booking_id=''){global $wpdb;$t=self::docs_table();if($order_ref)return $wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE shop_key=%s AND order_ref=%d ORDER BY id DESC",$shop,$order_ref));if($booking_id!=='')return $wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE booking_id=%s ORDER BY id DESC",$booking_id));return [];}
 static function save_freight_pdf($pdf,$filename,$type='label',$shop='local',$order_ref=0,$booking_id=''){
  if(strlen((string)$pdf)>10*1024*1024||substr((string)$pdf,0,5)!=='%PDF-')return new WP_Error('dw_doc','Välj en giltig PDF på högst 10 MB.');$path=Dennis_WMS_Security::write_private($pdf);if(is_wp_error($path))return $path;
  global $wpdb;$ok=Dennis_WMS_Audit::insert(self::docs_table(),['shop_key'=>$shop,'order_ref'=>absint($order_ref),'booking_id'=>sanitize_text_field($booking_id),'doc_type'=>sanitize_key($type),'filename'=>sanitize_file_name($filename),'path'=>$path,'created_at'=>current_time('mysql'),'created_by'=>get_current_user_id()]);if(!$ok){@unlink($path);return new WP_Error('dw_doc','Dokumentet kunde inte registreras.');}return (int)$wpdb->insert_id;
 }
 static function serve_freight_doc(){if(!current_user_can('pb_wms_view'))wp_die('Åtkomst nekad.',403);$id=absint($_GET['doc_id']??0);check_admin_referer('dennis_wms_freight_doc_'.$id);global $wpdb;$r=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::docs_table()." WHERE id=%d",$id));if(!$r)wp_die('Dokumentet saknas.',404);$sealed=Dennis_WMS_Security::seal($r->path);if(is_wp_error($sealed))wp_die('Dokumentet kunde inte skyddas.',503);$pdf=Dennis_WMS_Security::read_private($r->path);if(is_wp_error($pdf)||substr($pdf,0,5)!=='%PDF-')wp_die('Dokumentet kunde inte läsas.',404);nocache_headers();header('Cache-Control: private, no-store, max-age=0');header('X-Content-Type-Options: nosniff');header('Content-Security-Policy: sandbox');header('Referrer-Policy: no-referrer');header('Content-Type: application/pdf');header('Content-Disposition: inline; filename="'.sanitize_file_name($r->filename).'"');header('Content-Length: '.strlen($pdf));echo $pdf;exit;}
 static function upload_freight_doc(){if(!current_user_can(self::CAP))wp_die('Åtkomst nekad.',403);$shop=sanitize_text_field(wp_unslash($_POST['shop_key']??'local'));$ref=absint($_POST['order_ref']??0);check_admin_referer('dennis_wms_freight_doc_upload_'.$shop.'_'.$ref);if($shop!=='local'||!$ref||!self::local_order_exists($ref))wp_die('Ordern finns inte.',404);if(empty($_FILES['freight_doc']['tmp_name'])||!is_uploaded_file($_FILES['freight_doc']['tmp_name']))wp_die('Välj en PDF.',400);if(($_FILES['freight_doc']['size']??0)>10*1024*1024)wp_die('PDF-filen får vara högst 10 MB.',400);$pdf=file_get_contents($_FILES['freight_doc']['tmp_name']);$name=sanitize_file_name($_FILES['freight_doc']['name']??'fraktdokument.pdf');$res=self::save_freight_pdf($pdf,$name,'manual',$shop,$ref,'');if(is_wp_error($res))wp_die(esc_html($res->get_error_message()),500);wp_safe_redirect(admin_url('admin.php?page=dennis-wms-orders&order_id='.$ref.'&dw_doc_saved=1'));exit;}
 static function senders(){return array_values((array)get_option('dennis_wms_senders',[]));}
 static function default_sender_id(){return sanitize_key((string)get_option('dennis_wms_default_sender',''));}
 static function sender_by_id($id){$id=sanitize_key((string)$id);foreach(self::senders() as $r)if(sanitize_key((string)($r['id']??''))===$id)return $r;return null;}
 static function record($shop_key,$order_ref){global $wpdb;return $wpdb->get_row($wpdb->prepare('SELECT * FROM '.self::table().' WHERE shop_key=%s AND order_ref=%d',$shop_key,absint($order_ref)));}
 static function label_method($m){return ['ship'=>'Skickas','pickup'=>'Hämtas av kund','internal'=>'Intern order'][$m]??'Ej vald';}
 static function label_status($s){return ['waiting'=>'Väntar','ready'=>'Klar','booked'=>'Transport klar','dispatched'=>'Skickad','pickup_ready'=>'Klar för hämtning','picked_up'=>'Hämtad','internal_ready'=>'Klar internt','internal_done'=>'Utlämnad internt'][$s]??($s?:'Ej vald');}
 static function tracking_labels(){return ['registered'=>'Sändning registrerad','picked_up'=>'Hämtad av transportör','in_transit'=>'Under transport','terminal'=>'På terminal','out_for_delivery'=>'På väg för leverans','delivered'=>'Levererad','exception'=>'Avvikelse'];}
 static function tracking_label($s){$m=self::tracking_labels();return $m[$s]??($s?:'Ingen trackingstatus');}
 static function tracking_history($r){$h=$r&&isset($r->tracking_history)?json_decode((string)$r->tracking_history,true):[];return is_array($h)?$h:[];}
 static function append_tracking_event($history,$status,$note=''){array_unshift($history,['status'=>$status,'label'=>self::tracking_label($status),'time'=>current_time('mysql'),'note'=>$note,'user'=>get_current_user_id()]);return array_slice($history,0,100);}
 static function final_status($method){return $method==='ship'?'dispatched':($method==='pickup'?'picked_up':($method==='internal'?'internal_done':''));}
 static function allowed_statuses($method){if($method==='ship')return ['waiting'=>'Väntar på frakt','ready'=>'Klar för frakt','booked'=>'Transport klar','dispatched'=>'Skickad'];if($method==='pickup')return ['waiting'=>'Väntar','pickup_ready'=>'Klar för hämtning','picked_up'=>'Hämtad'];if($method==='internal')return ['waiting'=>'Väntar','internal_ready'=>'Klar internt','internal_done'=>'Utlämnad internt'];return ['waiting'=>'Väntar'];}
 static function method_for_order($shop_key,$order_ref){$r=self::record($shop_key,$order_ref);return $r&&$r->method?(string)$r->method:'';}
 static function workflow_status($shop_key,$order_ref,$order=null){
  $r=self::record($shop_key,$order_ref);
  // Lokala order följer först plock/pack. Efter packning tar valt leveransflöde över WMS-statusen.
  if($shop_key==='local'&&$order&&class_exists('Dennis_WMS_Orders')){
   if(class_exists('Dennis_WMS_Depot')&&Dennis_WMS_Depot::state($order)==='waiting')return ['label'=>'I depån','kind'=>'pink'];
   $pick=Dennis_WMS_Orders::phase_status($order,'pick');$pack=Dennis_WMS_Orders::phase_status($order,'pack');
   if($pick!=='done')return ['label'=>$pick==='active'?'Plockas':($pick==='paused'?'Plock pausad':'Väntar på plock'),'kind'=>$pick==='paused'?'pink':'blue'];
   if($pack!=='done')return ['label'=>$pack==='active'?'Packas':($pack==='paused'?'Packning pausad':'Väntar på packning'),'kind'=>$pack==='paused'?'pink':'blue'];
  }
  if(!$r||!$r->method)return ['label'=>($shop_key==='local'?'Packad – välj leveranssätt':'Leveranssätt ej valt'),'kind'=>'blue'];
  $map=[
   'ship'=>['waiting'=>'Väntar på frakt','ready'=>'Klar för frakt','booked'=>'Transport klar','dispatched'=>'Skickad'],
   'pickup'=>['waiting'=>'Väntar på kundhämtning','pickup_ready'=>'Klar för hämtning','picked_up'=>'Hämtad'],
   'internal'=>['waiting'=>'Väntar på intern utlämning','internal_ready'=>'Klar internt','internal_done'=>'Utlämnad internt']
  ];
  $label=$map[$r->method][$r->status]??self::label_status($r->status);$final=$r->status===self::final_status($r->method);
  return ['label'=>$label,'kind'=>$final?'green':($r->method==='pickup'?'pink':'blue')];
 }
 static function workflow_label($shop_key,$order_ref,$order=null){$w=self::workflow_status($shop_key,$order_ref,$order);return $w['label'];}
 static function crypt($v,$decrypt=false){$v=(string)$v;if($v==='')return '';return $decrypt?Dennis_WMS_Multi_Shop::decrypt($v):Dennis_WMS_Multi_Shop::encrypt($v);}
 static function save_order(){
  if(!current_user_can(self::CAP)||!current_user_can('edit_shop_orders'))wp_die('Åtkomst nekad.',403);check_admin_referer('dennis_wms_delivery_save');self::install();global $wpdb;
  $shop=sanitize_text_field(wp_unslash($_POST['shop_key']??'local'));if($shop!=='local'&&!preg_match('/^remote:\d+$/',$shop))wp_die('Ogiltig shop.',400);$ref=absint($_POST['order_ref']??0);if(!$ref)wp_die('Order saknas.',400);if($shop==='local'&&!self::local_order_exists($ref))wp_die('Ordern finns inte.',404);if($shop!=='local'){$remote=Dennis_WMS_Multi_Shop::get_cached_order($ref);if(!$remote||'remote:'.(int)$remote->shop_id!==$shop)wp_die('Ordern tillhör inte den valda shoppen.',404);}
  $method=sanitize_key(wp_unslash($_POST['method']??''));if(!in_array($method,['','ship','pickup','internal'],true))wp_die('Ogiltigt leveranssätt.',400);$status=sanitize_key(wp_unslash($_POST['status']??'waiting'));$allowed=self::allowed_statuses($method);if(!isset($allowed[$status]))$status='waiting';
  $carrier=$method==='ship'?sanitize_key(wp_unslash($_POST['carrier']??'')):'';if(!in_array($carrier,['','dhl','dsv'],true))$carrier='';$posted_sender=$method==='ship'?sanitize_key(wp_unslash($_POST['sender_id']??'')):'';$sender_row=$method==='ship'?self::sender_by_id($posted_sender):null;if($method==='ship'&&($posted_sender===''||!$sender_row))wp_die('Välj en giltig avsändare. Lägg först till en avsändaradress under Dennis WMS → Leverans & transport.',400);
  // Fraktuppgifter sparas endast för order som faktiskt ska skickas. På kundhämtning/intern order nollställs de.
  $is_ship=$method==='ship';$is_internal=$method==='internal';
  $existing=self::record($shop,$ref);$new_tracking=$is_ship?sanitize_text_field(wp_unslash($_POST['tracking']??'')):'';$old_tracking=$existing?(string)$existing->tracking:'';$tracking_status=$is_ship&&$existing?(string)($existing->tracking_status??''):'';$tracking_updated=$is_ship&&$existing?($existing->tracking_updated_at??null):null;$history=$is_ship?self::tracking_history($existing):[];if($is_ship&&$new_tracking!==''&&($new_tracking!==$old_tracking||$tracking_status==='')){$tracking_status='registered';$tracking_updated=current_time('mysql');$history=self::append_tracking_event($history,'registered',$new_tracking!==$old_tracking&&$old_tracking!==''?'Nytt trackingnummer registrerat.':'Trackingnummer registrerat.');}
  $data=['shop_key'=>$shop,'order_ref'=>$ref,'method'=>$method,'status'=>$status,'carrier'=>$carrier,
   'sender_id'=>$is_ship?$posted_sender:'',
   'packages'=>$is_ship?max(1,absint($_POST['packages']??1)):1,
   'weight'=>$is_ship?($existing->weight??null):null,
   'length'=>$is_ship?($existing->length??null):null,
   'width'=>$is_ship?($existing->width??null):null,
   'height'=>$is_ship?($existing->height??null):null,
   'tracking'=>$new_tracking,'tracking_status'=>$is_ship?$tracking_status:'','tracking_updated_at'=>$is_ship?$tracking_updated:null,'tracking_history'=>$is_ship?wp_json_encode($history,JSON_UNESCAPED_UNICODE):'',
   'project'=>$is_internal?sanitize_text_field(wp_unslash($_POST['project']??'')):'',
   'note'=>sanitize_textarea_field(wp_unslash($_POST['note']??'')),'updated_at'=>current_time('mysql'),'updated_by'=>get_current_user_id()];
  $data=array_merge($data,self::completion_fields($existing,$method,$status));
  $saved=$existing?Dennis_WMS_Audit::update(self::table(),$data,['id'=>$existing->id]):Dennis_WMS_Audit::insert(self::table(),$data);
  if($saved===false)wp_die('Leveransstatus kunde inte sparas. Försök igen eller kontrollera databasen.',500);
  if(class_exists('Dennis_WMS_Deadline'))Dennis_WMS_Deadline::capture_dispatch($shop,$ref,$status);
  // Optional and OFF by default: only local orders may be completed automatically when their WMS delivery flow is final.
  $set=self::settings();if($shop==='local'&&!empty($set['wc_complete'])&&$method!==''&&$status===self::final_status($method)&&function_exists('wc_get_order')){$o=wc_get_order($ref);if($o&&$o->get_status()!=='completed'){$o->update_status('completed','Dennis WMS: leveransflödet slutfört.');}}
  $back=sanitize_text_field(wp_unslash($_POST['return_to']??''));if($back==='remote')$url=admin_url('admin.php?page=dennis-wms-shops&view=order&remote_order_id='.$ref);else$url=admin_url('admin.php?page=dennis-wms-orders&order_id='.$ref);wp_safe_redirect(add_query_arg('dw_delivery_saved','1',$url));exit;
 }
 static function tracking_test(){
  if(!current_user_can(self::CAP)||!current_user_can('edit_shop_orders'))wp_die('Åtkomst nekad.',403);$set=self::settings();if(($set['carrier_mode']??'test')!=='test')wp_die('Simulering är endast tillgänglig i testläge.',400);$shop=sanitize_text_field(wp_unslash($_REQUEST['shop_key']??'local'));$ref=absint($_REQUEST['order_ref']??0);check_admin_referer('dennis_wms_tracking_test_'.$shop.'_'.$ref);$r=self::record($shop,$ref);if(!$r||$r->method!=='ship'||$r->tracking==='')wp_die('Ordern saknar en aktiv skickad leverans med trackingnummer.',400);$sequence=['registered','picked_up','in_transit','terminal','out_for_delivery','delivered'];$cur=(string)($r->tracking_status??'registered');$i=array_search($cur,$sequence,true);$next=$i===false?'registered':($sequence[min($i+1,count($sequence)-1)]);$h=self::append_tracking_event(self::tracking_history($r),$next,'Simulerad DHL/DSV-händelse i Dennis WMS testläge.');global $wpdb;Dennis_WMS_Audit::update(self::table(),['tracking_status'=>$next,'tracking_updated_at'=>current_time('mysql'),'tracking_history'=>wp_json_encode($h,JSON_UNESCAPED_UNICODE),'updated_at'=>current_time('mysql'),'updated_by'=>get_current_user_id()],['id'=>$r->id]);$back=sanitize_text_field(wp_unslash($_REQUEST['return_to']??''));$url=$back==='remote'?admin_url('admin.php?page=dennis-wms-shops&view=order&remote_order_id='.$ref):admin_url('admin.php?page=dennis-wms-orders&order_id='.$ref);wp_safe_redirect(add_query_arg('dw_tracking_test','1',$url));exit;
 }
 static function ensure_tracking_cron(){
  $s=self::settings();$next=wp_next_scheduled('dennis_wms_tracking_cron');
  if(!empty($s['enabled'])&&!empty($s['auto_tracking'])){if(!$next)wp_schedule_event(time()+300,'hourly','dennis_wms_tracking_cron');}
  elseif($next){wp_unschedule_event($next,'dennis_wms_tracking_cron');}
 }
 static function tracking_cron(){self::purge_missing_local_records();
  $s=self::settings();if(empty($s['enabled'])||empty($s['auto_tracking']))return;$interval=max(1,absint($s['tracking_interval']??1));$lr=(array)get_option('dennis_wms_tracking_last_run',[]);if(!empty($lr['time'])){$last=strtotime((string)$lr['time']);if($last&&$last>current_time('timestamp')-($interval*HOUR_IN_SECONDS)+300)return;}global $wpdb;
  $rows=$wpdb->get_results("SELECT * FROM ".self::table()." WHERE method='ship' AND tracking<>'' AND carrier IN ('dhl','dsv') AND (tracking_status='' OR tracking_status<>'delivered') ORDER BY COALESCE(tracking_updated_at,'1970-01-01') ASC LIMIT 50");
  $ok=0;$fail=0;foreach($rows as $r){$res=self::refresh_tracking_record($r,false);is_wp_error($res)?$fail++:$ok++;}
  update_option('dennis_wms_tracking_last_run',['time'=>current_time('mysql'),'ok'=>$ok,'fail'=>$fail],false);
 }
 static function tracking_refresh(){
  if(!current_user_can('pb_wms_view'))wp_die('Åtkomst nekad.',403);$shop=sanitize_text_field(wp_unslash($_REQUEST['shop_key']??'local'));$ref=absint($_REQUEST['order_ref']??0);check_admin_referer('dennis_wms_tracking_refresh_'.$shop.'_'.$ref);$r=self::record($shop,$ref);if(!$r||$r->method!=='ship'||$r->tracking==='')wp_die('Ordern saknar trackingnummer.',400);
  $res=self::refresh_tracking_record($r,true);$back=sanitize_text_field(wp_unslash($_REQUEST['return_to']??''));
  if($back==='center')$url=admin_url('admin.php?page=dennis-wms-tracking');elseif($back==='remote')$url=admin_url('admin.php?page=dennis-wms-shops&view=order&remote_order_id='.$ref);else$url=admin_url('admin.php?page=dennis-wms-orders&order_id='.$ref);
  $args=is_wp_error($res)?['dw_tracking_error'=>rawurlencode($res->get_error_message())]:['dw_tracking_refreshed'=>'1'];wp_safe_redirect(add_query_arg($args,$url));exit;
 }
 static function tracking_refresh_all(){
  if(!current_user_can('pb_wms_view'))wp_die('Åtkomst nekad.',403);check_admin_referer('dennis_wms_tracking_refresh_all');self::purge_missing_local_records();global $wpdb;
  $rows=$wpdb->get_results("SELECT * FROM ".self::table()." WHERE method='ship' AND tracking<>'' AND carrier IN ('dhl','dsv') AND (tracking_status='' OR tracking_status<>'delivered') ORDER BY COALESCE(tracking_updated_at,'1970-01-01') ASC LIMIT 50");
  $ok=0;$fail=0;foreach($rows as $r){$res=self::refresh_tracking_record($r,true);is_wp_error($res)?$fail++:$ok++;}
  update_option('dennis_wms_tracking_last_run',['time'=>current_time('mysql'),'ok'=>$ok,'fail'=>$fail],false);
  wp_safe_redirect(add_query_arg(['dw_tracking_all'=>'1','ok'=>$ok,'fail'=>$fail],admin_url('admin.php?page=dennis-wms-tracking')));exit;
 }
 static function refresh_tracking_record($r,$manual=false){
  if(!$r||$r->method!=='ship'||$r->tracking==='')return new WP_Error('dw_tracking','Trackingnummer saknas.');$carrier=(string)$r->carrier;$s=self::settings();
  if($carrier==='dhl')$data=self::fetch_dhl_tracking((string)$r->tracking,$s);elseif($carrier==='dsv')$data=self::fetch_dsv_tracking((string)$r->tracking,$s);else return new WP_Error('dw_tracking','Välj DHL eller DSV på ordern.');
  if(is_wp_error($data))return $data;$new=(string)($data['status']??'');if($new==='')return new WP_Error('dw_tracking','Transportören svarade men ingen trackingstatus kunde tolkas.');
  $old=(string)($r->tracking_status??'');$history=self::tracking_history($r);if($new!==$old){$note=trim((string)($data['note']??''));$history=self::append_tracking_event($history,$new,$note!==''?$note:'Automatiskt hämtad från '.strtoupper($carrier).'.');}
  $update=['tracking_status'=>$new,'tracking_updated_at'=>current_time('mysql'),'tracking_history'=>wp_json_encode($history,JSON_UNESCAPED_UNICODE),'updated_at'=>current_time('mysql')];
  if(in_array($new,['picked_up','in_transit','terminal','out_for_delivery','delivered'],true)&&$r->status!=='dispatched')$update=array_merge($update,['status'=>'dispatched'],self::completion_fields($r,'ship','dispatched'));
  global $wpdb;Dennis_WMS_Audit::update(self::table(),$update,['id'=>$r->id]);
  if(($update['status']??'')==='dispatched'&&$r->shop_key==='local'&&!empty($s['wc_complete'])&&function_exists('wc_get_order')){$o=wc_get_order((int)$r->order_ref);if($o&&$o->get_status()!=='completed')$o->update_status('completed','Dennis WMS: transportören har registrerat försändelsen som skickad.');}
  return $data;
 }
 static function fetch_dhl_tracking($tracking,$s){
  if(empty($s['dhl_enabled']))return new WP_Error('dw_dhl','DHL är inte aktiverat under System → Leverans & transport.');$key=self::crypt($s['dhl_key']??'',true);if($key==='')return new WP_Error('dw_dhl','DHL API-nyckel saknas.');
  $url=add_query_arg(['trackingNumber'=>$tracking,'service'=>'freight'],'https://api-eu.dhl.com/track/shipments');$res=wp_safe_remote_get($url,['redirection'=>0,'timeout'=>20,'headers'=>['DHL-API-Key'=>$key,'Accept'=>'application/json']]);if(is_wp_error($res))return $res;$code=wp_remote_retrieve_response_code($res);$body=json_decode(wp_remote_retrieve_body($res),true);if($code<200||$code>=300)return new WP_Error('dw_dhl','DHL svarade HTTP '.$code.self::api_error_suffix($body));
  $shipment=is_array($body)&&!empty($body['shipments'][0])?$body['shipments'][0]:$body;$status=self::map_provider_status($shipment);$note=self::provider_note($shipment);return ['status'=>$status,'note'=>$note,'provider'=>'DHL'];
 }

 static function dsv_api_test(){
  if(!current_user_can(self::CAP)||!current_user_can('manage_options'))wp_die('Åtkomst nekad.',403);check_admin_referer('dennis_wms_dsv_api_test');
  $reference=sanitize_text_field(wp_unslash($_POST['tracking_reference']??''));if($reference==='')wp_die('Ange ett befintligt tracking-/sändningsnummer.',400);
  $result=self::fetch_dsv_tracking($reference,self::settings());$ok=!is_wp_error($result);
  $message=$ok?'DSV Tracking svarade: '.self::tracking_label($result['status']).'.':$result->get_error_message();
  wp_safe_redirect(add_query_arg(['page'=>'dennis-wms-delivery','dsv_test'=>$ok?'ok':'fail','dsv_msg'=>$message],admin_url('admin.php')));exit;
 }
 static function xmlv($v){return htmlspecialchars((string)$v,ENT_QUOTES|ENT_XML1,'UTF-8');}



 static function fetch_dsv_tracking($tracking,$s){
  if(empty($s['dsv_enabled']))return new WP_Error('dw_dsv','DSV är inte aktiverat under System → Leverans & transport.');
  $subscription=self::crypt($s['dsv_tracking_key']??'',true);if($subscription==='')return new WP_Error('dw_dsv','DSV Tracking Primary Key saknas.');
  
  $url=($s['carrier_mode']??'test')==='production'?'https://api.dsv.com/connect/tracking/v1/TrackingWebService':'https://api.dsv.com/connect-demo/tracking/v1/TrackingWebService';
  $access=self::crypt($s['dsv_connect_access_key']??'',true);
  $rid='DWMS-'.gmdate('YmdHis').'-'.wp_rand(1000,9999);$from=gmdate('Y-m-d',strtotime('-90 days'));$to=gmdate('Y-m-d',strtotime('+1 day'));
  $xml='<?xml version="1.0" encoding="UTF-8"?><soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"><soapenv:Header/><soapenv:Body><getPublicServiceShipmentDetails><AccessKey>'.esc_html($access).'</AccessKey><in><ApplicationArea><requestId>'.esc_html($rid).'</requestId><CreationDateTime>'.esc_html(gmdate('c')).'</CreationDateTime></ApplicationArea><referenceType>ff</referenceType><referenceNumber>'.esc_html($tracking).'</referenceNumber><transportNature>exp</transportNature><shipmentDateFrom>'.$from.'</shipmentDateFrom><shipmentDateTo>'.$to.'</shipmentDateTo></in></getPublicServiceShipmentDetails></soapenv:Body></soapenv:Envelope>';
  $res=wp_safe_remote_post($url,['redirection'=>0,'timeout'=>25,'headers'=>['DSV-Subscription-Key'=>$subscription,'Content-Type'=>'text/xml; charset=utf-8','Accept'=>'text/xml, application/xml'],'body'=>$xml]);if(is_wp_error($res))return $res;$code=(int)wp_remote_retrieve_response_code($res);$raw=(string)wp_remote_retrieve_body($res);
  if($code<200||$code>=300)return new WP_Error('dw_dsv','DSV Connect Tracking svarade HTTP '.$code.self::xml_error_suffix($raw));
  $status=self::map_provider_text($raw);$note=self::xml_tracking_note($raw);return ['status'=>$status,'note'=>$note,'provider'=>'DSV'];
 }
 static function map_provider_text($raw){$t=strtolower(wp_strip_all_tags(str_replace(['<','>'],[' <','> '],(string)$raw)));
  if(preg_match('/delivered|delivery completed|proof of delivery|levererad|pod\b/',$t))return 'delivered';
  if(preg_match('/out for delivery|delivery vehicle|på väg för leverans/',$t))return 'out_for_delivery';
  if(preg_match('/exception|failed|failure|delay|delayed|held|avvikelse/',$t))return 'exception';
  if(preg_match('/terminal|hub|sorting|distribution center/',$t))return 'terminal';
  if(preg_match('/in transit|departed|transporting|linehaul|transit/',$t))return 'in_transit';
  if(preg_match('/picked up|collected|pickup completed|received by carrier|accepted/',$t))return 'picked_up';return 'registered';}
 static function xml_tracking_note($raw){$vals=[];foreach(['StatusInfo','Status'] as $tag){if(preg_match_all('~<(?:(?:\\w+):)?'.$tag.'[^>]*>(.*?)</(?:(?:\\w+):)?'.$tag.'>~is',(string)$raw,$m)){foreach($m[1] as $v){$v=trim(wp_strip_all_tags(html_entity_decode($v,ENT_QUOTES|ENT_XML1,'UTF-8')));if($v!==''&&!in_array($v,$vals,true))$vals[]=$v;}}}return implode(' · ',array_slice($vals,-3));}
 static function xml_error_suffix($raw){$raw=(string)$raw;foreach(['faultstring','FaultString','message','Message'] as $tag){if(preg_match('~<(?:(?:\\w+):)?'.$tag.'[^>]*>(.*?)</(?:(?:\\w+):)?'.$tag.'>~is',$raw,$m)){return ' – '.sanitize_text_field(wp_strip_all_tags(html_entity_decode($m[1],ENT_QUOTES|ENT_XML1,'UTF-8')));}}return '';}
 static function flatten_strings($v,&$out,$depth=0){if($depth>8)return;if(is_array($v)){foreach($v as $k=>$x){if(is_scalar($x)&&$x!=='')$out[]=strtolower((string)$k).': '.(string)$x;elseif(is_array($x))self::flatten_strings($x,$out,$depth+1);}}}
 static function map_provider_status($data){$parts=[];self::flatten_strings($data,$parts);$t=strtolower(implode(' | ',$parts));
  if(preg_match('/delivered|delivery completed|proof of delivery|levererad|pod\b/',$t))return 'delivered';
  if(preg_match('/out for delivery|with delivery courier|delivery vehicle|ute för leverans|på väg för leverans/',$t))return 'out_for_delivery';
  if(preg_match('/exception|failed|failure|delay|delayed|held|customs issue|avvikelse/',$t))return 'exception';
  if(preg_match('/terminal|hub|sorting|distribution center|warehouse arrival/',$t))return 'terminal';
  if(preg_match('/in transit|departed|transporting|linehaul|on the way|transit/',$t))return 'in_transit';
  if(preg_match('/picked up|collected|pickup completed|received by carrier|accepted/',$t))return 'picked_up';
  return 'registered';
 }
 static function provider_note($data){$keys=['description','remark','eventDescription','statusDescription','event','shipmentStatus','status'];$found=[];$walk=function($v)use(&$walk,&$found,$keys){if(!is_array($v)||count($found)>8)return;foreach($v as $k=>$x){if(in_array((string)$k,$keys,true)&&is_scalar($x)&&trim((string)$x)!=='')$found[]=trim((string)$x);elseif(is_array($x))$walk($x);}};$walk($data);return implode(' · ',array_slice(array_values(array_unique($found)),0,3));}
 static function api_error_suffix($body){if(!is_array($body))return '';$msg=$body['message']??$body['detail']??$body['error_description']??$body['error']??'';return $msg!==''?' – '.sanitize_text_field(is_scalar($msg)?(string)$msg:wp_json_encode($msg)):'';}
 static function num($v){$v=str_replace(',','.',sanitize_text_field(wp_unslash((string)$v)));return $v===''?null:max(0,(float)$v);}
 static function save_settings(){
  if(!current_user_can(self::CAP)||!current_user_can('manage_options'))wp_die('Åtkomst nekad.',403);check_admin_referer('dennis_wms_delivery_settings');self::remove_booking_settings();$s=self::settings();
  foreach(['enabled','wc_complete','auto_tracking','dhl_enabled','dsv_enabled'] as $field)$s[$field]=!empty($_POST[$field])?1:0;
  $interval=absint($_POST['tracking_interval']??1);$s['tracking_interval']=in_array($interval,[1,2,3,6,12,24],true)?$interval:1;
  $attention=absint($_POST['attention_hours']??48);$s['attention_hours']=in_array($attention,[12,24,48,72,96],true)?$attention:48;
  $s['carrier_mode']=sanitize_key(wp_unslash($_POST['carrier_mode']??'test'))==='production'?'production':'test';
  foreach(['dhl_key','dsv_tracking_key','dsv_tracking_secondary_key','dsv_connect_access_key'] as $field){$value=sanitize_text_field(wp_unslash($_POST[$field]??''));if($value!=='')$s[$field]=self::crypt($value);}
  update_option('dennis_wms_delivery_settings',$s,false);self::ensure_tracking_cron();wp_safe_redirect(admin_url('admin.php?page=dennis-wms-delivery&saved=1'));exit;
 }

 static function save_sender(){if(!current_user_can(self::CAP)||!current_user_can('manage_options'))wp_die('Åtkomst nekad.',403);check_admin_referer('dennis_wms_sender_save');$rows=self::senders();$id=sanitize_key(wp_unslash($_POST['sender_id']??''));if($id==='')$id='sender_'.strtolower(wp_generate_password(8,false,false));$row=['id'=>$id,'name'=>sanitize_text_field(wp_unslash($_POST['name']??'')),'company'=>sanitize_text_field(wp_unslash($_POST['company']??'')),'address'=>sanitize_text_field(wp_unslash($_POST['address']??'')),'postcode'=>sanitize_text_field(wp_unslash($_POST['postcode']??'')),'city'=>sanitize_text_field(wp_unslash($_POST['city']??'')),'country'=>strtoupper(substr(sanitize_text_field(wp_unslash($_POST['country']??'SE')),0,2)),'contact'=>sanitize_text_field(wp_unslash($_POST['contact']??'')),'phone'=>sanitize_text_field(wp_unslash($_POST['phone']??'')),'email'=>sanitize_email(wp_unslash($_POST['email']??''))];if($row['name']===''||$row['address']===''||$row['city']==='')wp_die('Namn, adress och ort krävs.',400);$found=false;foreach($rows as $i=>$r)if(($r['id']??'')===$id){$rows[$i]=$row;$found=true;}if(!$found)$rows[]=$row;update_option('dennis_wms_senders',$rows,false);if(!empty($_POST['make_default'])||self::default_sender_id()==='')update_option('dennis_wms_default_sender',$id,false);wp_safe_redirect(admin_url('admin.php?page=dennis-wms-delivery&sender_saved=1'));exit;}
 static function delete_sender(){if(!current_user_can(self::CAP)||!current_user_can('manage_options'))wp_die('Åtkomst nekad.',403);$id=sanitize_key(wp_unslash($_POST['sender_id']??''));check_admin_referer('dennis_wms_sender_delete_'.$id);$rows=array_values(array_filter(self::senders(),fn($r)=>sanitize_key((string)($r['id']??''))!==$id));update_option('dennis_wms_senders',$rows,false);wp_safe_redirect(admin_url('admin.php?page=dennis-wms-delivery'));exit;}
 static function render_order_section($shop_key,$order_ref,$return='local'){
  $set=self::settings();if(empty($set['enabled']))return;$r=self::record($shop_key,$order_ref);$method=$r->method??'';$status=$r->status??'waiting';$senders=self::senders();
  $ship_hidden=$method==='ship'?'':' hidden';$internal_hidden=$method==='internal'?'':' hidden';
  if(!empty($_GET['dw_delivery_saved']))echo '<div class="notice notice-success inline"><p><strong>✓ Leveransflödet sparat.</strong></p></div>';echo '<section id="dw-delivery" class="dw-order-section"><div class="dw-section-head"><div><span class="dashicons dashicons-location-alt"></span><div><h2>Leverans & utlämning</h2><p>Valfritt WMS-steg. Endast order som ska skickas visar fraktuppgifter.</p></div></div></div>';
  echo '<form id="dw-delivery-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_delivery_save');echo '<input type="hidden" name="action" value="dennis_wms_delivery_save"><input type="hidden" name="shop_key" value="'.esc_attr($shop_key).'"><input type="hidden" name="order_ref" value="'.esc_attr($order_ref).'"><input type="hidden" name="return_to" value="'.esc_attr($return).'">';
  echo '<div class="dw-delivery-grid"><label><strong>Leveranssätt</strong><select name="method" id="dw-delivery-method"><option value="" '.selected($method,'',false).'>Ej valt / använd inte</option><option value="ship" '.selected($method,'ship',false).'>🚚 Skickas</option><option value="pickup" '.selected($method,'pickup',false).'>🏢 Hämtas av kund</option><option value="internal" '.selected($method,'internal',false).'>📦 Intern order</option></select></label>';
  echo '<label><strong>Status</strong><select name="status" id="dw-delivery-status" data-current="'.esc_attr($status).'">';
  foreach(self::allowed_statuses($method) as $value=>$label)echo '<option value="'.esc_attr($value).'" '.selected($status,$value,false).'>'.esc_html($label).'</option>';
  echo '</select></label></div>';
  echo '<div id="dw-delivery-ship"'.$ship_hidden.'><h3 style="margin:18px 0 8px">Fraktuppgifter</h3><div class="dw-delivery-grid">';
  $selected_sender=(string)($r->sender_id??'');if($selected_sender===''&&!$r)$selected_sender=self::default_sender_id();
  echo '<label><strong>Avsändare</strong><select name="sender_id"><option value="">Ej vald</option>';foreach($senders as $sender){$sid=sanitize_key((string)($sender['id']??''));echo '<option value="'.esc_attr($sid).'" '.selected(sanitize_key($selected_sender),$sid,false).'>'.esc_html($sender['name']).($sid===self::default_sender_id()?' (standard)':'').'</option>';}echo '</select>';
  if(!$senders)echo '<small style="display:block;margin-top:6px;color:#b32d2e">Ingen avsändare finns ännu. <a href="'.esc_url(admin_url('admin.php?page=dennis-wms-delivery#dw-senders')).'">Lägg till avsändare</a>.</small>';echo '</label>';
  echo '<label><strong>Transportör</strong><select name="carrier"><option value="">Ej vald</option><option value="dhl" '.selected($r->carrier??'','dhl',false).'>DHL</option><option value="dsv" '.selected($r->carrier??'','dsv',false).'>DSV</option></select></label>';
  echo '<label><strong>Kolli</strong><input type="number" min="1" name="packages" value="'.esc_attr((string)($r->packages??1)).'"></label><label><strong>Tracking / sändningsnr</strong><input name="tracking" value="'.esc_attr((string)($r->tracking??'')).'" placeholder="Ange numret från er manuella bokning"></label></div>';
  $docs=self::freight_docs($shop_key,$order_ref);echo '<div class="dw-tracking-box" style="margin-top:14px;padding:14px;border:1px solid #dcdcde;border-radius:10px"><h3 style="margin-top:0">Fraktdokument</h3>';if($docs){echo '<ul>';foreach($docs as $d){$u=wp_nonce_url(add_query_arg(['action'=>'dennis_wms_freight_doc','doc_id'=>$d->id],admin_url('admin-post.php')),'dennis_wms_freight_doc_'.$d->id);echo '<li><a target="_blank" href="'.esc_url($u).'">📄 '.esc_html($d->filename).'</a> · '.esc_html($d->doc_type).' · '.esc_html($d->created_at).'</li>';}echo '</ul>';}else echo '<p>Inga fraktdokument sparade ännu.</p>';echo '</div>';
  if($method==='ship'&&$r&&!empty($r->tracking)){echo '<div class="dw-tracking-box" style="margin-top:14px;padding:14px;border:1px solid #dcdcde;border-radius:10px"><h3 style="margin-top:0">Tracking</h3><p><strong>'.esc_html(strtoupper($r->carrier?:'Transportör')).' · '.esc_html($r->tracking).'</strong><br>Status: <strong>'.esc_html(self::tracking_label($r->tracking_status??'')).'</strong>'.(!empty($r->tracking_updated_at)?' · '.esc_html($r->tracking_updated_at):'').'</p>';$hist=self::tracking_history($r);if($hist){echo '<details><summary>Visa trackinghistorik ('.count($hist).')</summary><ul>';foreach($hist as $e)echo '<li><strong>'.esc_html($e['label']??self::tracking_label($e['status']??'')).'</strong> · '.esc_html($e['time']??'').(!empty($e['note'])?' — '.esc_html($e['note']):'').'</li>';echo '</ul></details>';}if(($r->tracking_status??'')!=='delivered'){$refresh_url=wp_nonce_url(add_query_arg(['action'=>'dennis_wms_tracking_refresh','shop_key'=>$shop_key,'order_ref'=>$order_ref,'return_to'=>$return],admin_url('admin-post.php')),'dennis_wms_tracking_refresh_'.$shop_key.'_'.$order_ref);echo '<p style="margin-top:10px"><a class="button button-primary" href="'.esc_url($refresh_url).'">Hämta riktig trackingstatus nu</a>';if((self::settings()['carrier_mode']??'test')==='test'&&current_user_can(self::CAP)&&current_user_can('edit_shop_orders')){$test_url=wp_nonce_url(add_query_arg(['action'=>'dennis_wms_tracking_test','shop_key'=>$shop_key,'order_ref'=>$order_ref,'return_to'=>$return],admin_url('admin-post.php')),'dennis_wms_tracking_test_'.$shop_key.'_'.$order_ref);echo ' <a class="button" href="'.esc_url($test_url).'">Simulera status</a>';}echo '</p>';}echo '</div>';}
  echo '<div class="notice notice-info inline"><p><strong>Automatisk tracking:</strong> När API-uppgifterna är sparade hämtar Dennis WMS status från DHL/DSV automatiskt enligt valt kontrollintervall via WordPress Cron. Du kan även hämta status direkt med knappen ovan. Simulering finns kvar i testläge.</p></div></div>';
  echo '<div id="dw-delivery-pickup"'.($method==='pickup'?'':' hidden').'><div class="notice notice-info inline" style="margin-top:16px"><p><strong>Kundhämtning:</strong> inga fraktuppgifter, mått eller vikt behövs. Använd status för att markera Klar för hämtning och Hämtad.</p></div></div>';
  echo '<div id="dw-delivery-internal"'.$internal_hidden.'><h3 style="margin:18px 0 8px">Intern information</h3><div class="dw-delivery-grid"><label><strong>Projekt / kostnadsställe</strong><input name="project" value="'.esc_attr((string)($r->project??'')).'"></label></div></div>';
  echo '<p><label><strong>Anteckning</strong><br><textarea name="note" rows="2" style="width:100%;max-width:800px">'.esc_textarea((string)($r->note??'')).'</textarea></label></p>';if(current_user_can(self::CAP)&&current_user_can('edit_shop_orders'))echo '<p><button class="button button-primary">Spara leveransflöde</button></p>';else echo '<p class="description">Du har visningsrätt. Behörighet att hantera WMS och order krävs för att spara leveransuppgifter.</p>';
  echo '<script>(function(){var root=document.getElementById("dw-delivery-form");if(!root||root.dataset.ready)return;root.dataset.ready="1";var method=root.querySelector("#dw-delivery-method"),status=root.querySelector("#dw-delivery-status"),ship=root.querySelector("#dw-delivery-ship"),pickup=root.querySelector("#dw-delivery-pickup"),internal=root.querySelector("#dw-delivery-internal");var statuses={"":{"waiting":"Väntar"},ship:{waiting:"Väntar på frakt",ready:"Klar för frakt",booked:"Transport klar",dispatched:"Skickad"},pickup:{waiting:"Väntar",pickup_ready:"Klar för hämtning",picked_up:"Hämtad"},internal:{waiting:"Väntar",internal_ready:"Klar internt",internal_done:"Intern order klar"}};function sync(first){var m=method.value||"";ship.hidden=m!=="ship";pickup.hidden=m!=="pickup";internal.hidden=m!=="internal";var wanted=first?(status.dataset.current||"waiting"):(status.value||"waiting"),map=statuses[m]||statuses[""];status.innerHTML="";Object.keys(map).forEach(function(k){var o=document.createElement("option");o.value=k;o.textContent=map[k];status.appendChild(o);});status.value=Object.prototype.hasOwnProperty.call(map,wanted)?wanted:"waiting";}method.addEventListener("change",function(){sync(false);});sync(true);}());</script>';
  echo '</form>';
  // Keep document uploads separate: nested forms break status controls and submit ownership.
  if($shop_key==='local'&&current_user_can(self::CAP)){echo '<form method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_freight_doc_upload_'.$shop_key.'_'.$order_ref);echo '<input type="hidden" name="action" value="dennis_wms_freight_doc_upload"><input type="hidden" name="shop_key" value="'.esc_attr($shop_key).'"><input type="hidden" name="order_ref" value="'.esc_attr((string)$order_ref).'"><input type="file" name="freight_doc" accept="application/pdf" required> <button class="button">Lägg till fraktpapper PDF</button></form>';}
  echo '</section>';
 }
 static function tracking_center_order_meta($r){
  $shop=$r->shop_key==='local'?(get_bloginfo('name')?:'Huvudshop'):$r->shop_key;$num=(string)$r->order_ref;$url='';
  if($r->shop_key==='local'){$url=admin_url('admin.php?page=dennis-wms-orders&order_id='.(int)$r->order_ref);if(function_exists('wc_get_order')){$wo=wc_get_order((int)$r->order_ref);if($wo)$num=(string)$wo->get_order_number();}}
  elseif(preg_match('/^remote:(\d+)$/',$r->shop_key)){$url=admin_url('admin.php?page=dennis-wms-shops&view=order&remote_order_id='.(int)$r->order_ref);if(class_exists('Dennis_WMS_Multi_Shop')){$ro=Dennis_WMS_Multi_Shop::get_cached_order((int)$r->order_ref);if($ro){$num=(string)$ro->order_number;$shop=(string)$ro->shop_name;}}}
  return ['shop'=>$shop,'number'=>$num,'url'=>$url];
 }
 static function tracking_needs_attention($r){
  if(($r->tracking_status??'')==='exception')return true;
  if(($r->tracking_status??'')==='delivered')return false;
  $ts=!empty($r->tracking_updated_at)?strtotime((string)$r->tracking_updated_at):0;
  $hours=max(1,absint(self::settings()['attention_hours']??48));return $ts>0 && $ts < current_time('timestamp')-($hours*HOUR_IN_SECONDS);
 }
 static function tracking_center(){
  if(!current_user_can('pb_wms_view'))wp_die('Åtkomst nekad.',403);self::install();global $wpdb;
  self::purge_missing_local_records();
  $filter=sanitize_key(wp_unslash($_GET['tracking_filter']??'all'));$allowed=['all','ship','pickup','internal','active','delivered','attention','dhl','dsv'];if(!in_array($filter,$allowed,true))$filter='all';
  $q=sanitize_text_field(wp_unslash($_GET['s']??''));$rows=$wpdb->get_results("SELECT * FROM ".self::table()." WHERE method<>'' ORDER BY updated_at DESC LIMIT 500");
  $counts=['all'=>count($rows),'ship'=>0,'pickup'=>0,'internal'=>0,'active'=>0,'delivered'=>0,'attention'=>0,'dhl'=>0,'dsv'=>0];
  foreach($rows as $r){if(isset($counts[$r->method]))$counts[$r->method]++;if($r->method==='ship'){ $st=(string)($r->tracking_status??'');if($st==='delivered'||$r->status==='dispatched')$counts['delivered']++;else$counts['active']++;if($r->tracking!==''&&self::tracking_needs_attention($r))$counts['attention']++;if(isset($counts[$r->carrier]))$counts[$r->carrier]++;}}
  $shown=[];foreach($rows as $r){$st=(string)($r->tracking_status??'');$is_ship=$r->method==='ship';$ok=$filter==='all'||($filter==='ship'&&$is_ship)||($filter==='pickup'&&$r->method==='pickup')||($filter==='internal'&&$r->method==='internal')||($filter==='active'&&$is_ship&&$st!=='delivered'&&$r->status!=='dispatched')||($filter==='delivered'&&$is_ship&&($st==='delivered'||$r->status==='dispatched'))||($filter==='attention'&&$is_ship&&$r->tracking!==''&&self::tracking_needs_attention($r))||($filter==='dhl'&&$is_ship&&$r->carrier==='dhl')||($filter==='dsv'&&$is_ship&&$r->carrier==='dsv');if(!$ok)continue;$m=self::tracking_center_order_meta($r);if($q!==''&&!str_contains(strtolower($m['shop'].' '.$m['number'].' '.$r->tracking.' '.$r->carrier.' '.self::label_method($r->method).' '.self::label_status($r->status)),strtolower($q)))continue;$shown[]=[$r,$m];}
  echo '<div class="wrap dw-tracking-center"><h1>Leveranscenter & Tracking <span style="font-size:12px;background:#1D949C;color:#fff;border-radius:999px;padding:4px 8px;vertical-align:middle">BETA</span></h1><p>Samlad status för frakt, kundhämtning och interna order. Transportörstracking visas för DHL/DSV när trackingnummer finns.</p>';
  if(isset($_GET['dw_tracking_all']))echo '<div class="notice notice-success inline"><p>Tracking uppdaterad: '.absint($_GET['ok']??0).' OK, '.absint($_GET['fail']??0).' fel.</p></div>';
  if(!empty($_GET['dw_tracking_error']))echo '<div class="notice notice-error inline"><p>'.esc_html(rawurldecode(sanitize_text_field(wp_unslash($_GET['dw_tracking_error'])))).'</p></div>';
  $tabs=['all'=>'Alla','ship'=>'Frakt','pickup'=>'Kundhämtning','internal'=>'Interna','active'=>'På väg / aktiva','delivered'=>'Skickade / levererade','attention'=>'Problem','dhl'=>'DHL','dsv'=>'DSV'];echo '<div class="dw-track-tabs">';foreach($tabs as $k=>$label){$u=add_query_arg(['page'=>'dennis-wms-tracking','tracking_filter'=>$k],admin_url('admin.php'));echo '<a class="'.($filter===$k?'active':'').'" href="'.esc_url($u).'">'.esc_html($label).' <strong>'.absint($counts[$k]).'</strong></a>';}echo '</div>';
  echo '<div class="dw-track-toolbar"><form method="get"><input type="hidden" name="page" value="dennis-wms-tracking"><input type="hidden" name="tracking_filter" value="'.esc_attr($filter).'"><input type="search" name="s" value="'.esc_attr($q).'" placeholder="Sök order, shop, status eller trackingnummer"><button class="button">Sök</button></form><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_tracking_refresh_all');echo '<input type="hidden" name="action" value="dennis_wms_tracking_refresh_all"><button class="button button-primary">↻ Uppdatera aktiv tracking</button></form></div>';
  $lr=(array)get_option('dennis_wms_tracking_last_run',[]);if($lr)echo '<p class="description">Senaste automatiska trackingkontroll: '.esc_html($lr['time']??'–').' · OK '.absint($lr['ok']??0).' · Fel '.absint($lr['fail']??0).'</p>';
  echo '<div class="dw-track-cards"><div><span>Frakt</span><strong>'.absint($counts['ship']).'</strong></div><div><span>Kundhämtning</span><strong>'.absint($counts['pickup']).'</strong></div><div><span>Interna</span><strong>'.absint($counts['internal']).'</strong></div><div><span>Behöver kollas</span><strong>'.absint($counts['attention']).'</strong></div></div>';
  echo '<table class="widefat striped dw-track-table"><thead><tr><th>Shop / order</th><th>Leveranssätt</th><th>Leveransstatus</th><th>Transportör / tracking</th><th>Trackingstatus</th><th>Uppdaterad</th><th></th></tr></thead><tbody>';
  foreach($shown as [$r,$m]){$is_ship=$r->method==='ship';$hist=$is_ship?self::tracking_history($r):[];$last=$hist[0]??[];$attention=$is_ship&&$r->tracking!==''&&self::tracking_needs_attention($r);$tracking_status=$is_ship&&$r->tracking!==''?self::tracking_label((string)($r->tracking_status??'')):'–';$icon=$r->method==='ship'?'🚚':($r->method==='pickup'?'🏢':'📦');echo '<tr'.($attention?' class="dw-track-attention"':'').'><td data-label="Shop / order"><strong>'.esc_html($m['shop']).'</strong><br>'.($m['url']?'<a href="'.esc_url($m['url']).'">Order #'.esc_html($m['number']).'</a>':'Order #'.esc_html($m['number'])).'</td><td data-label="Leveranssätt">'.$icon.' <strong>'.esc_html(self::label_method($r->method)).'</strong></td><td data-label="Leveransstatus"><span class="dw-delivery-status-badge">'.esc_html(self::label_status($r->status)).'</span></td><td data-label="Transportör / tracking">'.($is_ship?'<span class="dw-carrier-badge">'.esc_html(strtoupper($r->carrier?:'Ej vald')).'</span>'.($r->tracking!==''?'<br><code>'.esc_html($r->tracking).'</code>':'<br><small>Inget trackingnummer</small>'):'–').'</td><td data-label="Trackingstatus"><strong>'.esc_html($tracking_status).'</strong>'.($attention?'<br><span class="dw-track-warning">⚠ Behöver kontrolleras</span>':'').(!empty($last['note'])?'<br><small>'.esc_html($last['note']).'</small>':'').'</td><td data-label="Uppdaterad">'.esc_html($is_ship&&$r->tracking_updated_at?$r->tracking_updated_at:$r->updated_at).'</td><td data-label="Åtgärder"><div class="dw-track-actions">';
   if($is_ship&&$r->tracking!==''){$refresh=wp_nonce_url(add_query_arg(['action'=>'dennis_wms_tracking_refresh','shop_key'=>$r->shop_key,'order_ref'=>(int)$r->order_ref,'return_to'=>'center'],admin_url('admin-post.php')),'dennis_wms_tracking_refresh_'.$r->shop_key.'_'.(int)$r->order_ref);echo '<a class="button" href="'.esc_url($refresh).'">↻ Tracking</a>';}if($m['url'])echo '<a class="button" href="'.esc_url($m['url']).'">Öppna order</a>';echo '</div></td></tr>';}
  if(!$shown)echo '<tr><td colspan="7">Inga order matchar filtret.</td></tr>';echo '</tbody></table><p class="description"><strong>Samma leveransstatus används i ordern, Orders in Progress och Leveranscenter.</strong> Trackingstatus är separat och gäller endast fraktorder med trackingnummer.</p></div>';
 }
 static function completion_fields($existing,$method,$status){
  if($method===''||$status!==self::final_status($method))return ['completed_at'=>null,'completion_estimated'=>0];
  if($existing&&$existing->method===$method&&$existing->status===$status&&!empty($existing->completed_at))return ['completed_at'=>$existing->completed_at,'completion_estimated'=>(int)($existing->completion_estimated??0)];
  return ['completed_at'=>current_time('mysql'),'completion_estimated'=>0];
 }
 static function delivery_summary($shop_key,$days){
  global $wpdb;$t=self::table();if(!$wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$t` LIKE %s",'completed_at')))return self::summarize_deliveries([]);$after=(new DateTimeImmutable('now',wp_timezone()))->modify('-'.absint($days).' days')->format('Y-m-d H:i:s');
  $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE shop_key=%s AND completed_at >= %s AND ((method='ship' AND status='dispatched') OR (method='pickup' AND status='picked_up') OR (method='internal' AND status='internal_done')) ORDER BY completed_at DESC,id DESC",$shop_key,$after));
  return self::summarize_deliveries($rows);
 }
 static function summarize_deliveries($rows){
  $out=['ship'=>0,'pickup'=>0,'internal'=>0,'carriers'=>[],'estimated'=>0,'rows'=>[]];
  foreach((array)$rows as $r){if(!isset($out[$r->method])||$r->status!==self::final_status($r->method))continue;
   if($r->shop_key==='local'&&function_exists('wc_get_order')&&!self::local_order_exists($r->order_ref))continue;
   if(preg_match('/^remote:(\d+)$/',$r->shop_key)&&class_exists('Dennis_WMS_Multi_Shop')&&!Dennis_WMS_Multi_Shop::get_cached_order((int)$r->order_ref))continue;
   $out[$r->method]++;$out['rows'][]=$r;$out['estimated']+=(int)!empty($r->completion_estimated);
   if($r->method==='ship'){$name=$r->carrier!==''?strtoupper($r->carrier):'Ej angiven';$out['carriers'][$name]=($out['carriers'][$name]??0)+1;}
  }arsort($out['carriers']);return $out;
 }
 static function stats($shop_key,$days){$s=self::delivery_summary($shop_key,$days);return ['ship'=>$s['ship'],'pickup'=>$s['pickup'],'internal'=>$s['internal']];}
 static function render_delivery_summary($s){
  echo '<h2>Levererade / utlämnade order</h2><p>Avslutade WMS-leveranser under vald period, räknat på datumet när leveransen markerades klar. Skickad = överlämnad till transport, kundhämtad = hämtad av kunden.</p><table class="widefat striped"><thead><tr><th>Leveranssätt / transportör</th><th>Antal order</th></tr></thead><tbody>';
  foreach(['Skickade'=>$s['ship'],'Hämtade av kund'=>$s['pickup'],'Utlämnade internt'=>$s['internal']] as $label=>$count)echo '<tr><td>'.esc_html($label).'</td><td>'.esc_html($count).'</td></tr>';
  foreach($s['carriers'] as $name=>$count)echo '<tr><td>Skickade med '.esc_html($name).'</td><td>'.esc_html($count).'</td></tr>';echo '</tbody></table>';
  if($s['estimated'])echo '<p><small>'.esc_html($s['estimated']).' äldre order använder senaste sparade leveransdatum som uppskattning.</small></p>';
 }
 static function queue(){global $wpdb;$rows=$wpdb->get_results("SELECT * FROM ".self::table()." WHERE method<>'' ORDER BY updated_at DESC LIMIT 100");echo '<h2 style="margin-top:28px">Leveranskö</h2><p>Här samlas de order där leveransmodulen används. Kundhämtning och interna order kan hanteras utan DHL/DSV.</p><table class="widefat striped dw-delivery-queue"><thead><tr><th>Shop</th><th>Order</th><th>Leveranssätt</th><th>Status</th><th>Transportör</th><th>Tracking</th><th>Projekt</th><th>Uppdaterad</th><th></th></tr></thead><tbody>';foreach($rows as $r){$shop=$r->shop_key==='local'?(get_bloginfo('name')?:'Huvudshop'):$r->shop_key;$num=(string)$r->order_ref;$url='';if($r->shop_key==='local'){$url=admin_url('admin.php?page=dennis-wms-orders&order_id='.(int)$r->order_ref);if(function_exists('wc_get_order')){$wo=wc_get_order((int)$r->order_ref);if($wo)$num=(string)$wo->get_order_number();}}elseif(preg_match('/^remote:(\d+)$/',$r->shop_key)){$url=admin_url('admin.php?page=dennis-wms-shops&view=order&remote_order_id='.(int)$r->order_ref);if(class_exists('Dennis_WMS_Multi_Shop')){$ro=Dennis_WMS_Multi_Shop::get_cached_order((int)$r->order_ref);if($ro){$num=(string)$ro->order_number;$shop=(string)$ro->shop_name;}}}echo '<tr><td data-label="Shop">'.esc_html($shop).'</td><td data-label="Order">#'.esc_html($num).'</td><td data-label="Leveranssätt">'.esc_html(self::label_method($r->method)).'</td><td data-label="Status">'.esc_html(self::label_status($r->status)).'</td><td data-label="Transportör">'.esc_html(strtoupper($r->carrier?:'–')).'</td><td data-label="Tracking">'.($r->tracking?esc_html($r->tracking).' · '.esc_html(self::tracking_label($r->tracking_status??'')):'–').'</td><td data-label="Projekt">'.esc_html($r->project?:'–').'</td><td data-label="Uppdaterad">'.esc_html($r->updated_at).'</td><td data-label="Åtgärd">'.($url?'<a class="button" href="'.esc_url($url).'">Öppna</a>':'').'</td></tr>';}if(!$rows)echo '<tr><td colspan="9">Ingen order använder leveransmodulen ännu.</td></tr>';echo '</tbody></table>';}
 static function page(){if(!current_user_can('pb_wms_view'))wp_die('Åtkomst nekad.',403);self::install();$s=self::settings();echo '<div class="wrap dw-delivery-page"><h1>Leverans & transport <span style="font-size:12px;background:#1D949C;color:#fff;border-radius:999px;padding:4px 8px;vertical-align:middle">BETA</span></h1><p>Modulen är helt valfri. Om den stängs av fortsätter plock, pack, batcher och övriga WMS-funktioner som tidigare.</p>';
  if(!current_user_can(self::CAP)||!current_user_can('manage_options')){echo '<p>Du behöver administratörsbehörighet för inställningarna.</p></div>';return;} if(isset($_GET['dsv_test'])){$ok=sanitize_key($_GET['dsv_test'])==='ok';$msg=sanitize_text_field(wp_unslash($_GET['dsv_msg']??''));echo '<div class="notice '.($ok?'notice-success':'notice-error').' inline"><p><strong>DSV API-test:</strong> '.esc_html($msg).'</p></div>';}
  echo '<div class="dw-ms-grid"><section class="dw-ms-card"><h2>Modul</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_delivery_settings');echo '<input type="hidden" name="action" value="dennis_wms_delivery_settings"><p><label><input type="checkbox" name="enabled" value="1" '.checked(!empty($s['enabled']),true,false).'> Aktivera Leverans & transport på order</label></p><p><label><input type="checkbox" name="wc_complete" value="1" '.checked(!empty($s['wc_complete']),true,false).'> Sätt lokal WooCommerce-order till Completed när leveransflödet avslutas</label></p><p class="description"><strong>Av som standard:</strong> Dennis WMS ändrar annars inte WooCommerce-status.</p><p><label><input type="checkbox" name="auto_tracking" value="1" '.checked(!empty($s['auto_tracking']),true,false).'> Hämta trackingstatus automatiskt</label></p><div class="dw-tracking-settings-grid"><label><strong>Kontrollintervall</strong><select name="tracking_interval">';foreach([1=>'1 timme',2=>'2 timmar',3=>'3 timmar',6=>'6 timmar',12=>'12 timmar',24=>'24 timmar'] as $v=>$lab)echo '<option value="'.esc_attr($v).'" '.selected((int)($s['tracking_interval']??1),$v,false).'>'.esc_html($lab).'</option>';echo '</select></label><label><strong>Markera utan uppdatering efter</strong><select name="attention_hours">';foreach([12,24,48,72,96] as $v)echo '<option value="'.esc_attr($v).'" '.selected((int)($s['attention_hours']??48),$v,false).'>'.esc_html($v.' timmar').'</option>';echo '</select></label></div><p class="description">Levererade försändelser kontrolleras inte igen automatiskt.</p><p><label><strong>API-miljö</strong><br><select name="carrier_mode"><option value="test" '.selected($s['carrier_mode'],'test',false).'>Test / Demo</option><option value="production" '.selected($s['carrier_mode'],'production',false).'>Produktion</option></select></label></p>';
  echo '<hr><h3>DHL Tracking</h3><p><label><input type="checkbox" name="dhl_enabled" value="1" '.checked(!empty($s['dhl_enabled']),true,false).'> Aktivera DHL-tracking</label></p><p><label>DHL-API-Key (Shipment Tracking – Unified)<br><input class="regular-text" type="password" autocomplete="new-password" name="dhl_key" placeholder="'.(!empty($s['dhl_key'])?'Sparad – lämna tomt för att behålla':'Klistra in DHL API key').'"></label></p><p class="description">DHL Unified Tracking använder API-nyckeln direkt.</p>';
  echo '<hr><h3>DSV Connect Tracking</h3><p><label><input type="checkbox" name="dsv_enabled" value="1" '.checked(!empty($s['dsv_enabled']),true,false).'> Aktivera DSV-tracking</label></p>';
  foreach(['dsv_tracking_key'=>'Tracking – Primary Key','dsv_tracking_secondary_key'=>'Tracking – Secondary Key (reserv)','dsv_connect_access_key'=>'Tracking – AccessKey (om DSV kräver det)'] as $field=>$label)echo '<p><label>'.esc_html($label).'<br><input class="regular-text" type="password" autocomplete="new-password" name="'.esc_attr($field).'" placeholder="'.(!empty($s[$field])?'Sparad – lämna tomt för att behålla':'Ange trackinguppgift från DSV').'"></label></p>';
  echo '<p><button class="button button-primary">Spara inställningar</button></p></form></section><section class="dw-ms-card"><h2>Manuell bokning – automatisk tracking</h2><p>Boka transporten hos DHL eller DSV. Lägg sedan in transportör och tracking-/sändningsnummer på ordern i WMS. Fraktpapper kan laddas upp som PDF.</p><h3>Testa DSV Tracking</h3><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_dsv_api_test');echo '<input type="hidden" name="action" value="dennis_wms_dsv_api_test"><p><label>Befintligt tracking-/sändningsnummer<br><input name="tracking_reference" required></label></p><button class="button">Hämta DSV-tracking</button></form><p class="description">Testet hämtar endast trackinginformation. Miljön följer Test / Demo eller Produktion ovan. DHL-tracking kan hämtas från orderns trackingruta.</p></section></div>';
  $lr=(array)get_option('dennis_wms_tracking_last_run',[]);if($lr)echo '<p><strong>Senaste automatiska trackingkörning:</strong> '.esc_html($lr['time']??'–').' · OK '.absint($lr['ok']??0).' · Fel '.absint($lr['fail']??0).'</p>';echo '<h2 id="dw-senders">Avsändaradresser</h2><p>Skapa minst en avsändare. Den första blir automatiskt standard på nya leveranser.</p><div class="dw-ms-grid"><section class="dw-ms-card"><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_sender_save');echo '<input type="hidden" name="action" value="dennis_wms_sender_save"><p><label><strong>Namn</strong><br><input name="name" required placeholder="Huvudlager"></label></p><p><label>Företag<br><input name="company"></label></p><p><label><strong>Adress</strong><br><input name="address" required></label></p><p><label>Postnummer<br><input name="postcode"></label></p><p><label><strong>Ort</strong><br><input name="city" required></label></p><p><label>Landkod<br><input name="country" value="SE" maxlength="2"></label></p><p><label>Kontaktperson<br><input name="contact"></label></p><p><label>Telefon<br><input name="phone"></label></p><p><label>E-post<br><input type="email" name="email"></label></p><p><label><input type="checkbox" name="make_default" value="1"> Sätt som standardavsändare</label></p><button class="button button-primary">Lägg till avsändare</button></form></section><section class="dw-ms-card"><h3>Sparade avsändare</h3>';
  $senders=self::senders();if(!$senders)echo '<p>Ingen avsändare sparad ännu.</p>';foreach($senders as $r){echo '<div style="border-bottom:1px solid #ddd;padding:10px 0"><strong>'.esc_html($r['name']).'</strong><br>'.esc_html(trim(($r['company']??'').' · '.($r['address']??'').' · '.($r['postcode']??'').' '.($r['city']??''),' ·')).'<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:6px">';wp_nonce_field('dennis_wms_sender_delete_'.$r['id']);echo '<input type="hidden" name="action" value="dennis_wms_sender_delete"><input type="hidden" name="sender_id" value="'.esc_attr($r['id']).'"><button class="button" onclick="return confirm(\'Ta bort avsändaren?\')">Ta bort</button></form></div>';}
  echo '</section></div>';self::queue();echo '</div>';}
}
Dennis_WMS_Delivery::boot();
