<?php
if (!defined('ABSPATH')) exit;

/**
 * Read-only diagnostics for WooCommerce orders.
 * This class never changes an order. It records snapshots so disappearing
 * orders can be distinguished from list/filter/cache problems.
 */
final class Dennis_WMS_Order_Debug {
 const OPTION = 'dennis_wms_order_debug_log_v157';
 const CAP = 'manage_woocommerce';

 static function boot() {
  add_action('admin_menu', [__CLASS__, 'menu'], 110);
  add_action('before_delete_post', [__CLASS__, 'before_delete_post'], 1, 2);
  add_action('wp_trash_post', [__CLASS__, 'trash_post'], 1, 1);
  add_action('untrashed_post', [__CLASS__, 'untrash_post'], 1, 1);
  add_action('woocommerce_before_delete_order', [__CLASS__, 'before_delete_order'], 1, 1);
  add_action('woocommerce_delete_order', [__CLASS__, 'after_delete_order'], 999, 1);
  add_action('admin_post_dennis_wms_debug_clear', [__CLASS__, 'clear']);
 }
 static function menu() {
  add_submenu_page('pb-wms','Order Debug','Order Debug',self::CAP,'dennis-wms-order-debug',[__CLASS__,'page']);
 }
 static function request_context() {
  return [
   'method'=>isset($_SERVER['REQUEST_METHOD'])?sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'])):'',
   'uri'=>isset($_SERVER['REQUEST_URI'])?sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])):'',
   'user'=>get_current_user_id(),
  ];
 }
 static function stack() {
  $trace=debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS,12);$out=[];
  foreach($trace as $row){$fn=(isset($row['class'])?$row['class'].'::':'').($row['function']??'');if($fn && strpos($fn,__CLASS__)===false)$out[]=$fn;}
  return implode(' > ',array_slice($out,0,8));
 }
 static function snapshot($order_id) {
  global $wpdb;$id=absint($order_id);
  $post=$wpdb->get_row($wpdb->prepare("SELECT ID,post_type,post_status FROM {$wpdb->posts} WHERE ID=%d",$id),ARRAY_A);
  $hpos_table=$wpdb->prefix.'wc_orders';$hpos=null;
  if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$hpos_table))===$hpos_table){
   $hpos=$wpdb->get_row($wpdb->prepare("SELECT id,type,status FROM {$hpos_table} WHERE id=%d",$id),ARRAY_A);
  }
  $wc=null;
  if(function_exists('wc_get_order')){$o=wc_get_order($id);if($o && is_a($o,'WC_Order'))$wc=['id'=>$o->get_id(),'number'=>$o->get_order_number(),'status'=>$o->get_status(),'type'=>$o->get_type()];}
  return ['wc'=>$wc,'legacy_post'=>$post,'hpos'=>$hpos];
 }
 static function log($event,$order_id,$extra=[]) {
  $logs=get_option(self::OPTION,[]);if(!is_array($logs))$logs=[];
  $logs[]=['time'=>current_time('mysql'),'event'=>sanitize_text_field($event),'order_id'=>absint($order_id),'snapshot'=>self::snapshot($order_id),'request'=>self::request_context(),'extra'=>$extra];
  if(count($logs)>150)$logs=array_slice($logs,-150);
  update_option(self::OPTION,$logs,false);
 }
 static function open_begin($order_id) { self::log('OPEN_BEGIN',$order_id,['note'=>'WMS ordervy börjar laddas. Ingen order sparas.']); }
 static function open_after_render($order_id) { self::log('OPEN_AFTER_RENDER',$order_id,['note'=>'WMS ordervy färdigrenderad.']); }
 static function watch_shutdown($order_id) {
  $id=absint($order_id);
  register_shutdown_function(function()use($id){Dennis_WMS_Order_Debug::log('OPEN_SHUTDOWN',$id,['last_error'=>error_get_last()]);});
 }
 static function before_delete_post($post_id,$post=null) {
  if($post && in_array($post->post_type,['shop_order','shop_order_refund'],true))self::log('DELETE_POST_ATTEMPT',$post_id,['stack'=>self::stack()]);
 }
 static function trash_post($post_id) {
  $p=get_post($post_id);if($p && in_array($p->post_type,['shop_order','shop_order_refund'],true))self::log('TRASH_POST',$post_id,['stack'=>self::stack()]);
 }
 static function untrash_post($post_id) {
  $p=get_post($post_id);if($p && in_array($p->post_type,['shop_order','shop_order_refund'],true))self::log('UNTRASH_POST',$post_id,['stack'=>self::stack()]);
 }
 static function before_delete_order($order_id) {self::log('WC_DELETE_ATTEMPT',$order_id,['stack'=>self::stack()]);}
 static function after_delete_order($order_id) {self::log('WC_DELETE_DONE',$order_id,['stack'=>self::stack()]);}
 static function clear() {
  if(!current_user_can(self::CAP))wp_die('Åtkomst nekad.',403);check_admin_referer('dennis_wms_debug_clear');delete_option(self::OPTION);wp_safe_redirect(admin_url('admin.php?page=dennis-wms-order-debug'));exit;
 }
 static function page() {
  if(!current_user_can(self::CAP))wp_die('Åtkomst nekad.',403);
  $logs=get_option(self::OPTION,[]);if(!is_array($logs))$logs=[];
  echo '<div class="wrap"><h1>Dennis WMS – Order Debug</h1><p><strong>v1.5.8 felsökningsläge.</strong> Loggen är endast diagnostik och ändrar inte WooCommerce-order.</p>';
  echo '<p>När du öppnar en plocklista registreras tre kontroller: <code>OPEN_BEGIN</code>, <code>OPEN_AFTER_RENDER</code> och <code>OPEN_SHUTDOWN</code>. Om något försöker radera en order loggas även DELETE/TRASH-händelser.</p>';
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_debug_clear');echo '<input type="hidden" name="action" value="dennis_wms_debug_clear"><button class="button">Rensa logg</button></form>';
  echo '<table class="widefat striped" style="margin-top:12px"><thead><tr><th>Tid</th><th>Händelse</th><th>Order</th><th>WooCommerce</th><th>Legacy</th><th>HPOS</th><th>Request / extra</th></tr></thead><tbody>';
  foreach(array_reverse($logs) as $row){$s=$row['snapshot']??[];$wc=$s['wc']??null;$lp=$s['legacy_post']??null;$hp=$s['hpos']??null;$req=$row['request']??[];$extra=$row['extra']??[];
   echo '<tr><td>'.esc_html($row['time']??'').'</td><td><strong>'.esc_html($row['event']??'').'</strong></td><td>#'.esc_html((string)($row['order_id']??0)).'</td>';
   echo '<td>'.esc_html($wc?('finns · '.$wc['status']):'SAKNAS').'</td><td>'.esc_html($lp?($lp['post_type'].' · '.$lp['post_status']):'saknas').'</td><td>'.esc_html($hp?(($hp['type']??'').' · '.($hp['status']??'')):'saknas').'</td>';
   echo '<td><code>'.esc_html(($req['method']??'').' '.($req['uri']??'')).'</code>';if(!empty($extra['stack']))echo '<br><small>'.esc_html($extra['stack']).'</small>';if(array_key_exists('last_error',$extra)&&$extra['last_error'])echo '<br><small>PHP: '.esc_html(wp_json_encode($extra['last_error'])).'</small>';echo '</td></tr>';
  }
  if(!$logs)echo '<tr><td colspan="7">Ingen logg ännu. Öppna en testorder via Orders in Progress.</td></tr>';
  echo '</tbody></table></div>';
 }
}
