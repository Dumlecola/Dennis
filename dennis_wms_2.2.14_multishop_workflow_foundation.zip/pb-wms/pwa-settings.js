jQuery(function($){
 const preview=$('#dw-app-preview'), input=$('#dw-app-icon-id');
 const fallback=window.DennisWMSDefaultIcon||preview.attr('src');
 $('#dw-app-choose').on('click',function(){
  const frame=wp.media({title:'Välj appikon',button:{text:'Använd som appikon'},library:{type:'image/png'},multiple:false});
  frame.on('select',function(){const item=frame.state().get('selection').first().toJSON();input.val(item.id);preview.attr('src',item.url);});frame.open();
 });
 $('#dw-app-reset').on('click',function(){input.val('0');preview.attr('src',fallback);});
});
