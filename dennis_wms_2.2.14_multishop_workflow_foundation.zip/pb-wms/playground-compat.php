<?php
if(!defined('ABSPATH'))exit;
/** Narrow compatibility fix for the Woo HPOS month selector on SQLite. */
final class Dennis_WMS_Playground_Compat {
 static $previous=null;
 static function sqlite(){global $wpdb;return is_a($wpdb,'WP_SQLite_DB')||(defined('DB_ENGINE')&&DB_ENGINE==='sqlite');}
 static function boot(){add_filter('query',[__CLASS__,'query'],999);add_action('init',[__CLASS__,'diagnostics'],99);}
 static function query($sql){if(!self::sqlite())return $sql;global $wpdb;$table=$wpdb->prefix.'wc_orders';$expected="SELECT MIN(date_created_gmt) as min_date_gmt, MAX(date_created_gmt) as max_date_gmt FROM ((SELECT date_created_gmt FROM $table WHERE type = 'shop_order' AND status != 'trash' ORDER BY date_created_gmt DESC LIMIT 1) UNION ALL (SELECT date_created_gmt FROM $table WHERE type = 'shop_order' AND status != 'trash' ORDER BY date_created_gmt ASC LIMIT 1)) d";
  $normalize=static function($q){return strtolower(preg_replace('/\s+/', '',str_replace('`','',rtrim(trim($q),';'))));};
  if($normalize($sql)!==$normalize($expected))return $sql;
  return "SELECT MIN(date_created_gmt) AS min_date_gmt, MAX(date_created_gmt) AS max_date_gmt FROM `$table` WHERE type = 'shop_order' AND status != 'trash'";
 }
 static function diagnostics(){if(!self::sqlite())return;self::$previous=set_error_handler([__CLASS__,'warning']);}
 static function warning($level,$message,$file,$line){
  if(($level&E_WARNING)&&strpos($message,'array_flip()')!==false&&strpos(str_replace('\\','/',$file),'/woocommerce/src/Admin/API/Reports/DataStore.php')!==false){
   static $seen=[];$key=$file.':'.$line;if(!isset($seen[$key])){$seen[$key]=true;$trace=[];foreach(debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS,12) as $frame){$trace[]=($frame['class']??'').($frame['type']??'').($frame['function']??'').' @ '.basename($frame['file']??'').':'.($frame['line']??0);}error_log('Dennis WMS report diagnostic: '.implode(' <- ',$trace));}
  }
  if(is_callable(self::$previous))return call_user_func(self::$previous,$level,$message,$file,$line);return false;
 }
}
Dennis_WMS_Playground_Compat::boot();
