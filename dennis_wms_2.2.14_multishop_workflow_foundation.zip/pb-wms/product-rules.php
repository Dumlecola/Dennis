<?php
if (!defined('ABSPATH')) { exit; }

/** Product data-quality rules for WooCommerce attributes, optionally scoped by product category. */
final class Dennis_WMS_Product_Rules {
 const OPTION = 'dennis_wms_required_attributes';
 const CAP = 'pb_wms_manage';

 static function boot() {
  add_action('admin_menu', [__CLASS__, 'menu'], 110);
  add_action('admin_post_dennis_wms_rule_add', [__CLASS__, 'add_rule']);
  add_action('admin_post_dennis_wms_rule_delete', [__CLASS__, 'delete_rule']);
 }
 static function menu() {
  add_submenu_page('pb-wms','Produktkontroll','Produktkontroll','pb_wms_view','dennis-wms-product-rules',[__CLASS__,'page']);
 }
 static function rules() {
  $raw = get_option(self::OPTION, []);
  if (!is_array($raw)) return [];
  $out=[];
  foreach ($raw as $rule) {
   if (!is_array($rule) || empty($rule['key'])) continue;
   $key = sanitize_text_field((string)$rule['key']);
   $cats=[];
   if (!empty($rule['category_ids']) && is_array($rule['category_ids'])) {
    foreach ($rule['category_ids'] as $cat_id) { $cat_id=absint($cat_id); if ($cat_id) $cats[]=$cat_id; }
   }
   $cats=array_values(array_unique($cats)); sort($cats,SORT_NUMERIC);
   $out[] = [
    'id' => isset($rule['id']) ? sanitize_key((string)$rule['id']) : md5($key),
    'key' => $key,
    'label' => !empty($rule['label']) ? sanitize_text_field((string)$rule['label']) : self::label_for($key),
    'severity' => (isset($rule['severity']) && $rule['severity']==='block') ? 'block' : 'warning',
    // Empty means all product categories. This keeps all older rules backwards compatible.
    'category_ids' => $cats,
    'include_children' => array_key_exists('include_children',$rule) ? !empty($rule['include_children']) : true,
   ];
  }
  return $out;
 }
 static function global_attributes() {
  $out=[];
  if (!function_exists('wc_get_attribute_taxonomies')) return $out;
  foreach ((array)wc_get_attribute_taxonomies() as $a) {
   if (empty($a->attribute_name)) continue;
   $key = function_exists('wc_attribute_taxonomy_name') ? wc_attribute_taxonomy_name($a->attribute_name) : 'pa_'.sanitize_title($a->attribute_name);
   $out[$key] = !empty($a->attribute_label) ? $a->attribute_label : $a->attribute_name;
  }
  return $out;
 }
 static function product_categories() {
  if (!taxonomy_exists('product_cat')) return [];
  $terms=get_terms(['taxonomy'=>'product_cat','hide_empty'=>false,'orderby'=>'name','order'=>'ASC']);
  return is_wp_error($terms) ? [] : $terms;
 }
 static function category_label($id) {
  $term=get_term(absint($id),'product_cat');
  return ($term && !is_wp_error($term)) ? $term->name : '#'.absint($id);
 }
 static function rule_scope_label($rule) {
  if (empty($rule['category_ids'])) return 'Alla kategorier';
  $names=[]; foreach ($rule['category_ids'] as $id) $names[]=self::category_label($id);
  $text=implode(', ',$names);
  if (!empty($rule['include_children'])) $text.=' + underkategorier';
  return $text;
 }
 static function label_for($key) {
  $globals=self::global_attributes();
  if (isset($globals[$key])) return $globals[$key];
  return preg_replace('/^pa_/', '', str_replace(['-','_'],' ',(string)$key));
 }
 static function product_has($product, $key) {
  if (!is_a($product,'WC_Product')) return false;
  $key=(string)$key;
  $value=$product->get_attribute($key);
  if (is_string($value) && trim(wp_strip_all_tags($value))!=='') return true;
  foreach ((array)$product->get_attributes() as $attr) {
   if (is_a($attr,'WC_Product_Attribute')) {
    $name=(string)$attr->get_name();
    if ($name===$key || sanitize_title($name)===sanitize_title($key)) {
     $opts=$attr->get_options();
     if (!empty($opts)) return true;
    }
   } elseif (is_string($attr) && trim($attr)!=='') return true;
  }
  if ($product->is_type('variation') && $product->get_parent_id()) {
   $parent=wc_get_product($product->get_parent_id());
   if ($parent && $parent->get_id()!==$product->get_id()) return self::product_has_parent_only($parent,$key);
  }
  return false;
 }
 static function product_has_parent_only($product,$key) {
  $value=$product->get_attribute($key);
  if (is_string($value) && trim(wp_strip_all_tags($value))!=='') return true;
  foreach ((array)$product->get_attributes() as $attr) {
   if (!is_a($attr,'WC_Product_Attribute')) continue;
   $name=(string)$attr->get_name();
   if (($name===$key || sanitize_title($name)===sanitize_title($key)) && !empty($attr->get_options())) return true;
  }
  return false;
 }
 static function product_category_ids($product) {
  if (!is_a($product,'WC_Product')) return [];
  $id=$product->get_id();
  if ($product->is_type('variation') && $product->get_parent_id()) $id=$product->get_parent_id();
  $ids=wp_get_post_terms($id,'product_cat',['fields'=>'ids']);
  if (is_wp_error($ids)) return [];
  return array_values(array_unique(array_map('absint',(array)$ids)));
 }
 static function rule_applies($rule,$product) {
  $selected=isset($rule['category_ids']) && is_array($rule['category_ids']) ? array_map('absint',$rule['category_ids']) : [];
  if (!$selected) return true;
  $product_cats=self::product_category_ids($product);
  if (!$product_cats) return false;
  $allowed=$selected;
  if (!empty($rule['include_children'])) {
   foreach ($selected as $cat_id) {
    $children=get_term_children($cat_id,'product_cat');
    if (!is_wp_error($children)) foreach ($children as $child) $allowed[]=absint($child);
   }
  }
  $allowed=array_unique($allowed);
  return (bool)array_intersect($product_cats,$allowed);
 }
 static function applicable_rules($product) {
  $out=[]; foreach (self::rules() as $rule) if (self::rule_applies($rule,$product)) $out[]=$rule;
  return $out;
 }
 static function missing($product) {
  $missing=[];
  foreach (self::applicable_rules($product) as $rule) if (!self::product_has($product,$rule['key'])) $missing[]=$rule;
  return $missing;
 }
 static function badge_html($product) {
  $rules=self::applicable_rules($product);
  if (!$rules) return '<span class="dw-data-status dw-data-neutral">Ingen kontroll</span>';
  $missing=[]; foreach($rules as $rule) if(!self::product_has($product,$rule['key'])) $missing[]=$rule;
  if (!$missing) return '<span class="dw-data-status dw-data-ok">✓ Komplett</span>';
  $block=false; foreach($missing as $r) if($r['severity']==='block') {$block=true;break;}
  $labels=implode(', ',array_map(static function($r){return $r['label'];},$missing));
  return '<span class="dw-data-status '.($block?'dw-data-error':'dw-data-warning').'">'.($block?'! Fel':'⚠ Saknas').'</span><small class="dw-data-missing">'.esc_html($labels).'</small>';
 }
 static function redirect($status='saved') {
  wp_safe_redirect(add_query_arg(['page'=>'dennis-wms-product-rules','rule_status'=>$status],admin_url('admin.php'))); exit;
 }
 static function add_rule() {
  if (!current_user_can(self::CAP)) wp_die('Åtkomst nekad.',403);
  check_admin_referer('dennis_wms_rule_add');
  $global=isset($_POST['global_attribute']) ? sanitize_text_field(wp_unslash($_POST['global_attribute'])) : '';
  $custom=isset($_POST['custom_attribute']) ? sanitize_text_field(wp_unslash($_POST['custom_attribute'])) : '';
  $key=trim($global!==''?$global:$custom);
  if ($key==='' || mb_strlen($key)>120) wp_die('Välj eller skriv ett giltigt attribut.',400);
  $severity=(isset($_POST['severity']) && wp_unslash($_POST['severity'])==='block')?'block':'warning';
  $category_ids=[];
  if (isset($_POST['category_ids']) && is_array($_POST['category_ids'])) {
   foreach (wp_unslash($_POST['category_ids']) as $cat_id) { $cat_id=absint($cat_id); if($cat_id && term_exists($cat_id,'product_cat')) $category_ids[]=$cat_id; }
  }
  $category_ids=array_values(array_unique($category_ids)); sort($category_ids,SORT_NUMERIC);
  $include_children=!empty($_POST['include_children']);
  $rules=self::rules();
  foreach($rules as $r) {
   $existing=$r['category_ids']; sort($existing,SORT_NUMERIC);
   if(sanitize_title($r['key'])===sanitize_title($key) && $existing===$category_ids && (bool)$r['include_children']===(bool)$include_children) self::redirect('exists');
  }
  $rules[]=['id'=>wp_generate_password(10,false,false),'key'=>$key,'label'=>self::label_for($key),'severity'=>$severity,'category_ids'=>$category_ids,'include_children'=>$include_children];
  update_option(self::OPTION,$rules,false);
  self::redirect('saved');
 }
 static function delete_rule() {
  if (!current_user_can(self::CAP)) wp_die('Åtkomst nekad.',403);
  $id=isset($_POST['rule_id'])?sanitize_key(wp_unslash($_POST['rule_id'])):'';
  check_admin_referer('dennis_wms_rule_delete_'.$id);
  $rules=array_values(array_filter(self::rules(),static function($r)use($id){return $r['id']!==$id;}));
  update_option(self::OPTION,$rules,false);
  self::redirect('deleted');
 }
 static function page() {
  if (!current_user_can('pb_wms_view')) wp_die('Åtkomst nekad.',403);
  echo '<div class="wrap dw-rules"><div class="dw-page-heading"><div><h1>Produktkontroll</h1><p>Styr vilka WooCommerce-attribut som krävs – globalt eller per produktkategori.</p></div></div>';
  if (!function_exists('wc_get_products')) {echo '<div class="notice notice-error"><p>WooCommerce måste vara aktivt.</p></div></div>';return;}
  $status=isset($_GET['rule_status'])?sanitize_key(wp_unslash($_GET['rule_status'])):'';
  if($status==='saved') echo '<div class="notice notice-success is-dismissible"><p>Regeln har lagts till.</p></div>';
  if($status==='deleted') echo '<div class="notice notice-success is-dismissible"><p>Regeln har tagits bort.</p></div>';
  if($status==='exists') echo '<div class="notice notice-warning is-dismissible"><p>Samma attributregel finns redan för den valda kategorin/kategorierna.</p></div>';

  $rules=self::rules();
  echo '<section class="dw-order-section"><div class="dw-section-head"><div><span class="dashicons dashicons-yes-alt"></span><div><h2>Attributregler</h2><p>Regler utan vald kategori gäller alla produkter. Kategoriregler kontrolleras bara på produkter i de valda kategorierna.</p></div></div></div>';
  if($rules){echo '<table class="widefat striped"><thead><tr><th>Attribut</th><th>Gäller för</th><th>Nivå</th><th></th></tr></thead><tbody>';
   foreach($rules as $r){echo '<tr><td><strong>'.esc_html($r['label']).'</strong><br><code>'.esc_html($r['key']).'</code></td><td><strong>'.esc_html(self::rule_scope_label($r)).'</strong></td><td><span class="dw-data-status '.($r['severity']==='block'?'dw-data-error':'dw-data-warning').'">'.esc_html($r['severity']==='block'?'Kritiskt fel':'Varning').'</span></td><td>';
    if(current_user_can(self::CAP)){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_rule_delete_'.$r['id']);echo '<input type="hidden" name="action" value="dennis_wms_rule_delete"><input type="hidden" name="rule_id" value="'.esc_attr($r['id']).'"><button class="button" onclick="return confirm(\'Ta bort denna kontrollregel?\')">Ta bort</button></form>';}
    echo '</td></tr>';}
   echo '</tbody></table>';} else echo '<div class="dw-empty"><span class="dashicons dashicons-yes"></span><p>Inga attributregler är skapade ännu.</p></div>';
  if(current_user_can(self::CAP)){
   $globals=self::global_attributes(); $categories=self::product_categories();
   echo '<hr><h3>Lägg till kontrollregel</h3><form class="dw-rule-form dw-rule-form-categories" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('dennis_wms_rule_add');
   echo '<input type="hidden" name="action" value="dennis_wms_rule_add"><label><strong>Globalt WooCommerce-attribut</strong><select name="global_attribute"><option value="">– välj –</option>';
   foreach($globals as $key=>$label) echo '<option value="'.esc_attr($key).'">'.esc_html($label).' ('.esc_html($key).')</option>';
   echo '</select></label><span class="dw-rule-or">eller</span><label><strong>Eget attributnamn</strong><input type="text" name="custom_attribute" maxlength="120" placeholder="t.ex. Material"></label><label><strong>Nivå</strong><select name="severity"><option value="warning">Varning</option><option value="block">Kritiskt fel</option></select></label>';
   echo '<label class="dw-rule-category"><strong>Gäller produktkategori</strong><select name="category_ids[]" multiple size="7">';
   foreach($categories as $term) echo '<option value="'.esc_attr((string)$term->term_id).'">'.esc_html($term->name).'</option>';
   echo '</select><small>Ingen vald = alla kategorier. Ctrl/Cmd-klick för flera kategorier.</small></label>';
   echo '<label class="dw-rule-check"><input type="checkbox" name="include_children" value="1" checked> <strong>Gäller även underkategorier</strong></label><button class="button button-primary">Lägg till regel</button></form>';
   echo '<p class="description">Exempel: välj attributet Storlek och kategorin Kläder. Då kontrolleras Storlek bara på produkter i Kläder (och underkategorier om valet ovan är markerat). Samma attribut kan ha separata regler för olika kategorier.</p>';
  }
  echo '</section>';

  $filter=isset($_GET['data_filter'])?sanitize_key(wp_unslash($_GET['data_filter'])):'all';
  $search=isset($_GET['product_search'])?sanitize_text_field(wp_unslash($_GET['product_search'])):'';
  $page=isset($_GET['product_page'])?max(1,absint($_GET['product_page'])):1;
  echo '<section class="dw-order-section"><div class="dw-section-head"><div><span class="dashicons dashicons-products"></span><div><h2>Produktstatus</h2><p>Varje produkt kontrolleras bara mot de regler som gäller produktens kategori.</p></div></div></div>';
  echo '<form class="dw-product-filter" method="get"><input type="hidden" name="page" value="dennis-wms-product-rules"><input type="search" name="product_search" value="'.esc_attr($search).'" placeholder="Sök produkt eller SKU"><select name="data_filter"><option value="all"'.selected($filter,'all',false).'>Alla</option><option value="missing"'.selected($filter,'missing',false).'>Endast med fel/varning</option><option value="complete"'.selected($filter,'complete',false).'>Endast kompletta</option></select><button class="button">Filtrera</button></form>';
  $args=['limit'=>50,'page'=>$page,'paginate'=>true,'orderby'=>'title','order'=>'ASC','status'=>['publish','private'],'type'=>['simple','variation']]; if($search!=='')$args['search']=$search;
  $result=wc_get_products($args); $shown=0;
  echo '<table class="widefat striped dw-product-check"><thead><tr><th>Produkt</th><th>SKU</th><th>Regler som gäller</th><th>Datastatus</th><th>Saknas</th><th>Åtgärd</th></tr></thead><tbody>';
  foreach($result->products as $p){$applicable=self::applicable_rules($p);$missing=self::missing($p);$is_complete=empty($missing);$has_rules=!empty($applicable);if($filter==='missing'&&$is_complete)continue;if($filter==='complete'&&!$is_complete)continue;$shown++;
   $labels=$is_complete?'–':implode(', ',array_map(static function($r){return $r['label'];},$missing));$block=false;foreach($missing as $r)if($r['severity']==='block'){$block=true;break;}
   $rule_labels=$has_rules?implode(', ',array_map(static function($r){return $r['label'];},$applicable)):'Ingen för denna kategori';
   $edit=get_edit_post_link($p->get_id(),'raw');
   echo '<tr class="'.(!$has_rules?'':($is_complete?'dw-row-ok':($block?'dw-row-error':'dw-row-warning'))).'"><td><strong>'.esc_html($p->get_name()).'</strong> <small>#'.esc_html((string)$p->get_id()).'</small></td><td>'.esc_html($p->get_sku()?:'–').'</td><td>'.esc_html($rule_labels).'</td><td>'.(!$has_rules?'<span class="dw-data-status dw-data-neutral">Ingen kontroll</span>':($is_complete?'<span class="dw-data-status dw-data-ok">✓ Komplett</span>':'<span class="dw-data-status '.($block?'dw-data-error':'dw-data-warning').'">'.($block?'! Kritiskt fel':'⚠ Varning').'</span>')).'</td><td>'.esc_html($labels).'</td><td>'.($edit?'<a class="button" href="'.esc_url($edit).'">Öppna produkt</a>':'–').'</td></tr>';
  }
  if(!$shown)echo '<tr><td colspan="6">Inga produkter matchar filtret på denna sida.</td></tr>';
  echo '</tbody></table>';
  if((int)$result->max_num_pages>1){echo '<p class="tablenav">Sida '.esc_html((string)$page).' av '.esc_html((string)$result->max_num_pages).' &nbsp;';if($page>1)echo '<a class="button" href="'.esc_url(add_query_arg(['page'=>'dennis-wms-product-rules','product_page'=>$page-1,'product_search'=>$search,'data_filter'=>$filter],admin_url('admin.php'))).'">Föregående</a> ';if($page<(int)$result->max_num_pages)echo '<a class="button" href="'.esc_url(add_query_arg(['page'=>'dennis-wms-product-rules','product_page'=>$page+1,'product_search'=>$search,'data_filter'=>$filter],admin_url('admin.php'))).'">Nästa</a>';echo '</p>';}
  echo '<p class="description">Filtret gäller den aktuella produktsidan. För stora produktkataloger bläddrar du vidare med sidknapparna.</p></section></div>';
 }
}
Dennis_WMS_Product_Rules::boot();
